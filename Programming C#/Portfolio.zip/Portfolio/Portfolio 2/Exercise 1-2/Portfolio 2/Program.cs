﻿using System;

namespace Portfolio_2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variables //
            int num = 0;

            // User enters integer to check //
            Console.WriteLine("Enter an integer to check if ODD or EVEN and PRIME or NOT PRIME");
            num = int.Parse(Console.ReadLine());

            // if the number modulus 2 leaves no remainder then the number must be even //
            if (num % 2 == 0)
            {
                Console.WriteLine(num + " is an EVEN number");
            }
            // if the number modulus 2 leaves a remainder then the number is odd //
            else
            {
                Console.WriteLine(num + " is an ODD number");
            }
            int modulus, breaker = 0;
            modulus = num / 2;

            // For loop checks if the number is prime or not//
            for (int i = 2; i <= modulus; i++)
            {
                if (num % i == 0)
                {
                    // When the programme finds that the number can de divided by a number other than itself or 1 and leaves no remainder, it increments the breaker which forces the programme out of the look and determines that the number is NOT PRIME//
                    Console.WriteLine(num + " is NOT PRIME");
                    breaker = 1;
                    break;
                }
            }
            if (breaker == 0)
            {
                Console.WriteLine(num + " is PRIME");
            }
        }
    }
}
