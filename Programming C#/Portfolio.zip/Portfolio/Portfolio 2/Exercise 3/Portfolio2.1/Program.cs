﻿using System;

namespace Portfolio2._1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variables //
            int num, count = 0;

            // User enters number of lines //
            Console.WriteLine("Enter the maximum number of lines of *: ");
            num = int.Parse(Console.ReadLine());

            // Nested for Loop creates the x of * //
            count = num * 2 - 1;
            for (int row = 0; row < count; row++)
            {
                for (int column = 0; column < count; column++)
                {
                    if (column == row || (column == count - row + 1))
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.Write(" ");
                    }
                }
                Console.Write("\n");
            }
        }
    }
}

        
    

