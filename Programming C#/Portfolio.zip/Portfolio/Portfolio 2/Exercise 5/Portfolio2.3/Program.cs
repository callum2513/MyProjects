﻿using System;

namespace Portfolio2._3
{
    class Program
    {
        static void Main(string[] args)
        {
            // Array of characters //
            char[] inputArr = new char [25];

            // Variables //
            string input;
            int length = 0;
            int breaker = 0;

            // Ask for input and store input in variable //
            Console.WriteLine("Enter a string: ");
            input = Console.ReadLine();
            // Convert string input to array of characters, making it easier to compare each character //
            inputArr = input.ToCharArray();

            // Setting length variable equal to length or array (length of string that was input by the user) //
            length = inputArr.Length;

            // For loop checking if the word is a palindrom, e.g. a 5 letter word (RADAR) will be checked by checking the first and last chars are the same, then the 2nd and the 4th and finally checks the middle char against itself //
            // If all characters match with their respective characters when checked, the word is a palindrome, if one doesnt, the breaker value is set to one and the word is not a palindrome //
            for (int i = 0; i < length; i++)
            {
                if (inputArr[i] != inputArr[length-i-1])
                {
                    breaker = 1;
                    break;
                }
            }

            if (breaker == 1)
            {
                // If breaker is 1, output that the word is not a palindrome //
                Console.WriteLine(input + " is not a palindrome");
            }
            else
            {
                // else, output that the word is a palindrome as breaker will otherwise be 0 //
                Console.WriteLine(input + " is a palindrome");
            }
        }
    }
}
