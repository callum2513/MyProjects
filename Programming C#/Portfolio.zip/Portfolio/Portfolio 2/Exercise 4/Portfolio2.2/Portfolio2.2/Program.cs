﻿using System;

namespace Portfolio2._2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Character array initiaslised //
            char[] s = new char[50];

            // Variables //
            string input;
            int i;

            // User enters string in lowercase //
            Console.WriteLine("Enter a string in lowercase: ");
            input = Console.ReadLine();

            // sets string that the user entered into the character array //
            s = input.ToCharArray();

            // converts each charcters in the char array to the uppercase equivelant using the ascii values //
            for (i = 0; i < s.Length; i++)
            {
                if (s[i]>=97 && s[i]<=122)
                {
                    s[i] = (char)(s[i]-32);
                }
            }

            // The line below was what I had originally coded but it did not work, I kept getting "System.Char[]" printed instead of the actual character array.
            // Console.WriteLine("The entered string in uppercase: " + s.ToString());

            // Create new string of the using the char array and print it //
            Console.WriteLine("The entered string in lowercase is: " + input);
            Console.WriteLine("The entered string in uppercase is: " + new string(s));


        }
    }
}
