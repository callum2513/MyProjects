﻿using System;
using System.Reflection.Metadata.Ecma335;

namespace Portfolio2._4
{
    class Program
    {
        static void Main(string[] args)
        {

            Random r = new Random();
            // Generate random number between 0-100)
            int rNum = r.Next(100);
            int counter = 5, userInput = 0;

            do
            {
                // Line below used for testing purposes
                // Console.WriteLine("random number is  " + rNum);

                Console.WriteLine("Guess a number 0-100: ");
                userInput = int.Parse(Console.ReadLine());

                if (userInput == rNum)
                {
                    Console.WriteLine("YOU GOT IT! THE NUMBER WAS: " + rNum);
                }
                // VERY HIGH OR VERY LOW //
                else if (Math.Abs(rNum - userInput) >= 50)
                {
                    if (userInput > rNum)
                    {
                        Console.WriteLine("Your guess was VERY HIGH");
                    }
                    else if (userInput < rNum)
                    {
                        Console.WriteLine("Your guess was VERY LOW");
                    }
                }
                // HIGH OR LOW //
                else if (Math.Abs(rNum - userInput) < 50 && (Math.Abs(rNum - userInput) >= 20))
                {
                    if (userInput > rNum)
                    {
                        Console.WriteLine("Your guess was HIGH");
                    }
                    else if (userInput < rNum)
                    {
                        Console.WriteLine("Your guess was LOW");
                    }
                }
                // MODERATELY HIGH OR MODERATELY LOW //
                else if (Math.Abs(rNum - userInput) < 20 && (Math.Abs(rNum - userInput) >= 10))
                {
                    if (userInput > rNum)
                    {
                        Console.WriteLine("Your guess was MODERATELY HIGH");
                    }
                    else if (userInput < rNum)
                    {
                        Console.WriteLine("Your guess was MODERATELY LOW");
                    }
                }
                // SOMEWHAT HIGH OR SOMEWHAT LOW //
                else if (Math.Abs(rNum - userInput) < 10)
                {
                    if (userInput > rNum)
                    {
                        Console.WriteLine("Your guess was SOMEWHAT HIGH");
                    }
                    else if (userInput < rNum)
                    {
                        Console.WriteLine("Your guess was SOMEWHAT LOW");
                    }
                }
                counter = counter - 1;
            } while (counter > 0);

            if (counter <= 0)
            {
                Console.WriteLine("Unlucky, you ran out of attempts. The number was: " + rNum);
            }
        }
    }
}
