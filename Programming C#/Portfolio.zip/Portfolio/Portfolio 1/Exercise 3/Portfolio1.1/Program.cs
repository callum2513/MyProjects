﻿using System;

namespace Portfolio1._1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variables //
            string forename, surname, fullName;
            int numNames;

            // Output message to user //
            Console.WriteLine("Please enter the number of people: ");
            numNames = Convert.ToInt32(Console.ReadLine());

            // Create string array storing the names, size determined by number entered by user //
            string [] nameArr = new string[numNames];

            // For loop running to number entered by the user //
            for (int i = 0; i < numNames; i++)
            {
                // User enters forename and surname //
                Console.WriteLine("Person " + (i + 1) + " Please enter your forename: ");
                forename = Console.ReadLine();
                Console.WriteLine("Person " + (i + 1) + " Please enter your Surname: ");
                surname = Console.ReadLine();

                // Converts forename and surname to a single variable which is then sotred in the name array //
                fullName = forename + " " + surname;
                nameArr[i] = fullName;
                fullName = " ";

            }

            // For loop to print out all names in the array and uses the for loop "i" variable to write out the number of the person in the array //
            for (int i = 0; i < numNames; i++)
            {
                Console.WriteLine("The name of person " + (i + 1) + " is: " + nameArr[i].ToString());
             
            }
        }
    }
}
