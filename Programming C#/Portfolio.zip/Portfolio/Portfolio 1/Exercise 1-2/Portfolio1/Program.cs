﻿using System;

namespace Portfolio1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variables //
            string s1, s2;


            Console.WriteLine("Enter Value 1:");
            s1 = Console.ReadLine();
            Console.WriteLine("Enter Value 2:");
            s2 = Console.ReadLine();
            // Entered values are stored as string NOT integer //
            Console.WriteLine("The entered values are: " + s1 + " and " + s2);
            //Convert them to integer and print the sum //
            int num1, num2;
            num1 = Convert.ToInt32(s1);
            num2 = Convert.ToInt32(s2);
            Console.WriteLine("The sum is: " + num1 + num2);
        }
    }
}
