﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Portfolio1._2
{
    class Pi
    {
        public static double piVar = 3.142;
            
    }
}
