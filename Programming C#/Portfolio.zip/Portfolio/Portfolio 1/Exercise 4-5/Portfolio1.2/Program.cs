﻿using System;

namespace Portfolio1._2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variable which is set to "piVar" from the Pi.cs class //
            double circPi = Pi.piVar;

            Double circRadius = 0, circArea = 0, circPerim = 0;

            // User enters circle radius, used to calculated area //
            Console.WriteLine("Please enter the circle radius");
            circRadius = Convert.ToDouble(Console.ReadLine());


            // Calculations used to find the area and perimeter of the circle using the radius entered by the user//
            circArea = Math.Round(circPi * (circRadius * circRadius), 3);
            circPerim = Math.Round((circRadius * circPi) * 2, 3);

            // Outputs area and perimeter of the circle //
            Console.WriteLine("The Area of the circle is: " + circArea);
            Console.WriteLine("The Perimeter of the circle is: " + circPerim);
        }
    }
}
