﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SinglyLinkedList
{
    class MySinglyLinkedList
    {
        public int val;
        public MySinglyLinkedList next;

        //Default Constructor
        public MySinglyLinkedList()
        {
            val = 0;
            next = null;
        }
        //Constructor with parameter
        public MySinglyLinkedList(int value)
        {
            val = value;
            next = null;
        }

        //Insert a new node with a value after the current node
        public void InsertNode(MySinglyLinkedList current, int value)
        {
            MySinglyLinkedList node = new MySinglyLinkedList(value);
            if (current.next == null)
            {
                
                //Add your code here
                //Insert at the end and easy to handle
                current.next = node;
                
            }
            else
            {
                //Insert in the middle
                //Use temp node for temporarily holding the next node 
                //Look lecture slides for the pseudocode for adding node in the middle

                //Add your code here
            }
        }
        public void DeleteNextNode(MySinglyLinkedList current)
        {
            if (current.next == null)//there is no next node, we have already reached the end
                return;
            else
            {
                //Update the next node pointer and reset the deleted node to null
                //Look lecture slides for the pseudocode for deleting a node in the middle

                //Add your code here
            }
        }
        public void TraverseList(MySinglyLinkedList node)
        {
            //Print the values stored at the each node in the list from head to tail
            Console.WriteLine("Traversing in forward direction...");
            while (node != null)//Traverse from the current node
            {
                //Add your code here
                Console.WriteLine(node.val);
                node = node.next;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Create the first node
            MySinglyLinkedList node = new MySinglyLinkedList(1);

            //Assign head
            MySinglyLinkedList head = node;
            MySinglyLinkedList tmp = node;
            //Add 9 more consecutive nodes 2-9
            for (int i = 2; i <= 10; i++)
            {
                //Add your code here
                node.InsertNode(node, i);
                node = node.next;
            }
            //Traverse the linked list from head to tail
            node.TraverseList(tmp);
            //Add your code here

            //Delete 3rd node and then traverse

            //Add your code here

            //Insert 100 after the node value 7 and then traverse

            //Add your code here

        }
    }
}
