﻿using System;

namespace Portfolio3._2
{
    class Program
    {
        

        public struct module_data
        {
            public string moduleCode;
            public string moduleTitle;
            public int moduleMark;
        }

        public struct student_data
        {
            public string forename;
            public string surname;
            public int id_number;
            public float averageGrade;
            public string proTitle;
            public string proCode;
            public module_data[] modulesArray;
        }

        // Notice that a reference to the struct is being passed in
        static void populateStruct(out student_data student, string fname, string surname, int id_number, float avGrade, string pCode, string pTitle, module_data[] modArray)
        {
            student.forename = fname;
            student.surname = surname;
            student.id_number = id_number;
            student.averageGrade = avGrade;
            student.proTitle = pTitle;
            student.proCode = pCode;
            student.modulesArray = modArray;
        }

        static void populateModule(out module_data module, string mCode, string mTitle, int mMark)
        {
            module.moduleCode = mCode;
            module.moduleTitle = mTitle;
            module.moduleMark = mMark;
        }
        static void Main(string[] args)
        {

            int numStudents = 0;
            float averageMark;

            Console.WriteLine("\nEnter the number of students you want to add: ");
            numStudents = Convert.ToInt32(Console.ReadLine());

            student_data[] students = new student_data[numStudents];

            for (int i = 0; i < numStudents; i++)
            {
                Console.WriteLine("\n\nPlease enter student No." + (i + 1) + " forename");
                students[i].forename = Console.ReadLine();
                Console.WriteLine("\nPlease enter the student No." + (i + 1) + " surname: ");
                students[i].surname = Console.ReadLine();
                Console.WriteLine("\nPlease enter the student No." + (i + 1) + " ID: ");
                students[i].id_number = Convert.ToInt32(Console.ReadLine());

                // Commented out entering the average grade manually as it is now calculated from the marks entered //
                // Console.WriteLine("\nPlease enter the student No." + (i + 1) + " average grade: ");
                //students[i].averageGrade = float.Parse(Console.ReadLine());

                Console.WriteLine("\nPlease enter the student No." + (i + 1) + " Programme Title: ");
                students[i].proTitle = Console.ReadLine();
                Console.WriteLine("\nPlease enter the student No." + (i + 1) + " Programme Code: ");
                students[i].proCode = Console.ReadLine();

                for (int x = 0; x < 6; x++)
                {
                    int totalMarks = 0;

                    Console.WriteLine("\nPlease enter module" + (x + 1) + "'s Module Code");
                    students[i].modulesArray[i].moduleCode = Console.ReadLine();
                    Console.WriteLine("\nPlease enter module" + (x + 1) + "'s Module Title");
                    students[i].modulesArray[i].moduleTitle = Console.ReadLine();
                    Console.WriteLine("\nPlease enter module" + (x + 1) + "'s Module Mark");
                    students[i].modulesArray[i].moduleMark = int.Parse(Console.ReadLine());
                    totalMarks += students[i].modulesArray[i].moduleMark;

                    averageMark = totalMarks / 6;
                    students[i].averageGrade = averageMark;
                }
                Console.WriteLine("Student: " + students[i].forename + " " + students[i].surname + " has been added!");
                
            }

            printAllStudent(students);
        }
        static void printAllStudent(student_data[] students)
        {
            foreach (student_data item in students)
            {
                Console.WriteLine("Name: " + item.forename + " " + item.surname);
                Console.WriteLine("Id: " + item.id_number);
                Console.WriteLine("Av grade: " + item.averageGrade.ToString("0.00"));
                Console.WriteLine("Programme Title: " + item.proTitle);
                Console.WriteLine("Programme Code: " + item.proCode + "\n");

                

            }
        }
    }
}
