﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Portfolio_3
{
    class Program
    {
        // Student struct with relevant variables //
        public struct student_data
        {
            public string forename;
            public string surname;
            public int id_number;
            public float averageGrade;
            public string proTitle;
            public string proCode;
        }
        // Notice that a reference to the struct is being passed in
        // Constructor for student struct
        static void populateStruct(out student_data student, string fname, string surname, int id_number, float avGrade, string pCode, string pTitle)
        {
            student.forename = fname;
            student.surname = surname;
            student.id_number = id_number;
            student.averageGrade = avGrade;
            student.proTitle = pTitle;
            student.proCode = pCode;
        }
        static void Main(string[] args)
        {
            // Array of student_data initialised //
            student_data[] students = new student_data[4];

            // populating the student array with 4 students with their grades and course info //
            populateStruct(out students[0], "Mark", "Anderson", 1, 58.0F, "Games Programming", "COM-GP");
            populateStruct(out students[1], "Ardhendu", "Behera", 2, 78.0F, "Computer Networks", "COM-CN");
            populateStruct(out students[2], "Tom", "Jones", 3, 67.7F, "Computer Science", "COM-SC");
            populateStruct(out students[3], "Ewan", "Evans", 4, 51.5F, "Computer Networks", "COM-CN");

            // print all students method called //
            printAllStudent(students);
        }

        static void printStudent(student_data student)
        {
            
            Console.WriteLine("Name: " + student.forename + " " + student.surname);
            Console.WriteLine("Id: " + student.id_number);
            Console.WriteLine("Av grade: " + student.averageGrade);
            Console.WriteLine("Programme Title:" + student.proTitle);
            Console.WriteLine("Programme Code:" + student.proCode);
        }

        static void printAllStudent(student_data[] students)
        {
            // for each loop which runs through each item in the array and prints out all their entries //
            foreach (student_data item in students)
            {
                Console.WriteLine("Name: " + item.forename + " " + item.surname);
                Console.WriteLine("Id: " + item.id_number);
                Console.WriteLine("Av grade: " + item.averageGrade.ToString("0.00"));
                Console.WriteLine("Programme Title: " + item.proTitle);
                Console.WriteLine("Programme Code: " + item.proCode + "\n");

            }
        }
    }
}