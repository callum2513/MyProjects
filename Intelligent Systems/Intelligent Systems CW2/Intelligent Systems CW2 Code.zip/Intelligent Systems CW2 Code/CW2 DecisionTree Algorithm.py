# -*- coding: utf-8 -*-
"""
Created on Sat Jan  1 13:20:58 2022

@author: Callum
"""

"Below, Importing Modules needed"
from sklearn import tree
from sklearn.metrics import classification_report
from load_data import load_data_from_csv
 

"Below is the code that imports the training and test data"
input_training_csv = 'C:\\CSV_ML_Data\\reviews_Video_Games_training.csv'
input_test_csv = 'C:\\CSV_ML_Data\\reviews_Video_Games_test.csv'

"Below is the training instances and the training labels being loaded fromt he csv file as well as the paramters for the algorithm "
training_feature_names, training_instances, training_labels = load_data_from_csv(input_csv=input_training_csv)
test_feature_names, test_instances, test_labels = load_data_from_csv(input_csv=input_test_csv)

classifier = tree.DecisionTreeClassifier()
classifier.fit(training_instances, training_labels)
predicted_test_lables = classifier.predict(test_instances)

print(classification_report(test_labels, predicted_test_lables))
"Prints our Classification Report Summary on Dataset when algorithm has been applied to given dataset"