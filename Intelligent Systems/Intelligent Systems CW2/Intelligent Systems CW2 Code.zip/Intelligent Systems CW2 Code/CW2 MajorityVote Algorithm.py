# -*- coding: utf-8 -*-
"""
Created on Sat Jan  1 12:50:14 2022

@author: Callum
"""
"Below, Importing Modules needed"
from sklearn.neighbors import KNeighborsClassifier
from sklearn import tree
from sklearn.ensemble import VotingClassifier
from sklearn.metrics import classification_report
from load_data import load_data_from_csv


"Below is the code that imports the training and test data"
input_training_csv = 'C:\\CSV_ML_Data\\reviews_Video_Games_training.csv'
input_test_csv = 'C:\\CSV_ML_Data\\reviews_Video_Games_test.csv'

training_feature_names, training_instances, training_labels = load_data_from_csv(input_csv=input_training_csv)
test_feature_names, test_instances, test_labels = load_data_from_csv(input_csv=input_test_csv)
SubClassifier1 = KNeighborsClassifier(n_neighbors=11)
SubClassifier2 = tree.DecisionTreeClassifier()
voting_classifier = VotingClassifier(estimators=[('SubClass1', SubClassifier1), ('SubClass2', SubClassifier2)], voting='hard')
"Above is the training instances and the training labels being loaded fromt he csv file as well as the paramters for the algorithm "
"Parameters are K for K-NN and the voting style for MJ, options of which are Hard or Soft"

voting_classifier.fit(training_instances, training_labels)
predicted_test_labels = voting_classifier.predict(test_instances)

print(classification_report(test_labels, predicted_test_labels))
"Prints our Classification Report Summary on Dataset when algorithm has been applied to given dataset"
