package coursework.mad.mobileappscw2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.location.Address;
import android.util.Log;

public class MyDBHelper {

    // Patient Tables Attributes //
    public static final String KEY_PATIENT_ROWID = "_id";
    public static final String KEY_FORENAME = "Forename";
    public static final String KEY_SURNAME = "Surname";
    public static final String KEY_DOB = "DOB";
    public static final String KEY_USERNAME = "Username";
    public static final String KEY_PASSWORD = "Password";
    public static final String KEY_MOBILENO = "MobileNo";
    public static final String KEY_ADDRESS = "Address";
    public static final String KEY_POSTCODE = "Postcode";
    // public static final String KEY_RISKLEVEL = "RiskLevel";

    // Health Readings Table Attributes //
    public static final String KEY_HEALTH_READINGS_ROWID = "PatientID";
    public static final String KEY_TEMPERATURE = "Temperature";
    public static final String KEY_LOWERBLOODPRESSURE = "LowerBloodPressure";
    public static final String KEY_HIGHERBLOODPRESSURE = "HigherBloodPressure";
    public static final String KEY_HEARTRATE = "HeartRate";


    private static final String TAG = "MyDBHelper";
    private static final String DATABASE_NAME = "MyMediCare.db";
    private static final String DATABASE_PATIENT_TABLE = "Patients";
    private static final String DATABASE_HEALTH_READINGS_TABLE = "HealthReadings";
    private static final int DATABASE_VERSION = 2;
    private static final String DATABASE_CREATE_PATIENTS =
            "create table Patients (_id integer primary key autoincrement, "
                    +"Forename text not null, Surname text not null, DOB text not null, Username text not null, Password text not null, " +
                    "MobileNo text not null, Address text not null, Postcode not null);";
    private static final String DATABASE_CREATE_HEALTH_READINGS =
            "create table HealthReadings (_id integer primary key autoincrement, " + "PatientID text not null, Temperature text not null, LowerBloodPressure text not null, HigherBloodPressure text not null, HeartRate text not null);";

    private final Context context;
    private DatabaseHelper DBHelper;
    private SQLiteDatabase db;
    public MyDBHelper(Context ctx)
    {
        this.context = ctx;
        DBHelper = new DatabaseHelper(context);
    }
    private static class DatabaseHelper extends SQLiteOpenHelper
    {
        DatabaseHelper(Context context)
        {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }
        @Override
        public void onCreate(SQLiteDatabase db)
        {
            try {
                db.execSQL(DATABASE_CREATE_PATIENTS);
                db.execSQL(DATABASE_CREATE_HEALTH_READINGS);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
        {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS Patients");
            db.execSQL("DROP TABLE IF EXISTS HealthReadings");
            onCreate(db);
        }
    }
    //---opens the database---
    public MyDBHelper open() throws SQLException
    {
        db = DBHelper.getWritableDatabase();
        return this;
    }
    //---closes the database---
    public void close()
    {
        DBHelper.close();
    }

    //---insert a Patient into the database---
    public long insertPatient(String Forename, String Surname, String DOB, String Username, String Password, String MobileNo, String Address, String Postcode)
    {
        ContentValues initialValuesPatient = new ContentValues();
        initialValuesPatient.put(KEY_FORENAME, Forename);
        initialValuesPatient.put(KEY_SURNAME, Surname);
        initialValuesPatient.put(KEY_DOB, DOB);
        initialValuesPatient.put(KEY_USERNAME, Username);
        initialValuesPatient.put(KEY_PASSWORD, Password);
        initialValuesPatient.put(KEY_MOBILENO, MobileNo);
        initialValuesPatient.put(KEY_ADDRESS, Address);
        initialValuesPatient.put(KEY_POSTCODE, Postcode);
        // initialValues.put(KEY_RISKLEVEL, RiskLevel);

        return db.insert(DATABASE_PATIENT_TABLE, null, initialValuesPatient);
    }

    // Insert Health Reading into the database //
    public long insertHealthReading (String PatientID, String Temperature, String LowerBloodPressure, String HigherBloodPressure, String HeartRate)
    {
        ContentValues initialValuesHealthReadings = new ContentValues();
        initialValuesHealthReadings.put(KEY_HEALTH_READINGS_ROWID, PatientID);
        initialValuesHealthReadings.put(KEY_TEMPERATURE, Temperature);
        initialValuesHealthReadings.put(KEY_LOWERBLOODPRESSURE, LowerBloodPressure);
        initialValuesHealthReadings.put(KEY_HIGHERBLOODPRESSURE, HigherBloodPressure);
        initialValuesHealthReadings.put(KEY_HEARTRATE, HeartRate);

        return db.insert(DATABASE_HEALTH_READINGS_TABLE, null, initialValuesHealthReadings);
    }


    //---retrieves all the Patients---
    public Cursor getAllPatients()
    {
        return db.query(DATABASE_PATIENT_TABLE, new String[]
                {KEY_PATIENT_ROWID, KEY_FORENAME, KEY_SURNAME, KEY_DOB, KEY_USERNAME, KEY_PASSWORD, KEY_MOBILENO, KEY_ADDRESS, KEY_POSTCODE}, null, null, null, null, null);
    }

    // Retrieves all readings //
    public Cursor getAllHealthReadings()
    {
        return db.query(DATABASE_HEALTH_READINGS_TABLE, new String[]
                {KEY_HEALTH_READINGS_ROWID, KEY_TEMPERATURE, KEY_LOWERBLOODPRESSURE, KEY_HIGHERBLOODPRESSURE, KEY_HEARTRATE}, null, null, null, null, null);
    }

    //---retrieves a particular Patient---
    public Cursor getPatient(long rowId) throws SQLException
    {
        Cursor mCursor =
                db.query(true, DATABASE_PATIENT_TABLE, new String[]
                                {KEY_PATIENT_ROWID,KEY_FORENAME, KEY_SURNAME, KEY_DOB, KEY_USERNAME, KEY_PASSWORD, KEY_MOBILENO, KEY_ADDRESS, KEY_POSTCODE}, KEY_PATIENT_ROWID + "=" + rowId, null,
                        null, null, null, null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }

    //Retrives all Health Readings for a specific patient//
    public Cursor getPatientHealthReadings(long rowId) throws SQLException
    {
        return null;
    }

    // This method to check if user exists or not //
    public boolean checkUser(String username, String password) {
        // array of columns to fetch
        String[] columns = {
                KEY_PATIENT_ROWID
        };
        SQLiteDatabase db = DBHelper.getReadableDatabase();
        // selection criteria
        String selection = KEY_USERNAME+ " = ?" + " AND " + KEY_PASSWORD + " = ?";
        // selection arguments
        String[] selectionArgs = {username, password};
        // query user table with conditions
        /**
         * Here the query function is used to fetch records from user table, this function works like an sql query.
         */
        Cursor cursor = db.query(DATABASE_PATIENT_TABLE, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                       //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }
        return false;
    }

    public boolean checkUser(String username) {
        // array of columns to fetch
        String[] columns = {
                KEY_PATIENT_ROWID
        };
        SQLiteDatabase db = DBHelper.getReadableDatabase();
        // selection criteria
        String selection = KEY_USERNAME + " = ?";
        // selection argument
        String[] selectionArgs = {username};
        // query user table with condition
        /**
         * Here the query function is used to fetch records from user table, this function works like an sql query.
         */
        Cursor cursor = db.query(DATABASE_PATIENT_TABLE, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }
        return false;
    }
}
