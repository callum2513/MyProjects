package coursework.mad.mobileappscw2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.renderscript.ScriptGroup;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.content.Intent;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;


public class MainActivity extends AppCompatActivity {

    private InputValidation inputValidation;
    private final AppCompatActivity activity = MainActivity.this;
    private MyDBHelper databaseHelper;

    private EditText txtLoginUsername;
    private EditText txtLoginPassword;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialiseObjects();


        // Register Button //
        Button btnRegister= (Button)findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(new OnClickListener(){
            public void onClick(View v)
            {
                startActivity(new Intent(MainActivity.this, RegisterActivity.class));
            }
        });

        // Register Button //
        Button btnSignIn= (Button)findViewById(R.id.btnSignIn);
        btnSignIn.setOnClickListener(new OnClickListener(){
            public void onClick(View v)
            {
                if (verifyLogin() == true)
                {
                    Toast.makeText(getBaseContext(), "Welcome back" + txtLoginUsername.toString(),
                            Toast        .LENGTH_LONG).show();
                }
                else
                {
                     Toast.makeText(getBaseContext(), "Invalid Username and/or Password",
                             Toast        .LENGTH_LONG).show();
                }
            }
        });
    }


    // Login process //

    private boolean verifyLogin()
    {
        if (databaseHelper.checkUser(txtLoginUsername.getText().toString().trim(), txtLoginPassword.getText().toString().trim()))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    // This method is to initialise objects that are to be used //
    private void initialiseObjects ()
    {
        databaseHelper = new MyDBHelper(activity);
    }
}