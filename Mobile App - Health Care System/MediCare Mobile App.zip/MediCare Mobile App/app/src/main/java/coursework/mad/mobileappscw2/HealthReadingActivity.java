package coursework.mad.mobileappscw2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class HealthReadingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_reading);
        MyDBHelper db = new MyDBHelper(getBaseContext()); //declare db as MyDBHelper type in


        // Variables to store attributes and pass to database //
        EditText editTextPatientNo = (EditText) findViewById(R.id.txtHealthReadingPatientNo);
        EditText editTextTemperature = (EditText) findViewById(R.id.txtTemperature);
        EditText editTextBloodPressureLower = (EditText)findViewById(R.id.txtLowerBloodPressure);
        EditText editTextBloodPressureHigher = (EditText) findViewById(R.id.txtHigherBloodPressure);
        EditText editTextHeartRate = (EditText) findViewById(R.id.txtHeartRate);






        // Add HealthReading Activity Button //
        Button btnAddHealthReading = (Button)findViewById(R.id.btnAddRecord);
        btnAddHealthReading.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                //the beginning of the class
                //---add a Patient---
                db.open();
                long id = db.insertHealthReading(editTextPatientNo.getText().toString(),editTextTemperature.getText().toString(), editTextBloodPressureLower.getText().toString(), editTextBloodPressureHigher.getText().toString(), editTextHeartRate.getText().toString());
                db.close();
                Toast.makeText(getBaseContext(), "Personal Details Saved Successfully!", Toast.LENGTH_SHORT).show();


                startActivity(new Intent(HealthReadingActivity.this, PatientProfileActivity.class));
            }
        });

    }


    // Method for calculating Patient Risk Level //
    public String calculateRiskLevel()
    {
        String riskLevel;

        if (
                Integer.parseInt(findViewById(R.id.txtTemperature).toString()) > 37 ||
                        Integer.parseInt(findViewById(R.id.txtLowerBloodPressure).toString()) > 80 ||
                        Integer.parseInt(findViewById(R.id.txtHigherBloodPressure).toString()) > 120 ||
                        Integer.parseInt(findViewById(R.id.txtHeartRate).toString()) > 72)
        {
            riskLevel = "Low Risk";
        }
        else if (
                Integer.parseInt(findViewById(R.id.txtTemperature).toString()) >= 38 ||
                        Integer.parseInt(findViewById(R.id.txtLowerBloodPressure).toString()) > 110 ||
                        Integer.parseInt(findViewById(R.id.txtHigherBloodPressure).toString()) > 180 ||
                        Integer.parseInt(findViewById(R.id.txtHeartRate).toString()) > 160)
        {
            riskLevel = "High Risk";
        }
        else
        {
            riskLevel = "Normal";
        }

        return riskLevel;
    }

}