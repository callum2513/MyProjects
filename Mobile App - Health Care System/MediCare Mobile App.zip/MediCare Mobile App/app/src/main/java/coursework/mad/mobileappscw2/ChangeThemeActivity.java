package coursework.mad.mobileappscw2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toolbar;

public class ChangeThemeActivity extends AppCompatActivity {

    Toolbar mToolbar;
    Button darkThemeButton;
    Button lightThemeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_theme);

         mToolbar = (Toolbar) findViewById(R.id.toolbar);
         darkThemeButton = (Button) findViewById(R.id.btnDarkTheme);
         lightThemeButton = (Button) findViewById(R.id.btnLightTheme);

    /*if (getColor() != getResources().getColor(R.color.lightThemeColor))
    {
        mToolbar.setBackgroundColor(getColor());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            getWindow().setStatusBarColor(getColor());
        }
    }*/

         darkThemeButton.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick (View view)
             {
                 mToolbar.setBackgroundColor(getResources().getColor(R.color.darkThemeColor));
                 if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
                 {
                     getWindow().setStatusBarColor(getResources().getColor(R.color.darkThemeColor));
                 }
                 storeColor(getResources().getColor(R.color.darkThemeColor));
             }
         });

        lightThemeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View view)
            {
                mToolbar.setBackgroundColor(getResources().getColor(R.color.lightThemeColor));
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
                {
                    getWindow().setStatusBarColor(getResources().getColor(R.color.lightThemeColor));
                }
                storeColor(getResources().getColor(R.color.lightThemeColor));
            }
        });

}




    private void storeColor (int color){
        SharedPreferences mSharedPreferences = getSharedPreferences("ToolbarColor", MODE_PRIVATE);
        SharedPreferences.Editor mEditor = mSharedPreferences.edit();
        mEditor.putInt("color", color);
        mEditor.apply();
    }

    private int getColor (){
        SharedPreferences mSharedPreferences = getSharedPreferences("ToolbarColor", MODE_PRIVATE);
        int selectedColor = mSharedPreferences.getInt("color", getResources().getColor(R.color.design_default_color_primary));
        return selectedColor;
    }

}