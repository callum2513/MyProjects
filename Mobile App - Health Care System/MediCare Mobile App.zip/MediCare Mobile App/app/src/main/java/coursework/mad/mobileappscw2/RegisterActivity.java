package coursework.mad.mobileappscw2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class RegisterActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {
    MyDBHelper db;
    private TextView dateText;
    String riskLevel = "Normal";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        dateText = findViewById(R.id.txtDateText);
        Button btnReg = (Button) findViewById(R.id.btnRegisterSubmit);
        MyDBHelper db = new MyDBHelper(getBaseContext()); //declare db as MyDBHelper type in

        findViewById(R.id.btnShowDialog).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                showDatePicker();
            }
        });


        // Variables to store attributes and pass to database //
        EditText editTextForename = (EditText) findViewById(R.id.txtUserForename);
        EditText editTextSurname = (EditText)findViewById(R.id.txtUserSurname);
        EditText editTextDOB = (EditText) findViewById(R.id.txtDateText);
        EditText editTextUsername = (EditText) findViewById(R.id.txtUserName);
        EditText editTextPassword = (EditText) findViewById(R.id.txtPassword);
        EditText editTextMobileNum = (EditText) findViewById(R.id.txtMobileNum);
        EditText editTextAddress = (EditText) findViewById(R.id.txtAddress);
        EditText editTextPostcode = (EditText) findViewById(R.id.txtPostcode);


        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                //the beginning of the class
                //---add a Patient---
                db.open();
                long id = db.insertPatient(editTextForename.getText().toString(), editTextSurname.getText().toString(), editTextDOB.getText().toString(),  editTextUsername.getText().toString()
                        , editTextPassword.getText().toString(), editTextMobileNum.getText().toString(), editTextAddress.getText().toString(),  editTextPostcode.getText().toString());
                db.close();
                Toast.makeText(getBaseContext(), "Personal Details Saved Successfully!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(RegisterActivity.this, PatientProfileActivity.class));

            }
        });
    }

    private void showDatePicker()
    {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                this,
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth)
    {
        String date = "" + month + "/" + dayOfMonth + "/" + year;
        dateText.setText(date);
    }

    public void DisplayPatient(Cursor c) {
        Toast.makeText( this, "id: " + c.getString(0) + "\n" + " First Name: " + c.getString(1) + "\n" + "Surname: " + c.getString(2)+"\n" + "email: " + c.getString(3), Toast.LENGTH_LONG).show();
    }
}