package coursework.mad.mobileappscw2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PatientProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_profile);

        // Add HealthReading Activity Button //
        Button btnHealthReading= (Button)findViewById(R.id.btnHealthReadingStart);
        btnHealthReading.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                startActivity(new Intent(PatientProfileActivity.this, HealthReadingActivity.class));
            }
        });

        // Logout Activity Button //
        Button btnProfLogout= (Button)findViewById(R.id.btnProfileLogout);
        btnProfLogout.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                startActivity(new Intent(PatientProfileActivity.this, MainActivity.class));
            }
        });

        // Send GP Message Button //
        Button btnSendGPMessage= (Button)findViewById(R.id.btnContactGP);
        btnSendGPMessage.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                startActivity(new Intent(PatientProfileActivity.this, SendGPMessageActivity.class));
            }
        });

        // Register Button //
        Button btnChangeTheme = (Button)findViewById(R.id.btnChangeTheme);
        btnChangeTheme.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                startActivity(new Intent(PatientProfileActivity.this, ChangeThemeActivity.class));
            }
        });



        MyDBHelper db = new MyDBHelper(getBaseContext()); //declare db as MyDBHelper type in

        db.open();

        try {

            EditText setPatientName = findViewById(R.id.txtShowPatientName);
            EditText setPatientDOB = findViewById(R.id.txtShowPatientDOB);
            EditText setPatientMobileNo = findViewById(R.id.txtShowPatientMobNo);
            EditText setPatientAddress = findViewById(R.id.txtShowPatientAddress);
            EditText setPatientPostcode = findViewById(R.id.txtShowPatientPostcode);


            Cursor c = db.getAllPatients();
            if (c.moveToFirst()) {
                do {

                    // Setting database values to EditText on profile Screen //
                    // Create string and set to value of forename and surname in db//
                    String fullName = c.getString(1) + " " + c.getString(2);
                    setPatientName.setText("Name:  " + fullName);

                    // Setting Profile DOB //
                    String DOB = c.getString(3);
                    setPatientDOB.setText("DOB:  " + DOB);

                    // Setting Profile MobileNo //
                    String MobileNo = c.getString(6);
                    setPatientMobileNo.setText("MobileNo:  " + MobileNo);

                    String Address = c.getString(7);
                    setPatientAddress.setText("Address:  " + Address);

                    String Postcode = c.getString(8);
                    setPatientPostcode.setText("Postcode:  " + Postcode);

                } while (c.moveToNext());
            }

            // Toast.makeText(getBaseContext(), "Name: " + firstName,
            //         Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), "data was not found",
                    Toast.LENGTH_LONG).show();

            db.close();
        }
    }

    private void disableEditText(EditText editText) {
        editText.setFocusable(false);
        editText.setEnabled(false);
        editText.setCursorVisible(false);
        editText.setKeyListener(null);
        editText.setBackgroundColor(Color.TRANSPARENT);
    }
}