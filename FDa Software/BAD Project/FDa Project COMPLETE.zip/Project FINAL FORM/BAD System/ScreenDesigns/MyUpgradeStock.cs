﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScreenDesigns
{
    class MyUpgradeStock
    {
        private string upgradeID, upgradeDesc, supplierID, makeID;
        private double sellPrice, purchasePrice;
        private int qtyInStock;

        public MyUpgradeStock()
        {
            this.upgradeID = "";
            this.upgradeDesc = "";
            this.supplierID = "";
            this.makeID = "";
            this.sellPrice = 0;
            this.qtyInStock = 0;
            this.purchasePrice = 0;
        }

        public MyUpgradeStock(string upgradeID, string upgradeDesc, string supplierID, string makeID, int sellPrice, int qtyInStock, int purchasePrice)
        {
            this.upgradeID = upgradeID;
            this.upgradeDesc = upgradeDesc;
            this.supplierID = supplierID;
            this.makeID = makeID;
            this.sellPrice = sellPrice;
            this.qtyInStock = qtyInStock;
            this.purchasePrice = purchasePrice;
        }

        public string UpgradeID
        {
            get { return upgradeID; }
            set { upgradeID = value; }
        }

        public string UpgradeDesc
        {
            get { return upgradeDesc; }
            set
            {
                if (MyValidation.validLength(value, 5, 25) && MyValidation.validForename(value))
                {
                    upgradeDesc = MyValidation.firstLetterEachWordUpper(value);
                }
                else
                {
                    throw new MyException("Description must be between 5-25 letters & have no numbers.");
                }
            }
        }

        public string SupplierID
        {
            get { return supplierID; }
            set { supplierID = value; }
           
        }

        public string MakeID
        {
            get { return makeID; }
            set
            {
                if (MyValidation.validMake(value))
                {
                     makeID = value;
                }
                else
                {
                    throw new MyException("Invalid make!");
                }
            }
        }

        public double SellPrice
        {
            get { return sellPrice; }
            set
            {

                if (MyValidation.validDouble(value.ToString()) && MyValidation.validLength(value.ToString(), 1, 6))
                {
                    sellPrice = value;
                }
                else
                {
                    throw new MyException("Incorrect sell price input!");
                }
            }
        }

        public int QtyInStock
        {
            get { return qtyInStock; }
            set
            {
                if (MyValidation.validNumber(value.ToString()) && MyValidation.validLength(value.ToString(), 2, 4))
                {
                    qtyInStock = value;
                }
                else
                {
                    throw new MyException("Incorrect quantity input!");
                }
            }
        }

        public double PurchasePrice
        {
            get { return purchasePrice; }
            set
            {
                if (MyValidation.validNumber(value.ToString()) && MyValidation.validLength(value.ToString(), 1, 6))
                {
                    purchasePrice = value;
                }
                else
                {
                    throw new MyException("Incorrect quantity input!");
                }
            }
        }








    }
}
