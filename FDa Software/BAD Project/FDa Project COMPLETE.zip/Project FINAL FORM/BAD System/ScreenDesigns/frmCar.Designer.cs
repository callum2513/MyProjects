﻿namespace ScreenDesigns
{
    partial class frmCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.Button btnEditCarEdit;
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCar));
			this.tabCarEdit = new System.Windows.Forms.TabPage();
			this.txtEditCarRegNo = new System.Windows.Forms.MaskedTextBox();
			this.txtEditCarMileage = new System.Windows.Forms.NumericUpDown();
			this.cmbEditCarTransmission = new System.Windows.Forms.ComboBox();
			this.txtEditCarSalePrice = new System.Windows.Forms.MaskedTextBox();
			this.txtEditCarPurchasePrice = new System.Windows.Forms.MaskedTextBox();
			this.cmbEditCarCondition = new System.Windows.Forms.ComboBox();
			this.lblEditCarMileage = new System.Windows.Forms.Label();
			this.lblEditCarSalePrice = new System.Windows.Forms.Label();
			this.dtpEditCarYear = new System.Windows.Forms.DateTimePicker();
			this.txtEditCarColour = new System.Windows.Forms.TextBox();
			this.cmbEditCarBody = new System.Windows.Forms.ComboBox();
			this.lblEditCarBody = new System.Windows.Forms.Label();
			this.lblCarEditHeader = new System.Windows.Forms.Label();
			this.cmbEditCarDoorNo = new System.Windows.Forms.ComboBox();
			this.lblEditCarDoorNo = new System.Windows.Forms.Label();
			this.lblEditCarConidtion = new System.Windows.Forms.Label();
			this.lblEditCarYear = new System.Windows.Forms.Label();
			this.txtEditCarInterior = new System.Windows.Forms.TextBox();
			this.txtEditCarModel = new System.Windows.Forms.TextBox();
			this.lblEditCarColour = new System.Windows.Forms.Label();
			this.lblEditCarTransmission = new System.Windows.Forms.Label();
			this.lblEditCarInterior = new System.Windows.Forms.Label();
			this.lblEditCarPurchasePrice = new System.Windows.Forms.Label();
			this.lblEditCarModel = new System.Windows.Forms.Label();
			this.cmbEditCarMake = new System.Windows.Forms.ComboBox();
			this.lblEditCarMake = new System.Windows.Forms.Label();
			this.lblEditCarReg = new System.Windows.Forms.Label();
			this.lblEditCarEdit = new System.Windows.Forms.Label();
			this.lblAddCarReset = new System.Windows.Forms.Label();
			this.btnAddCarReset = new System.Windows.Forms.Button();
			this.lblAddCarBtn = new System.Windows.Forms.Label();
			this.btnAddCarAdd = new System.Windows.Forms.Button();
			this.errP = new System.Windows.Forms.ErrorProvider(this.components);
			this.lblAddCarBody = new System.Windows.Forms.Label();
			this.lblCarAddHeader = new System.Windows.Forms.Label();
			this.cmbAddCarDoorNo = new System.Windows.Forms.ComboBox();
			this.lblAddCarDoorNo = new System.Windows.Forms.Label();
			this.lblAddCarCondition = new System.Windows.Forms.Label();
			this.lblAddCarYear = new System.Windows.Forms.Label();
			this.txtAddCarInterior = new System.Windows.Forms.TextBox();
			this.txtAddCarModel = new System.Windows.Forms.TextBox();
			this.lblAddCarColour = new System.Windows.Forms.Label();
			this.panel3 = new System.Windows.Forms.Panel();
			this.tabCar = new System.Windows.Forms.TabControl();
			this.tabCarDisplay = new System.Windows.Forms.TabPage();
			this.lblSearchReg = new System.Windows.Forms.Label();
			this.txtSearchMake = new System.Windows.Forms.TextBox();
			this.dgvCar = new System.Windows.Forms.DataGridView();
			this.tabCarAdd = new System.Windows.Forms.TabPage();
			this.txtAddCarMileage = new System.Windows.Forms.NumericUpDown();
			this.cmbAddCarTransmission = new System.Windows.Forms.ComboBox();
			this.txtAddCarSalePrice = new System.Windows.Forms.MaskedTextBox();
			this.txtAddCarPurchasePrice = new System.Windows.Forms.MaskedTextBox();
			this.cmbAddCarCondition = new System.Windows.Forms.ComboBox();
			this.txtAddCarReg = new System.Windows.Forms.MaskedTextBox();
			this.lblAddCarMileage = new System.Windows.Forms.Label();
			this.lblAddCarSalePrice = new System.Windows.Forms.Label();
			this.dtpAddCarYear = new System.Windows.Forms.DateTimePicker();
			this.txtAddCarColour = new System.Windows.Forms.TextBox();
			this.cmbAddCarBody = new System.Windows.Forms.ComboBox();
			this.lblAddCarTransmission = new System.Windows.Forms.Label();
			this.lblAddCarInterior = new System.Windows.Forms.Label();
			this.lblAddCarPurchasePrice = new System.Windows.Forms.Label();
			this.lblAddCarModel = new System.Windows.Forms.Label();
			this.cmbAddCarMake = new System.Windows.Forms.ComboBox();
			this.lblAddCarMake = new System.Windows.Forms.Label();
			this.lblAddCarRegNo = new System.Windows.Forms.Label();
			this.lblCarTitle = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.pnlTopMenuBar = new System.Windows.Forms.Panel();
			this.panel4 = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.bannerTimer = new System.Windows.Forms.Timer(this.components);
			this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.panel6 = new System.Windows.Forms.Panel();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this.btnCarHome = new System.Windows.Forms.Button();
			this.btnCarExit = new System.Windows.Forms.Button();
			this.btnCarAdd = new System.Windows.Forms.Button();
			this.btnCarEdit = new System.Windows.Forms.Button();
			this.btnCarDelete = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.tabRep = new System.Windows.Forms.TabPage();
			btnEditCarEdit = new System.Windows.Forms.Button();
			this.tabCarEdit.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.txtEditCarMileage)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.errP)).BeginInit();
			this.tabCar.SuspendLayout();
			this.tabCarDisplay.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvCar)).BeginInit();
			this.tabCarAdd.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.txtAddCarMileage)).BeginInit();
			this.panel1.SuspendLayout();
			this.pnlTopMenuBar.SuspendLayout();
			this.panel4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// btnEditCarEdit
			// 
			btnEditCarEdit.Location = new System.Drawing.Point(36, 382);
			btnEditCarEdit.Name = "btnEditCarEdit";
			btnEditCarEdit.Size = new System.Drawing.Size(50, 50);
			btnEditCarEdit.TabIndex = 55;
			btnEditCarEdit.UseVisualStyleBackColor = true;
			btnEditCarEdit.Click += new System.EventHandler(this.btnEditCarEdit_Click);
			// 
			// tabCarEdit
			// 
			this.tabCarEdit.Controls.Add(this.txtEditCarRegNo);
			this.tabCarEdit.Controls.Add(this.txtEditCarMileage);
			this.tabCarEdit.Controls.Add(this.cmbEditCarTransmission);
			this.tabCarEdit.Controls.Add(this.txtEditCarSalePrice);
			this.tabCarEdit.Controls.Add(this.txtEditCarPurchasePrice);
			this.tabCarEdit.Controls.Add(this.cmbEditCarCondition);
			this.tabCarEdit.Controls.Add(this.lblEditCarMileage);
			this.tabCarEdit.Controls.Add(this.lblEditCarSalePrice);
			this.tabCarEdit.Controls.Add(this.dtpEditCarYear);
			this.tabCarEdit.Controls.Add(this.txtEditCarColour);
			this.tabCarEdit.Controls.Add(this.cmbEditCarBody);
			this.tabCarEdit.Controls.Add(this.lblEditCarBody);
			this.tabCarEdit.Controls.Add(this.lblCarEditHeader);
			this.tabCarEdit.Controls.Add(this.cmbEditCarDoorNo);
			this.tabCarEdit.Controls.Add(this.lblEditCarDoorNo);
			this.tabCarEdit.Controls.Add(this.lblEditCarConidtion);
			this.tabCarEdit.Controls.Add(this.lblEditCarYear);
			this.tabCarEdit.Controls.Add(this.txtEditCarInterior);
			this.tabCarEdit.Controls.Add(this.txtEditCarModel);
			this.tabCarEdit.Controls.Add(this.lblEditCarColour);
			this.tabCarEdit.Controls.Add(this.lblEditCarTransmission);
			this.tabCarEdit.Controls.Add(this.lblEditCarInterior);
			this.tabCarEdit.Controls.Add(this.lblEditCarPurchasePrice);
			this.tabCarEdit.Controls.Add(this.lblEditCarModel);
			this.tabCarEdit.Controls.Add(this.cmbEditCarMake);
			this.tabCarEdit.Controls.Add(this.lblEditCarMake);
			this.tabCarEdit.Controls.Add(this.lblEditCarReg);
			this.tabCarEdit.Controls.Add(this.lblEditCarEdit);
			this.tabCarEdit.Controls.Add(btnEditCarEdit);
			this.tabCarEdit.Location = new System.Drawing.Point(4, 22);
			this.tabCarEdit.Name = "tabCarEdit";
			this.tabCarEdit.Size = new System.Drawing.Size(857, 452);
			this.tabCarEdit.TabIndex = 2;
			this.tabCarEdit.Text = "Edit";
			this.tabCarEdit.UseVisualStyleBackColor = true;
			// 
			// txtEditCarRegNo
			// 
			this.txtEditCarRegNo.Enabled = false;
			this.txtEditCarRegNo.Location = new System.Drawing.Point(156, 78);
			this.txtEditCarRegNo.Mask = "AAAAAAA";
			this.txtEditCarRegNo.Name = "txtEditCarRegNo";
			this.txtEditCarRegNo.PromptChar = ' ';
			this.txtEditCarRegNo.Size = new System.Drawing.Size(72, 20);
			this.txtEditCarRegNo.TabIndex = 121;
			// 
			// txtEditCarMileage
			// 
			this.txtEditCarMileage.Location = new System.Drawing.Point(517, 206);
			this.txtEditCarMileage.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
			this.txtEditCarMileage.Name = "txtEditCarMileage";
			this.txtEditCarMileage.Size = new System.Drawing.Size(139, 20);
			this.txtEditCarMileage.TabIndex = 95;
			// 
			// cmbEditCarTransmission
			// 
			this.cmbEditCarTransmission.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbEditCarTransmission.Enabled = false;
			this.cmbEditCarTransmission.FormattingEnabled = true;
			this.cmbEditCarTransmission.Items.AddRange(new object[] {
            "Manual",
            "Automatic"});
			this.cmbEditCarTransmission.Location = new System.Drawing.Point(156, 207);
			this.cmbEditCarTransmission.Name = "cmbEditCarTransmission";
			this.cmbEditCarTransmission.Size = new System.Drawing.Size(145, 21);
			this.cmbEditCarTransmission.TabIndex = 120;
			this.cmbEditCarTransmission.TextChanged += new System.EventHandler(this.cmbEditCarTransmission_TextChanged);
			// 
			// txtEditCarSalePrice
			// 
			this.txtEditCarSalePrice.Enabled = false;
			this.txtEditCarSalePrice.Location = new System.Drawing.Point(517, 264);
			this.txtEditCarSalePrice.Mask = "######";
			this.txtEditCarSalePrice.Name = "txtEditCarSalePrice";
			this.txtEditCarSalePrice.PromptChar = ' ';
			this.txtEditCarSalePrice.Size = new System.Drawing.Size(87, 20);
			this.txtEditCarSalePrice.TabIndex = 119;
			this.txtEditCarSalePrice.TextChanged += new System.EventHandler(this.txtEditCarSalePrice_TextChanged);
			// 
			// txtEditCarPurchasePrice
			// 
			this.txtEditCarPurchasePrice.Enabled = false;
			this.txtEditCarPurchasePrice.Location = new System.Drawing.Point(517, 236);
			this.txtEditCarPurchasePrice.Mask = "######";
			this.txtEditCarPurchasePrice.Name = "txtEditCarPurchasePrice";
			this.txtEditCarPurchasePrice.PromptChar = ' ';
			this.txtEditCarPurchasePrice.Size = new System.Drawing.Size(87, 20);
			this.txtEditCarPurchasePrice.TabIndex = 118;
			this.txtEditCarPurchasePrice.TextChanged += new System.EventHandler(this.txtEditCarPurchasePrice_TextChanged);
			// 
			// cmbEditCarCondition
			// 
			this.cmbEditCarCondition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbEditCarCondition.Enabled = false;
			this.cmbEditCarCondition.FormattingEnabled = true;
			this.cmbEditCarCondition.Items.AddRange(new object[] {
            "New",
            "Used"});
			this.cmbEditCarCondition.Location = new System.Drawing.Point(519, 107);
			this.cmbEditCarCondition.Name = "cmbEditCarCondition";
			this.cmbEditCarCondition.Size = new System.Drawing.Size(137, 21);
			this.cmbEditCarCondition.TabIndex = 116;
			this.cmbEditCarCondition.TextChanged += new System.EventHandler(this.cmbEditCarCondition_TextChanged);
			// 
			// lblEditCarMileage
			// 
			this.lblEditCarMileage.AutoSize = true;
			this.lblEditCarMileage.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblEditCarMileage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblEditCarMileage.Location = new System.Drawing.Point(362, 206);
			this.lblEditCarMileage.Name = "lblEditCarMileage";
			this.lblEditCarMileage.Size = new System.Drawing.Size(76, 21);
			this.lblEditCarMileage.TabIndex = 114;
			this.lblEditCarMileage.Text = "Mileage:";
			// 
			// lblEditCarSalePrice
			// 
			this.lblEditCarSalePrice.AutoSize = true;
			this.lblEditCarSalePrice.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblEditCarSalePrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblEditCarSalePrice.Location = new System.Drawing.Point(362, 263);
			this.lblEditCarSalePrice.Name = "lblEditCarSalePrice";
			this.lblEditCarSalePrice.Size = new System.Drawing.Size(88, 21);
			this.lblEditCarSalePrice.TabIndex = 113;
			this.lblEditCarSalePrice.Text = "Sale Price:";
			// 
			// dtpEditCarYear
			// 
			this.dtpEditCarYear.Enabled = false;
			this.dtpEditCarYear.Location = new System.Drawing.Point(519, 137);
			this.dtpEditCarYear.Name = "dtpEditCarYear";
			this.dtpEditCarYear.Size = new System.Drawing.Size(137, 20);
			this.dtpEditCarYear.TabIndex = 112;
			// 
			// txtEditCarColour
			// 
			this.txtEditCarColour.Enabled = false;
			this.txtEditCarColour.Location = new System.Drawing.Point(156, 271);
			this.txtEditCarColour.Name = "txtEditCarColour";
			this.txtEditCarColour.Size = new System.Drawing.Size(147, 20);
			this.txtEditCarColour.TabIndex = 111;
			this.txtEditCarColour.TextChanged += new System.EventHandler(this.txtEditCarColour_TextChanged);
			// 
			// cmbEditCarBody
			// 
			this.cmbEditCarBody.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbEditCarBody.Enabled = false;
			this.cmbEditCarBody.FormattingEnabled = true;
			this.cmbEditCarBody.Items.AddRange(new object[] {
            "Sedan",
            "Coupe",
            "SUV",
            "Hatchback",
            "Sport",
            "Van"});
			this.cmbEditCarBody.Location = new System.Drawing.Point(156, 239);
			this.cmbEditCarBody.Name = "cmbEditCarBody";
			this.cmbEditCarBody.Size = new System.Drawing.Size(145, 21);
			this.cmbEditCarBody.TabIndex = 110;
			this.cmbEditCarBody.TextChanged += new System.EventHandler(this.cmbEditCarBody_TextChanged);
			// 
			// lblEditCarBody
			// 
			this.lblEditCarBody.AutoSize = true;
			this.lblEditCarBody.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblEditCarBody.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblEditCarBody.Location = new System.Drawing.Point(32, 238);
			this.lblEditCarBody.Name = "lblEditCarBody";
			this.lblEditCarBody.Size = new System.Drawing.Size(95, 21);
			this.lblEditCarBody.TabIndex = 109;
			this.lblEditCarBody.Text = "Body Style:";
			// 
			// lblCarEditHeader
			// 
			this.lblCarEditHeader.AutoSize = true;
			this.lblCarEditHeader.BackColor = System.Drawing.Color.White;
			this.lblCarEditHeader.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCarEditHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblCarEditHeader.Location = new System.Drawing.Point(19, 19);
			this.lblCarEditHeader.Name = "lblCarEditHeader";
			this.lblCarEditHeader.Size = new System.Drawing.Size(150, 45);
			this.lblCarEditHeader.TabIndex = 108;
			this.lblCarEditHeader.Text = "Edit Car";
			// 
			// cmbEditCarDoorNo
			// 
			this.cmbEditCarDoorNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbEditCarDoorNo.Enabled = false;
			this.cmbEditCarDoorNo.FormattingEnabled = true;
			this.cmbEditCarDoorNo.Items.AddRange(new object[] {
            "3",
            "5"});
			this.cmbEditCarDoorNo.Location = new System.Drawing.Point(517, 172);
			this.cmbEditCarDoorNo.Name = "cmbEditCarDoorNo";
			this.cmbEditCarDoorNo.Size = new System.Drawing.Size(139, 21);
			this.cmbEditCarDoorNo.TabIndex = 107;
			this.cmbEditCarDoorNo.TextChanged += new System.EventHandler(this.cmbEditCarDoorNo_TextChanged);
			// 
			// lblEditCarDoorNo
			// 
			this.lblEditCarDoorNo.AutoSize = true;
			this.lblEditCarDoorNo.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblEditCarDoorNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblEditCarDoorNo.Location = new System.Drawing.Point(362, 172);
			this.lblEditCarDoorNo.Name = "lblEditCarDoorNo";
			this.lblEditCarDoorNo.Size = new System.Drawing.Size(79, 21);
			this.lblEditCarDoorNo.TabIndex = 106;
			this.lblEditCarDoorNo.Text = "Door No:";
			// 
			// lblEditCarConidtion
			// 
			this.lblEditCarConidtion.AutoSize = true;
			this.lblEditCarConidtion.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblEditCarConidtion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblEditCarConidtion.Location = new System.Drawing.Point(362, 107);
			this.lblEditCarConidtion.Name = "lblEditCarConidtion";
			this.lblEditCarConidtion.Size = new System.Drawing.Size(90, 21);
			this.lblEditCarConidtion.TabIndex = 105;
			this.lblEditCarConidtion.Text = "Condition:";
			// 
			// lblEditCarYear
			// 
			this.lblEditCarYear.AutoSize = true;
			this.lblEditCarYear.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblEditCarYear.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblEditCarYear.Location = new System.Drawing.Point(362, 139);
			this.lblEditCarYear.Name = "lblEditCarYear";
			this.lblEditCarYear.Size = new System.Drawing.Size(48, 21);
			this.lblEditCarYear.TabIndex = 104;
			this.lblEditCarYear.Text = "Year:";
			// 
			// txtEditCarInterior
			// 
			this.txtEditCarInterior.Enabled = false;
			this.txtEditCarInterior.Location = new System.Drawing.Point(156, 172);
			this.txtEditCarInterior.Name = "txtEditCarInterior";
			this.txtEditCarInterior.Size = new System.Drawing.Size(145, 20);
			this.txtEditCarInterior.TabIndex = 102;
			this.txtEditCarInterior.TextChanged += new System.EventHandler(this.txtEditCarInterior_TextChanged);
			// 
			// txtEditCarModel
			// 
			this.txtEditCarModel.Enabled = false;
			this.txtEditCarModel.Location = new System.Drawing.Point(156, 140);
			this.txtEditCarModel.Name = "txtEditCarModel";
			this.txtEditCarModel.Size = new System.Drawing.Size(145, 20);
			this.txtEditCarModel.TabIndex = 101;
			this.txtEditCarModel.TextChanged += new System.EventHandler(this.txtEditCarModel_TextChanged);
			// 
			// lblEditCarColour
			// 
			this.lblEditCarColour.AutoSize = true;
			this.lblEditCarColour.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblEditCarColour.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblEditCarColour.Location = new System.Drawing.Point(32, 270);
			this.lblEditCarColour.Name = "lblEditCarColour";
			this.lblEditCarColour.Size = new System.Drawing.Size(65, 21);
			this.lblEditCarColour.TabIndex = 100;
			this.lblEditCarColour.Text = "Colour:";
			// 
			// lblEditCarTransmission
			// 
			this.lblEditCarTransmission.AutoSize = true;
			this.lblEditCarTransmission.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblEditCarTransmission.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblEditCarTransmission.Location = new System.Drawing.Point(31, 207);
			this.lblEditCarTransmission.Name = "lblEditCarTransmission";
			this.lblEditCarTransmission.Size = new System.Drawing.Size(114, 21);
			this.lblEditCarTransmission.TabIndex = 99;
			this.lblEditCarTransmission.Text = "Transmission:";
			// 
			// lblEditCarInterior
			// 
			this.lblEditCarInterior.AutoSize = true;
			this.lblEditCarInterior.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblEditCarInterior.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblEditCarInterior.Location = new System.Drawing.Point(31, 172);
			this.lblEditCarInterior.Name = "lblEditCarInterior";
			this.lblEditCarInterior.Size = new System.Drawing.Size(71, 21);
			this.lblEditCarInterior.TabIndex = 98;
			this.lblEditCarInterior.Text = "Interior:";
			// 
			// lblEditCarPurchasePrice
			// 
			this.lblEditCarPurchasePrice.AutoSize = true;
			this.lblEditCarPurchasePrice.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblEditCarPurchasePrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblEditCarPurchasePrice.Location = new System.Drawing.Point(362, 234);
			this.lblEditCarPurchasePrice.Name = "lblEditCarPurchasePrice";
			this.lblEditCarPurchasePrice.Size = new System.Drawing.Size(125, 21);
			this.lblEditCarPurchasePrice.TabIndex = 97;
			this.lblEditCarPurchasePrice.Text = "Purchase Price:";
			// 
			// lblEditCarModel
			// 
			this.lblEditCarModel.AutoSize = true;
			this.lblEditCarModel.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblEditCarModel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblEditCarModel.Location = new System.Drawing.Point(32, 140);
			this.lblEditCarModel.Name = "lblEditCarModel";
			this.lblEditCarModel.Size = new System.Drawing.Size(63, 21);
			this.lblEditCarModel.TabIndex = 96;
			this.lblEditCarModel.Text = "Model:";
			// 
			// cmbEditCarMake
			// 
			this.cmbEditCarMake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbEditCarMake.Enabled = false;
			this.cmbEditCarMake.FormattingEnabled = true;
			this.cmbEditCarMake.Items.AddRange(new object[] {
            "FRD",
            "REN",
            "AUD",
            "NIS",
            "HON",
            "FIA",
            "BMW"});
			this.cmbEditCarMake.Location = new System.Drawing.Point(156, 108);
			this.cmbEditCarMake.Name = "cmbEditCarMake";
			this.cmbEditCarMake.Size = new System.Drawing.Size(145, 21);
			this.cmbEditCarMake.TabIndex = 95;
			this.cmbEditCarMake.TextChanged += new System.EventHandler(this.cmbEditCarMake_TextChanged);
			// 
			// lblEditCarMake
			// 
			this.lblEditCarMake.AutoSize = true;
			this.lblEditCarMake.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblEditCarMake.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblEditCarMake.Location = new System.Drawing.Point(32, 108);
			this.lblEditCarMake.Name = "lblEditCarMake";
			this.lblEditCarMake.Size = new System.Drawing.Size(56, 21);
			this.lblEditCarMake.TabIndex = 94;
			this.lblEditCarMake.Text = "Make:";
			// 
			// lblEditCarReg
			// 
			this.lblEditCarReg.AutoSize = true;
			this.lblEditCarReg.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblEditCarReg.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblEditCarReg.Location = new System.Drawing.Point(32, 77);
			this.lblEditCarReg.Name = "lblEditCarReg";
			this.lblEditCarReg.Size = new System.Drawing.Size(70, 21);
			this.lblEditCarReg.TabIndex = 93;
			this.lblEditCarReg.Text = "Reg No:";
			// 
			// lblEditCarEdit
			// 
			this.lblEditCarEdit.AutoSize = true;
			this.lblEditCarEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold);
			this.lblEditCarEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblEditCarEdit.Location = new System.Drawing.Point(92, 397);
			this.lblEditCarEdit.Name = "lblEditCarEdit";
			this.lblEditCarEdit.Size = new System.Drawing.Size(40, 21);
			this.lblEditCarEdit.TabIndex = 56;
			this.lblEditCarEdit.Text = "Edit";
			// 
			// lblAddCarReset
			// 
			this.lblAddCarReset.AutoSize = true;
			this.lblAddCarReset.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold);
			this.lblAddCarReset.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblAddCarReset.Location = new System.Drawing.Point(298, 404);
			this.lblAddCarReset.Name = "lblAddCarReset";
			this.lblAddCarReset.Size = new System.Drawing.Size(94, 21);
			this.lblAddCarReset.TabIndex = 54;
			this.lblAddCarReset.Text = "Reset Form";
			// 
			// btnAddCarReset
			// 
			this.btnAddCarReset.Location = new System.Drawing.Point(242, 389);
			this.btnAddCarReset.Name = "btnAddCarReset";
			this.btnAddCarReset.Size = new System.Drawing.Size(50, 50);
			this.btnAddCarReset.TabIndex = 53;
			this.btnAddCarReset.UseVisualStyleBackColor = true;
			this.btnAddCarReset.Click += new System.EventHandler(this.btnAddCarReset_Click);
			// 
			// lblAddCarBtn
			// 
			this.lblAddCarBtn.AutoSize = true;
			this.lblAddCarBtn.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold);
			this.lblAddCarBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblAddCarBtn.Location = new System.Drawing.Point(83, 404);
			this.lblAddCarBtn.Name = "lblAddCarBtn";
			this.lblAddCarBtn.Size = new System.Drawing.Size(70, 21);
			this.lblAddCarBtn.TabIndex = 52;
			this.lblAddCarBtn.Text = "Add Car";
			// 
			// btnAddCarAdd
			// 
			this.btnAddCarAdd.Location = new System.Drawing.Point(27, 389);
			this.btnAddCarAdd.Name = "btnAddCarAdd";
			this.btnAddCarAdd.Size = new System.Drawing.Size(50, 50);
			this.btnAddCarAdd.TabIndex = 51;
			this.btnAddCarAdd.UseVisualStyleBackColor = true;
			this.btnAddCarAdd.Click += new System.EventHandler(this.btnAddCarAdd_Click);
			// 
			// errP
			// 
			this.errP.ContainerControl = this;
			// 
			// lblAddCarBody
			// 
			this.lblAddCarBody.AutoSize = true;
			this.lblAddCarBody.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAddCarBody.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblAddCarBody.Location = new System.Drawing.Point(23, 245);
			this.lblAddCarBody.Name = "lblAddCarBody";
			this.lblAddCarBody.Size = new System.Drawing.Size(95, 21);
			this.lblAddCarBody.TabIndex = 49;
			this.lblAddCarBody.Text = "Body Style:";
			// 
			// lblCarAddHeader
			// 
			this.lblCarAddHeader.AutoSize = true;
			this.lblCarAddHeader.BackColor = System.Drawing.Color.White;
			this.lblCarAddHeader.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCarAddHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblCarAddHeader.Location = new System.Drawing.Point(10, 26);
			this.lblCarAddHeader.Name = "lblCarAddHeader";
			this.lblCarAddHeader.Size = new System.Drawing.Size(154, 45);
			this.lblCarAddHeader.TabIndex = 48;
			this.lblCarAddHeader.Text = "Add Car";
			// 
			// cmbAddCarDoorNo
			// 
			this.cmbAddCarDoorNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbAddCarDoorNo.FormattingEnabled = true;
			this.cmbAddCarDoorNo.Items.AddRange(new object[] {
            "3",
            "5"});
			this.cmbAddCarDoorNo.Location = new System.Drawing.Point(508, 179);
			this.cmbAddCarDoorNo.Name = "cmbAddCarDoorNo";
			this.cmbAddCarDoorNo.Size = new System.Drawing.Size(139, 21);
			this.cmbAddCarDoorNo.TabIndex = 23;
			this.cmbAddCarDoorNo.TextChanged += new System.EventHandler(this.cmbAddCarDoorNo_TextChanged);
			// 
			// lblAddCarDoorNo
			// 
			this.lblAddCarDoorNo.AutoSize = true;
			this.lblAddCarDoorNo.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAddCarDoorNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblAddCarDoorNo.Location = new System.Drawing.Point(353, 179);
			this.lblAddCarDoorNo.Name = "lblAddCarDoorNo";
			this.lblAddCarDoorNo.Size = new System.Drawing.Size(79, 21);
			this.lblAddCarDoorNo.TabIndex = 18;
			this.lblAddCarDoorNo.Text = "Door No:";
			// 
			// lblAddCarCondition
			// 
			this.lblAddCarCondition.AutoSize = true;
			this.lblAddCarCondition.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAddCarCondition.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblAddCarCondition.Location = new System.Drawing.Point(353, 114);
			this.lblAddCarCondition.Name = "lblAddCarCondition";
			this.lblAddCarCondition.Size = new System.Drawing.Size(90, 21);
			this.lblAddCarCondition.TabIndex = 17;
			this.lblAddCarCondition.Text = "Condition:";
			// 
			// lblAddCarYear
			// 
			this.lblAddCarYear.AutoSize = true;
			this.lblAddCarYear.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAddCarYear.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblAddCarYear.Location = new System.Drawing.Point(353, 146);
			this.lblAddCarYear.Name = "lblAddCarYear";
			this.lblAddCarYear.Size = new System.Drawing.Size(48, 21);
			this.lblAddCarYear.TabIndex = 14;
			this.lblAddCarYear.Text = "Year:";
			// 
			// txtAddCarInterior
			// 
			this.txtAddCarInterior.Location = new System.Drawing.Point(147, 179);
			this.txtAddCarInterior.Name = "txtAddCarInterior";
			this.txtAddCarInterior.Size = new System.Drawing.Size(145, 20);
			this.txtAddCarInterior.TabIndex = 11;
			this.txtAddCarInterior.TextChanged += new System.EventHandler(this.txtAddCarInterior_TextChanged);
			// 
			// txtAddCarModel
			// 
			this.txtAddCarModel.Location = new System.Drawing.Point(147, 147);
			this.txtAddCarModel.Name = "txtAddCarModel";
			this.txtAddCarModel.Size = new System.Drawing.Size(145, 20);
			this.txtAddCarModel.TabIndex = 9;
			this.txtAddCarModel.TextChanged += new System.EventHandler(this.txtAddCarModel_TextChanged);
			// 
			// lblAddCarColour
			// 
			this.lblAddCarColour.AutoSize = true;
			this.lblAddCarColour.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAddCarColour.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblAddCarColour.Location = new System.Drawing.Point(23, 277);
			this.lblAddCarColour.Name = "lblAddCarColour";
			this.lblAddCarColour.Size = new System.Drawing.Size(65, 21);
			this.lblAddCarColour.TabIndex = 8;
			this.lblAddCarColour.Text = "Colour:";
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.panel3.Location = new System.Drawing.Point(95, 57);
			this.panel3.Margin = new System.Windows.Forms.Padding(2);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(3, 520);
			this.panel3.TabIndex = 49;
			// 
			// tabCar
			// 
			this.tabCar.CausesValidation = false;
			this.tabCar.Controls.Add(this.tabCarDisplay);
			this.tabCar.Controls.Add(this.tabCarAdd);
			this.tabCar.Controls.Add(this.tabCarEdit);
			this.tabCar.Controls.Add(this.tabRep);
			this.tabCar.Location = new System.Drawing.Point(110, 74);
			this.tabCar.Name = "tabCar";
			this.tabCar.SelectedIndex = 0;
			this.tabCar.Size = new System.Drawing.Size(865, 478);
			this.tabCar.TabIndex = 52;
			this.tabCar.SelectedIndexChanged += new System.EventHandler(this.tabCar_SelectedIndexChanged);
			// 
			// tabCarDisplay
			// 
			this.tabCarDisplay.Controls.Add(this.lblSearchReg);
			this.tabCarDisplay.Controls.Add(this.txtSearchMake);
			this.tabCarDisplay.Controls.Add(this.dgvCar);
			this.tabCarDisplay.Location = new System.Drawing.Point(4, 22);
			this.tabCarDisplay.Name = "tabCarDisplay";
			this.tabCarDisplay.Padding = new System.Windows.Forms.Padding(3);
			this.tabCarDisplay.Size = new System.Drawing.Size(857, 452);
			this.tabCarDisplay.TabIndex = 0;
			this.tabCarDisplay.Text = "Display";
			this.tabCarDisplay.UseVisualStyleBackColor = true;
			// 
			// lblSearchReg
			// 
			this.lblSearchReg.AutoSize = true;
			this.lblSearchReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblSearchReg.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblSearchReg.Location = new System.Drawing.Point(584, 11);
			this.lblSearchReg.Name = "lblSearchReg";
			this.lblSearchReg.Size = new System.Drawing.Size(136, 16);
			this.lblSearchReg.TabIndex = 2;
			this.lblSearchReg.Text = "Search By RegNo:";
			this.lblSearchReg.Click += new System.EventHandler(this.lblSearchReg_Click);
			// 
			// txtSearchMake
			// 
			this.txtSearchMake.Location = new System.Drawing.Point(726, 10);
			this.txtSearchMake.Name = "txtSearchMake";
			this.txtSearchMake.Size = new System.Drawing.Size(109, 20);
			this.txtSearchMake.TabIndex = 1;
			this.txtSearchMake.TextChanged += new System.EventHandler(this.txtSearchSurname_TextChanged);
			// 
			// dgvCar
			// 
			this.dgvCar.AllowUserToAddRows = false;
			this.dgvCar.AllowUserToDeleteRows = false;
			this.dgvCar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvCar.Location = new System.Drawing.Point(17, 35);
			this.dgvCar.Name = "dgvCar";
			this.dgvCar.ReadOnly = true;
			this.dgvCar.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dgvCar.Size = new System.Drawing.Size(821, 411);
			this.dgvCar.TabIndex = 0;
			this.dgvCar.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCar_CellContentClick);
			// 
			// tabCarAdd
			// 
			this.tabCarAdd.Controls.Add(this.txtAddCarMileage);
			this.tabCarAdd.Controls.Add(this.cmbAddCarTransmission);
			this.tabCarAdd.Controls.Add(this.txtAddCarSalePrice);
			this.tabCarAdd.Controls.Add(this.txtAddCarPurchasePrice);
			this.tabCarAdd.Controls.Add(this.cmbAddCarCondition);
			this.tabCarAdd.Controls.Add(this.txtAddCarReg);
			this.tabCarAdd.Controls.Add(this.lblAddCarMileage);
			this.tabCarAdd.Controls.Add(this.lblAddCarSalePrice);
			this.tabCarAdd.Controls.Add(this.dtpAddCarYear);
			this.tabCarAdd.Controls.Add(this.txtAddCarColour);
			this.tabCarAdd.Controls.Add(this.cmbAddCarBody);
			this.tabCarAdd.Controls.Add(this.lblAddCarReset);
			this.tabCarAdd.Controls.Add(this.btnAddCarReset);
			this.tabCarAdd.Controls.Add(this.lblAddCarBtn);
			this.tabCarAdd.Controls.Add(this.btnAddCarAdd);
			this.tabCarAdd.Controls.Add(this.lblAddCarBody);
			this.tabCarAdd.Controls.Add(this.lblCarAddHeader);
			this.tabCarAdd.Controls.Add(this.cmbAddCarDoorNo);
			this.tabCarAdd.Controls.Add(this.lblAddCarDoorNo);
			this.tabCarAdd.Controls.Add(this.lblAddCarCondition);
			this.tabCarAdd.Controls.Add(this.lblAddCarYear);
			this.tabCarAdd.Controls.Add(this.txtAddCarInterior);
			this.tabCarAdd.Controls.Add(this.txtAddCarModel);
			this.tabCarAdd.Controls.Add(this.lblAddCarColour);
			this.tabCarAdd.Controls.Add(this.lblAddCarTransmission);
			this.tabCarAdd.Controls.Add(this.lblAddCarInterior);
			this.tabCarAdd.Controls.Add(this.lblAddCarPurchasePrice);
			this.tabCarAdd.Controls.Add(this.lblAddCarModel);
			this.tabCarAdd.Controls.Add(this.cmbAddCarMake);
			this.tabCarAdd.Controls.Add(this.lblAddCarMake);
			this.tabCarAdd.Controls.Add(this.lblAddCarRegNo);
			this.tabCarAdd.Location = new System.Drawing.Point(4, 22);
			this.tabCarAdd.Name = "tabCarAdd";
			this.tabCarAdd.Padding = new System.Windows.Forms.Padding(3);
			this.tabCarAdd.Size = new System.Drawing.Size(857, 452);
			this.tabCarAdd.TabIndex = 1;
			this.tabCarAdd.Text = "Add";
			this.tabCarAdd.UseVisualStyleBackColor = true;
			// 
			// txtAddCarMileage
			// 
			this.txtAddCarMileage.Location = new System.Drawing.Point(508, 213);
			this.txtAddCarMileage.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
			this.txtAddCarMileage.Name = "txtAddCarMileage";
			this.txtAddCarMileage.Size = new System.Drawing.Size(139, 20);
			this.txtAddCarMileage.TabIndex = 94;
			// 
			// cmbAddCarTransmission
			// 
			this.cmbAddCarTransmission.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbAddCarTransmission.FormattingEnabled = true;
			this.cmbAddCarTransmission.Items.AddRange(new object[] {
            "Manual",
            "Automatic"});
			this.cmbAddCarTransmission.Location = new System.Drawing.Point(147, 214);
			this.cmbAddCarTransmission.Name = "cmbAddCarTransmission";
			this.cmbAddCarTransmission.Size = new System.Drawing.Size(145, 21);
			this.cmbAddCarTransmission.TabIndex = 93;
			this.cmbAddCarTransmission.TextChanged += new System.EventHandler(this.cmbAddCarTransmission_TextChanged);
			// 
			// txtAddCarSalePrice
			// 
			this.txtAddCarSalePrice.Location = new System.Drawing.Point(508, 271);
			this.txtAddCarSalePrice.Mask = "######";
			this.txtAddCarSalePrice.Name = "txtAddCarSalePrice";
			this.txtAddCarSalePrice.PromptChar = ' ';
			this.txtAddCarSalePrice.Size = new System.Drawing.Size(87, 20);
			this.txtAddCarSalePrice.TabIndex = 92;
			// 
			// txtAddCarPurchasePrice
			// 
			this.txtAddCarPurchasePrice.Location = new System.Drawing.Point(508, 243);
			this.txtAddCarPurchasePrice.Mask = "######";
			this.txtAddCarPurchasePrice.Name = "txtAddCarPurchasePrice";
			this.txtAddCarPurchasePrice.PromptChar = ' ';
			this.txtAddCarPurchasePrice.Size = new System.Drawing.Size(87, 20);
			this.txtAddCarPurchasePrice.TabIndex = 91;
			// 
			// cmbAddCarCondition
			// 
			this.cmbAddCarCondition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbAddCarCondition.FormattingEnabled = true;
			this.cmbAddCarCondition.Items.AddRange(new object[] {
            "New",
            "Used"});
			this.cmbAddCarCondition.Location = new System.Drawing.Point(510, 114);
			this.cmbAddCarCondition.Name = "cmbAddCarCondition";
			this.cmbAddCarCondition.Size = new System.Drawing.Size(137, 21);
			this.cmbAddCarCondition.TabIndex = 89;
			this.cmbAddCarCondition.TextChanged += new System.EventHandler(this.cmbAddCarCondition_TextChanged);
			// 
			// txtAddCarReg
			// 
			this.txtAddCarReg.Location = new System.Drawing.Point(147, 85);
			this.txtAddCarReg.Mask = "AAAAAAA";
			this.txtAddCarReg.Name = "txtAddCarReg";
			this.txtAddCarReg.PromptChar = ' ';
			this.txtAddCarReg.Size = new System.Drawing.Size(72, 20);
			this.txtAddCarReg.TabIndex = 88;
			this.txtAddCarReg.TextChanged += new System.EventHandler(this.txtAddCarReg_TextChanged);
			// 
			// lblAddCarMileage
			// 
			this.lblAddCarMileage.AutoSize = true;
			this.lblAddCarMileage.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAddCarMileage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblAddCarMileage.Location = new System.Drawing.Point(353, 213);
			this.lblAddCarMileage.Name = "lblAddCarMileage";
			this.lblAddCarMileage.Size = new System.Drawing.Size(76, 21);
			this.lblAddCarMileage.TabIndex = 84;
			this.lblAddCarMileage.Text = "Mileage:";
			// 
			// lblAddCarSalePrice
			// 
			this.lblAddCarSalePrice.AutoSize = true;
			this.lblAddCarSalePrice.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAddCarSalePrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblAddCarSalePrice.Location = new System.Drawing.Point(353, 270);
			this.lblAddCarSalePrice.Name = "lblAddCarSalePrice";
			this.lblAddCarSalePrice.Size = new System.Drawing.Size(88, 21);
			this.lblAddCarSalePrice.TabIndex = 82;
			this.lblAddCarSalePrice.Text = "Sale Price:";
			// 
			// dtpAddCarYear
			// 
			this.dtpAddCarYear.Location = new System.Drawing.Point(510, 144);
			this.dtpAddCarYear.MaxDate = new System.DateTime(2020, 2, 18, 0, 0, 0, 0);
			this.dtpAddCarYear.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
			this.dtpAddCarYear.Name = "dtpAddCarYear";
			this.dtpAddCarYear.Size = new System.Drawing.Size(137, 20);
			this.dtpAddCarYear.TabIndex = 81;
			this.dtpAddCarYear.Value = new System.DateTime(2020, 2, 18, 0, 0, 0, 0);
			// 
			// txtAddCarColour
			// 
			this.txtAddCarColour.Location = new System.Drawing.Point(147, 278);
			this.txtAddCarColour.Name = "txtAddCarColour";
			this.txtAddCarColour.Size = new System.Drawing.Size(147, 20);
			this.txtAddCarColour.TabIndex = 80;
			this.txtAddCarColour.TextChanged += new System.EventHandler(this.txtAddCarColour_TextChanged);
			// 
			// cmbAddCarBody
			// 
			this.cmbAddCarBody.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbAddCarBody.FormattingEnabled = true;
			this.cmbAddCarBody.Items.AddRange(new object[] {
            "Sedan",
            "Coupe",
            "Hatchback",
            "SUV",
            "Sport",
            "Van"});
			this.cmbAddCarBody.Location = new System.Drawing.Point(147, 246);
			this.cmbAddCarBody.Name = "cmbAddCarBody";
			this.cmbAddCarBody.Size = new System.Drawing.Size(145, 21);
			this.cmbAddCarBody.TabIndex = 78;
			this.cmbAddCarBody.TextChanged += new System.EventHandler(this.cmbAddCarBody_TextChanged);
			// 
			// lblAddCarTransmission
			// 
			this.lblAddCarTransmission.AutoSize = true;
			this.lblAddCarTransmission.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAddCarTransmission.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblAddCarTransmission.Location = new System.Drawing.Point(22, 214);
			this.lblAddCarTransmission.Name = "lblAddCarTransmission";
			this.lblAddCarTransmission.Size = new System.Drawing.Size(114, 21);
			this.lblAddCarTransmission.TabIndex = 7;
			this.lblAddCarTransmission.Text = "Transmission:";
			// 
			// lblAddCarInterior
			// 
			this.lblAddCarInterior.AutoSize = true;
			this.lblAddCarInterior.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAddCarInterior.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblAddCarInterior.Location = new System.Drawing.Point(22, 179);
			this.lblAddCarInterior.Name = "lblAddCarInterior";
			this.lblAddCarInterior.Size = new System.Drawing.Size(71, 21);
			this.lblAddCarInterior.TabIndex = 6;
			this.lblAddCarInterior.Text = "Interior:";
			// 
			// lblAddCarPurchasePrice
			// 
			this.lblAddCarPurchasePrice.AutoSize = true;
			this.lblAddCarPurchasePrice.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAddCarPurchasePrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblAddCarPurchasePrice.Location = new System.Drawing.Point(353, 241);
			this.lblAddCarPurchasePrice.Name = "lblAddCarPurchasePrice";
			this.lblAddCarPurchasePrice.Size = new System.Drawing.Size(125, 21);
			this.lblAddCarPurchasePrice.TabIndex = 5;
			this.lblAddCarPurchasePrice.Text = "Purchase Price:";
			// 
			// lblAddCarModel
			// 
			this.lblAddCarModel.AutoSize = true;
			this.lblAddCarModel.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAddCarModel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblAddCarModel.Location = new System.Drawing.Point(23, 147);
			this.lblAddCarModel.Name = "lblAddCarModel";
			this.lblAddCarModel.Size = new System.Drawing.Size(63, 21);
			this.lblAddCarModel.TabIndex = 4;
			this.lblAddCarModel.Text = "Model:";
			// 
			// cmbAddCarMake
			// 
			this.cmbAddCarMake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbAddCarMake.FormattingEnabled = true;
			this.cmbAddCarMake.Location = new System.Drawing.Point(147, 115);
			this.cmbAddCarMake.Name = "cmbAddCarMake";
			this.cmbAddCarMake.Size = new System.Drawing.Size(145, 21);
			this.cmbAddCarMake.TabIndex = 3;
			this.cmbAddCarMake.TextChanged += new System.EventHandler(this.cmbAddCarMake_TextChanged);
			// 
			// lblAddCarMake
			// 
			this.lblAddCarMake.AutoSize = true;
			this.lblAddCarMake.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAddCarMake.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblAddCarMake.Location = new System.Drawing.Point(23, 115);
			this.lblAddCarMake.Name = "lblAddCarMake";
			this.lblAddCarMake.Size = new System.Drawing.Size(56, 21);
			this.lblAddCarMake.TabIndex = 2;
			this.lblAddCarMake.Text = "Make:";
			// 
			// lblAddCarRegNo
			// 
			this.lblAddCarRegNo.AutoSize = true;
			this.lblAddCarRegNo.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAddCarRegNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblAddCarRegNo.Location = new System.Drawing.Point(23, 84);
			this.lblAddCarRegNo.Name = "lblAddCarRegNo";
			this.lblAddCarRegNo.Size = new System.Drawing.Size(70, 21);
			this.lblAddCarRegNo.TabIndex = 0;
			this.lblAddCarRegNo.Text = "Reg No:";
			// 
			// lblCarTitle
			// 
			this.lblCarTitle.AutoSize = true;
			this.lblCarTitle.BackColor = System.Drawing.Color.White;
			this.lblCarTitle.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCarTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.lblCarTitle.Location = new System.Drawing.Point(885, 7);
			this.lblCarTitle.Name = "lblCarTitle";
			this.lblCarTitle.Size = new System.Drawing.Size(87, 45);
			this.lblCarTitle.TabIndex = 51;
			this.lblCarTitle.Text = "Cars";
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Location = new System.Drawing.Point(-12, 56);
			this.panel1.Margin = new System.Windows.Forms.Padding(2);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1000, 2);
			this.panel1.TabIndex = 48;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.panel2.Location = new System.Drawing.Point(1, 1);
			this.panel2.Margin = new System.Windows.Forms.Padding(2);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(1000, 2);
			this.panel2.TabIndex = 49;
			// 
			// pnlTopMenuBar
			// 
			this.pnlTopMenuBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.pnlTopMenuBar.Controls.Add(this.panel4);
			this.pnlTopMenuBar.Location = new System.Drawing.Point(1, 1);
			this.pnlTopMenuBar.Margin = new System.Windows.Forms.Padding(2);
			this.pnlTopMenuBar.Name = "pnlTopMenuBar";
			this.pnlTopMenuBar.Size = new System.Drawing.Size(1000, 3);
			this.pnlTopMenuBar.TabIndex = 46;
			// 
			// panel4
			// 
			this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.panel4.Controls.Add(this.panel5);
			this.panel4.Location = new System.Drawing.Point(2, 0);
			this.panel4.Margin = new System.Windows.Forms.Padding(2);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(1000, 2);
			this.panel4.TabIndex = 50;
			// 
			// panel5
			// 
			this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.panel5.Location = new System.Drawing.Point(1, 1);
			this.panel5.Margin = new System.Windows.Forms.Padding(2);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(1000, 2);
			this.panel5.TabIndex = 49;
			// 
			// bannerTimer
			// 
			this.bannerTimer.Enabled = true;
			// 
			// contextMenuStrip1
			// 
			this.contextMenuStrip1.Name = "contextMenuStrip1";
			this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
			// 
			// panel6
			// 
			this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
			this.panel6.Location = new System.Drawing.Point(0, 1);
			this.panel6.Margin = new System.Windows.Forms.Padding(2);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(1000, 2);
			this.panel6.TabIndex = 49;
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.BackColor = System.Drawing.Color.White;
			this.flowLayoutPanel1.Location = new System.Drawing.Point(770, 9);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Size = new System.Drawing.Size(108, 42);
			this.flowLayoutPanel1.TabIndex = 87;
			// 
			// btnCarHome
			// 
			this.btnCarHome.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCarHome.BackgroundImage")));
			this.btnCarHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.btnCarHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCarHome.Location = new System.Drawing.Point(9, 366);
			this.btnCarHome.Margin = new System.Windows.Forms.Padding(2);
			this.btnCarHome.Name = "btnCarHome";
			this.btnCarHome.Size = new System.Drawing.Size(75, 75);
			this.btnCarHome.TabIndex = 57;
			this.btnCarHome.UseVisualStyleBackColor = true;
			this.btnCarHome.Click += new System.EventHandler(this.btnCarHome_Click);
			// 
			// btnCarExit
			// 
			this.btnCarExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCarExit.BackgroundImage")));
			this.btnCarExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.btnCarExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCarExit.Location = new System.Drawing.Point(9, 456);
			this.btnCarExit.Margin = new System.Windows.Forms.Padding(2);
			this.btnCarExit.Name = "btnCarExit";
			this.btnCarExit.Size = new System.Drawing.Size(75, 75);
			this.btnCarExit.TabIndex = 56;
			this.btnCarExit.UseVisualStyleBackColor = true;
			this.btnCarExit.Click += new System.EventHandler(this.btnCarExit_Click);
			// 
			// btnCarAdd
			// 
			this.btnCarAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCarAdd.BackgroundImage")));
			this.btnCarAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.btnCarAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCarAdd.Location = new System.Drawing.Point(9, 96);
			this.btnCarAdd.Margin = new System.Windows.Forms.Padding(2);
			this.btnCarAdd.Name = "btnCarAdd";
			this.btnCarAdd.Size = new System.Drawing.Size(75, 75);
			this.btnCarAdd.TabIndex = 55;
			this.btnCarAdd.UseVisualStyleBackColor = true;
			this.btnCarAdd.Click += new System.EventHandler(this.btnCarAdd_Click);
			// 
			// btnCarEdit
			// 
			this.btnCarEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCarEdit.BackgroundImage")));
			this.btnCarEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.btnCarEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCarEdit.Location = new System.Drawing.Point(9, 186);
			this.btnCarEdit.Margin = new System.Windows.Forms.Padding(2);
			this.btnCarEdit.Name = "btnCarEdit";
			this.btnCarEdit.Size = new System.Drawing.Size(75, 75);
			this.btnCarEdit.TabIndex = 54;
			this.btnCarEdit.UseVisualStyleBackColor = true;
			this.btnCarEdit.Click += new System.EventHandler(this.btnCarEdit_Click);
			// 
			// btnCarDelete
			// 
			this.btnCarDelete.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCarDelete.BackgroundImage")));
			this.btnCarDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.btnCarDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCarDelete.Location = new System.Drawing.Point(9, 276);
			this.btnCarDelete.Margin = new System.Windows.Forms.Padding(2);
			this.btnCarDelete.Name = "btnCarDelete";
			this.btnCarDelete.Size = new System.Drawing.Size(75, 75);
			this.btnCarDelete.TabIndex = 53;
			this.btnCarDelete.UseVisualStyleBackColor = true;
			this.btnCarDelete.Click += new System.EventHandler(this.btnCarDelete_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
			this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBox1.Location = new System.Drawing.Point(-103, -2);
			this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(1089, 55);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 47;
			this.pictureBox1.TabStop = false;
			// 
			// tabRep
			// 
			this.tabRep.Location = new System.Drawing.Point(4, 22);
			this.tabRep.Name = "tabRep";
			this.tabRep.Size = new System.Drawing.Size(857, 452);
			this.tabRep.TabIndex = 3;
			this.tabRep.Text = "Report";
			this.tabRep.UseVisualStyleBackColor = true;
			// 
			// frmCar
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(984, 561);
			this.Controls.Add(this.flowLayoutPanel1);
			this.Controls.Add(this.panel6);
			this.Controls.Add(this.btnCarHome);
			this.Controls.Add(this.btnCarExit);
			this.Controls.Add(this.btnCarAdd);
			this.Controls.Add(this.btnCarEdit);
			this.Controls.Add(this.btnCarDelete);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.tabCar);
			this.Controls.Add(this.lblCarTitle);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.pnlTopMenuBar);
			this.Controls.Add(this.pictureBox1);
			this.Name = "frmCar";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Desmond Motors | Sales Management System | © PLAB Software Solutions 2020";
			this.Load += new System.EventHandler(this.frmCar_Load);
			this.Shown += new System.EventHandler(this.frmCar_Shown);
			this.tabCarEdit.ResumeLayout(false);
			this.tabCarEdit.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.txtEditCarMileage)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.errP)).EndInit();
			this.tabCar.ResumeLayout(false);
			this.tabCarDisplay.ResumeLayout(false);
			this.tabCarDisplay.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvCar)).EndInit();
			this.tabCarAdd.ResumeLayout(false);
			this.tabCarAdd.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.txtAddCarMileage)).EndInit();
			this.panel1.ResumeLayout(false);
			this.pnlTopMenuBar.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tabCarEdit;
        private System.Windows.Forms.Label lblEditCarEdit;
        private System.Windows.Forms.Label lblAddCarReset;
        private System.Windows.Forms.Button btnAddCarReset;
        private System.Windows.Forms.Label lblAddCarBtn;
        private System.Windows.Forms.Button btnAddCarAdd;
        private System.Windows.Forms.ErrorProvider errP;
        private System.Windows.Forms.Button btnCarHome;
        private System.Windows.Forms.Button btnCarExit;
        private System.Windows.Forms.Button btnCarAdd;
        private System.Windows.Forms.Button btnCarEdit;
        private System.Windows.Forms.Button btnCarDelete;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TabControl tabCar;
        private System.Windows.Forms.TabPage tabCarDisplay;
        private System.Windows.Forms.DataGridView dgvCar;
        private System.Windows.Forms.TabPage tabCarAdd;
        private System.Windows.Forms.Label lblAddCarBody;
        private System.Windows.Forms.Label lblCarAddHeader;
        private System.Windows.Forms.ComboBox cmbAddCarDoorNo;
        private System.Windows.Forms.Label lblAddCarDoorNo;
        private System.Windows.Forms.Label lblAddCarCondition;
        private System.Windows.Forms.Label lblAddCarYear;
        private System.Windows.Forms.TextBox txtAddCarInterior;
        private System.Windows.Forms.TextBox txtAddCarModel;
        private System.Windows.Forms.Label lblAddCarColour;
        private System.Windows.Forms.Label lblAddCarTransmission;
        private System.Windows.Forms.Label lblAddCarInterior;
        private System.Windows.Forms.Label lblAddCarPurchasePrice;
        private System.Windows.Forms.Label lblAddCarModel;
        private System.Windows.Forms.ComboBox cmbAddCarMake;
        private System.Windows.Forms.Label lblAddCarMake;
        private System.Windows.Forms.Label lblAddCarRegNo;
        private System.Windows.Forms.Label lblCarTitle;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnlTopMenuBar;
        private System.Windows.Forms.Timer bannerTimer;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.ComboBox cmbAddCarBody;
        private System.Windows.Forms.TextBox txtAddCarColour;
        private System.Windows.Forms.DateTimePicker dtpAddCarYear;
        private System.Windows.Forms.Label lblAddCarSalePrice;
        private System.Windows.Forms.Label lblAddCarMileage;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.MaskedTextBox txtAddCarReg;
        private System.Windows.Forms.ComboBox cmbAddCarCondition;
        private System.Windows.Forms.MaskedTextBox txtAddCarSalePrice;
        private System.Windows.Forms.MaskedTextBox txtAddCarPurchasePrice;
        private System.Windows.Forms.MaskedTextBox txtEditCarSalePrice;
        private System.Windows.Forms.MaskedTextBox txtEditCarPurchasePrice;
        private System.Windows.Forms.ComboBox cmbEditCarCondition;
        private System.Windows.Forms.Label lblEditCarMileage;
        private System.Windows.Forms.Label lblEditCarSalePrice;
        private System.Windows.Forms.DateTimePicker dtpEditCarYear;
        private System.Windows.Forms.TextBox txtEditCarColour;
        private System.Windows.Forms.ComboBox cmbEditCarBody;
        private System.Windows.Forms.Label lblEditCarBody;
        private System.Windows.Forms.Label lblCarEditHeader;
        private System.Windows.Forms.ComboBox cmbEditCarDoorNo;
        private System.Windows.Forms.Label lblEditCarDoorNo;
        private System.Windows.Forms.Label lblEditCarConidtion;
        private System.Windows.Forms.Label lblEditCarYear;
        private System.Windows.Forms.TextBox txtEditCarInterior;
        private System.Windows.Forms.TextBox txtEditCarModel;
        private System.Windows.Forms.Label lblEditCarColour;
        private System.Windows.Forms.Label lblEditCarTransmission;
        private System.Windows.Forms.Label lblEditCarInterior;
        private System.Windows.Forms.Label lblEditCarPurchasePrice;
        private System.Windows.Forms.Label lblEditCarModel;
        private System.Windows.Forms.ComboBox cmbEditCarMake;
        private System.Windows.Forms.Label lblEditCarMake;
        private System.Windows.Forms.Label lblEditCarReg;
        private System.Windows.Forms.ComboBox cmbEditCarTransmission;
        private System.Windows.Forms.ComboBox cmbAddCarTransmission;
        private System.Windows.Forms.NumericUpDown txtAddCarMileage;
        private System.Windows.Forms.NumericUpDown txtEditCarMileage;
        private System.Windows.Forms.TextBox txtSearchMake;
        private System.Windows.Forms.Label lblSearchReg;
        private System.Windows.Forms.MaskedTextBox txtEditCarRegNo;
        private System.Windows.Forms.TabPage tabRep;
    }
}