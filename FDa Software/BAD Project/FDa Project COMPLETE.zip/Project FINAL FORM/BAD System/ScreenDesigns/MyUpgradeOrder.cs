﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScreenDesigns
{
    class MyUpgradeOrder
    {
        private DateTime dateOrdered, dateCompleted;
        private string upgradeOrderID, regNo;

        public MyUpgradeOrder()
        {
            this.upgradeOrderID = "";
            this.regNo = "";
            this.dateOrdered = DateTime.Today;
            this.dateCompleted = DateTime.Today;
        }

        public MyUpgradeOrder(DateTime dateOrdered, DateTime dateCompleted, string upgradeOrderID, string regNo)
        {
            this.dateCompleted = dateOrdered;
            this.dateCompleted = dateCompleted;
            this.upgradeOrderID = upgradeOrderID;
            this.regNo = regNo;
        }

        public string UpgradeOrderID
        {
            get { return upgradeOrderID; }
            set { upgradeOrderID = value; }
            
        }

        public string RegNo
        {
            get { return regNo; }
            set { regNo = value; }
        }

        public DateTime DateOrdered
        {
            get { return dateOrdered; }
            set { dateOrdered = value; }
        }

        public DateTime DateCompleted
        {
            get { return dateCompleted; }
            set { dateCompleted = value; }
        }
    }
}
