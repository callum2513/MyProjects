﻿using CrystalDecisions.Shared;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScreenDesigns
{
    public partial class frmUpgrades : Form
    {
        SqlDataAdapter daUpgrade, daUpgradeSearch, daMake, daSupplierName, daSupplier;
        DataSet dsDesmonds = new DataSet();
        SqlCommandBuilder cmdBUpgrade, cmdbUpgradeSearch, cmdBMake, cmdBSupplier;
        DataRow drUpgrade;
        String connStr, sqlUpgrade, sqlUpgradeSearch, sqlMake, sqlSupplier, sqlSupplierName;
        int selectedTab = 0;
        bool upgradeSelected = false;
        int upgradeNoSelected = 0;
        String upgradeID = "UP";
        String tempupgrade = "";
        int tempUpgradeID = 0;
        String[] upgradeTempArray = new String[4];
        int upgradeTempCMBMake = 0;


        lowStock ls = new lowStock();
        allStock alls = new allStock();


        private void txtDisplaySearch_TextChanged(object sender, EventArgs e)
        {
            upgradeDataGrid();
        }

        private void btnDisplayExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMaintenance frmMain = new frmMaintenance();
            frmMain.ShowDialog();

        }

        private void btnDisplayAdd_Click(object sender, EventArgs e)
        {
            tabUpgrades.SelectedIndex = 1;
        }

        private void btnDisplayEdit_Click(object sender, EventArgs e)
        {
            tabUpgrades.SelectedIndex = 2;
        }

        private void btnDisplayDelete_Click(object sender, EventArgs e)
        {
            if (dgvUpgrades.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an upgrade from the list", "Upgrades");
            }
            else
            {
                drUpgrade = dsDesmonds.Tables["upgradeStock"].Rows.Find(dgvUpgrades.SelectedRows[0].Cells[0].Value);

                string tempName = drUpgrade["MakeID"].ToString() + " " + drUpgrade["UpgradeDesc"].ToString() + "?";

                if (MessageBox.Show("Are you sure you want to delete " + tempName, "Delete Upgrades", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    try
                    {
                        drUpgrade.Delete();
                        daUpgrade.Update(dsDesmonds, "upgradeStock");
                    }
                    catch (SqlException)
                    {

                        MessageBox.Show("Can't Delete this upgrade!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        drUpgrade.RejectChanges();
                    }

                }
            }
        }

        private void tabUpgrades_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool ok = true;

            if (lblEditEdit.Text.Equals("Save") && tabUpgrades.SelectedIndex != 2)
            {
                ok = false;
                tabUpgrades.SelectedIndex = 2;
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to cancel any changes?", "Cancel Changes", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    txtEditUpgradeDesc.Text = upgradeTempArray[0];
                    txtEditSellingPrice.Text = upgradeTempArray[1];
                    txtEditPurchasePrice.Text = upgradeTempArray[2];
                    txtEditQuantity.Text = upgradeTempArray[3];
                    cmbEditMakeID.SelectedIndex = upgradeTempCMBMake;

                    btnDisplayAdd.Enabled = true;
                    btnDisplayDelete.Enabled = true;
                    btnDisplayEdit.Enabled = true;
                    btnHome.Enabled = true;

                    txtEditPurchasePrice.Clear();
                    txtEditQuantity.Clear();
                    txtEditSellingPrice.Clear();
                    txtEditUpgradeDesc.Clear();
                    lblEditDisplaySupplierID.Text = "";
                    lblEditDisplaySupplierName.Text = "";

                    txtEditPurchasePrice.Enabled = false;
                    txtEditQuantity.Enabled = false;
                    txtEditSellingPrice.Enabled = false;
                    txtEditUpgradeDesc.Enabled = false;
                    txtEditPurchasePrice.Enabled = false;
                    cmbEditMakeID.Enabled = false;


                    
                    lblEditEdit.Text = "Edit";
                }
                else
                {
                    
                }
            }
            else
            {
                selectedTab = tabUpgrades.SelectedIndex;
                tabUpgrades.TabPages[tabUpgrades.SelectedIndex].Focus();
                tabUpgrades.TabPages[tabUpgrades.SelectedIndex].CausesValidation = true;

                switch (tabUpgrades.SelectedIndex)
                {
                    case 0: //When display tab selected
                        {
                            this.Size = new Size(919, 593);
                            tabUpgrades.Size = new Size(1008, 518);
                            dgvUpgrades.Size = new Size(777, 423);
                            dsDesmonds.Tables["upgradeStock"].Clear();
                            daUpgrade.Fill(dsDesmonds, "upgradeStock");

                            Array.Clear(upgradeTempArray, 0, 4);
                            btnEditCancel.Enabled = false;

                            cmbDisplaySearch.Visible = true;
                            txtDisplaySearch.Visible = true;

                            txtEditPurchasePrice.Clear();
                            txtEditQuantity.Clear();
                            txtEditSellingPrice.Clear();
                            txtEditUpgradeDesc.Clear();
                            lblEditDisplaySupplierID.Text = "";
                            lblEditDisplaySupplierName.Text = "";

                            txtEditPurchasePrice.Enabled = false;
                            txtEditQuantity.Enabled = false;
                            txtEditSellingPrice.Enabled = false;
                            txtEditUpgradeDesc.Enabled = false;
                            txtEditPurchasePrice.Enabled = false;
                            cmbEditMakeID.Enabled = false;



                            btnEditCancel.Enabled = false;
                            lblEditEdit.Text = "Edit";

                            break;
                        }

                    case 1: //When add tab selected
                        {
                            this.Size = new Size(919, 593);
                            tabUpgrades.Size = new Size(776, 451);
                            cmbDisplaySearch.Visible = false;
                            txtDisplaySearch.Visible = false;
                            int noRows = dsDesmonds.Tables["upgradeStock"].Rows.Count;

                            if (noRows == 0)
                            {
                                lblAddDisplayUpgradeID.Text = "10000";

                            }
                            else
                            {
                                getNumber(noRows);
                            }

                            errP.Clear();
                            clearAddForm();

                            sqlMake = @"select * from make";
                            daMake = new SqlDataAdapter(sqlMake, connStr);
                            cmdBMake = new SqlCommandBuilder(daMake);
                            daMake.FillSchema(dsDesmonds, SchemaType.Source, "make");
                            daMake.Fill(dsDesmonds, "make");

                            sqlSupplier = @"select * from supplier";
                            daSupplier = new SqlDataAdapter(sqlSupplier, connStr);
                            cmdBSupplier = new SqlCommandBuilder(daSupplier);
                            daSupplier.FillSchema(dsDesmonds, SchemaType.Source, "supplier");
                            daSupplier.Fill(dsDesmonds, "supplier");


                            cmbAddMakeID.DataSource = dsDesmonds.Tables["make"];
                            cmbAddMakeID.DisplayMember = "MakeDesc";
                            cmbAddMakeID.ValueMember = "MakeID";
                            cmbAddMakeID.SelectedIndex = -1;




                            cmbAddSupplier.DataSource = dsDesmonds.Tables["supplier"];
                            cmbAddSupplier.DisplayMember = "CompanyName";
                            cmbAddSupplier.ValueMember = "SupplierID";
                            cmbAddSupplier.SelectedIndex = -1;

                            break;
                        }
                    case 2: //When edit tab selected
                        {
                            this.Size = new Size(919, 593);
                            tabUpgrades.Size = new Size(776, 451);
                            cmbDisplaySearch.Visible = false;
                            txtDisplaySearch.Visible = false;

                            if (upgradeNoSelected == 0)
                            {
                                tabUpgrades.SelectedIndex = 2;
                                break;
                            }
                            else
                            {

                                lblEditDisplayUpgradeID.Text = (upgradeID + upgradeNoSelected.ToString());

                                drUpgrade = dsDesmonds.Tables["upgradeStock"].Rows.Find(lblEditDisplayUpgradeID.Text);

                                if (drUpgrade == null)
                                {
                                    MessageBox.Show("Row no longer exists.");
                                    tabUpgrades.SelectedIndex = 0;

                                }
                                else
                                {
                                    string temp = "'" + drUpgrade.Field<string>("SupplierID") + "'";



                                    sqlMake = @"select * from make";
                                    daMake = new SqlDataAdapter(sqlMake, connStr);
                                    cmdBMake = new SqlCommandBuilder(daMake);
                                    daMake.FillSchema(dsDesmonds, SchemaType.Source, "make");
                                    daMake.Fill(dsDesmonds, "make");


                                    cmbEditMakeID.DataSource = dsDesmonds.Tables["make"];
                                    cmbEditMakeID.DisplayMember = "MakeDesc";
                                    cmbEditMakeID.ValueMember = "MakeID";

                                    switch (drUpgrade["MakeID"].ToString())
                                    {
                                        case "AUD":
                                            cmbEditMakeID.SelectedIndex = 0;
                                            break;
                                        case "FIA":
                                            cmbEditMakeID.SelectedIndex = 1;
                                            break;
                                        case "FRD":
                                            cmbEditMakeID.SelectedIndex = 2;
                                            break;
                                        case "HON":
                                            cmbEditMakeID.SelectedIndex = 3;
                                            break;
                                        case "NIS":
                                            cmbEditMakeID.SelectedIndex = 4;
                                            break;
                                        case "REN":
                                            cmbEditMakeID.SelectedIndex = 5;
                                            break;
                                        default:
                                            break;
                                    }

                                    txtEditUpgradeDesc.Text = drUpgrade["UpgradeDesc"].ToString();
                                    txtEditSellingPrice.Text = drUpgrade["SellPrice"].ToString();

                                    string newTemp = "";
                                    using (SqlConnection conn = new SqlConnection(connStr))
                                    {
                                        conn.Open();
                                        using (SqlCommand command = new SqlCommand(@"select distinct supplier.CompanyName from upgradeStock
                                                                            inner join supplier on supplier.SupplierID = upgradeStock.SupplierID
                                                                            where upgradeStock.SupplierID like" + temp, conn))
                                        {
                                            SqlDataReader read = command.ExecuteReader();

                                            while (read.Read())
                                            {
                                                newTemp = read["CompanyName"] as string;
                                            }
                                        }
                                    }

                                    lblEditDisplaySupplierName.Text = newTemp;




                                    lblEditDisplaySupplierID.Text = drUpgrade["SupplierID"].ToString();



                                    txtEditQuantity.Text = drUpgrade["QtyInStock"].ToString();
                                    txtEditPurchasePrice.Text = drUpgrade["PurchasePrice"].ToString();
                                }
                                break;
                            }

                        }
                    case 3: //When reports tab  selected
                        {
                            this.Size = new Size(1139, 623);
                            tabUpgrades.Size = new Size(983, 454);
                            cmbDisplaySearch.Visible = false;
                            txtDisplaySearch.Visible = false;

                            
                            break;

                        }
                    default:
                        break;
                }
            }
            
        }

        private void btnEditCancel_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to cancel any changes?", "Cancel Changes", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                txtEditUpgradeDesc.Text = upgradeTempArray[0];
                txtEditSellingPrice.Text = upgradeTempArray[1];
                txtEditPurchasePrice.Text = upgradeTempArray[2];
                txtEditQuantity.Text = upgradeTempArray[3];
                cmbEditMakeID.SelectedIndex = upgradeTempCMBMake;

                btnDisplayAdd.Enabled = true;
                btnDisplayDelete.Enabled = true;
                btnDisplayEdit.Enabled = true;
                btnHome.Enabled = true;

            }
            else if (dialogResult == DialogResult.No)
            {
                //do nothing
            }
        }

        private void cmbDisplaySearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtDisplaySearch.Enabled = true;
        }

        

        private void btnHome_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMainMenu frmMM = new frmMainMenu();
            frmMM.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            crystalReportViewer1.ReportSource = alls;
        }

        private void btnLowStock_Click(object sender, EventArgs e)
        {
            try
            {

                ls.SetParameterValue("MakeCK", cmbMake.SelectedValue.ToString());
                crystalReportViewer1.ReportSource = ls;

                if (txtLowStock.Text.Trim().Equals(""))
                {
                    ls.SetParameterValue("QtyCheck", 1000);
                    crystalReportViewer1.ReportSource = ls;
                }
                else
                {
                    ls.SetParameterValue("QtyCheck", txtLowStock.Text.Trim());
                    crystalReportViewer1.ReportSource = ls;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid input!");
            }
        }

        private void cmbMake_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tabAdd_Click(object sender, EventArgs e)
        {

        }

        private void getNumber(int noRows)
        {
            drUpgrade = dsDesmonds.Tables["upgradeStock"].Rows[noRows - 1];
            tempupgrade = drUpgrade["UpgradeID"].ToString();
            tempupgrade = tempupgrade.Substring(2, 5);
            tempUpgradeID = Int32.Parse(tempupgrade);
            tempUpgradeID++;
            String strUpgradeID = (upgradeID + (tempUpgradeID));
            lblAddDisplayUpgradeID.Text = (strUpgradeID);
        }

        void clearAddForm()
        {
            txtAddUpgradeDesc.Clear();
            txtAddSellingPrice.Clear();
            txtAddQuantity.Clear();
            txtAddPurchasePrice.Clear();
            cmbAddMakeID.SelectedIndex = -1;
        
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnAddAdd_Click(object sender, EventArgs e)
        {
            MyUpgradeStock myStock = new MyUpgradeStock(); // makes a new upgrade stock instance
            bool ok = true;
            errP.Clear();
            Regex regexDec = new Regex("^(-?)(0|([1-9][0-9]*))(\\.[0-9]+)?$");

            try
            {
                myStock.UpgradeID = lblAddDisplayUpgradeID.Text.Trim();
            }
            catch (MyException MyEx)
            {
                ok = false;
                errP.SetError(lblAddDisplayUpgradeID, MyEx.toString());
            }

            try
            {
                myStock.UpgradeDesc = txtAddUpgradeDesc.Text.Trim();
            }
            catch (MyException MyEx)
            {
                ok = false;
                errP.SetError(txtAddUpgradeDesc, MyEx.toString());
            }

            try 
            {
                myStock.SellPrice = double.Parse(txtAddSellingPrice.Text.Trim());

            }
            catch (FormatException)
            {
                ok = false;
                errP.SetError(txtAddSellingPrice, "Entry was not in correct format! (Must be Decimal)");
            }
            catch (MyException MyEx)
            {
                ok = false;
                errP.SetError(txtAddSellingPrice, MyEx.ToString());
            }

            try
            {
                myStock.PurchasePrice = double.Parse(txtAddPurchasePrice.Text.Trim());
            }
            catch (FormatException)
            {
                ok = false;
                errP.SetError(txtAddPurchasePrice, "Entry was not in correct format! (Must be Decimal)");
            }
            catch (MyException MyEx)
            {
                ok = false;
                errP.SetError(txtAddPurchasePrice, MyEx.toString());
            }

            try
            {
                myStock.SupplierID = cmbAddSupplier.SelectedValue.ToString();
            }
            catch (NullReferenceException)
            {
                ok = false;
                errP.SetError(cmbAddSupplier, "No supplier selected!");
            }

            try
            {
                myStock.QtyInStock = Int32.Parse(txtAddQuantity.Text.Trim());
            }
            catch (FormatException)
            {
                ok = false;
                errP.SetError(txtAddQuantity, "Entry was not in correct format! (Must be an Integer)");
            }
            catch (MyException MyEx)
            {
                ok = false;
                errP.SetError(txtAddQuantity, MyEx.toString());
            }

            try
            {
                myStock.MakeID = cmbAddMakeID.SelectedValue.ToString();
            }
            catch (NullReferenceException)
            {
                ok = false;
                errP.SetError(cmbAddMakeID, "No makeID selected!");
            }


            try
            {
                if (ok)
                {
                    drUpgrade = dsDesmonds.Tables["upgradeStock"].NewRow();

                    drUpgrade["UpgradeID"] = myStock.UpgradeID;
                    drUpgrade["UpgradeDesc"] = myStock.UpgradeDesc;
                    drUpgrade["SellPrice"] = myStock.SellPrice;
                    drUpgrade["QtyInStock"] = myStock.QtyInStock;
                    drUpgrade["SupplierID"] = myStock.SupplierID;
                    drUpgrade["PurchasePrice"] = myStock.PurchasePrice;
                    drUpgrade["MakeID"] = myStock.MakeID;
                    cmbAddMakeID.SelectedIndex = -1;
                    cmbAddSupplier.SelectedIndex = -1;

                    dsDesmonds.Tables["upgradeStock"].Rows.Add(drUpgrade);
                    daUpgrade.Update(dsDesmonds, "upgradeStock");

                    MessageBox.Show("Upgrade Added.");

                    if (MessageBox.Show("Would you like to add another upgrade?", "Add Upgrade", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes) 
                    {
                        clearAddForm();
                        getNumber(dsDesmonds.Tables["upgradeStock"].Rows.Count);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("" + ex.TargetSite + "" + ex.Message, "Error!", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
            }

        }

        private void upgradeDataGrid()
        {
            dgvUpgrades.DataSource = null;
            dgvUpgrades.Refresh();

            String tempPara = ("'%" + txtDisplaySearch.Text.ToString() + "%'");
            String tempAtt = cmbDisplaySearch.Text.ToString();

            sqlUpgradeSearch = @"select * from upgradeStock where " + tempAtt + " like " + tempPara;
            daUpgradeSearch = new SqlDataAdapter(sqlUpgradeSearch, connStr);
            cmdbUpgradeSearch = new SqlCommandBuilder(daUpgradeSearch);
            dsDesmonds.Tables["upgradeStock"].Clear();
            daUpgradeSearch.FillSchema(dsDesmonds, SchemaType.Source, "upgradeStock");
            daUpgradeSearch.Fill(dsDesmonds, "upgradeStock");




            dgvUpgrades.DataSource = dsDesmonds.Tables["upgradeStock"];

            dgvUpgrades.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            dgvUpgrades.Refresh();
        }

        public frmUpgrades()
        {
            InitializeComponent();
        }

        private void frmUpgrades_Load(object sender, EventArgs e)
        {
            connStr = @"Data Source = .; Initial Catalog = Desmonds; Integrated Security = true";
            sqlUpgrade = @"select * from upgradeStock";
            daUpgrade = new SqlDataAdapter(sqlUpgrade, connStr);
            cmdBUpgrade = new SqlCommandBuilder(daUpgrade);
            daUpgrade.FillSchema(dsDesmonds, SchemaType.Source, "upgradeStock");
            daUpgrade.Fill(dsDesmonds, "upgradeStock");
            dgvUpgrades.DataSource = dsDesmonds.Tables["upgradeStock"];
            dgvUpgrades.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

            connStr = @"Data Source = .; Initial Catalog = Desmonds; Integrated Security = true";
            sqlMake = @"select * from make";
            daMake = new SqlDataAdapter(sqlMake, connStr);
            cmdBMake = new SqlCommandBuilder(daMake);
            daMake.FillSchema(dsDesmonds, SchemaType.Source, "make");
            daMake.Fill(dsDesmonds, "make");


            cmbMake.DataSource = dsDesmonds.Tables["make"];
            cmbMake.DisplayMember = "MakeDesc";
            cmbMake.ValueMember = "MakeID";

            cmbAddMakeID.SelectedIndex = -1;
            cmbAddSupplier.SelectedIndex = -1;


            crystalReportViewer1.ReportSource = alls;

            txtEditPurchasePrice.Enabled = false;
            txtEditQuantity.Enabled = false;
            txtEditSellingPrice.Enabled = false;
            txtEditUpgradeDesc.Enabled = false;
            txtEditPurchasePrice.Enabled = false;
            cmbEditMakeID.Enabled = false;
            btnEditCancel.Enabled = false;

            txtDisplaySearch.Enabled = false;

            lblEditEdit.Text = "Edit";
        }

        private void btnEditEdit_Click(object sender, EventArgs e)
        {
            if (lblEditEdit.Text.Equals("Edit"))
            {
                if (lblEditDisplayUpgradeID.Text.Trim() != "-")
                { 
                    upgradeTempArray[0] = txtEditUpgradeDesc.Text.Trim();
                    upgradeTempArray[1] = txtEditSellingPrice.Text.Trim();
                    upgradeTempArray[2] = txtEditPurchasePrice.Text.Trim();
                    upgradeTempArray[3] = txtEditQuantity.Text.Trim();
                    upgradeTempCMBMake = cmbEditMakeID.SelectedIndex;
                    
                    txtEditPurchasePrice.Enabled = true;
                    txtEditQuantity.Enabled = true;
                    txtEditSellingPrice.Enabled = true;
                    txtEditUpgradeDesc.Enabled = true;
                    txtEditPurchasePrice.Enabled = true;
                    cmbEditMakeID.Enabled = true;

                    btnDisplayAdd.Enabled = false;
                    btnDisplayDelete.Enabled = false;
                    btnDisplayEdit.Enabled = false;
                    btnHome.Enabled = false;

                    btnEditCancel.Enabled = true;
                    lblEditEdit.Text = "Save";
                }
                else
                {
                    MessageBox.Show("No upgrade selected!");
                    tabUpgrades.SelectedIndex = 0;
                }

            }
            else if(lblEditEdit.Text.Equals("Save"))
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to save your changes?", "Save Changes", MessageBoxButtons.YesNo);

                if (dialogResult == DialogResult.Yes)
                {
                    MyUpgradeStock myStock = new MyUpgradeStock(); // makes a new upgrade stock instance
                    bool ok = true;
                    errP.Clear();
                    Regex regexDec = new Regex("^(-?)(0|([1-9][0-9]*))(\\.[0-9]+)?$");

                    try
                    {
                        myStock.UpgradeID = lblEditDisplayUpgradeID.Text.Trim();
                    }
                    catch (MyException MyEx)
                    {
                        ok = false;
                        errP.SetError(lblEditDisplayUpgradeID, MyEx.toString());
                    }

                    try
                    {
                        myStock.UpgradeDesc = txtEditUpgradeDesc.Text.Trim();
                    }
                    catch (MyException MyEx)
                    {
                        ok = false;
                        errP.SetError(txtEditUpgradeDesc, MyEx.toString());
                    }

                    try
                    {
                        myStock.SellPrice = double.Parse(txtEditSellingPrice.Text.Trim());

                    }
                    catch (FormatException)
                    {
                        ok = false;
                        errP.SetError(txtEditSellingPrice, "Entry was not in correct format! (Must be Decimal)");
                    }
                    catch (MyException MyEx)
                    {
                        ok = false;
                        errP.SetError(txtEditSellingPrice, MyEx.ToString());
                    }

                    try
                    {
                        myStock.PurchasePrice = double.Parse(txtEditPurchasePrice.Text.Trim());
                    }
                    catch (FormatException)
                    {
                        ok = false;
                        errP.SetError(txtEditPurchasePrice, "Entry was not in correct format! (Must be Decimal)");
                    }
                    catch (MyException MyEx)
                    {
                        ok = false;
                        errP.SetError(txtEditPurchasePrice, MyEx.toString());
                    }

                   

                    try
                    {
                        myStock.QtyInStock = Int32.Parse(txtEditQuantity.Text.Trim());
                    }
                    catch (FormatException)
                    {
                        ok = false;
                        errP.SetError(txtEditQuantity, "Entry was not in correct format! (Must be an Integer)");
                    }
                    catch (MyException MyEx)
                    {
                        ok = false;
                        errP.SetError(txtEditQuantity, MyEx.toString());
                    }

                    try
                    {
                        myStock.MakeID = cmbEditMakeID.SelectedValue.ToString();
                    }
                    catch (MyException MyEx)
                    {
                        ok = false;
                        errP.SetError(cmbEditMakeID, MyEx.toString());
                    }

                    try
                    {
                        if (ok)
                        {
                            drUpgrade.BeginEdit();

                            drUpgrade["UpgradeID"] = myStock.UpgradeID;
                            drUpgrade["UpgradeDesc"] = myStock.UpgradeDesc;
                            drUpgrade["SellPrice"] = myStock.SellPrice;
                            drUpgrade["QtyInStock"] = myStock.QtyInStock;
                            drUpgrade["PurchasePrice"] = myStock.PurchasePrice;
                            drUpgrade["MakeID"] = myStock.MakeID;

                            drUpgrade.EndEdit();
                            daUpgrade.Update(dsDesmonds, "upgradeStock");

                            MessageBox.Show("Stock Details Updated", "Stock");

                            txtEditPurchasePrice.Enabled = false;
                            txtEditQuantity.Enabled = false;
                            txtEditSellingPrice.Enabled = false;
                            txtEditUpgradeDesc.Enabled = false;
                            txtEditPurchasePrice.Enabled = false;
                            cmbEditMakeID.Enabled = false;
                            btnEditCancel.Enabled = false;

                            btnDisplayAdd.Enabled = true;
                            btnDisplayDelete.Enabled = true;
                            btnDisplayEdit.Enabled = true;
                            btnHome.Enabled = true;

                            lblEditEdit.Text = "Edit";
                            tabUpgrades.SelectedIndex = 0;

                        }
                    }
                    catch (MyException MyEx)
                    {
                        MessageBox.Show("" + MyEx.TargetSite + "" + MyEx.Message, "Error!", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
                    }
                }
            }
        }

        void EditTabValidate(object sender, CancelEventArgs e) //This is to ensure that the correct customer number is displayed in the edit tab when a customer is selected
        {

            if (dgvUpgrades.SelectedRows.Count == 0)
            {
                upgradeSelected = false;
                upgradeNoSelected = 0;
            }
            else if (dgvUpgrades.SelectedRows.Count == 1)
            {
                upgradeSelected = true;


                tempupgrade = (dgvUpgrades.SelectedRows[0].Cells[0].Value).ToString();
                tempupgrade = tempupgrade.Substring(2, 5);
                tempUpgradeID = Int32.Parse(tempupgrade);

                upgradeNoSelected = tempUpgradeID;
            }
        }

  

        void AddTabValidate(object sender, CancelEventArgs e) //This is to ensure that the correct staff number is displayed in the add tab when a staff is selected
        {
            if (dgvUpgrades.SelectedRows.Count == 0)
            {
                upgradeSelected = false;
                upgradeNoSelected = 0;
            }
            else if (dgvUpgrades.SelectedRows.Count == 1)
            {
                upgradeSelected = true;

                tempupgrade = (dgvUpgrades.SelectedRows[0].Cells[0].Value).ToString();
                tempupgrade = tempupgrade.Substring(2, 5);
                tempUpgradeID = Int32.Parse(tempupgrade);

                upgradeNoSelected = tempUpgradeID;
            }

        }


        private void frmUpgrades_Shown(object sender, EventArgs e)
        {
            tabUpgrades.TabPages[0].CausesValidation = true;
            tabUpgrades.TabPages[0].Validating += new CancelEventHandler(AddTabValidate);

            tabUpgrades.TabPages[2].CausesValidation = true;
            tabUpgrades.TabPages[2].Validating += new CancelEventHandler(EditTabValidate);
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
