﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScreenDesigns
{
    class MyUpgradeOrderDetails
    {
        String upgradeOrderID, upgradeID, staffID;
        int quantity;


        public MyUpgradeOrderDetails()
        {
            this.upgradeID = "";
            this.upgradeOrderID = "";
            this.staffID = "";
            this.quantity = 0;
        }

        public MyUpgradeOrderDetails(string upgradeID, string upgradeOrderID, string staffID, int quantity)
        {
            this.upgradeID = upgradeID;
            this.upgradeOrderID = upgradeOrderID;
            this.staffID = staffID;
            this.quantity = quantity;
        }

        public string UpgradeID
        {
            get { return upgradeID; }
            set { upgradeID = value; }
        }

        public string UpgradeOrderID
        {
            get { return upgradeOrderID; }
            set { upgradeOrderID = value; }
        }
        public string StaffID
        {
            get { return staffID; }
            set { staffID = value; }
        }

        public int Quantity
        {
            get { return quantity; }
            set
            {
                if (MyValidation.validNumber(value.ToString()))
                {
                    quantity = value;
                }
            }
        }

    }
}
