﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScreenDesigns
{
	public partial class Pics : Form
	{
		public Pics()
		{
			InitializeComponent();
		}

		private void tmrMove_Tick(object sender, EventArgs e)
		{
			pb1.Left -= 2;
			pb2.Left -= 2;

			if (pb1.Left == -100)
				pb1.Left = 100;

			if (pb2.Left <= -100)
				pb2.Left = pb1.Left + 100;

		}
	}
}
