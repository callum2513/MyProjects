﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScreenDesigns
{
    class MyFinanceAgreement
    {
        string financeID, regNo;
        DateTime agreementDate = DateTime.Now;
        int noOfPayments = 0;
        double monthlyPayment = 0, deposit = 0, tradeInValue = 0, interestRate = 0;

        public MyFinanceAgreement()
        {
            this.financeID = ""; this.regNo = "";
            this.agreementDate = DateTime.Now;
            this.noOfPayments = 0;
            this.monthlyPayment = 0; this.deposit = 0; this.tradeInValue = 0; this.interestRate = 0;
        }

        public MyFinanceAgreement(string financeID, string regNo, DateTime agreementDate, int noOfPayments, double monthlyPayment, double deposit, double tradeInValue, double interestRate)
        {
            this.financeID = financeID;
            this.regNo = regNo;
            this.agreementDate = agreementDate;
            this.noOfPayments = noOfPayments;
            this.monthlyPayment = monthlyPayment;
            this.deposit = deposit;
            this.tradeInValue = tradeInValue;
            this.interestRate = interestRate;
        }

        public string FinanceID
        {
            get { return financeID; }
            set { financeID = value; }
        }
        public string RegNo
        {
            get { return regNo; }
            set { regNo = value; }
        }
        public DateTime AgreementDate
        {
            get { return agreementDate; }
            set
            {
                if (value.Date >= DateTime.Now.Date)
                {
                    agreementDate = value;
                }
                else
                    throw new MyException("Agreement Date cannot be in the past");
            }
        }
        public int NoOfPayments
        {
            get { return noOfPayments; }
            set { noOfPayments = value; }
        }
        public double MonthlyPayment
        {
            get { return monthlyPayment; }
            set { monthlyPayment = value; }
        }
        public double Deposit
        {
            get { return deposit; }
            set { deposit = value; }
        }
        public double TradeInValue
        {
            get { return tradeInValue; }
            set { tradeInValue = value; }
        }
        public double InterestRate
        {
            get { return interestRate; }
            set { interestRate = value; }
        }

    }
}
