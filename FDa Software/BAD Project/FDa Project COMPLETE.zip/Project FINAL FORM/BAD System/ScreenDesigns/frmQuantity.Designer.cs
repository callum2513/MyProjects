﻿namespace ScreenDesigns
{
    partial class frmQuantity
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSelected = new System.Windows.Forms.Label();
            this.lblDisplayDesc = new System.Windows.Forms.Label();
            this.lblDisplayMake = new System.Windows.Forms.Label();
            this.lblMake = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.lblDisplaySupplier = new System.Windows.Forms.Label();
            this.lblSupplier = new System.Windows.Forms.Label();
            this.lblDisplayPrice = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblDisplayUpgradeID = new System.Windows.Forms.Label();
            this.lblUpgradeID = new System.Windows.Forms.Label();
            this.numQty = new System.Windows.Forms.NumericUpDown();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbStaffID = new System.Windows.Forms.ComboBox();
            this.btnExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numQty)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSelected
            // 
            this.lblSelected.AutoSize = true;
            this.lblSelected.Location = new System.Drawing.Point(2, 28);
            this.lblSelected.Name = "lblSelected";
            this.lblSelected.Size = new System.Drawing.Size(102, 13);
            this.lblSelected.TabIndex = 1;
            this.lblSelected.Text = "You have selected: ";
            // 
            // lblDisplayDesc
            // 
            this.lblDisplayDesc.AutoSize = true;
            this.lblDisplayDesc.Location = new System.Drawing.Point(110, 28);
            this.lblDisplayDesc.Name = "lblDisplayDesc";
            this.lblDisplayDesc.Size = new System.Drawing.Size(10, 13);
            this.lblDisplayDesc.TabIndex = 2;
            this.lblDisplayDesc.Text = "-";
            // 
            // lblDisplayMake
            // 
            this.lblDisplayMake.AutoSize = true;
            this.lblDisplayMake.Location = new System.Drawing.Point(110, 120);
            this.lblDisplayMake.Name = "lblDisplayMake";
            this.lblDisplayMake.Size = new System.Drawing.Size(10, 13);
            this.lblDisplayMake.TabIndex = 4;
            this.lblDisplayMake.Text = "-";
            // 
            // lblMake
            // 
            this.lblMake.AutoSize = true;
            this.lblMake.Location = new System.Drawing.Point(2, 120);
            this.lblMake.Name = "lblMake";
            this.lblMake.Size = new System.Drawing.Size(40, 13);
            this.lblMake.TabIndex = 3;
            this.lblMake.Text = "Make: ";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Location = new System.Drawing.Point(2, 156);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(83, 13);
            this.lblQuantity.TabIndex = 5;
            this.lblQuantity.Text = "Select quantity: ";
            // 
            // lblDisplaySupplier
            // 
            this.lblDisplaySupplier.AutoSize = true;
            this.lblDisplaySupplier.Location = new System.Drawing.Point(110, 96);
            this.lblDisplaySupplier.Name = "lblDisplaySupplier";
            this.lblDisplaySupplier.Size = new System.Drawing.Size(10, 13);
            this.lblDisplaySupplier.TabIndex = 8;
            this.lblDisplaySupplier.Text = "-";
            // 
            // lblSupplier
            // 
            this.lblSupplier.AutoSize = true;
            this.lblSupplier.Location = new System.Drawing.Point(2, 96);
            this.lblSupplier.Name = "lblSupplier";
            this.lblSupplier.Size = new System.Drawing.Size(51, 13);
            this.lblSupplier.TabIndex = 7;
            this.lblSupplier.Text = "Supplier: ";
            // 
            // lblDisplayPrice
            // 
            this.lblDisplayPrice.AutoSize = true;
            this.lblDisplayPrice.Location = new System.Drawing.Point(110, 73);
            this.lblDisplayPrice.Name = "lblDisplayPrice";
            this.lblDisplayPrice.Size = new System.Drawing.Size(10, 13);
            this.lblDisplayPrice.TabIndex = 10;
            this.lblDisplayPrice.Text = "-";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(2, 73);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(37, 13);
            this.lblPrice.TabIndex = 9;
            this.lblPrice.Text = "Price: ";
            // 
            // lblDisplayUpgradeID
            // 
            this.lblDisplayUpgradeID.AutoSize = true;
            this.lblDisplayUpgradeID.Location = new System.Drawing.Point(110, 51);
            this.lblDisplayUpgradeID.Name = "lblDisplayUpgradeID";
            this.lblDisplayUpgradeID.Size = new System.Drawing.Size(10, 13);
            this.lblDisplayUpgradeID.TabIndex = 12;
            this.lblDisplayUpgradeID.Text = "-";
            // 
            // lblUpgradeID
            // 
            this.lblUpgradeID.AutoSize = true;
            this.lblUpgradeID.Location = new System.Drawing.Point(2, 51);
            this.lblUpgradeID.Name = "lblUpgradeID";
            this.lblUpgradeID.Size = new System.Drawing.Size(68, 13);
            this.lblUpgradeID.TabIndex = 11;
            this.lblUpgradeID.Text = "Upgrade ID: ";
            // 
            // numQty
            // 
            this.numQty.Location = new System.Drawing.Point(113, 149);
            this.numQty.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numQty.Name = "numQty";
            this.numQty.Size = new System.Drawing.Size(162, 20);
            this.numQty.TabIndex = 13;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(45, 216);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 14;
            this.btnSubmit.Text = "submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 180);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Select Staff Member: ";
            // 
            // cmbStaffID
            // 
            this.cmbStaffID.FormattingEnabled = true;
            this.cmbStaffID.Items.AddRange(new object[] {
            "SF10000 - John Smith",
            "SF10001 - Mike Smith",
            "SF10002 - Jack Harkness",
            "SF10003 - Kevin ODonnell",
            "SF10004 - Jamie Hevron",
            "SF10005 - Greame Souness",
            "SF10006 - Aaron McClenaghan",
            "SF10007 - Rick Ashley",
            "SF10008 - Delia Smith",
            "SF10009 - Rose Tyler",
            "SF10010 - Amy Pond",
            "SF10011 - Clara Rodgers",
            "SF10012 - Martha Jones"});
            this.cmbStaffID.Location = new System.Drawing.Point(113, 177);
            this.cmbStaffID.Name = "cmbStaffID";
            this.cmbStaffID.Size = new System.Drawing.Size(162, 21);
            this.cmbStaffID.TabIndex = 16;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(138, 216);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 17;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmQuantity
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(298, 251);
            this.ControlBox = false;
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.cmbStaffID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.numQty);
            this.Controls.Add(this.lblDisplayUpgradeID);
            this.Controls.Add(this.lblUpgradeID);
            this.Controls.Add(this.lblDisplayPrice);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblDisplaySupplier);
            this.Controls.Add(this.lblSupplier);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.lblDisplayMake);
            this.Controls.Add(this.lblMake);
            this.Controls.Add(this.lblDisplayDesc);
            this.Controls.Add(this.lblSelected);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmQuantity";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmQuantity";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.frmQuantity_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numQty)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblSelected;
        private System.Windows.Forms.Label lblDisplayDesc;
        private System.Windows.Forms.Label lblDisplayMake;
        private System.Windows.Forms.Label lblMake;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lblDisplaySupplier;
        private System.Windows.Forms.Label lblSupplier;
        private System.Windows.Forms.Label lblDisplayPrice;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblDisplayUpgradeID;
        private System.Windows.Forms.Label lblUpgradeID;
        private System.Windows.Forms.NumericUpDown numQty;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbStaffID;
        private System.Windows.Forms.Button btnExit;
    }
}