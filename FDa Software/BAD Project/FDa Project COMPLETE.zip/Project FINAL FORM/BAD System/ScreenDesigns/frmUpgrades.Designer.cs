﻿namespace ScreenDesigns
{
    partial class frmUpgrades
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUpgrades));
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnDisplayExit = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.btnDisplayDelete = new System.Windows.Forms.Button();
            this.btnDisplayEdit = new System.Windows.Forms.Button();
            this.btnDisplayAdd = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.errP = new System.Windows.Forms.ErrorProvider(this.components);
            this.tabEdit = new System.Windows.Forms.TabPage();
            this.lblEditDisplaySupplierName = new System.Windows.Forms.Label();
            this.lblEditSupplierName = new System.Windows.Forms.Label();
            this.lblEditDisplaySupplierID = new System.Windows.Forms.Label();
            this.cmbEditMakeID = new System.Windows.Forms.ComboBox();
            this.lblEditMakeID = new System.Windows.Forms.Label();
            this.lblEditSupplierID = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnEditCancel = new System.Windows.Forms.Button();
            this.txtEditQuantity = new System.Windows.Forms.TextBox();
            this.txtEditPurchasePrice = new System.Windows.Forms.TextBox();
            this.txtEditUpgradeDesc = new System.Windows.Forms.TextBox();
            this.txtEditSellingPrice = new System.Windows.Forms.TextBox();
            this.lblEditDisplayUpgradeID = new System.Windows.Forms.Label();
            this.lblEditPurchasePrice = new System.Windows.Forms.Label();
            this.lblEditQuantity = new System.Windows.Forms.Label();
            this.lblEditSellingPrice = new System.Windows.Forms.Label();
            this.lblEditUpgradeDesc = new System.Windows.Forms.Label();
            this.lblEditUpgradeID = new System.Windows.Forms.Label();
            this.lblEditEdit = new System.Windows.Forms.Label();
            this.btnEditEdit = new System.Windows.Forms.Button();
            this.tabAdd = new System.Windows.Forms.TabPage();
            this.cmbAddSupplier = new System.Windows.Forms.ComboBox();
            this.cmbAddMakeID = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblAddEmail = new System.Windows.Forms.Label();
            this.lblAddClear = new System.Windows.Forms.Label();
            this.btnAddClear = new System.Windows.Forms.Button();
            this.txtAddQuantity = new System.Windows.Forms.TextBox();
            this.txtAddPurchasePrice = new System.Windows.Forms.TextBox();
            this.txtAddUpgradeDesc = new System.Windows.Forms.TextBox();
            this.txtAddSellingPrice = new System.Windows.Forms.TextBox();
            this.lblAddDisplayUpgradeID = new System.Windows.Forms.Label();
            this.lblAddMobileNo = new System.Windows.Forms.Label();
            this.lblAddPostcode = new System.Windows.Forms.Label();
            this.lblAddSellingPrice = new System.Windows.Forms.Label();
            this.lblAddUpgradeDesc = new System.Windows.Forms.Label();
            this.lblAddUpgradeID = new System.Windows.Forms.Label();
            this.lblAddBtnAdd = new System.Windows.Forms.Label();
            this.btnAddAdd = new System.Windows.Forms.Button();
            this.tabDisplay = new System.Windows.Forms.TabPage();
            this.dgvUpgrades = new System.Windows.Forms.DataGridView();
            this.txtDisplaySearch = new System.Windows.Forms.TextBox();
            this.cmbDisplaySearch = new System.Windows.Forms.ComboBox();
            this.tabUpgrades = new System.Windows.Forms.TabControl();
            this.tabReport = new System.Windows.Forms.TabPage();
            this.btnReset = new System.Windows.Forms.Button();
            this.lblDescSort = new System.Windows.Forms.Label();
            this.lblStockSearch = new System.Windows.Forms.Label();
            this.cmbMake = new System.Windows.Forms.ComboBox();
            this.txtLowStock = new System.Windows.Forms.TextBox();
            this.btnLowStock = new System.Windows.Forms.Button();
            this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.lowStockReport = new ScreenDesigns.lowStock();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errP)).BeginInit();
            this.tabEdit.SuspendLayout();
            this.tabAdd.SuspendLayout();
            this.tabDisplay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUpgrades)).BeginInit();
            this.tabUpgrades.SuspendLayout();
            this.tabReport.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(95, 54);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(3, 520);
            this.panel4.TabIndex = 54;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel5.Location = new System.Drawing.Point(-31, 0);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(3, 520);
            this.panel5.TabIndex = 38;
            // 
            // btnDisplayExit
            // 
            this.btnDisplayExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDisplayExit.BackgroundImage")));
            this.btnDisplayExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDisplayExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplayExit.Location = new System.Drawing.Point(12, 460);
            this.btnDisplayExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnDisplayExit.Name = "btnDisplayExit";
            this.btnDisplayExit.Size = new System.Drawing.Size(75, 75);
            this.btnDisplayExit.TabIndex = 59;
            this.btnDisplayExit.UseVisualStyleBackColor = true;
            this.btnDisplayExit.Click += new System.EventHandler(this.btnDisplayExit_Click);
            // 
            // btnHome
            // 
            this.btnHome.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHome.BackgroundImage")));
            this.btnHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.Location = new System.Drawing.Point(12, 370);
            this.btnHome.Margin = new System.Windows.Forms.Padding(2);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(75, 75);
            this.btnHome.TabIndex = 58;
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // btnDisplayDelete
            // 
            this.btnDisplayDelete.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDisplayDelete.BackgroundImage")));
            this.btnDisplayDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDisplayDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplayDelete.Location = new System.Drawing.Point(12, 278);
            this.btnDisplayDelete.Margin = new System.Windows.Forms.Padding(2);
            this.btnDisplayDelete.Name = "btnDisplayDelete";
            this.btnDisplayDelete.Size = new System.Drawing.Size(75, 75);
            this.btnDisplayDelete.TabIndex = 57;
            this.btnDisplayDelete.UseVisualStyleBackColor = true;
            this.btnDisplayDelete.Click += new System.EventHandler(this.btnDisplayDelete_Click);
            // 
            // btnDisplayEdit
            // 
            this.btnDisplayEdit.BackgroundImage = global::ScreenDesigns.Properties.Resources.icons8_edit_100;
            this.btnDisplayEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDisplayEdit.Location = new System.Drawing.Point(12, 184);
            this.btnDisplayEdit.Name = "btnDisplayEdit";
            this.btnDisplayEdit.Size = new System.Drawing.Size(75, 77);
            this.btnDisplayEdit.TabIndex = 56;
            this.btnDisplayEdit.UseVisualStyleBackColor = true;
            this.btnDisplayEdit.Click += new System.EventHandler(this.btnDisplayEdit_Click);
            // 
            // btnDisplayAdd
            // 
            this.btnDisplayAdd.BackgroundImage = global::ScreenDesigns.Properties.Resources.icons8_add_100;
            this.btnDisplayAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDisplayAdd.Location = new System.Drawing.Point(12, 90);
            this.btnDisplayAdd.Name = "btnDisplayAdd";
            this.btnDisplayAdd.Size = new System.Drawing.Size(75, 77);
            this.btnDisplayAdd.TabIndex = 55;
            this.btnDisplayAdd.UseVisualStyleBackColor = true;
            this.btnDisplayAdd.Click += new System.EventHandler(this.btnDisplayAdd_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(-87, -1);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1281, 55);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 52;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(-1, 53);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1300, 3);
            this.panel1.TabIndex = 60;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel2.Location = new System.Drawing.Point(-31, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(3, 520);
            this.panel2.TabIndex = 38;
            // 
            // errP
            // 
            this.errP.ContainerControl = this;
            // 
            // tabEdit
            // 
            this.tabEdit.Controls.Add(this.lblEditDisplaySupplierName);
            this.tabEdit.Controls.Add(this.lblEditSupplierName);
            this.tabEdit.Controls.Add(this.lblEditDisplaySupplierID);
            this.tabEdit.Controls.Add(this.cmbEditMakeID);
            this.tabEdit.Controls.Add(this.lblEditMakeID);
            this.tabEdit.Controls.Add(this.lblEditSupplierID);
            this.tabEdit.Controls.Add(this.label4);
            this.tabEdit.Controls.Add(this.btnEditCancel);
            this.tabEdit.Controls.Add(this.txtEditQuantity);
            this.tabEdit.Controls.Add(this.txtEditPurchasePrice);
            this.tabEdit.Controls.Add(this.txtEditUpgradeDesc);
            this.tabEdit.Controls.Add(this.txtEditSellingPrice);
            this.tabEdit.Controls.Add(this.lblEditDisplayUpgradeID);
            this.tabEdit.Controls.Add(this.lblEditPurchasePrice);
            this.tabEdit.Controls.Add(this.lblEditQuantity);
            this.tabEdit.Controls.Add(this.lblEditSellingPrice);
            this.tabEdit.Controls.Add(this.lblEditUpgradeDesc);
            this.tabEdit.Controls.Add(this.lblEditUpgradeID);
            this.tabEdit.Controls.Add(this.lblEditEdit);
            this.tabEdit.Controls.Add(this.btnEditEdit);
            this.tabEdit.Location = new System.Drawing.Point(4, 22);
            this.tabEdit.Name = "tabEdit";
            this.tabEdit.Size = new System.Drawing.Size(664, 453);
            this.tabEdit.TabIndex = 4;
            this.tabEdit.Text = "Edit";
            this.tabEdit.UseVisualStyleBackColor = true;
            // 
            // lblEditDisplaySupplierName
            // 
            this.lblEditDisplaySupplierName.AutoSize = true;
            this.lblEditDisplaySupplierName.Location = new System.Drawing.Point(239, 258);
            this.lblEditDisplaySupplierName.Name = "lblEditDisplaySupplierName";
            this.lblEditDisplaySupplierName.Size = new System.Drawing.Size(10, 13);
            this.lblEditDisplaySupplierName.TabIndex = 135;
            this.lblEditDisplaySupplierName.Text = "-";
            // 
            // lblEditSupplierName
            // 
            this.lblEditSupplierName.AutoSize = true;
            this.lblEditSupplierName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditSupplierName.Location = new System.Drawing.Point(53, 255);
            this.lblEditSupplierName.Name = "lblEditSupplierName";
            this.lblEditSupplierName.Size = new System.Drawing.Size(121, 20);
            this.lblEditSupplierName.TabIndex = 134;
            this.lblEditSupplierName.Text = "Supplier Name: ";
            // 
            // lblEditDisplaySupplierID
            // 
            this.lblEditDisplaySupplierID.AutoSize = true;
            this.lblEditDisplaySupplierID.Location = new System.Drawing.Point(239, 227);
            this.lblEditDisplaySupplierID.Name = "lblEditDisplaySupplierID";
            this.lblEditDisplaySupplierID.Size = new System.Drawing.Size(10, 13);
            this.lblEditDisplaySupplierID.TabIndex = 133;
            this.lblEditDisplaySupplierID.Text = "-";
            // 
            // cmbEditMakeID
            // 
            this.cmbEditMakeID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEditMakeID.FormattingEnabled = true;
            this.cmbEditMakeID.Location = new System.Drawing.Point(239, 315);
            this.cmbEditMakeID.Name = "cmbEditMakeID";
            this.cmbEditMakeID.Size = new System.Drawing.Size(231, 21);
            this.cmbEditMakeID.TabIndex = 132;
            // 
            // lblEditMakeID
            // 
            this.lblEditMakeID.AutoSize = true;
            this.lblEditMakeID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditMakeID.Location = new System.Drawing.Point(54, 315);
            this.lblEditMakeID.Name = "lblEditMakeID";
            this.lblEditMakeID.Size = new System.Drawing.Size(77, 20);
            this.lblEditMakeID.TabIndex = 131;
            this.lblEditMakeID.Text = "Make ID: ";
            // 
            // lblEditSupplierID
            // 
            this.lblEditSupplierID.AutoSize = true;
            this.lblEditSupplierID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditSupplierID.Location = new System.Drawing.Point(54, 226);
            this.lblEditSupplierID.Name = "lblEditSupplierID";
            this.lblEditSupplierID.Size = new System.Drawing.Size(96, 20);
            this.lblEditSupplierID.TabIndex = 130;
            this.lblEditSupplierID.Text = "Supplier ID: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(215, 358);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 20);
            this.label4.TabIndex = 129;
            this.label4.Text = "Cancel";
            // 
            // btnEditCancel
            // 
            this.btnEditCancel.Location = new System.Drawing.Point(173, 350);
            this.btnEditCancel.Name = "btnEditCancel";
            this.btnEditCancel.Size = new System.Drawing.Size(36, 31);
            this.btnEditCancel.TabIndex = 121;
            this.btnEditCancel.UseVisualStyleBackColor = true;
            this.btnEditCancel.Click += new System.EventHandler(this.btnEditCancel_Click);
            // 
            // txtEditQuantity
            // 
            this.txtEditQuantity.Location = new System.Drawing.Point(239, 287);
            this.txtEditQuantity.Name = "txtEditQuantity";
            this.txtEditQuantity.Size = new System.Drawing.Size(231, 20);
            this.txtEditQuantity.TabIndex = 119;
            // 
            // txtEditPurchasePrice
            // 
            this.txtEditPurchasePrice.Location = new System.Drawing.Point(239, 191);
            this.txtEditPurchasePrice.Name = "txtEditPurchasePrice";
            this.txtEditPurchasePrice.Size = new System.Drawing.Size(231, 20);
            this.txtEditPurchasePrice.TabIndex = 117;
            // 
            // txtEditUpgradeDesc
            // 
            this.txtEditUpgradeDesc.Location = new System.Drawing.Point(239, 63);
            this.txtEditUpgradeDesc.Multiline = true;
            this.txtEditUpgradeDesc.Name = "txtEditUpgradeDesc";
            this.txtEditUpgradeDesc.Size = new System.Drawing.Size(231, 72);
            this.txtEditUpgradeDesc.TabIndex = 115;
            // 
            // txtEditSellingPrice
            // 
            this.txtEditSellingPrice.Location = new System.Drawing.Point(239, 154);
            this.txtEditSellingPrice.Name = "txtEditSellingPrice";
            this.txtEditSellingPrice.Size = new System.Drawing.Size(231, 20);
            this.txtEditSellingPrice.TabIndex = 116;
            // 
            // lblEditDisplayUpgradeID
            // 
            this.lblEditDisplayUpgradeID.AutoSize = true;
            this.lblEditDisplayUpgradeID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditDisplayUpgradeID.Location = new System.Drawing.Point(195, 27);
            this.lblEditDisplayUpgradeID.Name = "lblEditDisplayUpgradeID";
            this.lblEditDisplayUpgradeID.Size = new System.Drawing.Size(14, 20);
            this.lblEditDisplayUpgradeID.TabIndex = 128;
            this.lblEditDisplayUpgradeID.Text = "-";
            // 
            // lblEditPurchasePrice
            // 
            this.lblEditPurchasePrice.AutoSize = true;
            this.lblEditPurchasePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditPurchasePrice.Location = new System.Drawing.Point(54, 191);
            this.lblEditPurchasePrice.Name = "lblEditPurchasePrice";
            this.lblEditPurchasePrice.Size = new System.Drawing.Size(142, 20);
            this.lblEditPurchasePrice.TabIndex = 127;
            this.lblEditPurchasePrice.Text = "Purchase Price (£):";
            // 
            // lblEditQuantity
            // 
            this.lblEditQuantity.AutoSize = true;
            this.lblEditQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditQuantity.Location = new System.Drawing.Point(54, 287);
            this.lblEditQuantity.Name = "lblEditQuantity";
            this.lblEditQuantity.Size = new System.Drawing.Size(137, 20);
            this.lblEditQuantity.TabIndex = 126;
            this.lblEditQuantity.Text = "Quantity in Stock: ";
            // 
            // lblEditSellingPrice
            // 
            this.lblEditSellingPrice.AutoSize = true;
            this.lblEditSellingPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditSellingPrice.Location = new System.Drawing.Point(56, 154);
            this.lblEditSellingPrice.Name = "lblEditSellingPrice";
            this.lblEditSellingPrice.Size = new System.Drawing.Size(126, 20);
            this.lblEditSellingPrice.TabIndex = 125;
            this.lblEditSellingPrice.Text = "Selling Price (£): ";
            // 
            // lblEditUpgradeDesc
            // 
            this.lblEditUpgradeDesc.AutoSize = true;
            this.lblEditUpgradeDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditUpgradeDesc.Location = new System.Drawing.Point(54, 61);
            this.lblEditUpgradeDesc.Name = "lblEditUpgradeDesc";
            this.lblEditUpgradeDesc.Size = new System.Drawing.Size(155, 20);
            this.lblEditUpgradeDesc.TabIndex = 124;
            this.lblEditUpgradeDesc.Text = "Upgrade Description";
            // 
            // lblEditUpgradeID
            // 
            this.lblEditUpgradeID.AutoSize = true;
            this.lblEditUpgradeID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditUpgradeID.Location = new System.Drawing.Point(35, 27);
            this.lblEditUpgradeID.Name = "lblEditUpgradeID";
            this.lblEditUpgradeID.Size = new System.Drawing.Size(100, 20);
            this.lblEditUpgradeID.TabIndex = 123;
            this.lblEditUpgradeID.Text = "Upgrade ID: ";
            // 
            // lblEditEdit
            // 
            this.lblEditEdit.AutoSize = true;
            this.lblEditEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditEdit.Location = new System.Drawing.Point(112, 358);
            this.lblEditEdit.Name = "lblEditEdit";
            this.lblEditEdit.Size = new System.Drawing.Size(37, 20);
            this.lblEditEdit.TabIndex = 122;
            this.lblEditEdit.Text = "Edit";
            // 
            // btnEditEdit
            // 
            this.btnEditEdit.Location = new System.Drawing.Point(70, 350);
            this.btnEditEdit.Name = "btnEditEdit";
            this.btnEditEdit.Size = new System.Drawing.Size(36, 31);
            this.btnEditEdit.TabIndex = 120;
            this.btnEditEdit.UseVisualStyleBackColor = true;
            this.btnEditEdit.Click += new System.EventHandler(this.btnEditEdit_Click);
            // 
            // tabAdd
            // 
            this.tabAdd.Controls.Add(this.cmbAddSupplier);
            this.tabAdd.Controls.Add(this.cmbAddMakeID);
            this.tabAdd.Controls.Add(this.label1);
            this.tabAdd.Controls.Add(this.lblAddEmail);
            this.tabAdd.Controls.Add(this.lblAddClear);
            this.tabAdd.Controls.Add(this.btnAddClear);
            this.tabAdd.Controls.Add(this.txtAddQuantity);
            this.tabAdd.Controls.Add(this.txtAddPurchasePrice);
            this.tabAdd.Controls.Add(this.txtAddUpgradeDesc);
            this.tabAdd.Controls.Add(this.txtAddSellingPrice);
            this.tabAdd.Controls.Add(this.lblAddDisplayUpgradeID);
            this.tabAdd.Controls.Add(this.lblAddMobileNo);
            this.tabAdd.Controls.Add(this.lblAddPostcode);
            this.tabAdd.Controls.Add(this.lblAddSellingPrice);
            this.tabAdd.Controls.Add(this.lblAddUpgradeDesc);
            this.tabAdd.Controls.Add(this.lblAddUpgradeID);
            this.tabAdd.Controls.Add(this.lblAddBtnAdd);
            this.tabAdd.Controls.Add(this.btnAddAdd);
            this.tabAdd.Location = new System.Drawing.Point(4, 22);
            this.tabAdd.Name = "tabAdd";
            this.tabAdd.Padding = new System.Windows.Forms.Padding(3);
            this.tabAdd.Size = new System.Drawing.Size(664, 453);
            this.tabAdd.TabIndex = 1;
            this.tabAdd.Text = "Add";
            this.tabAdd.UseVisualStyleBackColor = true;
            this.tabAdd.Click += new System.EventHandler(this.tabAdd_Click);
            // 
            // cmbAddSupplier
            // 
            this.cmbAddSupplier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAddSupplier.FormattingEnabled = true;
            this.cmbAddSupplier.Location = new System.Drawing.Point(245, 229);
            this.cmbAddSupplier.Name = "cmbAddSupplier";
            this.cmbAddSupplier.Size = new System.Drawing.Size(231, 21);
            this.cmbAddSupplier.TabIndex = 115;
            // 
            // cmbAddMakeID
            // 
            this.cmbAddMakeID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAddMakeID.FormattingEnabled = true;
            this.cmbAddMakeID.Location = new System.Drawing.Point(245, 288);
            this.cmbAddMakeID.Name = "cmbAddMakeID";
            this.cmbAddMakeID.Size = new System.Drawing.Size(231, 21);
            this.cmbAddMakeID.TabIndex = 114;
            this.cmbAddMakeID.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(60, 288);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 20);
            this.label1.TabIndex = 113;
            this.label1.Text = "Make ID: ";
            // 
            // lblAddEmail
            // 
            this.lblAddEmail.AutoSize = true;
            this.lblAddEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddEmail.Location = new System.Drawing.Point(60, 227);
            this.lblAddEmail.Name = "lblAddEmail";
            this.lblAddEmail.Size = new System.Drawing.Size(96, 20);
            this.lblAddEmail.TabIndex = 112;
            this.lblAddEmail.Text = "Supplier ID: ";
            // 
            // lblAddClear
            // 
            this.lblAddClear.AutoSize = true;
            this.lblAddClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddClear.Location = new System.Drawing.Point(221, 335);
            this.lblAddClear.Name = "lblAddClear";
            this.lblAddClear.Size = new System.Drawing.Size(46, 20);
            this.lblAddClear.TabIndex = 111;
            this.lblAddClear.Text = "Clear";
            // 
            // btnAddClear
            // 
            this.btnAddClear.Location = new System.Drawing.Point(179, 327);
            this.btnAddClear.Name = "btnAddClear";
            this.btnAddClear.Size = new System.Drawing.Size(36, 31);
            this.btnAddClear.TabIndex = 100;
            this.btnAddClear.UseVisualStyleBackColor = true;
            // 
            // txtAddQuantity
            // 
            this.txtAddQuantity.Location = new System.Drawing.Point(245, 260);
            this.txtAddQuantity.Name = "txtAddQuantity";
            this.txtAddQuantity.Size = new System.Drawing.Size(231, 20);
            this.txtAddQuantity.TabIndex = 96;
            // 
            // txtAddPurchasePrice
            // 
            this.txtAddPurchasePrice.Location = new System.Drawing.Point(245, 192);
            this.txtAddPurchasePrice.Name = "txtAddPurchasePrice";
            this.txtAddPurchasePrice.Size = new System.Drawing.Size(231, 20);
            this.txtAddPurchasePrice.TabIndex = 93;
            // 
            // txtAddUpgradeDesc
            // 
            this.txtAddUpgradeDesc.Location = new System.Drawing.Point(245, 64);
            this.txtAddUpgradeDesc.Multiline = true;
            this.txtAddUpgradeDesc.Name = "txtAddUpgradeDesc";
            this.txtAddUpgradeDesc.Size = new System.Drawing.Size(231, 72);
            this.txtAddUpgradeDesc.TabIndex = 91;
            // 
            // txtAddSellingPrice
            // 
            this.txtAddSellingPrice.Location = new System.Drawing.Point(245, 155);
            this.txtAddSellingPrice.Name = "txtAddSellingPrice";
            this.txtAddSellingPrice.Size = new System.Drawing.Size(231, 20);
            this.txtAddSellingPrice.TabIndex = 92;
            // 
            // lblAddDisplayUpgradeID
            // 
            this.lblAddDisplayUpgradeID.AutoSize = true;
            this.lblAddDisplayUpgradeID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddDisplayUpgradeID.Location = new System.Drawing.Point(201, 28);
            this.lblAddDisplayUpgradeID.Name = "lblAddDisplayUpgradeID";
            this.lblAddDisplayUpgradeID.Size = new System.Drawing.Size(14, 20);
            this.lblAddDisplayUpgradeID.TabIndex = 110;
            this.lblAddDisplayUpgradeID.Text = "-";
            // 
            // lblAddMobileNo
            // 
            this.lblAddMobileNo.AutoSize = true;
            this.lblAddMobileNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddMobileNo.Location = new System.Drawing.Point(60, 192);
            this.lblAddMobileNo.Name = "lblAddMobileNo";
            this.lblAddMobileNo.Size = new System.Drawing.Size(142, 20);
            this.lblAddMobileNo.TabIndex = 109;
            this.lblAddMobileNo.Text = "Purchase Price (£):";
            // 
            // lblAddPostcode
            // 
            this.lblAddPostcode.AutoSize = true;
            this.lblAddPostcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddPostcode.Location = new System.Drawing.Point(60, 260);
            this.lblAddPostcode.Name = "lblAddPostcode";
            this.lblAddPostcode.Size = new System.Drawing.Size(137, 20);
            this.lblAddPostcode.TabIndex = 108;
            this.lblAddPostcode.Text = "Quantity in Stock: ";
            // 
            // lblAddSellingPrice
            // 
            this.lblAddSellingPrice.AutoSize = true;
            this.lblAddSellingPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddSellingPrice.Location = new System.Drawing.Point(62, 155);
            this.lblAddSellingPrice.Name = "lblAddSellingPrice";
            this.lblAddSellingPrice.Size = new System.Drawing.Size(126, 20);
            this.lblAddSellingPrice.TabIndex = 107;
            this.lblAddSellingPrice.Text = "Selling Price (£): ";
            // 
            // lblAddUpgradeDesc
            // 
            this.lblAddUpgradeDesc.AutoSize = true;
            this.lblAddUpgradeDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddUpgradeDesc.Location = new System.Drawing.Point(60, 62);
            this.lblAddUpgradeDesc.Name = "lblAddUpgradeDesc";
            this.lblAddUpgradeDesc.Size = new System.Drawing.Size(155, 20);
            this.lblAddUpgradeDesc.TabIndex = 104;
            this.lblAddUpgradeDesc.Text = "Upgrade Description";
            // 
            // lblAddUpgradeID
            // 
            this.lblAddUpgradeID.AutoSize = true;
            this.lblAddUpgradeID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddUpgradeID.Location = new System.Drawing.Point(41, 28);
            this.lblAddUpgradeID.Name = "lblAddUpgradeID";
            this.lblAddUpgradeID.Size = new System.Drawing.Size(100, 20);
            this.lblAddUpgradeID.TabIndex = 102;
            this.lblAddUpgradeID.Text = "Upgrade ID: ";
            // 
            // lblAddBtnAdd
            // 
            this.lblAddBtnAdd.AutoSize = true;
            this.lblAddBtnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddBtnAdd.Location = new System.Drawing.Point(118, 335);
            this.lblAddBtnAdd.Name = "lblAddBtnAdd";
            this.lblAddBtnAdd.Size = new System.Drawing.Size(38, 20);
            this.lblAddBtnAdd.TabIndex = 101;
            this.lblAddBtnAdd.Text = "Add";
            // 
            // btnAddAdd
            // 
            this.btnAddAdd.Location = new System.Drawing.Point(76, 327);
            this.btnAddAdd.Name = "btnAddAdd";
            this.btnAddAdd.Size = new System.Drawing.Size(36, 31);
            this.btnAddAdd.TabIndex = 99;
            this.btnAddAdd.UseVisualStyleBackColor = true;
            this.btnAddAdd.Click += new System.EventHandler(this.btnAddAdd_Click);
            // 
            // tabDisplay
            // 
            this.tabDisplay.Controls.Add(this.dgvUpgrades);
            this.tabDisplay.Controls.Add(this.txtDisplaySearch);
            this.tabDisplay.Controls.Add(this.cmbDisplaySearch);
            this.tabDisplay.Location = new System.Drawing.Point(4, 22);
            this.tabDisplay.Name = "tabDisplay";
            this.tabDisplay.Padding = new System.Windows.Forms.Padding(3);
            this.tabDisplay.Size = new System.Drawing.Size(664, 453);
            this.tabDisplay.TabIndex = 0;
            this.tabDisplay.Text = "Display";
            this.tabDisplay.UseVisualStyleBackColor = true;
            // 
            // dgvUpgrades
            // 
            this.dgvUpgrades.AllowUserToAddRows = false;
            this.dgvUpgrades.AllowUserToDeleteRows = false;
            this.dgvUpgrades.AllowUserToResizeColumns = false;
            this.dgvUpgrades.AllowUserToResizeRows = false;
            this.dgvUpgrades.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUpgrades.Location = new System.Drawing.Point(6, 41);
            this.dgvUpgrades.Name = "dgvUpgrades";
            this.dgvUpgrades.ReadOnly = true;
            this.dgvUpgrades.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUpgrades.Size = new System.Drawing.Size(777, 423);
            this.dgvUpgrades.TabIndex = 0;
            // 
            // txtDisplaySearch
            // 
            this.txtDisplaySearch.Location = new System.Drawing.Point(133, 16);
            this.txtDisplaySearch.Name = "txtDisplaySearch";
            this.txtDisplaySearch.Size = new System.Drawing.Size(120, 20);
            this.txtDisplaySearch.TabIndex = 63;
            this.txtDisplaySearch.TextChanged += new System.EventHandler(this.txtDisplaySearch_TextChanged);
            // 
            // cmbDisplaySearch
            // 
            this.cmbDisplaySearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDisplaySearch.FormattingEnabled = true;
            this.cmbDisplaySearch.Items.AddRange(new object[] {
            "UpgradeID",
            "UpgradeDesc",
            "SellPrice",
            "QtyInStock",
            "SupplierID",
            "PurchasePrice",
            "MakeID"});
            this.cmbDisplaySearch.Location = new System.Drawing.Point(6, 15);
            this.cmbDisplaySearch.Name = "cmbDisplaySearch";
            this.cmbDisplaySearch.Size = new System.Drawing.Size(121, 21);
            this.cmbDisplaySearch.TabIndex = 62;
            this.cmbDisplaySearch.SelectedIndexChanged += new System.EventHandler(this.cmbDisplaySearch_SelectedIndexChanged);
            // 
            // tabUpgrades
            // 
            this.tabUpgrades.Controls.Add(this.tabDisplay);
            this.tabUpgrades.Controls.Add(this.tabAdd);
            this.tabUpgrades.Controls.Add(this.tabEdit);
            this.tabUpgrades.Controls.Add(this.tabReport);
            this.tabUpgrades.Location = new System.Drawing.Point(103, 56);
            this.tabUpgrades.Name = "tabUpgrades";
            this.tabUpgrades.SelectedIndex = 0;
            this.tabUpgrades.Size = new System.Drawing.Size(672, 479);
            this.tabUpgrades.TabIndex = 61;
            this.tabUpgrades.SelectedIndexChanged += new System.EventHandler(this.tabUpgrades_SelectedIndexChanged);
            // 
            // tabReport
            // 
            this.tabReport.Controls.Add(this.btnReset);
            this.tabReport.Controls.Add(this.lblDescSort);
            this.tabReport.Controls.Add(this.lblStockSearch);
            this.tabReport.Controls.Add(this.cmbMake);
            this.tabReport.Controls.Add(this.txtLowStock);
            this.tabReport.Controls.Add(this.btnLowStock);
            this.tabReport.Controls.Add(this.crystalReportViewer1);
            this.tabReport.Location = new System.Drawing.Point(4, 22);
            this.tabReport.Name = "tabReport";
            this.tabReport.Size = new System.Drawing.Size(664, 453);
            this.tabReport.TabIndex = 5;
            this.tabReport.Text = "Report";
            this.tabReport.UseVisualStyleBackColor = true;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(41, 337);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(110, 23);
            this.btnReset.TabIndex = 17;
            this.btnReset.Text = "Reset Form";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // lblDescSort
            // 
            this.lblDescSort.AutoSize = true;
            this.lblDescSort.Location = new System.Drawing.Point(44, 181);
            this.lblDescSort.Name = "lblDescSort";
            this.lblDescSort.Size = new System.Drawing.Size(76, 13);
            this.lblDescSort.TabIndex = 15;
            this.lblDescSort.Text = "Select a Make";
            // 
            // lblStockSearch
            // 
            this.lblStockSearch.AutoSize = true;
            this.lblStockSearch.Location = new System.Drawing.Point(44, 134);
            this.lblStockSearch.Name = "lblStockSearch";
            this.lblStockSearch.Size = new System.Drawing.Size(105, 13);
            this.lblStockSearch.TabIndex = 14;
            this.lblStockSearch.Text = "Enter stock amount: ";
            // 
            // cmbMake
            // 
            this.cmbMake.FormattingEnabled = true;
            this.cmbMake.Location = new System.Drawing.Point(41, 200);
            this.cmbMake.Name = "cmbMake";
            this.cmbMake.Size = new System.Drawing.Size(110, 21);
            this.cmbMake.TabIndex = 13;
            this.cmbMake.SelectedIndexChanged += new System.EventHandler(this.cmbMake_SelectedIndexChanged);
            // 
            // txtLowStock
            // 
            this.txtLowStock.Location = new System.Drawing.Point(41, 150);
            this.txtLowStock.Name = "txtLowStock";
            this.txtLowStock.Size = new System.Drawing.Size(110, 20);
            this.txtLowStock.TabIndex = 12;
            // 
            // btnLowStock
            // 
            this.btnLowStock.Location = new System.Drawing.Point(41, 308);
            this.btnLowStock.Name = "btnLowStock";
            this.btnLowStock.Size = new System.Drawing.Size(110, 23);
            this.btnLowStock.TabIndex = 11;
            this.btnLowStock.Text = "Search";
            this.btnLowStock.UseVisualStyleBackColor = true;
            this.btnLowStock.Click += new System.EventHandler(this.btnLowStock_Click);
            // 
            // crystalReportViewer1
            // 
            this.crystalReportViewer1.ActiveViewIndex = 0;
            this.crystalReportViewer1.AutoSize = true;
            this.crystalReportViewer1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.crystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crystalReportViewer1.Location = new System.Drawing.Point(0, 0);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.ReportSource = this.lowStockReport;
            this.crystalReportViewer1.ShowGroupTreeButton = false;
            this.crystalReportViewer1.Size = new System.Drawing.Size(664, 453);
            this.crystalReportViewer1.TabIndex = 10;
            // 
            // frmUpgrades
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(787, 550);
            this.Controls.Add(this.tabUpgrades);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnDisplayExit);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.btnDisplayDelete);
            this.Controls.Add(this.btnDisplayEdit);
            this.Controls.Add(this.btnDisplayAdd);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frmUpgrades";
            this.Text = "frmUpgrades";
            this.Load += new System.EventHandler(this.frmUpgrades_Load);
            this.Shown += new System.EventHandler(this.frmUpgrades_Shown);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errP)).EndInit();
            this.tabEdit.ResumeLayout(false);
            this.tabEdit.PerformLayout();
            this.tabAdd.ResumeLayout(false);
            this.tabAdd.PerformLayout();
            this.tabDisplay.ResumeLayout(false);
            this.tabDisplay.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUpgrades)).EndInit();
            this.tabUpgrades.ResumeLayout(false);
            this.tabReport.ResumeLayout(false);
            this.tabReport.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnDisplayExit;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button btnDisplayDelete;
        private System.Windows.Forms.Button btnDisplayEdit;
        private System.Windows.Forms.Button btnDisplayAdd;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ErrorProvider errP;
        private System.Windows.Forms.TabControl tabUpgrades;
        private System.Windows.Forms.TabPage tabDisplay;
        private System.Windows.Forms.DataGridView dgvUpgrades;
        private System.Windows.Forms.TextBox txtDisplaySearch;
        private System.Windows.Forms.ComboBox cmbDisplaySearch;
        private System.Windows.Forms.TabPage tabAdd;
        private System.Windows.Forms.ComboBox cmbAddSupplier;
        private System.Windows.Forms.ComboBox cmbAddMakeID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblAddEmail;
        private System.Windows.Forms.Label lblAddClear;
        private System.Windows.Forms.Button btnAddClear;
        private System.Windows.Forms.TextBox txtAddQuantity;
        private System.Windows.Forms.TextBox txtAddPurchasePrice;
        private System.Windows.Forms.TextBox txtAddUpgradeDesc;
        private System.Windows.Forms.TextBox txtAddSellingPrice;
        private System.Windows.Forms.Label lblAddDisplayUpgradeID;
        private System.Windows.Forms.Label lblAddMobileNo;
        private System.Windows.Forms.Label lblAddPostcode;
        private System.Windows.Forms.Label lblAddSellingPrice;
        private System.Windows.Forms.Label lblAddUpgradeDesc;
        private System.Windows.Forms.Label lblAddUpgradeID;
        private System.Windows.Forms.Label lblAddBtnAdd;
        private System.Windows.Forms.Button btnAddAdd;
        private System.Windows.Forms.TabPage tabEdit;
        private System.Windows.Forms.Label lblEditDisplaySupplierName;
        private System.Windows.Forms.Label lblEditSupplierName;
        private System.Windows.Forms.Label lblEditDisplaySupplierID;
        private System.Windows.Forms.ComboBox cmbEditMakeID;
        private System.Windows.Forms.Label lblEditMakeID;
        private System.Windows.Forms.Label lblEditSupplierID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnEditCancel;
        private System.Windows.Forms.TextBox txtEditQuantity;
        private System.Windows.Forms.TextBox txtEditPurchasePrice;
        private System.Windows.Forms.TextBox txtEditUpgradeDesc;
        private System.Windows.Forms.TextBox txtEditSellingPrice;
        private System.Windows.Forms.Label lblEditDisplayUpgradeID;
        private System.Windows.Forms.Label lblEditPurchasePrice;
        private System.Windows.Forms.Label lblEditQuantity;
        private System.Windows.Forms.Label lblEditSellingPrice;
        private System.Windows.Forms.Label lblEditUpgradeDesc;
        private System.Windows.Forms.Label lblEditUpgradeID;
        private System.Windows.Forms.Label lblEditEdit;
        private System.Windows.Forms.Button btnEditEdit;
        private System.Windows.Forms.TabPage tabReport;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label lblDescSort;
        private System.Windows.Forms.Label lblStockSearch;
        private System.Windows.Forms.ComboBox cmbMake;
        private System.Windows.Forms.TextBox txtLowStock;
        private System.Windows.Forms.Button btnLowStock;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer1;
        private lowStock lowStockReport;
    }
}