﻿namespace ScreenDesigns
{
    partial class frmUpgradeOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUpgradeOrders));
            this.errP = new System.Windows.Forms.ErrorProvider(this.components);
            this.lblFormTitle = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dtpAddDateCompleted = new System.Windows.Forms.DateTimePicker();
            this.dtpAddDateOrdered = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblDisplayUpgradeOrderID = new System.Windows.Forms.Label();
            this.lblAddUpgradeOrderID = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblDisplayRegNo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // errP
            // 
            this.errP.ContainerControl = this;
            // 
            // lblFormTitle
            // 
            this.lblFormTitle.AutoSize = true;
            this.lblFormTitle.BackColor = System.Drawing.Color.White;
            this.lblFormTitle.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFormTitle.Location = new System.Drawing.Point(635, 9);
            this.lblFormTitle.Name = "lblFormTitle";
            this.lblFormTitle.Size = new System.Drawing.Size(269, 45);
            this.lblFormTitle.TabIndex = 64;
            this.lblFormTitle.Text = "Upgrade Orders";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(-87, 2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1093, 55);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 53;
            this.pictureBox1.TabStop = false;
            // 
            // dtpAddDateCompleted
            // 
            this.dtpAddDateCompleted.Location = new System.Drawing.Point(183, 260);
            this.dtpAddDateCompleted.Name = "dtpAddDateCompleted";
            this.dtpAddDateCompleted.Size = new System.Drawing.Size(230, 20);
            this.dtpAddDateCompleted.TabIndex = 111;
            // 
            // dtpAddDateOrdered
            // 
            this.dtpAddDateOrdered.Location = new System.Drawing.Point(183, 224);
            this.dtpAddDateOrdered.MinDate = new System.DateTime(2020, 2, 28, 0, 0, 0, 0);
            this.dtpAddDateOrdered.Name = "dtpAddDateOrdered";
            this.dtpAddDateOrdered.Size = new System.Drawing.Size(230, 20);
            this.dtpAddDateOrdered.TabIndex = 110;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(40, 260);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 20);
            this.label1.TabIndex = 108;
            this.label1.Text = "Date Completed";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(94, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 20);
            this.label2.TabIndex = 107;
            this.label2.Text = "Reg. No";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(40, 224);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 20);
            this.label3.TabIndex = 106;
            this.label3.Text = "Date Ordered";
            // 
            // lblDisplayUpgradeOrderID
            // 
            this.lblDisplayUpgradeOrderID.AutoSize = true;
            this.lblDisplayUpgradeOrderID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDisplayUpgradeOrderID.Location = new System.Drawing.Point(193, 85);
            this.lblDisplayUpgradeOrderID.Name = "lblDisplayUpgradeOrderID";
            this.lblDisplayUpgradeOrderID.Size = new System.Drawing.Size(14, 20);
            this.lblDisplayUpgradeOrderID.TabIndex = 105;
            this.lblDisplayUpgradeOrderID.Text = "-";
            // 
            // lblAddUpgradeOrderID
            // 
            this.lblAddUpgradeOrderID.AutoSize = true;
            this.lblAddUpgradeOrderID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddUpgradeOrderID.Location = new System.Drawing.Point(33, 85);
            this.lblAddUpgradeOrderID.Name = "lblAddUpgradeOrderID";
            this.lblAddUpgradeOrderID.Size = new System.Drawing.Size(128, 20);
            this.lblAddUpgradeOrderID.TabIndex = 104;
            this.lblAddUpgradeOrderID.Text = "UpgradeOrderID";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(148, 341);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(89, 23);
            this.btnSubmit.TabIndex = 112;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(264, 342);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 113;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblDisplayRegNo
            // 
            this.lblDisplayRegNo.AutoSize = true;
            this.lblDisplayRegNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblDisplayRegNo.Location = new System.Drawing.Point(193, 126);
            this.lblDisplayRegNo.Name = "lblDisplayRegNo";
            this.lblDisplayRegNo.Size = new System.Drawing.Size(14, 20);
            this.lblDisplayRegNo.TabIndex = 114;
            this.lblDisplayRegNo.Text = "-";
            // 
            // frmUpgradeOrders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(527, 377);
            this.Controls.Add(this.lblDisplayRegNo);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.dtpAddDateCompleted);
            this.Controls.Add(this.dtpAddDateOrdered);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblDisplayUpgradeOrderID);
            this.Controls.Add(this.lblAddUpgradeOrderID);
            this.Controls.Add(this.lblFormTitle);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frmUpgradeOrders";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "   ";
            this.Load += new System.EventHandler(this.frmUpgradeOrders_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ErrorProvider errP;
        private System.Windows.Forms.Label lblFormTitle;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.DateTimePicker dtpAddDateCompleted;
        private System.Windows.Forms.DateTimePicker dtpAddDateOrdered;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblDisplayUpgradeOrderID;
        private System.Windows.Forms.Label lblAddUpgradeOrderID;
        private System.Windows.Forms.Label lblDisplayRegNo;
    }
}