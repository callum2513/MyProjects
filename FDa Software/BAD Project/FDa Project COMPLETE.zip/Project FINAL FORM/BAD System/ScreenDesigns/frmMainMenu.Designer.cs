﻿namespace ScreenDesigns
{
	partial class frmMainMenu
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMainMenu));
            this.pnlTopMenuBar = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnAppointments = new System.Windows.Forms.Button();
            this.btnSales = new System.Windows.Forms.Button();
            this.btnCustomer = new System.Windows.Forms.Button();
            this.btnMaintenance = new System.Windows.Forms.Button();
            this.btnCars = new System.Windows.Forms.Button();
            this.bannerTimer = new System.Windows.Forms.Timer(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pb2 = new System.Windows.Forms.PictureBox();
            this.pb1 = new System.Windows.Forms.PictureBox();
            this.lblCustBtn = new System.Windows.Forms.Label();
            this.lblMaintenanceBtn = new System.Windows.Forms.Label();
            this.lblCarsBtn = new System.Windows.Forms.Label();
            this.lblSalesBtn = new System.Windows.Forms.Label();
            this.btnStaff = new System.Windows.Forms.Label();
            this.lblExitBtn = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTopMenuBar
            // 
            this.pnlTopMenuBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.pnlTopMenuBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTopMenuBar.Margin = new System.Windows.Forms.Padding(2);
            this.pnlTopMenuBar.Name = "pnlTopMenuBar";
            this.pnlTopMenuBar.Size = new System.Drawing.Size(1000, 2);
            this.pnlTopMenuBar.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(428, 218);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(566, 379);
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ScreenDesigns.Properties.Resources.Logo;
            this.pictureBox1.Location = new System.Drawing.Point(-98, 2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1088, 55);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel1.Location = new System.Drawing.Point(-10, 60);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1000, 2);
            this.panel1.TabIndex = 13;
            // 
            // btnExit
            // 
            this.btnExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnExit.BackgroundImage")));
            this.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(11, 494);
            this.btnExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(65, 65);
            this.btnExit.TabIndex = 22;
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.MouseLeave += new System.EventHandler(this.btnExit_MouseLeave);
            this.btnExit.MouseHover += new System.EventHandler(this.btnExit_MouseHover);
            // 
            // btnAppointments
            // 
            this.btnAppointments.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAppointments.BackgroundImage")));
            this.btnAppointments.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAppointments.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAppointments.Location = new System.Drawing.Point(11, 425);
            this.btnAppointments.Margin = new System.Windows.Forms.Padding(2);
            this.btnAppointments.Name = "btnAppointments";
            this.btnAppointments.Size = new System.Drawing.Size(65, 65);
            this.btnAppointments.TabIndex = 21;
            this.btnAppointments.UseVisualStyleBackColor = true;
            this.btnAppointments.Click += new System.EventHandler(this.btnAppointments_Click);
            this.btnAppointments.MouseLeave += new System.EventHandler(this.btnAppointments_MouseLeave);
            this.btnAppointments.MouseHover += new System.EventHandler(this.btnAppointments_MouseHover);
            // 
            // btnSales
            // 
            this.btnSales.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSales.BackgroundImage")));
            this.btnSales.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSales.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSales.Location = new System.Drawing.Point(11, 356);
            this.btnSales.Margin = new System.Windows.Forms.Padding(2);
            this.btnSales.Name = "btnSales";
            this.btnSales.Size = new System.Drawing.Size(65, 65);
            this.btnSales.TabIndex = 20;
            this.btnSales.UseVisualStyleBackColor = true;
            this.btnSales.Click += new System.EventHandler(this.btnSales_Click);
            this.btnSales.MouseLeave += new System.EventHandler(this.btnSales_MouseLeave);
            this.btnSales.MouseHover += new System.EventHandler(this.btnSales_MouseHover);
            // 
            // btnCustomer
            // 
            this.btnCustomer.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCustomer.BackgroundImage")));
            this.btnCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomer.Location = new System.Drawing.Point(11, 149);
            this.btnCustomer.Margin = new System.Windows.Forms.Padding(2);
            this.btnCustomer.Name = "btnCustomer";
            this.btnCustomer.Size = new System.Drawing.Size(65, 65);
            this.btnCustomer.TabIndex = 19;
            this.btnCustomer.UseVisualStyleBackColor = true;
            this.btnCustomer.Click += new System.EventHandler(this.btnCustomer_Click);
            this.btnCustomer.MouseLeave += new System.EventHandler(this.btnCustomer_MouseLeave);
            this.btnCustomer.MouseHover += new System.EventHandler(this.btnCustomer_MouseHover);
            // 
            // btnMaintenance
            // 
            this.btnMaintenance.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMaintenance.BackgroundImage")));
            this.btnMaintenance.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMaintenance.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMaintenance.Location = new System.Drawing.Point(11, 218);
            this.btnMaintenance.Margin = new System.Windows.Forms.Padding(2);
            this.btnMaintenance.Name = "btnMaintenance";
            this.btnMaintenance.Size = new System.Drawing.Size(65, 65);
            this.btnMaintenance.TabIndex = 18;
            this.btnMaintenance.UseVisualStyleBackColor = true;
            this.btnMaintenance.Click += new System.EventHandler(this.btnMaintenance_Click);
            this.btnMaintenance.MouseLeave += new System.EventHandler(this.btnMaintenance_MouseLeave);
            this.btnMaintenance.MouseHover += new System.EventHandler(this.btnMaintenance_MouseHover);
            // 
            // btnCars
            // 
            this.btnCars.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCars.BackgroundImage")));
            this.btnCars.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCars.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCars.Location = new System.Drawing.Point(11, 287);
            this.btnCars.Margin = new System.Windows.Forms.Padding(2);
            this.btnCars.Name = "btnCars";
            this.btnCars.Size = new System.Drawing.Size(65, 65);
            this.btnCars.TabIndex = 17;
            this.btnCars.UseVisualStyleBackColor = true;
            this.btnCars.Click += new System.EventHandler(this.btnCars_Click);
            this.btnCars.MouseLeave += new System.EventHandler(this.btnCars_MouseLeave);
            this.btnCars.MouseHover += new System.EventHandler(this.btnCars_MouseHover);
            // 
            // bannerTimer
            // 
            this.bannerTimer.Tick += new System.EventHandler(this.bannerTimer_Tick);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.pb2);
            this.panel2.Controls.Add(this.pb1);
            this.panel2.Location = new System.Drawing.Point(0, 63);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(990, 75);
            this.panel2.TabIndex = 25;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel3.Location = new System.Drawing.Point(-4, 73);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1000, 3);
            this.panel3.TabIndex = 32;
            // 
            // pb2
            // 
            this.pb2.Image = global::ScreenDesigns.Properties.Resources.desmonds;
            this.pb2.Location = new System.Drawing.Point(459, 2);
            this.pb2.Margin = new System.Windows.Forms.Padding(2);
            this.pb2.Name = "pb2";
            this.pb2.Size = new System.Drawing.Size(509, 70);
            this.pb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb2.TabIndex = 1;
            this.pb2.TabStop = false;
            // 
            // pb1
            // 
            this.pb1.Image = global::ScreenDesigns.Properties.Resources.Logo;
            this.pb1.Location = new System.Drawing.Point(2, 2);
            this.pb1.Margin = new System.Windows.Forms.Padding(2);
            this.pb1.Name = "pb1";
            this.pb1.Size = new System.Drawing.Size(452, 70);
            this.pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb1.TabIndex = 0;
            this.pb1.TabStop = false;
            // 
            // lblCustBtn
            // 
            this.lblCustBtn.AutoSize = true;
            this.lblCustBtn.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustBtn.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblCustBtn.Location = new System.Drawing.Point(94, 170);
            this.lblCustBtn.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCustBtn.Name = "lblCustBtn";
            this.lblCustBtn.Size = new System.Drawing.Size(95, 19);
            this.lblCustBtn.TabIndex = 26;
            this.lblCustBtn.Text = "Customers";
            this.lblCustBtn.Visible = false;
            // 
            // lblMaintenanceBtn
            // 
            this.lblMaintenanceBtn.AutoSize = true;
            this.lblMaintenanceBtn.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaintenanceBtn.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblMaintenanceBtn.Location = new System.Drawing.Point(94, 243);
            this.lblMaintenanceBtn.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMaintenanceBtn.Name = "lblMaintenanceBtn";
            this.lblMaintenanceBtn.Size = new System.Drawing.Size(113, 19);
            this.lblMaintenanceBtn.TabIndex = 27;
            this.lblMaintenanceBtn.Text = "Maintenance";
            this.lblMaintenanceBtn.Visible = false;
            // 
            // lblCarsBtn
            // 
            this.lblCarsBtn.AutoSize = true;
            this.lblCarsBtn.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarsBtn.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblCarsBtn.Location = new System.Drawing.Point(94, 305);
            this.lblCarsBtn.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCarsBtn.Name = "lblCarsBtn";
            this.lblCarsBtn.Size = new System.Drawing.Size(45, 19);
            this.lblCarsBtn.TabIndex = 28;
            this.lblCarsBtn.Text = "Cars";
            this.lblCarsBtn.Visible = false;
            // 
            // lblSalesBtn
            // 
            this.lblSalesBtn.AutoSize = true;
            this.lblSalesBtn.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalesBtn.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblSalesBtn.Location = new System.Drawing.Point(94, 377);
            this.lblSalesBtn.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSalesBtn.Name = "lblSalesBtn";
            this.lblSalesBtn.Size = new System.Drawing.Size(52, 19);
            this.lblSalesBtn.TabIndex = 29;
            this.lblSalesBtn.Text = "Sales";
            this.lblSalesBtn.Visible = false;
            // 
            // btnStaff
            // 
            this.btnStaff.AutoSize = true;
            this.btnStaff.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStaff.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnStaff.Location = new System.Drawing.Point(94, 446);
            this.btnStaff.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btnStaff.Name = "btnStaff";
            this.btnStaff.Size = new System.Drawing.Size(48, 19);
            this.btnStaff.TabIndex = 30;
            this.btnStaff.Text = "Staff";
            this.btnStaff.Visible = false;
            // 
            // lblExitBtn
            // 
            this.lblExitBtn.AutoSize = true;
            this.lblExitBtn.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExitBtn.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblExitBtn.Location = new System.Drawing.Point(94, 515);
            this.lblExitBtn.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblExitBtn.Name = "lblExitBtn";
            this.lblExitBtn.Size = new System.Drawing.Size(41, 19);
            this.lblExitBtn.TabIndex = 31;
            this.lblExitBtn.Text = "Exit";
            this.lblExitBtn.Visible = false;
            // 
            // frmMainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.lblExitBtn);
            this.Controls.Add(this.btnStaff);
            this.Controls.Add(this.lblSalesBtn);
            this.Controls.Add(this.lblCarsBtn);
            this.Controls.Add(this.lblMaintenanceBtn);
            this.Controls.Add(this.lblCustBtn);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnAppointments);
            this.Controls.Add(this.btnSales);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnCustomer);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnMaintenance);
            this.Controls.Add(this.pnlTopMenuBar);
            this.Controls.Add(this.btnCars);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmMainMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMainMenu";
            this.Load += new System.EventHandler(this.frmMainMenu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Panel pnlTopMenuBar;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button btnExit;
		private System.Windows.Forms.Button btnAppointments;
		private System.Windows.Forms.Button btnSales;
		private System.Windows.Forms.Button btnCustomer;
		private System.Windows.Forms.Button btnMaintenance;
		private System.Windows.Forms.Button btnCars;
		private System.Windows.Forms.Timer bannerTimer;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.PictureBox pb2;
		private System.Windows.Forms.PictureBox pb1;
		private System.Windows.Forms.Label lblCustBtn;
		private System.Windows.Forms.Label lblMaintenanceBtn;
		private System.Windows.Forms.Label lblCarsBtn;
		private System.Windows.Forms.Label lblSalesBtn;
		private System.Windows.Forms.Label btnStaff;
		private System.Windows.Forms.Label lblExitBtn;
		private System.Windows.Forms.Panel panel3;
	}
}