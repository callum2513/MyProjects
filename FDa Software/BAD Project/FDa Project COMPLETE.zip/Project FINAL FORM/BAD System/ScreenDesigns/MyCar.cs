﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScreenDesigns
{
    class MyCar
    {
        private string regNo, makeID, model, interior, transmission, bodyStyle, colour, condition, modelYear, doorNo;
        private double salePrice, purchasePrice;
        private int mileage;

        public MyCar()
        {
            this.regNo = ""; this.makeID = ""; this.model = "";
            this.interior = ""; this.transmission = ""; this.bodyStyle = "";this.colour = "";
            this.condition = ""; this.modelYear = ""; this.doorNo = "";
            this.salePrice = 0.0; this.purchasePrice = 0.0;
            this.mileage = 0;
        }

        public string RegNo
        {
            get { return regNo; }
            set
            {
                if (MyValidation.validLength(value, 1,7))
                {
                    regNo = MyValidation.EachLetterToUpper(value);
                }
                else
                    throw new MyException("Please enter a valid RegNo");
            }
        }
        public string MakeID
        {
            get { return makeID; }
            set
            {
                if (MyValidation.validLength(value, 3, 20) && MyValidation.validLetterWhiteSpace(value))
                {
                    makeID = MyValidation.EachLetterToUpper(value);
                }
                else
                    throw new MyException("Please Select a Make from the Dropdown List");
            }
        }
        public string Model
        {
            get { return model; }
            set
            {
                if (MyValidation.validLength(value, 1, 20) && MyValidation.validLetterWhiteSpace(value))
                {
                    model = MyValidation.firstLetterEachWordUpper(value);
                }
                else
                    throw new MyException("Model must be 1-20 characters");
            }
        }
        public string Interior
        {
            get { return interior; }
            set
            {
                if (MyValidation.validLength(value, 3, 20) && MyValidation.validLetterWhiteSpace(value))
                {
                    interior = MyValidation.firstLetterEachWordUpper(value);
                }
                else
                    throw new MyException("Interior must be 3-20 characters");
            }
        }
        public string Transmission
        {
            get { return transmission; }
            set
            {
                if (MyValidation.validLength(value, 6, 9) && MyValidation.validLetterWhiteSpace(value))
                {
                    transmission = MyValidation.firstLetterEachWordUpper(value);
                }
                else
                    throw new MyException("Please Select a Transmission type from the Dropdown List"); ;
            }
        }
        public string BodyStyle
        {
            get { return bodyStyle; }
            set
            {
                if (MyValidation.validLength(value, 3, 20) && MyValidation.validLetterWhiteSpace(value))
                {
                    bodyStyle = MyValidation.firstLetterEachWordUpper(value);
                }
                else
                    throw new MyException("Please Select a Body Type from the Dropdown List");
            }
        }
        public string Colour
        {
            get { return colour; }
            set
            {
                if (MyValidation.validLength(value, 3, 20) && MyValidation.validLetterWhiteSpace(value))
                {
                    colour = MyValidation.firstLetterEachWordUpper(value);
                }
                else
                    throw new MyException("Colour must be 3-20 characters");
            }
        }
        public string Condition
        {
            get { return condition; }
            set
            {
                if (MyValidation.validLength(value, 3, 5) && MyValidation.validLetterWhiteSpace(value))
                {
                    condition = MyValidation.firstLetterEachWordUpper(value);
                }
                else
                    throw new MyException("Please Select a Condition from the Dropdown List");
            }
        }
        public string ModelYear
        {
            get { return modelYear; }
            set
            {
                if (MyValidation.validLength(value, 4, 4))
                {
                    modelYear = value;
                }
                else
                    throw new MyException("Please Enter the Model Year");
            }
        }
        public string DoorNo
        {
            get { return doorNo; }
            set
            {
                if (MyValidation.validLength(value, 1, 1))
                {
                    doorNo = value;
                }
                else
                    throw new MyException("Please Select a Door No from the Dropdown List");
            }
        }
        public double SalePrice
        {
            get { return salePrice; }
            set
            {
                if (value > 0)
                {
                    salePrice = value;
                }
                else
                    throw new MyException("Sale Price must be greater than £0");
            }
        }
        public double PurchasePrice
        {
            get { return purchasePrice; }
            set
            {
                if (value > 0)
                {
                    purchasePrice = value;
                }
                else
                    throw new MyException("Purchase Price must be greater than £0");
            }
        }
        public int Mileage
        {
            get { return mileage; }
            set
            {
                if (value > 0)
                {
                    mileage = value;
                }
                else
                    throw new MyException("Mileage must be at least 1");
            }
        }

        





    }
}
