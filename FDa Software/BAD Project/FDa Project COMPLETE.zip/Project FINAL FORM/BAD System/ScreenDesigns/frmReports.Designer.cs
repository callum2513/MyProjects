﻿namespace ScreenDesigns
{
    partial class frmReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lowStockReport = new ScreenDesigns.lowStock();
            this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.btnLowStock = new System.Windows.Forms.Button();
            this.txtLowStock = new System.Windows.Forms.TextBox();
            this.cmbMake = new System.Windows.Forms.ComboBox();
            this.lblStockSearch = new System.Windows.Forms.Label();
            this.lblDescSort = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lowStockReport
            // 
            this.lowStockReport.InitReport += new System.EventHandler(this.lowStockReport_InitReport);
            // 
            // crystalReportViewer1
            // 
            this.crystalReportViewer1.ActiveViewIndex = 0;
            this.crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.crystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crystalReportViewer1.Location = new System.Drawing.Point(0, 0);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.ReportSource = this.lowStockReport;
            this.crystalReportViewer1.Size = new System.Drawing.Size(985, 706);
            this.crystalReportViewer1.TabIndex = 0;
            this.crystalReportViewer1.Load += new System.EventHandler(this.crystalReportViewer1_Load);
            // 
            // btnLowStock
            // 
            this.btnLowStock.Location = new System.Drawing.Point(31, 359);
            this.btnLowStock.Name = "btnLowStock";
            this.btnLowStock.Size = new System.Drawing.Size(110, 23);
            this.btnLowStock.TabIndex = 1;
            this.btnLowStock.Text = "Search";
            this.btnLowStock.UseVisualStyleBackColor = true;
            this.btnLowStock.Click += new System.EventHandler(this.btnLowStock_Click);
            // 
            // txtLowStock
            // 
            this.txtLowStock.Location = new System.Drawing.Point(33, 127);
            this.txtLowStock.Name = "txtLowStock";
            this.txtLowStock.Size = new System.Drawing.Size(110, 20);
            this.txtLowStock.TabIndex = 3;
            this.txtLowStock.TextChanged += new System.EventHandler(this.txtLowStock_TextChanged);
            // 
            // cmbMake
            // 
            this.cmbMake.FormattingEnabled = true;
            this.cmbMake.Location = new System.Drawing.Point(31, 180);
            this.cmbMake.Name = "cmbMake";
            this.cmbMake.Size = new System.Drawing.Size(110, 21);
            this.cmbMake.TabIndex = 4;
            this.cmbMake.SelectedIndexChanged += new System.EventHandler(this.cmbMake_SelectedIndexChanged);
            // 
            // lblStockSearch
            // 
            this.lblStockSearch.AutoSize = true;
            this.lblStockSearch.Location = new System.Drawing.Point(34, 111);
            this.lblStockSearch.Name = "lblStockSearch";
            this.lblStockSearch.Size = new System.Drawing.Size(105, 13);
            this.lblStockSearch.TabIndex = 5;
            this.lblStockSearch.Text = "Enter stock amount: ";
            this.lblStockSearch.Click += new System.EventHandler(this.lblStockSearch_Click);
            // 
            // lblDescSort
            // 
            this.lblDescSort.AutoSize = true;
            this.lblDescSort.Location = new System.Drawing.Point(34, 161);
            this.lblDescSort.Name = "lblDescSort";
            this.lblDescSort.Size = new System.Drawing.Size(76, 13);
            this.lblDescSort.TabIndex = 7;
            this.lblDescSort.Text = "Select a Make";
            this.lblDescSort.Click += new System.EventHandler(this.lblDescSort_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(37, 646);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(110, 23);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(37, 617);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(110, 23);
            this.btnReset.TabIndex = 9;
            this.btnReset.Text = "Reset Form";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // frmReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 706);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblDescSort);
            this.Controls.Add(this.lblStockSearch);
            this.Controls.Add(this.cmbMake);
            this.Controls.Add(this.txtLowStock);
            this.Controls.Add(this.btnLowStock);
            this.Controls.Add(this.crystalReportViewer1);
            this.Name = "frmReports";
            this.Text = "frmReports";
            this.Load += new System.EventHandler(this.frmReports_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private lowStock lowStockReport;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer1;
        private System.Windows.Forms.Button btnLowStock;
        private System.Windows.Forms.TextBox txtLowStock;
        private System.Windows.Forms.ComboBox cmbMake;
        private System.Windows.Forms.Label lblStockSearch;
        private System.Windows.Forms.Label lblDescSort;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnReset;
    }
}