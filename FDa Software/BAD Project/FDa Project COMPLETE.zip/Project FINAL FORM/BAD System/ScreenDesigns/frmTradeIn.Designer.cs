﻿namespace ScreenDesigns
{
    partial class frmTradeIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTradeIn));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnlTopMenuBar = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lblCarTitle = new System.Windows.Forms.Label();
            this.errP = new System.Windows.Forms.ErrorProvider(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtTradeCarMileage = new System.Windows.Forms.NumericUpDown();
            this.cmbTradeCarTransmission = new System.Windows.Forms.ComboBox();
            this.txtTradeCarSalePrice = new System.Windows.Forms.MaskedTextBox();
            this.cmbTradeCarCondition = new System.Windows.Forms.ComboBox();
            this.txtTradeCarReg = new System.Windows.Forms.MaskedTextBox();
            this.lblTradeCarMileage = new System.Windows.Forms.Label();
            this.lblTradeCarSalePrice = new System.Windows.Forms.Label();
            this.dtpTradeCarYear = new System.Windows.Forms.DateTimePicker();
            this.txtTradeCarColour = new System.Windows.Forms.TextBox();
            this.cmbTradeCarBody = new System.Windows.Forms.ComboBox();
            this.lblTradeCarReset = new System.Windows.Forms.Label();
            this.btnTradeAarReset = new System.Windows.Forms.Button();
            this.lblTradeCarBtn = new System.Windows.Forms.Label();
            this.btnTradeCarAdd = new System.Windows.Forms.Button();
            this.lblTradeCarBody = new System.Windows.Forms.Label();
            this.lblCarTradeInHeader = new System.Windows.Forms.Label();
            this.cmbTradeCarDoorNo = new System.Windows.Forms.ComboBox();
            this.lblTradeCarDoorNo = new System.Windows.Forms.Label();
            this.lblTradeCarCondition = new System.Windows.Forms.Label();
            this.lblTradeCarYear = new System.Windows.Forms.Label();
            this.txtTradeCarInterior = new System.Windows.Forms.TextBox();
            this.txtTradeCarModel = new System.Windows.Forms.TextBox();
            this.lblTradeCarColour = new System.Windows.Forms.Label();
            this.lblTradeCarTransmission = new System.Windows.Forms.Label();
            this.lblTradeCarInterior = new System.Windows.Forms.Label();
            this.lblTradeCarPurchasePrice = new System.Windows.Forms.Label();
            this.lblTradeCarModel = new System.Windows.Forms.Label();
            this.cmbTradeCarMake = new System.Windows.Forms.ComboBox();
            this.lblTradeCarMake = new System.Windows.Forms.Label();
            this.lblTradeCarRegNo = new System.Windows.Forms.Label();
            this.txtCarPurchasePrice = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.pnlTopMenuBar.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTradeCarMileage)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(-6, 49);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1000, 2);
            this.panel1.TabIndex = 90;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel2.Location = new System.Drawing.Point(1, 1);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1000, 2);
            this.panel2.TabIndex = 49;
            // 
            // pnlTopMenuBar
            // 
            this.pnlTopMenuBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.pnlTopMenuBar.Controls.Add(this.panel4);
            this.pnlTopMenuBar.Location = new System.Drawing.Point(7, -6);
            this.pnlTopMenuBar.Margin = new System.Windows.Forms.Padding(2);
            this.pnlTopMenuBar.Name = "pnlTopMenuBar";
            this.pnlTopMenuBar.Size = new System.Drawing.Size(1000, 3);
            this.pnlTopMenuBar.TabIndex = 88;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(2, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1000, 2);
            this.panel4.TabIndex = 50;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel5.Location = new System.Drawing.Point(1, 1);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1000, 2);
            this.panel5.TabIndex = 49;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.White;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(776, 2);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(108, 42);
            this.flowLayoutPanel1.TabIndex = 100;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel6.Location = new System.Drawing.Point(6, -6);
            this.panel6.Margin = new System.Windows.Forms.Padding(2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1000, 2);
            this.panel6.TabIndex = 92;
            // 
            // lblCarTitle
            // 
            this.lblCarTitle.AutoSize = true;
            this.lblCarTitle.BackColor = System.Drawing.Color.White;
            this.lblCarTitle.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblCarTitle.Location = new System.Drawing.Point(891, 0);
            this.lblCarTitle.Name = "lblCarTitle";
            this.lblCarTitle.Size = new System.Drawing.Size(87, 45);
            this.lblCarTitle.TabIndex = 93;
            this.lblCarTitle.Text = "Cars";
            // 
            // errP
            // 
            this.errP.ContainerControl = this;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(-97, -9);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1089, 55);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 89;
            this.pictureBox1.TabStop = false;
            // 
            // txtTradeCarMileage
            // 
            this.txtTradeCarMileage.Location = new System.Drawing.Point(643, 274);
            this.txtTradeCarMileage.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.txtTradeCarMileage.Name = "txtTradeCarMileage";
            this.txtTradeCarMileage.Size = new System.Drawing.Size(139, 20);
            this.txtTradeCarMileage.TabIndex = 131;
            // 
            // cmbTradeCarTransmission
            // 
            this.cmbTradeCarTransmission.FormattingEnabled = true;
            this.cmbTradeCarTransmission.Items.AddRange(new object[] {
            "Manual",
            "Automatic"});
            this.cmbTradeCarTransmission.Location = new System.Drawing.Point(282, 275);
            this.cmbTradeCarTransmission.Name = "cmbTradeCarTransmission";
            this.cmbTradeCarTransmission.Size = new System.Drawing.Size(145, 21);
            this.cmbTradeCarTransmission.TabIndex = 130;
            // 
            // txtTradeCarSalePrice
            // 
            this.txtTradeCarSalePrice.Location = new System.Drawing.Point(643, 332);
            this.txtTradeCarSalePrice.Mask = "######";
            this.txtTradeCarSalePrice.Name = "txtTradeCarSalePrice";
            this.txtTradeCarSalePrice.PromptChar = ' ';
            this.txtTradeCarSalePrice.Size = new System.Drawing.Size(87, 20);
            this.txtTradeCarSalePrice.TabIndex = 129;
            // 
            // cmbTradeCarCondition
            // 
            this.cmbTradeCarCondition.FormattingEnabled = true;
            this.cmbTradeCarCondition.Items.AddRange(new object[] {
            "New",
            "Used"});
            this.cmbTradeCarCondition.Location = new System.Drawing.Point(645, 175);
            this.cmbTradeCarCondition.Name = "cmbTradeCarCondition";
            this.cmbTradeCarCondition.Size = new System.Drawing.Size(137, 21);
            this.cmbTradeCarCondition.TabIndex = 127;
            // 
            // txtTradeCarReg
            // 
            this.txtTradeCarReg.Location = new System.Drawing.Point(282, 146);
            this.txtTradeCarReg.Mask = "AAAAAAA";
            this.txtTradeCarReg.Name = "txtTradeCarReg";
            this.txtTradeCarReg.PromptChar = ' ';
            this.txtTradeCarReg.Size = new System.Drawing.Size(72, 20);
            this.txtTradeCarReg.TabIndex = 126;
            // 
            // lblTradeCarMileage
            // 
            this.lblTradeCarMileage.AutoSize = true;
            this.lblTradeCarMileage.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTradeCarMileage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblTradeCarMileage.Location = new System.Drawing.Point(488, 274);
            this.lblTradeCarMileage.Name = "lblTradeCarMileage";
            this.lblTradeCarMileage.Size = new System.Drawing.Size(76, 21);
            this.lblTradeCarMileage.TabIndex = 125;
            this.lblTradeCarMileage.Text = "Mileage:";
            // 
            // lblTradeCarSalePrice
            // 
            this.lblTradeCarSalePrice.AutoSize = true;
            this.lblTradeCarSalePrice.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTradeCarSalePrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblTradeCarSalePrice.Location = new System.Drawing.Point(488, 331);
            this.lblTradeCarSalePrice.Name = "lblTradeCarSalePrice";
            this.lblTradeCarSalePrice.Size = new System.Drawing.Size(88, 21);
            this.lblTradeCarSalePrice.TabIndex = 124;
            this.lblTradeCarSalePrice.Text = "Sale Price:";
            // 
            // dtpTradeCarYear
            // 
            this.dtpTradeCarYear.Location = new System.Drawing.Point(645, 205);
            this.dtpTradeCarYear.Name = "dtpTradeCarYear";
            this.dtpTradeCarYear.Size = new System.Drawing.Size(137, 20);
            this.dtpTradeCarYear.TabIndex = 123;
            // 
            // txtTradeCarColour
            // 
            this.txtTradeCarColour.Location = new System.Drawing.Point(282, 339);
            this.txtTradeCarColour.Name = "txtTradeCarColour";
            this.txtTradeCarColour.Size = new System.Drawing.Size(147, 20);
            this.txtTradeCarColour.TabIndex = 122;
            // 
            // cmbTradeCarBody
            // 
            this.cmbTradeCarBody.FormattingEnabled = true;
            this.cmbTradeCarBody.Items.AddRange(new object[] {
            "Sedan",
            "Coupe",
            "Hatchback",
            "SUV",
            "Sport",
            "Van"});
            this.cmbTradeCarBody.Location = new System.Drawing.Point(282, 307);
            this.cmbTradeCarBody.Name = "cmbTradeCarBody";
            this.cmbTradeCarBody.Size = new System.Drawing.Size(145, 21);
            this.cmbTradeCarBody.TabIndex = 121;
            // 
            // lblTradeCarReset
            // 
            this.lblTradeCarReset.AutoSize = true;
            this.lblTradeCarReset.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold);
            this.lblTradeCarReset.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblTradeCarReset.Location = new System.Drawing.Point(433, 465);
            this.lblTradeCarReset.Name = "lblTradeCarReset";
            this.lblTradeCarReset.Size = new System.Drawing.Size(94, 21);
            this.lblTradeCarReset.TabIndex = 120;
            this.lblTradeCarReset.Text = "Reset Form";
            // 
            // btnTradeAarReset
            // 
            this.btnTradeAarReset.Location = new System.Drawing.Point(377, 450);
            this.btnTradeAarReset.Name = "btnTradeAarReset";
            this.btnTradeAarReset.Size = new System.Drawing.Size(50, 50);
            this.btnTradeAarReset.TabIndex = 119;
            this.btnTradeAarReset.UseVisualStyleBackColor = true;
            // 
            // lblTradeCarBtn
            // 
            this.lblTradeCarBtn.AutoSize = true;
            this.lblTradeCarBtn.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold);
            this.lblTradeCarBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblTradeCarBtn.Location = new System.Drawing.Point(218, 465);
            this.lblTradeCarBtn.Name = "lblTradeCarBtn";
            this.lblTradeCarBtn.Size = new System.Drawing.Size(70, 21);
            this.lblTradeCarBtn.TabIndex = 118;
            this.lblTradeCarBtn.Text = "Add Car";
            // 
            // btnTradeCarAdd
            // 
            this.btnTradeCarAdd.Location = new System.Drawing.Point(162, 450);
            this.btnTradeCarAdd.Name = "btnTradeCarAdd";
            this.btnTradeCarAdd.Size = new System.Drawing.Size(50, 50);
            this.btnTradeCarAdd.TabIndex = 117;
            this.btnTradeCarAdd.UseVisualStyleBackColor = true;
            this.btnTradeCarAdd.Click += new System.EventHandler(this.btnTradeCarAdd_Click);
            // 
            // lblTradeCarBody
            // 
            this.lblTradeCarBody.AutoSize = true;
            this.lblTradeCarBody.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTradeCarBody.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblTradeCarBody.Location = new System.Drawing.Point(158, 306);
            this.lblTradeCarBody.Name = "lblTradeCarBody";
            this.lblTradeCarBody.Size = new System.Drawing.Size(95, 21);
            this.lblTradeCarBody.TabIndex = 116;
            this.lblTradeCarBody.Text = "Body Style:";
            // 
            // lblCarTradeInHeader
            // 
            this.lblCarTradeInHeader.AutoSize = true;
            this.lblCarTradeInHeader.BackColor = System.Drawing.Color.Transparent;
            this.lblCarTradeInHeader.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarTradeInHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblCarTradeInHeader.Location = new System.Drawing.Point(145, 87);
            this.lblCarTradeInHeader.Name = "lblCarTradeInHeader";
            this.lblCarTradeInHeader.Size = new System.Drawing.Size(222, 45);
            this.lblCarTradeInHeader.TabIndex = 115;
            this.lblCarTradeInHeader.Text = "Trade In Car";
            // 
            // cmbTradeCarDoorNo
            // 
            this.cmbTradeCarDoorNo.FormattingEnabled = true;
            this.cmbTradeCarDoorNo.Items.AddRange(new object[] {
            "3",
            "5"});
            this.cmbTradeCarDoorNo.Location = new System.Drawing.Point(643, 240);
            this.cmbTradeCarDoorNo.Name = "cmbTradeCarDoorNo";
            this.cmbTradeCarDoorNo.Size = new System.Drawing.Size(139, 21);
            this.cmbTradeCarDoorNo.TabIndex = 114;
            // 
            // lblTradeCarDoorNo
            // 
            this.lblTradeCarDoorNo.AutoSize = true;
            this.lblTradeCarDoorNo.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTradeCarDoorNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblTradeCarDoorNo.Location = new System.Drawing.Point(488, 240);
            this.lblTradeCarDoorNo.Name = "lblTradeCarDoorNo";
            this.lblTradeCarDoorNo.Size = new System.Drawing.Size(79, 21);
            this.lblTradeCarDoorNo.TabIndex = 113;
            this.lblTradeCarDoorNo.Text = "Door No:";
            // 
            // lblTradeCarCondition
            // 
            this.lblTradeCarCondition.AutoSize = true;
            this.lblTradeCarCondition.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTradeCarCondition.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblTradeCarCondition.Location = new System.Drawing.Point(488, 175);
            this.lblTradeCarCondition.Name = "lblTradeCarCondition";
            this.lblTradeCarCondition.Size = new System.Drawing.Size(90, 21);
            this.lblTradeCarCondition.TabIndex = 112;
            this.lblTradeCarCondition.Text = "Condition:";
            // 
            // lblTradeCarYear
            // 
            this.lblTradeCarYear.AutoSize = true;
            this.lblTradeCarYear.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTradeCarYear.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblTradeCarYear.Location = new System.Drawing.Point(488, 207);
            this.lblTradeCarYear.Name = "lblTradeCarYear";
            this.lblTradeCarYear.Size = new System.Drawing.Size(48, 21);
            this.lblTradeCarYear.TabIndex = 111;
            this.lblTradeCarYear.Text = "Year:";
            // 
            // txtTradeCarInterior
            // 
            this.txtTradeCarInterior.Location = new System.Drawing.Point(282, 240);
            this.txtTradeCarInterior.Name = "txtTradeCarInterior";
            this.txtTradeCarInterior.Size = new System.Drawing.Size(145, 20);
            this.txtTradeCarInterior.TabIndex = 110;
            // 
            // txtTradeCarModel
            // 
            this.txtTradeCarModel.Location = new System.Drawing.Point(282, 208);
            this.txtTradeCarModel.Name = "txtTradeCarModel";
            this.txtTradeCarModel.Size = new System.Drawing.Size(145, 20);
            this.txtTradeCarModel.TabIndex = 109;
            // 
            // lblTradeCarColour
            // 
            this.lblTradeCarColour.AutoSize = true;
            this.lblTradeCarColour.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTradeCarColour.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblTradeCarColour.Location = new System.Drawing.Point(158, 338);
            this.lblTradeCarColour.Name = "lblTradeCarColour";
            this.lblTradeCarColour.Size = new System.Drawing.Size(65, 21);
            this.lblTradeCarColour.TabIndex = 108;
            this.lblTradeCarColour.Text = "Colour:";
            // 
            // lblTradeCarTransmission
            // 
            this.lblTradeCarTransmission.AutoSize = true;
            this.lblTradeCarTransmission.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTradeCarTransmission.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblTradeCarTransmission.Location = new System.Drawing.Point(157, 275);
            this.lblTradeCarTransmission.Name = "lblTradeCarTransmission";
            this.lblTradeCarTransmission.Size = new System.Drawing.Size(114, 21);
            this.lblTradeCarTransmission.TabIndex = 107;
            this.lblTradeCarTransmission.Text = "Transmission:";
            // 
            // lblTradeCarInterior
            // 
            this.lblTradeCarInterior.AutoSize = true;
            this.lblTradeCarInterior.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTradeCarInterior.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblTradeCarInterior.Location = new System.Drawing.Point(157, 240);
            this.lblTradeCarInterior.Name = "lblTradeCarInterior";
            this.lblTradeCarInterior.Size = new System.Drawing.Size(71, 21);
            this.lblTradeCarInterior.TabIndex = 106;
            this.lblTradeCarInterior.Text = "Interior:";
            // 
            // lblTradeCarPurchasePrice
            // 
            this.lblTradeCarPurchasePrice.AutoSize = true;
            this.lblTradeCarPurchasePrice.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTradeCarPurchasePrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblTradeCarPurchasePrice.Location = new System.Drawing.Point(488, 302);
            this.lblTradeCarPurchasePrice.Name = "lblTradeCarPurchasePrice";
            this.lblTradeCarPurchasePrice.Size = new System.Drawing.Size(125, 21);
            this.lblTradeCarPurchasePrice.TabIndex = 105;
            this.lblTradeCarPurchasePrice.Text = "Purchase Price:";
            // 
            // lblTradeCarModel
            // 
            this.lblTradeCarModel.AutoSize = true;
            this.lblTradeCarModel.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTradeCarModel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblTradeCarModel.Location = new System.Drawing.Point(158, 208);
            this.lblTradeCarModel.Name = "lblTradeCarModel";
            this.lblTradeCarModel.Size = new System.Drawing.Size(63, 21);
            this.lblTradeCarModel.TabIndex = 104;
            this.lblTradeCarModel.Text = "Model:";
            // 
            // cmbTradeCarMake
            // 
            this.cmbTradeCarMake.FormattingEnabled = true;
            this.cmbTradeCarMake.Location = new System.Drawing.Point(282, 176);
            this.cmbTradeCarMake.Name = "cmbTradeCarMake";
            this.cmbTradeCarMake.Size = new System.Drawing.Size(145, 21);
            this.cmbTradeCarMake.TabIndex = 103;
            // 
            // lblTradeCarMake
            // 
            this.lblTradeCarMake.AutoSize = true;
            this.lblTradeCarMake.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTradeCarMake.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblTradeCarMake.Location = new System.Drawing.Point(158, 176);
            this.lblTradeCarMake.Name = "lblTradeCarMake";
            this.lblTradeCarMake.Size = new System.Drawing.Size(56, 21);
            this.lblTradeCarMake.TabIndex = 102;
            this.lblTradeCarMake.Text = "Make:";
            // 
            // lblTradeCarRegNo
            // 
            this.lblTradeCarRegNo.AutoSize = true;
            this.lblTradeCarRegNo.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTradeCarRegNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblTradeCarRegNo.Location = new System.Drawing.Point(158, 145);
            this.lblTradeCarRegNo.Name = "lblTradeCarRegNo";
            this.lblTradeCarRegNo.Size = new System.Drawing.Size(70, 21);
            this.lblTradeCarRegNo.TabIndex = 101;
            this.lblTradeCarRegNo.Text = "Reg No:";
            // 
            // txtCarPurchasePrice
            // 
            this.txtCarPurchasePrice.Location = new System.Drawing.Point(643, 303);
            this.txtCarPurchasePrice.Name = "txtCarPurchasePrice";
            this.txtCarPurchasePrice.Size = new System.Drawing.Size(100, 20);
            this.txtCarPurchasePrice.TabIndex = 132;
            // 
            // frmTradeIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.txtCarPurchasePrice);
            this.Controls.Add(this.txtTradeCarMileage);
            this.Controls.Add(this.cmbTradeCarTransmission);
            this.Controls.Add(this.txtTradeCarSalePrice);
            this.Controls.Add(this.cmbTradeCarCondition);
            this.Controls.Add(this.txtTradeCarReg);
            this.Controls.Add(this.lblTradeCarMileage);
            this.Controls.Add(this.lblTradeCarSalePrice);
            this.Controls.Add(this.dtpTradeCarYear);
            this.Controls.Add(this.txtTradeCarColour);
            this.Controls.Add(this.cmbTradeCarBody);
            this.Controls.Add(this.lblTradeCarReset);
            this.Controls.Add(this.btnTradeAarReset);
            this.Controls.Add(this.lblTradeCarBtn);
            this.Controls.Add(this.btnTradeCarAdd);
            this.Controls.Add(this.lblTradeCarBody);
            this.Controls.Add(this.lblCarTradeInHeader);
            this.Controls.Add(this.cmbTradeCarDoorNo);
            this.Controls.Add(this.lblTradeCarDoorNo);
            this.Controls.Add(this.lblTradeCarCondition);
            this.Controls.Add(this.lblTradeCarYear);
            this.Controls.Add(this.txtTradeCarInterior);
            this.Controls.Add(this.txtTradeCarModel);
            this.Controls.Add(this.lblTradeCarColour);
            this.Controls.Add(this.lblTradeCarTransmission);
            this.Controls.Add(this.lblTradeCarInterior);
            this.Controls.Add(this.lblTradeCarPurchasePrice);
            this.Controls.Add(this.lblTradeCarModel);
            this.Controls.Add(this.cmbTradeCarMake);
            this.Controls.Add(this.lblTradeCarMake);
            this.Controls.Add(this.lblTradeCarRegNo);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlTopMenuBar);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.lblCarTitle);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frmTradeIn";
            this.Text = "frmTradeIn";
            this.Load += new System.EventHandler(this.frmTradeIn_Load);
            this.panel1.ResumeLayout(false);
            this.pnlTopMenuBar.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTradeCarMileage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel pnlTopMenuBar;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lblCarTitle;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ErrorProvider errP;
        private System.Windows.Forms.NumericUpDown txtTradeCarMileage;
        private System.Windows.Forms.ComboBox cmbTradeCarTransmission;
        private System.Windows.Forms.MaskedTextBox txtTradeCarSalePrice;
        private System.Windows.Forms.ComboBox cmbTradeCarCondition;
        private System.Windows.Forms.MaskedTextBox txtTradeCarReg;
        private System.Windows.Forms.Label lblTradeCarMileage;
        private System.Windows.Forms.Label lblTradeCarSalePrice;
        private System.Windows.Forms.DateTimePicker dtpTradeCarYear;
        private System.Windows.Forms.TextBox txtTradeCarColour;
        private System.Windows.Forms.ComboBox cmbTradeCarBody;
        private System.Windows.Forms.Label lblTradeCarReset;
        private System.Windows.Forms.Button btnTradeAarReset;
        private System.Windows.Forms.Label lblTradeCarBtn;
        private System.Windows.Forms.Button btnTradeCarAdd;
        private System.Windows.Forms.Label lblTradeCarBody;
        private System.Windows.Forms.Label lblCarTradeInHeader;
        private System.Windows.Forms.ComboBox cmbTradeCarDoorNo;
        private System.Windows.Forms.Label lblTradeCarDoorNo;
        private System.Windows.Forms.Label lblTradeCarCondition;
        private System.Windows.Forms.Label lblTradeCarYear;
        private System.Windows.Forms.TextBox txtTradeCarInterior;
        private System.Windows.Forms.TextBox txtTradeCarModel;
        private System.Windows.Forms.Label lblTradeCarColour;
        private System.Windows.Forms.Label lblTradeCarTransmission;
        private System.Windows.Forms.Label lblTradeCarInterior;
        private System.Windows.Forms.Label lblTradeCarPurchasePrice;
        private System.Windows.Forms.Label lblTradeCarModel;
        private System.Windows.Forms.ComboBox cmbTradeCarMake;
        private System.Windows.Forms.Label lblTradeCarMake;
        private System.Windows.Forms.Label lblTradeCarRegNo;
        private System.Windows.Forms.TextBox txtCarPurchasePrice;
    }
}