﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScreenDesigns
{
    public partial class frmQuantity : Form
    {
        public String upgradeID, upgradeDesc, supplier, make, staffID;
        public Double sellPrice, purchasePrice;
        public int quantity;

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (numQty.Value < 1)
            {
                MessageBox.Show("No quantity selected");
            }
            else
            {
                staffID = cmbStaffID.Text;
                staffID = staffID.Substring(0, 7);

                quantity = Convert.ToInt32(numQty.Value);
                this.Close();
            }
             
        }
        
        public frmQuantity()
        {
            InitializeComponent();
        }
        protected override void OnClosing(CancelEventArgs e)
        {
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmQuantity_Load(object sender, EventArgs e)
        {
            cmbStaffID.SelectedIndex = 1;
            lblDisplayDesc.Text = upgradeDesc;
            lblDisplayMake.Text = make;
            lblDisplayPrice.Text = ("£" + sellPrice);
            lblDisplaySupplier.Text = supplier;
            lblDisplayUpgradeID.Text = upgradeID;
        }

        
    }
}
