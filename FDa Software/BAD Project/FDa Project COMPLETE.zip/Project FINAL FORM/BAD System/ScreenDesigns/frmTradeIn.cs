﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScreenDesigns
{
    public partial class frmTradeIn : Form
    {
        SqlDataAdapter daCar, daMake, daSearch;
        DataSet dsDesmonds = new DataSet();
        DataTable dtDesmonds = new DataTable();
        SqlCommandBuilder cmdBCar, cmdBMake, cmdBSearch;
        DataRow drCar;


        String connStr, sqlCar, sqlMake;
        Color clrTheme = Color.FromArgb(50, 115, 165);

        public frmTradeIn()
        {
            InitializeComponent();
        }

        private void frmTradeIn_Load(object sender, EventArgs e)
        {
            errP.Clear();
            connStr = @"Data Source = .; Initial Catalog = desmonds; Integrated Security = true";


            sqlCar = @"select * from car";
            daCar = new SqlDataAdapter(sqlCar, connStr);
            cmdBCar = new SqlCommandBuilder(daCar);
            daCar.FillSchema(dsDesmonds, SchemaType.Source, "Car");
            daCar.Fill(dsDesmonds, "Car"); // Naming the table in VS //
        }
        private void btnTradeCarAdd_Click(object sender, EventArgs e)
        {
            GlobalVar.purchasePriceGlobal = int.Parse(txtCarPurchasePrice.Text);

            MyCar myCar = new MyCar();
            bool Ok = true;
            String invalMessage = "Invalid data entry for: ";
            errP.Clear();

            try
            {
                myCar.RegNo = txtTradeCarReg.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtTradeCarReg, MyEx.toString());
            }

            try
            {
                myCar.MakeID = cmbTradeCarMake.SelectedValue.ToString(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(cmbTradeCarMake, MyEx.toString());
            }

            try
            {
                myCar.Model = txtTradeCarModel.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtTradeCarModel, MyEx.toString());
            }

            try
            {
                myCar.Interior = txtTradeCarInterior.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtTradeCarInterior, MyEx.toString());
            }

            try
            {
                myCar.Transmission = cmbTradeCarTransmission.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(cmbTradeCarTransmission, MyEx.toString());
            }
            try
            {
                myCar.BodyStyle = cmbTradeCarBody.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(cmbTradeCarBody, MyEx.toString());
            }
            try
            {
                myCar.Colour = txtTradeCarColour.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtTradeCarColour, MyEx.toString());
            }

            try
            {
                myCar.Condition = cmbTradeCarCondition.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(cmbTradeCarCondition, MyEx.toString());
            }

            try
            {
                myCar.ModelYear = dtpTradeCarYear.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(dtpTradeCarYear, MyEx.toString());
            }

            try
            {
                myCar.DoorNo = cmbTradeCarDoorNo.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(cmbTradeCarDoorNo, MyEx.toString());
            }
            try
            {
                myCar.Mileage = int.Parse(txtTradeCarMileage.Text.Trim()); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtTradeCarMileage, MyEx.toString());
            }

            try
            {
                myCar.PurchasePrice = Double.Parse(txtCarPurchasePrice.Text.Trim()); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtCarPurchasePrice, MyEx.toString());
            }

            try
            {
                myCar.SalePrice = Double.Parse(txtTradeCarSalePrice.Text); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtTradeCarSalePrice, MyEx.toString());
            }

            try
            {
                if (Ok)
                {
                    drCar = dsDesmonds.Tables["Car"].NewRow();

                    drCar["RegNo"] = myCar.RegNo;
                    drCar["MakeID"] = myCar.MakeID;
                    drCar["Model"] = myCar.Model;
                    drCar["SalePrice"] = myCar.SalePrice;
                    drCar["Interior"] = myCar.Interior;
                    drCar["Transmission"] = myCar.Transmission;
                    drCar["BodyStyle"] = myCar.BodyStyle;
                    drCar["Colour"] = myCar.Colour;
                    drCar["Mileage"] = myCar.Mileage;
                    drCar["Condition"] = myCar.Condition;
                    drCar["ModelYear"] = myCar.ModelYear;
                    drCar["PurchasePrice"] = myCar.PurchasePrice;
                    drCar["DoorNo"] = myCar.DoorNo;

                    dsDesmonds.Tables["Car"].Rows.Add(drCar);
                    daCar.Update(dsDesmonds, "Car");

                    MessageBox.Show("Car Added");

                    MessageBox.Show("The Car has been added", "Car Added to Database");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex.TargetSite + "" + ex.Message, "Error!", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
            }
        }
    }
}


