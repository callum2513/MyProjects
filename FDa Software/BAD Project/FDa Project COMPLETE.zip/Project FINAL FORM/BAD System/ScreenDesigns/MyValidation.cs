﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ScreenDesigns
{
    class MyValidation
    {
        public static bool validLength(string txt, int min, int max)
        {
            bool ok = true;

            if (string.IsNullOrEmpty(txt))
                ok = false;
            else if(txt.Length < min || txt.Length > max)
                ok = false;
            return ok;
        }
        public static bool validNumber(string txt)
        {
            bool ok = true;

            for (int count = 0; count < txt.Length; count++)
            {
                if (!(char.IsNumber(txt[count])))
                {
                    ok = false;
                }
            }
            return ok;
        }

        public static bool validDouble(string txt)
        {
            bool ok = true;

            for (int count = 0; count < txt.Length; count++)
            {
                if (!(char.IsDigit(txt[count])))
                {
                    ok = false;
                }
            }
            return ok;
        }

        public static bool validLetter(string txt) //allows alphabetic characters//
        {
            bool ok = true;

            if (txt.Trim().Length == 0)
            {
                ok = false;
            }

            else
            {
                for (int count = 0; count < txt.Length; count++)
                {
                    if (!(char.IsLetter(txt[count])) && !(char.IsWhiteSpace(txt[count])))
                        ok = false;
                }
            }
            return ok;
        }
        public static bool validForename(string txt) //allows alphabetic, dash and whitepsace for double barrel names//
        {
            bool ok = true;

            if (txt.Trim().Length == 0)
            {
                ok = false;
            }
            else
            {
                for (int count = 0; count < txt.Length; count++)
                {
                    if (!(char.IsLetter(txt[count])) && !(char.IsWhiteSpace(txt[count])) && !(txt[count].Equals('-')))
                    {
                        ok = false;
                    }
                }
            }
            return ok;
        }
        public static bool validLetterWhiteSpace(String txt)
        {
            bool ok = true;

            if (txt.Trim().Length == 0)
            {
                ok = false;
            }
            else
            {
                for (int x = 0; x < txt.Length; x++)
                {
                    if (!(char.IsLetter(txt[x])) && !char.IsWhiteSpace(txt[x]))
                    {
                        ok = false;
                    }
                }
            }
            return ok;
        }
        public static bool validSurname(string txt) //allows alphabetic, dash and whitepsace for double barrel names//
        {
            bool ok = true;

            if (txt.Trim().Length == 0)
            {
                ok = false;
            }
            else
            {
                for (int count = 0; count < txt.Length; count++)
                {
                    if (!(char.IsLetter(txt[count])) && !(char.IsWhiteSpace(txt[count])) && !(txt[count].Equals('-')))
                    {
                        ok = false;
                    }
                }
            }
            return ok;
        }
        public static bool validEmail(string txt) //allows alphanumeric and whitespace
        {
            bool ok = true;

            if (txt.Trim().Length == 0)
            {
                ok = false;
            }
            else
            {
                for (int count = 0; count < txt.Length; count++)
                {
                    if (!(char.IsLetter(txt[count])) && !(char.IsNumber(txt[count]))
                        && !((txt[count].Equals('@'))) && !((txt[count].Equals('-')))
                        && !((txt[count].Equals('_'))) && !((txt[count].Equals('.'))))
                    {
                        ok = false;
                    }
                }
            }
            return ok;
        }
        public static bool validDogDOB(DateTime dogDOB)
        {
            DateTime currentDate = DateTime.Now;
            TimeSpan t = currentDate - dogDOB;

            double NoOfDays = t.TotalDays;

            bool ok = true;

            if (NoOfDays <= 56)
            {
                ok = false;
            }
            return ok;
        }
        public static String firstLetterEachWordUpper(String word)
        {
            Char[] array = word.ToCharArray();

            if (Char.IsLower(array[0]))
            {
                array[0] = Char.ToUpper(array[0]);
            }
            for (int count = 1; count < array.Length; count++)
            {
                if (array[count - 1] == ' ')
                {
                    if (Char.IsLower(array[count]))
                    {
                        array[count] = Char.ToUpper(array[count]);
                    }
                }
                else
                    array[count] = Char.ToLower(array[count]);
            }
            return new string(array);
        }
        public static String EachLetterToUpper(String word)
        {
            Char[] array = word.ToCharArray();

            for (int count = 0; count < array.Length; count++)
            {
                if (Char.IsLower(array[count]))
                {
                    array[count] = char.ToUpper(array[count]);
                }
            }
            return new string(array);
        }
        public static bool validLetterNumberWhiteSpace(String txt)
        {
            bool ok = true;

            if (txt.Trim().Length == 0)
            {
                ok = false;
            }
            else
            {
                for (int x = 0; x < txt.Length; x++)
                {
                    if (!(char.IsNumber(txt[x])) && !char.IsWhiteSpace(txt[x]) && !(char.IsLetter(txt[x])))
                    {
                        ok = false;
                    }
                }
            }
            return ok;
        }
        public static bool validTelNo(String txt)
        {
            bool ok = true;

            if (txt.Trim().Length == 0 || txt.Trim().Length > 11)
            {
                ok = false;
            }
            else
            {

                bool isTelNo = Regex.IsMatch(txt, "[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]", RegexOptions.IgnoreCase);

                if (!isTelNo)
                {
                    ok = false;
                }
            }
            return ok;
        }
        public static bool validPostcode(String txt)
        {
            bool ok = true;

            if (txt.Trim().Length == 0)
            {
                ok = false;
            }
            else
            {

                bool isPostcode = Regex.IsMatch(txt, "[A-Z][A-Z][0-9][0-9] [0-9][A-Z][A-Z]", RegexOptions.IgnoreCase);

                if (!isPostcode)
                {
                    ok = false;
                }
            }
            return ok;
        }
        public static bool validMake(string txt)
        {
            bool ok = true;

            if (txt.Trim().Length == 0)
            {
                ok = false;
            }
            else
            {
                string[] makes = new string[] { "AUD", "FIA", "FRD", "HON", "NIS", "REN" };

                for (int i = 0; i < makes.Length; i++)
                {
                    if (makes[i].Equals(txt))
                    {
                        ok = true;
                        break;
                    }

                    ok = false;
                }
            }

            return ok;
        }

    }
}
