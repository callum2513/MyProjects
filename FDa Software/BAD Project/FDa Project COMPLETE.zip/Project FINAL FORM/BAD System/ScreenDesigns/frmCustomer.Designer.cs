﻿namespace ScreenDesigns
{
    partial class frmCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Button btnEditCustEdit;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCustomer));
            this.bannerTimer = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlTopMenuBar = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblCustomerTitle = new System.Windows.Forms.Label();
            this.tabCustomer = new System.Windows.Forms.TabControl();
            this.tabDisplay = new System.Windows.Forms.TabPage();
            this.dgvCustomer = new System.Windows.Forms.DataGridView();
            this.tabAdd = new System.Windows.Forms.TabPage();
            this.stStrip = new System.Windows.Forms.StatusStrip();
            this.stLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.txtAddCustPostcode = new System.Windows.Forms.MaskedTextBox();
            this.lblAddCustReset = new System.Windows.Forms.Label();
            this.btnAddCustReset = new System.Windows.Forms.Button();
            this.lblAddCustBtn = new System.Windows.Forms.Label();
            this.btnAddCustAdd = new System.Windows.Forms.Button();
            this.txtAddCustCounty = new System.Windows.Forms.TextBox();
            this.lblAddCustCounty = new System.Windows.Forms.Label();
            this.lblCustAddHeader = new System.Windows.Forms.Label();
            this.cmbAddCustCreditRating = new System.Windows.Forms.ComboBox();
            this.txtAddCustTelNum = new System.Windows.Forms.TextBox();
            this.txtAddCustEmail = new System.Windows.Forms.TextBox();
            this.lblAddCustCreditRating = new System.Windows.Forms.Label();
            this.lblAddCustEmail = new System.Windows.Forms.Label();
            this.lblAddCustTelNum = new System.Windows.Forms.Label();
            this.txtAddCustTown = new System.Windows.Forms.TextBox();
            this.txtAddCustStreet = new System.Windows.Forms.TextBox();
            this.txtAddCustSurname = new System.Windows.Forms.TextBox();
            this.txtAddCustForename = new System.Windows.Forms.TextBox();
            this.lblAddCustPostcode = new System.Windows.Forms.Label();
            this.lblAddCustTown = new System.Windows.Forms.Label();
            this.lblAddCustStreet = new System.Windows.Forms.Label();
            this.lblAddCustSurname = new System.Windows.Forms.Label();
            this.lblAddCustForename = new System.Windows.Forms.Label();
            this.cmbAddCustTitle = new System.Windows.Forms.ComboBox();
            this.lblAddCustTitle = new System.Windows.Forms.Label();
            this.lblAddCustNoShow = new System.Windows.Forms.Label();
            this.lblAddCustNo = new System.Windows.Forms.Label();
            this.tabEdit = new System.Windows.Forms.TabPage();
            this.txtEditCustPostcode = new System.Windows.Forms.MaskedTextBox();
            this.txtEditCustCounty = new System.Windows.Forms.TextBox();
            this.lblEditCustCounty = new System.Windows.Forms.Label();
            this.lblEditCustEdit = new System.Windows.Forms.Label();
            this.lblCustEditTitle = new System.Windows.Forms.Label();
            this.cmbEditCustCreditRating = new System.Windows.Forms.ComboBox();
            this.txtEditCustTelNum = new System.Windows.Forms.TextBox();
            this.txtEditCustEmail = new System.Windows.Forms.TextBox();
            this.lblEditCustCreditRating = new System.Windows.Forms.Label();
            this.lblEditCustEmail = new System.Windows.Forms.Label();
            this.lblEditCustTelNum = new System.Windows.Forms.Label();
            this.txtEditCustTown = new System.Windows.Forms.TextBox();
            this.txtEditCustStreet = new System.Windows.Forms.TextBox();
            this.txtEditCustSurname = new System.Windows.Forms.TextBox();
            this.txtEditCustForename = new System.Windows.Forms.TextBox();
            this.lblEditCustPostcode = new System.Windows.Forms.Label();
            this.lblEditCustTown = new System.Windows.Forms.Label();
            this.lblEditCustStreet = new System.Windows.Forms.Label();
            this.lblEditCustSurname = new System.Windows.Forms.Label();
            this.lblEditCustForename = new System.Windows.Forms.Label();
            this.cmbEditCustTitle = new System.Windows.Forms.ComboBox();
            this.lblEditCustTitle = new System.Windows.Forms.Label();
            this.lblEditCustNoShow = new System.Windows.Forms.Label();
            this.lblEditCustNo = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnCustExit = new System.Windows.Forms.Button();
            this.btnAddCust = new System.Windows.Forms.Button();
            this.btnCustEdit = new System.Windows.Forms.Button();
            this.btnCustDelete = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnCustHome = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.errP = new System.Windows.Forms.ErrorProvider(this.components);
            btnEditCustEdit = new System.Windows.Forms.Button();
            this.tabCustomer.SuspendLayout();
            this.tabDisplay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).BeginInit();
            this.tabAdd.SuspendLayout();
            this.stStrip.SuspendLayout();
            this.tabEdit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errP)).BeginInit();
            this.SuspendLayout();
            // 
            // btnEditCustEdit
            // 
            btnEditCustEdit.Location = new System.Drawing.Point(36, 372);
            btnEditCustEdit.Name = "btnEditCustEdit";
            btnEditCustEdit.Size = new System.Drawing.Size(50, 50);
            btnEditCustEdit.TabIndex = 55;
            btnEditCustEdit.UseVisualStyleBackColor = true;
            btnEditCustEdit.Click += new System.EventHandler(this.btnEditCustEdit_Click);
            // 
            // bannerTimer
            // 
            this.bannerTimer.Enabled = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel1.Location = new System.Drawing.Point(1, 55);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1000, 2);
            this.panel1.TabIndex = 35;
            // 
            // pnlTopMenuBar
            // 
            this.pnlTopMenuBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.pnlTopMenuBar.Location = new System.Drawing.Point(41, -18);
            this.pnlTopMenuBar.Margin = new System.Windows.Forms.Padding(2);
            this.pnlTopMenuBar.Name = "pnlTopMenuBar";
            this.pnlTopMenuBar.Size = new System.Drawing.Size(1000, 2);
            this.pnlTopMenuBar.TabIndex = 32;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel2.Location = new System.Drawing.Point(1, 1);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1000, 2);
            this.panel2.TabIndex = 36;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // lblCustomerTitle
            // 
            this.lblCustomerTitle.AutoSize = true;
            this.lblCustomerTitle.BackColor = System.Drawing.Color.White;
            this.lblCustomerTitle.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblCustomerTitle.Location = new System.Drawing.Point(771, 6);
            this.lblCustomerTitle.Name = "lblCustomerTitle";
            this.lblCustomerTitle.Size = new System.Drawing.Size(185, 45);
            this.lblCustomerTitle.TabIndex = 37;
            this.lblCustomerTitle.Text = "Customers";
            // 
            // tabCustomer
            // 
            this.tabCustomer.CausesValidation = false;
            this.tabCustomer.Controls.Add(this.tabDisplay);
            this.tabCustomer.Controls.Add(this.tabAdd);
            this.tabCustomer.Controls.Add(this.tabEdit);
            this.tabCustomer.Location = new System.Drawing.Point(110, 74);
            this.tabCustomer.Name = "tabCustomer";
            this.tabCustomer.SelectedIndex = 0;
            this.tabCustomer.Size = new System.Drawing.Size(865, 478);
            this.tabCustomer.TabIndex = 38;
            this.tabCustomer.SelectedIndexChanged += new System.EventHandler(this.tabCustomer_SelectedIndexChanged);
            // 
            // tabDisplay
            // 
            this.tabDisplay.Controls.Add(this.dgvCustomer);
            this.tabDisplay.Location = new System.Drawing.Point(4, 22);
            this.tabDisplay.Name = "tabDisplay";
            this.tabDisplay.Padding = new System.Windows.Forms.Padding(3);
            this.tabDisplay.Size = new System.Drawing.Size(857, 452);
            this.tabDisplay.TabIndex = 0;
            this.tabDisplay.Text = "Display";
            this.tabDisplay.UseVisualStyleBackColor = true;
            // 
            // dgvCustomer
            // 
            this.dgvCustomer.AllowUserToAddRows = false;
            this.dgvCustomer.AllowUserToDeleteRows = false;
            this.dgvCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomer.Location = new System.Drawing.Point(20, 16);
            this.dgvCustomer.Name = "dgvCustomer";
            this.dgvCustomer.ReadOnly = true;
            this.dgvCustomer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCustomer.Size = new System.Drawing.Size(822, 416);
            this.dgvCustomer.TabIndex = 0;
            // 
            // tabAdd
            // 
            this.tabAdd.Controls.Add(this.stStrip);
            this.tabAdd.Controls.Add(this.txtAddCustPostcode);
            this.tabAdd.Controls.Add(this.lblAddCustReset);
            this.tabAdd.Controls.Add(this.btnAddCustReset);
            this.tabAdd.Controls.Add(this.lblAddCustBtn);
            this.tabAdd.Controls.Add(this.btnAddCustAdd);
            this.tabAdd.Controls.Add(this.txtAddCustCounty);
            this.tabAdd.Controls.Add(this.lblAddCustCounty);
            this.tabAdd.Controls.Add(this.lblCustAddHeader);
            this.tabAdd.Controls.Add(this.cmbAddCustCreditRating);
            this.tabAdd.Controls.Add(this.txtAddCustTelNum);
            this.tabAdd.Controls.Add(this.txtAddCustEmail);
            this.tabAdd.Controls.Add(this.lblAddCustCreditRating);
            this.tabAdd.Controls.Add(this.lblAddCustEmail);
            this.tabAdd.Controls.Add(this.lblAddCustTelNum);
            this.tabAdd.Controls.Add(this.txtAddCustTown);
            this.tabAdd.Controls.Add(this.txtAddCustStreet);
            this.tabAdd.Controls.Add(this.txtAddCustSurname);
            this.tabAdd.Controls.Add(this.txtAddCustForename);
            this.tabAdd.Controls.Add(this.lblAddCustPostcode);
            this.tabAdd.Controls.Add(this.lblAddCustTown);
            this.tabAdd.Controls.Add(this.lblAddCustStreet);
            this.tabAdd.Controls.Add(this.lblAddCustSurname);
            this.tabAdd.Controls.Add(this.lblAddCustForename);
            this.tabAdd.Controls.Add(this.cmbAddCustTitle);
            this.tabAdd.Controls.Add(this.lblAddCustTitle);
            this.tabAdd.Controls.Add(this.lblAddCustNoShow);
            this.tabAdd.Controls.Add(this.lblAddCustNo);
            this.tabAdd.Location = new System.Drawing.Point(4, 22);
            this.tabAdd.Name = "tabAdd";
            this.tabAdd.Padding = new System.Windows.Forms.Padding(3);
            this.tabAdd.Size = new System.Drawing.Size(857, 452);
            this.tabAdd.TabIndex = 1;
            this.tabAdd.Text = "Add";
            this.tabAdd.UseVisualStyleBackColor = true;
            // 
            // stStrip
            // 
            this.stStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stLabel});
            this.stStrip.Location = new System.Drawing.Point(3, 427);
            this.stStrip.Name = "stStrip";
            this.stStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.stStrip.Size = new System.Drawing.Size(851, 22);
            this.stStrip.TabIndex = 78;
            this.stStrip.Text = "statusStrip1";
            // 
            // stLabel
            // 
            this.stLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stLabel.Name = "stLabel";
            this.stLabel.Size = new System.Drawing.Size(0, 17);
            // 
            // txtAddCustPostcode
            // 
            this.txtAddCustPostcode.Enabled = false;
            this.txtAddCustPostcode.Location = new System.Drawing.Point(156, 290);
            this.txtAddCustPostcode.Mask = "LL00 0LL";
            this.txtAddCustPostcode.Name = "txtAddCustPostcode";
            this.txtAddCustPostcode.Size = new System.Drawing.Size(91, 20);
            this.txtAddCustPostcode.TabIndex = 77;
            // 
            // lblAddCustReset
            // 
            this.lblAddCustReset.AutoSize = true;
            this.lblAddCustReset.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold);
            this.lblAddCustReset.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblAddCustReset.Location = new System.Drawing.Point(307, 387);
            this.lblAddCustReset.Name = "lblAddCustReset";
            this.lblAddCustReset.Size = new System.Drawing.Size(94, 21);
            this.lblAddCustReset.TabIndex = 54;
            this.lblAddCustReset.Text = "Reset Form";
            // 
            // btnAddCustReset
            // 
            this.btnAddCustReset.Location = new System.Drawing.Point(251, 372);
            this.btnAddCustReset.Name = "btnAddCustReset";
            this.btnAddCustReset.Size = new System.Drawing.Size(50, 50);
            this.btnAddCustReset.TabIndex = 53;
            this.btnAddCustReset.UseVisualStyleBackColor = true;
            this.btnAddCustReset.Click += new System.EventHandler(this.btnAddCustClear_Click);
            // 
            // lblAddCustBtn
            // 
            this.lblAddCustBtn.AutoSize = true;
            this.lblAddCustBtn.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold);
            this.lblAddCustBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblAddCustBtn.Location = new System.Drawing.Point(92, 387);
            this.lblAddCustBtn.Name = "lblAddCustBtn";
            this.lblAddCustBtn.Size = new System.Drawing.Size(118, 21);
            this.lblAddCustBtn.TabIndex = 52;
            this.lblAddCustBtn.Text = "Add Customer";
            // 
            // btnAddCustAdd
            // 
            this.btnAddCustAdd.Location = new System.Drawing.Point(36, 372);
            this.btnAddCustAdd.Name = "btnAddCustAdd";
            this.btnAddCustAdd.Size = new System.Drawing.Size(50, 50);
            this.btnAddCustAdd.TabIndex = 51;
            this.btnAddCustAdd.UseVisualStyleBackColor = true;
            this.btnAddCustAdd.Click += new System.EventHandler(this.btnAddCustAdd_Click);
            // 
            // txtAddCustCounty
            // 
            this.txtAddCustCounty.Location = new System.Drawing.Point(156, 264);
            this.txtAddCustCounty.Name = "txtAddCustCounty";
            this.txtAddCustCounty.Size = new System.Drawing.Size(147, 20);
            this.txtAddCustCounty.TabIndex = 50;
            this.txtAddCustCounty.TextChanged += new System.EventHandler(this.txtAddCustCounty_TextChanged);
            // 
            // lblAddCustCounty
            // 
            this.lblAddCustCounty.AutoSize = true;
            this.lblAddCustCounty.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddCustCounty.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblAddCustCounty.Location = new System.Drawing.Point(32, 263);
            this.lblAddCustCounty.Name = "lblAddCustCounty";
            this.lblAddCustCounty.Size = new System.Drawing.Size(69, 21);
            this.lblAddCustCounty.TabIndex = 49;
            this.lblAddCustCounty.Text = "County:";
            // 
            // lblCustAddHeader
            // 
            this.lblCustAddHeader.AutoSize = true;
            this.lblCustAddHeader.BackColor = System.Drawing.Color.White;
            this.lblCustAddHeader.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustAddHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.errP.SetIconAlignment(this.lblCustAddHeader, System.Windows.Forms.ErrorIconAlignment.BottomRight);
            this.lblCustAddHeader.Location = new System.Drawing.Point(19, 19);
            this.lblCustAddHeader.Name = "lblCustAddHeader";
            this.lblCustAddHeader.Size = new System.Drawing.Size(267, 45);
            this.lblCustAddHeader.TabIndex = 48;
            this.lblCustAddHeader.Text = "Add Customer ";
            // 
            // cmbAddCustCreditRating
            // 
            this.cmbAddCustCreditRating.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAddCustCreditRating.FormattingEnabled = true;
            this.cmbAddCustCreditRating.Items.AddRange(new object[] {
            "Very Poor",
            "Poor",
            "Average",
            "Good",
            "Very Good",
            "Excellent"});
            this.cmbAddCustCreditRating.Location = new System.Drawing.Point(519, 172);
            this.cmbAddCustCreditRating.Name = "cmbAddCustCreditRating";
            this.cmbAddCustCreditRating.Size = new System.Drawing.Size(137, 21);
            this.cmbAddCustCreditRating.TabIndex = 23;
            // 
            // txtAddCustTelNum
            // 
            this.txtAddCustTelNum.Location = new System.Drawing.Point(519, 140);
            this.txtAddCustTelNum.Name = "txtAddCustTelNum";
            this.txtAddCustTelNum.Size = new System.Drawing.Size(171, 20);
            this.txtAddCustTelNum.TabIndex = 20;
            this.txtAddCustTelNum.TextChanged += new System.EventHandler(this.txtAddCustTelNum_TextChanged);
            // 
            // txtAddCustEmail
            // 
            this.txtAddCustEmail.Location = new System.Drawing.Point(519, 109);
            this.txtAddCustEmail.Name = "txtAddCustEmail";
            this.txtAddCustEmail.Size = new System.Drawing.Size(171, 20);
            this.txtAddCustEmail.TabIndex = 19;
            this.txtAddCustEmail.TextChanged += new System.EventHandler(this.txtAddCustEmail_TextChanged);
            // 
            // lblAddCustCreditRating
            // 
            this.lblAddCustCreditRating.AutoSize = true;
            this.lblAddCustCreditRating.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddCustCreditRating.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblAddCustCreditRating.Location = new System.Drawing.Point(362, 172);
            this.lblAddCustCreditRating.Name = "lblAddCustCreditRating";
            this.lblAddCustCreditRating.Size = new System.Drawing.Size(114, 21);
            this.lblAddCustCreditRating.TabIndex = 18;
            this.lblAddCustCreditRating.Text = "Credit Rating:";
            // 
            // lblAddCustEmail
            // 
            this.lblAddCustEmail.AutoSize = true;
            this.lblAddCustEmail.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddCustEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblAddCustEmail.Location = new System.Drawing.Point(362, 108);
            this.lblAddCustEmail.Name = "lblAddCustEmail";
            this.lblAddCustEmail.Size = new System.Drawing.Size(57, 21);
            this.lblAddCustEmail.TabIndex = 17;
            this.lblAddCustEmail.Text = "Email:";
            // 
            // lblAddCustTelNum
            // 
            this.lblAddCustTelNum.AutoSize = true;
            this.lblAddCustTelNum.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddCustTelNum.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblAddCustTelNum.Location = new System.Drawing.Point(362, 139);
            this.lblAddCustTelNum.Name = "lblAddCustTelNum";
            this.lblAddCustTelNum.Size = new System.Drawing.Size(79, 21);
            this.lblAddCustTelNum.TabIndex = 14;
            this.lblAddCustTelNum.Text = "Tel Num:";
            // 
            // txtAddCustTown
            // 
            this.txtAddCustTown.Location = new System.Drawing.Point(156, 234);
            this.txtAddCustTown.Name = "txtAddCustTown";
            this.txtAddCustTown.Size = new System.Drawing.Size(147, 20);
            this.txtAddCustTown.TabIndex = 12;
            this.txtAddCustTown.TextChanged += new System.EventHandler(this.txtAddCustTown_TextChanged);
            // 
            // txtAddCustStreet
            // 
            this.txtAddCustStreet.Location = new System.Drawing.Point(156, 202);
            this.txtAddCustStreet.Name = "txtAddCustStreet";
            this.txtAddCustStreet.Size = new System.Drawing.Size(147, 20);
            this.txtAddCustStreet.TabIndex = 11;
            this.txtAddCustStreet.TextChanged += new System.EventHandler(this.txtAddCustStreet_TextChanged);
            // 
            // txtAddCustSurname
            // 
            this.txtAddCustSurname.Location = new System.Drawing.Point(156, 172);
            this.txtAddCustSurname.Name = "txtAddCustSurname";
            this.txtAddCustSurname.Size = new System.Drawing.Size(147, 20);
            this.txtAddCustSurname.TabIndex = 10;
            this.txtAddCustSurname.TextChanged += new System.EventHandler(this.txtAddCustSurname_TextChanged);
            // 
            // txtAddCustForename
            // 
            this.txtAddCustForename.Location = new System.Drawing.Point(156, 140);
            this.txtAddCustForename.Name = "txtAddCustForename";
            this.txtAddCustForename.Size = new System.Drawing.Size(147, 20);
            this.txtAddCustForename.TabIndex = 9;
            this.txtAddCustForename.TextChanged += new System.EventHandler(this.txtAddCustForename_TextChanged);
            // 
            // lblAddCustPostcode
            // 
            this.lblAddCustPostcode.AutoSize = true;
            this.lblAddCustPostcode.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddCustPostcode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblAddCustPostcode.Location = new System.Drawing.Point(32, 293);
            this.lblAddCustPostcode.Name = "lblAddCustPostcode";
            this.lblAddCustPostcode.Size = new System.Drawing.Size(84, 21);
            this.lblAddCustPostcode.TabIndex = 8;
            this.lblAddCustPostcode.Text = "Postcode:";
            // 
            // lblAddCustTown
            // 
            this.lblAddCustTown.AutoSize = true;
            this.lblAddCustTown.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddCustTown.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblAddCustTown.Location = new System.Drawing.Point(32, 233);
            this.lblAddCustTown.Name = "lblAddCustTown";
            this.lblAddCustTown.Size = new System.Drawing.Size(56, 21);
            this.lblAddCustTown.TabIndex = 7;
            this.lblAddCustTown.Text = "Town:";
            // 
            // lblAddCustStreet
            // 
            this.lblAddCustStreet.AutoSize = true;
            this.lblAddCustStreet.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddCustStreet.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblAddCustStreet.Location = new System.Drawing.Point(32, 201);
            this.lblAddCustStreet.Name = "lblAddCustStreet";
            this.lblAddCustStreet.Size = new System.Drawing.Size(55, 21);
            this.lblAddCustStreet.TabIndex = 6;
            this.lblAddCustStreet.Text = "Street";
            // 
            // lblAddCustSurname
            // 
            this.lblAddCustSurname.AutoSize = true;
            this.lblAddCustSurname.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddCustSurname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblAddCustSurname.Location = new System.Drawing.Point(32, 171);
            this.lblAddCustSurname.Name = "lblAddCustSurname";
            this.lblAddCustSurname.Size = new System.Drawing.Size(82, 21);
            this.lblAddCustSurname.TabIndex = 5;
            this.lblAddCustSurname.Text = "Surname:";
            // 
            // lblAddCustForename
            // 
            this.lblAddCustForename.AutoSize = true;
            this.lblAddCustForename.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddCustForename.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblAddCustForename.Location = new System.Drawing.Point(32, 140);
            this.lblAddCustForename.Name = "lblAddCustForename";
            this.lblAddCustForename.Size = new System.Drawing.Size(90, 21);
            this.lblAddCustForename.TabIndex = 4;
            this.lblAddCustForename.Text = "Forename:";
            // 
            // cmbAddCustTitle
            // 
            this.cmbAddCustTitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAddCustTitle.FormattingEnabled = true;
            this.cmbAddCustTitle.Items.AddRange(new object[] {
            "Mr",
            "Miss",
            "Mrs",
            "Ms"});
            this.cmbAddCustTitle.Location = new System.Drawing.Point(156, 108);
            this.cmbAddCustTitle.Name = "cmbAddCustTitle";
            this.cmbAddCustTitle.Size = new System.Drawing.Size(91, 21);
            this.cmbAddCustTitle.TabIndex = 3;
            // 
            // lblAddCustTitle
            // 
            this.lblAddCustTitle.AutoSize = true;
            this.lblAddCustTitle.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddCustTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblAddCustTitle.Location = new System.Drawing.Point(32, 108);
            this.lblAddCustTitle.Name = "lblAddCustTitle";
            this.lblAddCustTitle.Size = new System.Drawing.Size(48, 21);
            this.lblAddCustTitle.TabIndex = 2;
            this.lblAddCustTitle.Text = "Title:";
            // 
            // lblAddCustNoShow
            // 
            this.lblAddCustNoShow.AutoSize = true;
            this.lblAddCustNoShow.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddCustNoShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblAddCustNoShow.Location = new System.Drawing.Point(152, 77);
            this.lblAddCustNoShow.Name = "lblAddCustNoShow";
            this.lblAddCustNoShow.Size = new System.Drawing.Size(123, 21);
            this.lblAddCustNoShow.TabIndex = 1;
            this.lblAddCustNoShow.Text = "CUST NO HERE";
            // 
            // lblAddCustNo
            // 
            this.lblAddCustNo.AutoSize = true;
            this.lblAddCustNo.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddCustNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblAddCustNo.Location = new System.Drawing.Point(32, 77);
            this.lblAddCustNo.Name = "lblAddCustNo";
            this.lblAddCustNo.Size = new System.Drawing.Size(114, 21);
            this.lblAddCustNo.TabIndex = 0;
            this.lblAddCustNo.Text = "Customer No:";
            // 
            // tabEdit
            // 
            this.tabEdit.Controls.Add(this.txtEditCustPostcode);
            this.tabEdit.Controls.Add(this.txtEditCustCounty);
            this.tabEdit.Controls.Add(this.lblEditCustCounty);
            this.tabEdit.Controls.Add(this.lblEditCustEdit);
            this.tabEdit.Controls.Add(this.lblCustEditTitle);
            this.tabEdit.Controls.Add(btnEditCustEdit);
            this.tabEdit.Controls.Add(this.cmbEditCustCreditRating);
            this.tabEdit.Controls.Add(this.txtEditCustTelNum);
            this.tabEdit.Controls.Add(this.txtEditCustEmail);
            this.tabEdit.Controls.Add(this.lblEditCustCreditRating);
            this.tabEdit.Controls.Add(this.lblEditCustEmail);
            this.tabEdit.Controls.Add(this.lblEditCustTelNum);
            this.tabEdit.Controls.Add(this.txtEditCustTown);
            this.tabEdit.Controls.Add(this.txtEditCustStreet);
            this.tabEdit.Controls.Add(this.txtEditCustSurname);
            this.tabEdit.Controls.Add(this.txtEditCustForename);
            this.tabEdit.Controls.Add(this.lblEditCustPostcode);
            this.tabEdit.Controls.Add(this.lblEditCustTown);
            this.tabEdit.Controls.Add(this.lblEditCustStreet);
            this.tabEdit.Controls.Add(this.lblEditCustSurname);
            this.tabEdit.Controls.Add(this.lblEditCustForename);
            this.tabEdit.Controls.Add(this.cmbEditCustTitle);
            this.tabEdit.Controls.Add(this.lblEditCustTitle);
            this.tabEdit.Controls.Add(this.lblEditCustNoShow);
            this.tabEdit.Controls.Add(this.lblEditCustNo);
            this.tabEdit.Location = new System.Drawing.Point(4, 22);
            this.tabEdit.Name = "tabEdit";
            this.tabEdit.Size = new System.Drawing.Size(857, 452);
            this.tabEdit.TabIndex = 2;
            this.tabEdit.Text = "Edit";
            this.tabEdit.UseVisualStyleBackColor = true;
            // 
            // txtEditCustPostcode
            // 
            this.txtEditCustPostcode.Enabled = false;
            this.txtEditCustPostcode.Location = new System.Drawing.Point(156, 290);
            this.txtEditCustPostcode.Mask = "LL00 0LL";
            this.txtEditCustPostcode.Name = "txtEditCustPostcode";
            this.txtEditCustPostcode.Size = new System.Drawing.Size(91, 20);
            this.txtEditCustPostcode.TabIndex = 76;
            // 
            // txtEditCustCounty
            // 
            this.txtEditCustCounty.Enabled = false;
            this.txtEditCustCounty.Location = new System.Drawing.Point(156, 264);
            this.txtEditCustCounty.Name = "txtEditCustCounty";
            this.txtEditCustCounty.Size = new System.Drawing.Size(147, 20);
            this.txtEditCustCounty.TabIndex = 75;
            this.txtEditCustCounty.TextChanged += new System.EventHandler(this.txtEditCustCounty_TextChanged_1);
            // 
            // lblEditCustCounty
            // 
            this.lblEditCustCounty.AutoSize = true;
            this.lblEditCustCounty.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditCustCounty.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblEditCustCounty.Location = new System.Drawing.Point(32, 263);
            this.lblEditCustCounty.Name = "lblEditCustCounty";
            this.lblEditCustCounty.Size = new System.Drawing.Size(69, 21);
            this.lblEditCustCounty.TabIndex = 74;
            this.lblEditCustCounty.Text = "County:";
            // 
            // lblEditCustEdit
            // 
            this.lblEditCustEdit.AutoSize = true;
            this.lblEditCustEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold);
            this.lblEditCustEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblEditCustEdit.Location = new System.Drawing.Point(92, 387);
            this.lblEditCustEdit.Name = "lblEditCustEdit";
            this.lblEditCustEdit.Size = new System.Drawing.Size(40, 21);
            this.lblEditCustEdit.TabIndex = 56;
            this.lblEditCustEdit.Text = "Edit";
            // 
            // lblCustEditTitle
            // 
            this.lblCustEditTitle.AutoSize = true;
            this.lblCustEditTitle.BackColor = System.Drawing.Color.White;
            this.lblCustEditTitle.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustEditTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblCustEditTitle.Location = new System.Drawing.Point(19, 19);
            this.lblCustEditTitle.Name = "lblCustEditTitle";
            this.lblCustEditTitle.Size = new System.Drawing.Size(263, 45);
            this.lblCustEditTitle.TabIndex = 73;
            this.lblCustEditTitle.Text = "Edit Customer ";
            // 
            // cmbEditCustCreditRating
            // 
            this.cmbEditCustCreditRating.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEditCustCreditRating.Enabled = false;
            this.cmbEditCustCreditRating.FormattingEnabled = true;
            this.cmbEditCustCreditRating.Items.AddRange(new object[] {
            "Very Poor",
            "Poor",
            "Average",
            "Good",
            "Very Good",
            "Excellent"});
            this.cmbEditCustCreditRating.Location = new System.Drawing.Point(519, 172);
            this.cmbEditCustCreditRating.Name = "cmbEditCustCreditRating";
            this.cmbEditCustCreditRating.Size = new System.Drawing.Size(137, 21);
            this.cmbEditCustCreditRating.TabIndex = 72;
            // 
            // txtEditCustTelNum
            // 
            this.txtEditCustTelNum.Enabled = false;
            this.txtEditCustTelNum.Location = new System.Drawing.Point(519, 140);
            this.txtEditCustTelNum.Name = "txtEditCustTelNum";
            this.txtEditCustTelNum.Size = new System.Drawing.Size(171, 20);
            this.txtEditCustTelNum.TabIndex = 69;
            this.txtEditCustTelNum.TextChanged += new System.EventHandler(this.txtEditCustTelNum_TextChanged_1);
            // 
            // txtEditCustEmail
            // 
            this.txtEditCustEmail.Enabled = false;
            this.txtEditCustEmail.Location = new System.Drawing.Point(519, 109);
            this.txtEditCustEmail.Name = "txtEditCustEmail";
            this.txtEditCustEmail.Size = new System.Drawing.Size(171, 20);
            this.txtEditCustEmail.TabIndex = 68;
            this.txtEditCustEmail.TextChanged += new System.EventHandler(this.txtEditCustEmail_TextChanged_1);
            // 
            // lblEditCustCreditRating
            // 
            this.lblEditCustCreditRating.AutoSize = true;
            this.lblEditCustCreditRating.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditCustCreditRating.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblEditCustCreditRating.Location = new System.Drawing.Point(362, 172);
            this.lblEditCustCreditRating.Name = "lblEditCustCreditRating";
            this.lblEditCustCreditRating.Size = new System.Drawing.Size(114, 21);
            this.lblEditCustCreditRating.TabIndex = 67;
            this.lblEditCustCreditRating.Text = "Credit Rating:";
            // 
            // lblEditCustEmail
            // 
            this.lblEditCustEmail.AutoSize = true;
            this.lblEditCustEmail.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditCustEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblEditCustEmail.Location = new System.Drawing.Point(362, 108);
            this.lblEditCustEmail.Name = "lblEditCustEmail";
            this.lblEditCustEmail.Size = new System.Drawing.Size(57, 21);
            this.lblEditCustEmail.TabIndex = 66;
            this.lblEditCustEmail.Text = "Email:";
            // 
            // lblEditCustTelNum
            // 
            this.lblEditCustTelNum.AutoSize = true;
            this.lblEditCustTelNum.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditCustTelNum.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblEditCustTelNum.Location = new System.Drawing.Point(362, 139);
            this.lblEditCustTelNum.Name = "lblEditCustTelNum";
            this.lblEditCustTelNum.Size = new System.Drawing.Size(79, 21);
            this.lblEditCustTelNum.TabIndex = 63;
            this.lblEditCustTelNum.Text = "Tel Num:";
            // 
            // txtEditCustTown
            // 
            this.txtEditCustTown.Enabled = false;
            this.txtEditCustTown.Location = new System.Drawing.Point(156, 234);
            this.txtEditCustTown.Name = "txtEditCustTown";
            this.txtEditCustTown.Size = new System.Drawing.Size(147, 20);
            this.txtEditCustTown.TabIndex = 61;
            this.txtEditCustTown.TextChanged += new System.EventHandler(this.txtEditCustTown_TextChanged_1);
            // 
            // txtEditCustStreet
            // 
            this.txtEditCustStreet.Enabled = false;
            this.txtEditCustStreet.Location = new System.Drawing.Point(156, 202);
            this.txtEditCustStreet.Name = "txtEditCustStreet";
            this.txtEditCustStreet.Size = new System.Drawing.Size(147, 20);
            this.txtEditCustStreet.TabIndex = 60;
            this.txtEditCustStreet.TextChanged += new System.EventHandler(this.txtEditCustStreet_TextChanged_1);
            // 
            // txtEditCustSurname
            // 
            this.txtEditCustSurname.Enabled = false;
            this.txtEditCustSurname.Location = new System.Drawing.Point(156, 172);
            this.txtEditCustSurname.Name = "txtEditCustSurname";
            this.txtEditCustSurname.Size = new System.Drawing.Size(147, 20);
            this.txtEditCustSurname.TabIndex = 59;
            // 
            // txtEditCustForename
            // 
            this.txtEditCustForename.Enabled = false;
            this.txtEditCustForename.Location = new System.Drawing.Point(156, 140);
            this.txtEditCustForename.Name = "txtEditCustForename";
            this.txtEditCustForename.Size = new System.Drawing.Size(147, 20);
            this.txtEditCustForename.TabIndex = 58;
            // 
            // lblEditCustPostcode
            // 
            this.lblEditCustPostcode.AutoSize = true;
            this.lblEditCustPostcode.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditCustPostcode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblEditCustPostcode.Location = new System.Drawing.Point(32, 293);
            this.lblEditCustPostcode.Name = "lblEditCustPostcode";
            this.lblEditCustPostcode.Size = new System.Drawing.Size(84, 21);
            this.lblEditCustPostcode.TabIndex = 57;
            this.lblEditCustPostcode.Text = "Postcode:";
            // 
            // lblEditCustTown
            // 
            this.lblEditCustTown.AutoSize = true;
            this.lblEditCustTown.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditCustTown.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblEditCustTown.Location = new System.Drawing.Point(32, 233);
            this.lblEditCustTown.Name = "lblEditCustTown";
            this.lblEditCustTown.Size = new System.Drawing.Size(56, 21);
            this.lblEditCustTown.TabIndex = 56;
            this.lblEditCustTown.Text = "Town:";
            // 
            // lblEditCustStreet
            // 
            this.lblEditCustStreet.AutoSize = true;
            this.lblEditCustStreet.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditCustStreet.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblEditCustStreet.Location = new System.Drawing.Point(32, 201);
            this.lblEditCustStreet.Name = "lblEditCustStreet";
            this.lblEditCustStreet.Size = new System.Drawing.Size(55, 21);
            this.lblEditCustStreet.TabIndex = 55;
            this.lblEditCustStreet.Text = "Street";
            // 
            // lblEditCustSurname
            // 
            this.lblEditCustSurname.AutoSize = true;
            this.lblEditCustSurname.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditCustSurname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblEditCustSurname.Location = new System.Drawing.Point(32, 171);
            this.lblEditCustSurname.Name = "lblEditCustSurname";
            this.lblEditCustSurname.Size = new System.Drawing.Size(82, 21);
            this.lblEditCustSurname.TabIndex = 54;
            this.lblEditCustSurname.Text = "Surname:";
            // 
            // lblEditCustForename
            // 
            this.lblEditCustForename.AutoSize = true;
            this.lblEditCustForename.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditCustForename.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblEditCustForename.Location = new System.Drawing.Point(32, 140);
            this.lblEditCustForename.Name = "lblEditCustForename";
            this.lblEditCustForename.Size = new System.Drawing.Size(90, 21);
            this.lblEditCustForename.TabIndex = 53;
            this.lblEditCustForename.Text = "Forename:";
            // 
            // cmbEditCustTitle
            // 
            this.cmbEditCustTitle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEditCustTitle.Enabled = false;
            this.cmbEditCustTitle.FormattingEnabled = true;
            this.cmbEditCustTitle.Items.AddRange(new object[] {
            "Mr",
            "Miss",
            "Mrs",
            "Ms"});
            this.cmbEditCustTitle.Location = new System.Drawing.Point(156, 108);
            this.cmbEditCustTitle.Name = "cmbEditCustTitle";
            this.cmbEditCustTitle.Size = new System.Drawing.Size(91, 21);
            this.cmbEditCustTitle.TabIndex = 52;
            // 
            // lblEditCustTitle
            // 
            this.lblEditCustTitle.AutoSize = true;
            this.lblEditCustTitle.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditCustTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblEditCustTitle.Location = new System.Drawing.Point(32, 108);
            this.lblEditCustTitle.Name = "lblEditCustTitle";
            this.lblEditCustTitle.Size = new System.Drawing.Size(48, 21);
            this.lblEditCustTitle.TabIndex = 51;
            this.lblEditCustTitle.Text = "Title:";
            // 
            // lblEditCustNoShow
            // 
            this.lblEditCustNoShow.AutoSize = true;
            this.lblEditCustNoShow.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditCustNoShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblEditCustNoShow.Location = new System.Drawing.Point(152, 77);
            this.lblEditCustNoShow.Name = "lblEditCustNoShow";
            this.lblEditCustNoShow.Size = new System.Drawing.Size(123, 21);
            this.lblEditCustNoShow.TabIndex = 50;
            this.lblEditCustNoShow.Text = "CUST NO HERE";
            // 
            // lblEditCustNo
            // 
            this.lblEditCustNo.AutoSize = true;
            this.lblEditCustNo.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditCustNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblEditCustNo.Location = new System.Drawing.Point(32, 77);
            this.lblEditCustNo.Name = "lblEditCustNo";
            this.lblEditCustNo.Size = new System.Drawing.Size(114, 21);
            this.lblEditCustNo.TabIndex = 49;
            this.lblEditCustNo.Text = "Customer No:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel3.Location = new System.Drawing.Point(95, 57);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(3, 520);
            this.panel3.TabIndex = 36;
            // 
            // btnCustExit
            // 
            this.btnCustExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCustExit.BackgroundImage")));
            this.btnCustExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCustExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustExit.Location = new System.Drawing.Point(9, 456);
            this.btnCustExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnCustExit.Name = "btnCustExit";
            this.btnCustExit.Size = new System.Drawing.Size(75, 75);
            this.btnCustExit.TabIndex = 44;
            this.btnCustExit.UseVisualStyleBackColor = true;
            this.btnCustExit.Click += new System.EventHandler(this.btnCustExit_Click);
            // 
            // btnAddCust
            // 
            this.btnAddCust.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddCust.BackgroundImage")));
            this.btnAddCust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAddCust.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCust.Location = new System.Drawing.Point(9, 96);
            this.btnAddCust.Margin = new System.Windows.Forms.Padding(2);
            this.btnAddCust.Name = "btnAddCust";
            this.btnAddCust.Size = new System.Drawing.Size(75, 75);
            this.btnAddCust.TabIndex = 41;
            this.btnAddCust.UseVisualStyleBackColor = true;
            this.btnAddCust.Click += new System.EventHandler(this.btnAddCust_Click);
            // 
            // btnCustEdit
            // 
            this.btnCustEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCustEdit.BackgroundImage")));
            this.btnCustEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCustEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustEdit.Location = new System.Drawing.Point(9, 186);
            this.btnCustEdit.Margin = new System.Windows.Forms.Padding(2);
            this.btnCustEdit.Name = "btnCustEdit";
            this.btnCustEdit.Size = new System.Drawing.Size(75, 75);
            this.btnCustEdit.TabIndex = 40;
            this.btnCustEdit.UseVisualStyleBackColor = true;
            this.btnCustEdit.Click += new System.EventHandler(this.btnCustEdit_Click);
            // 
            // btnCustDelete
            // 
            this.btnCustDelete.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCustDelete.BackgroundImage")));
            this.btnCustDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCustDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustDelete.Location = new System.Drawing.Point(9, 276);
            this.btnCustDelete.Margin = new System.Windows.Forms.Padding(2);
            this.btnCustDelete.Name = "btnCustDelete";
            this.btnCustDelete.Size = new System.Drawing.Size(75, 75);
            this.btnCustDelete.TabIndex = 39;
            this.btnCustDelete.UseVisualStyleBackColor = true;
            this.btnCustDelete.Click += new System.EventHandler(this.btnCustDelete_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(-103, -2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1089, 55);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            // 
            // btnCustHome
            // 
            this.btnCustHome.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCustHome.BackgroundImage")));
            this.btnCustHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCustHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustHome.Location = new System.Drawing.Point(9, 366);
            this.btnCustHome.Margin = new System.Windows.Forms.Padding(2);
            this.btnCustHome.Name = "btnCustHome";
            this.btnCustHome.Size = new System.Drawing.Size(75, 75);
            this.btnCustHome.TabIndex = 45;
            this.btnCustHome.UseVisualStyleBackColor = true;
            this.btnCustHome.Click += new System.EventHandler(this.btnCustHome_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // errP
            // 
            this.errP.ContainerControl = this;
            // 
            // frmCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.btnCustHome);
            this.Controls.Add(this.btnCustExit);
            this.Controls.Add(this.btnAddCust);
            this.Controls.Add(this.btnCustEdit);
            this.Controls.Add(this.btnCustDelete);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.tabCustomer);
            this.Controls.Add(this.lblCustomerTitle);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pnlTopMenuBar);
            this.Name = "frmCustomer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Desmond Motors | Sales Management System | © PLAB Software Solutions 2020";
            this.Load += new System.EventHandler(this.frmCustomer_Load);
            this.Shown += new System.EventHandler(this.frmCustomer_Shown);
            this.tabCustomer.ResumeLayout(false);
            this.tabDisplay.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).EndInit();
            this.tabAdd.ResumeLayout(false);
            this.tabAdd.PerformLayout();
            this.stStrip.ResumeLayout(false);
            this.stStrip.PerformLayout();
            this.tabEdit.ResumeLayout(false);
            this.tabEdit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errP)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer bannerTimer;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnlTopMenuBar;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblCustomerTitle;
        private System.Windows.Forms.TabControl tabCustomer;
        private System.Windows.Forms.TabPage tabDisplay;
        private System.Windows.Forms.TabPage tabAdd;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnCustExit;
        private System.Windows.Forms.Button btnAddCust;
        private System.Windows.Forms.Button btnCustEdit;
        private System.Windows.Forms.Button btnCustDelete;
        private System.Windows.Forms.DataGridView dgvCustomer;
        private System.Windows.Forms.Button btnCustHome;
        private System.Windows.Forms.Label lblAddCustNoShow;
        private System.Windows.Forms.Label lblAddCustNo;
        private System.Windows.Forms.Label lblAddCustSurname;
        private System.Windows.Forms.Label lblAddCustForename;
        private System.Windows.Forms.ComboBox cmbAddCustTitle;
        private System.Windows.Forms.Label lblAddCustTitle;
        private System.Windows.Forms.TextBox txtAddCustTown;
        private System.Windows.Forms.TextBox txtAddCustStreet;
        private System.Windows.Forms.TextBox txtAddCustSurname;
        private System.Windows.Forms.TextBox txtAddCustForename;
        private System.Windows.Forms.Label lblAddCustPostcode;
        private System.Windows.Forms.Label lblAddCustTown;
        private System.Windows.Forms.Label lblAddCustStreet;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ComboBox cmbAddCustCreditRating;
        private System.Windows.Forms.TextBox txtAddCustTelNum;
        private System.Windows.Forms.TextBox txtAddCustEmail;
        private System.Windows.Forms.Label lblAddCustCreditRating;
        private System.Windows.Forms.Label lblAddCustEmail;
        private System.Windows.Forms.Label lblAddCustTelNum;
        private System.Windows.Forms.Label lblCustAddHeader;
		private System.Windows.Forms.TextBox txtAddCustCounty;
		private System.Windows.Forms.Label lblAddCustCounty;
        private System.Windows.Forms.Label lblAddCustBtn;
        private System.Windows.Forms.Button btnAddCustAdd;
        private System.Windows.Forms.Label lblAddCustReset;
        private System.Windows.Forms.Button btnAddCustReset;
        private System.Windows.Forms.TabPage tabEdit;
        private System.Windows.Forms.TextBox txtEditCustCounty;
        private System.Windows.Forms.Label lblEditCustCounty;
        private System.Windows.Forms.Label lblEditCustEdit;
        private System.Windows.Forms.Label lblCustEditTitle;
        private System.Windows.Forms.ComboBox cmbEditCustCreditRating;
        private System.Windows.Forms.TextBox txtEditCustTelNum;
        private System.Windows.Forms.TextBox txtEditCustEmail;
        private System.Windows.Forms.Label lblEditCustCreditRating;
        private System.Windows.Forms.Label lblEditCustEmail;
        private System.Windows.Forms.Label lblEditCustTelNum;
        private System.Windows.Forms.TextBox txtEditCustTown;
        private System.Windows.Forms.TextBox txtEditCustStreet;
        private System.Windows.Forms.TextBox txtEditCustSurname;
        private System.Windows.Forms.TextBox txtEditCustForename;
        private System.Windows.Forms.Label lblEditCustPostcode;
        private System.Windows.Forms.Label lblEditCustTown;
        private System.Windows.Forms.Label lblEditCustStreet;
        private System.Windows.Forms.Label lblEditCustSurname;
        private System.Windows.Forms.Label lblEditCustForename;
        private System.Windows.Forms.ComboBox cmbEditCustTitle;
        private System.Windows.Forms.Label lblEditCustTitle;
        private System.Windows.Forms.Label lblEditCustNoShow;
        private System.Windows.Forms.Label lblEditCustNo;
        private System.Windows.Forms.ErrorProvider errP;
        private System.Windows.Forms.MaskedTextBox txtEditCustPostcode;
        private System.Windows.Forms.MaskedTextBox txtAddCustPostcode;
        private System.Windows.Forms.StatusStrip stStrip;
        private System.Windows.Forms.ToolStripStatusLabel stLabel;
    }
}