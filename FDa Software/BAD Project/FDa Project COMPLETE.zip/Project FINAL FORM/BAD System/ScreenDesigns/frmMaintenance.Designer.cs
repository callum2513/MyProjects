﻿namespace ScreenDesigns
{
    partial class frmMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMaintenance));
            this.lblExitBtn = new System.Windows.Forms.Label();
            this.lblUpgradesBtn = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pb1 = new System.Windows.Forms.PictureBox();
            this.bannerTimer = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlTopMenuBar = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnMaintenance = new System.Windows.Forms.Button();
            this.btnCars = new System.Windows.Forms.Button();
            this.btnDisplayEdit = new System.Windows.Forms.Button();
            this.lblEditBtns = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblExitBtn
            // 
            this.lblExitBtn.AutoSize = true;
            this.lblExitBtn.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExitBtn.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblExitBtn.Location = new System.Drawing.Point(91, 242);
            this.lblExitBtn.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblExitBtn.Name = "lblExitBtn";
            this.lblExitBtn.Size = new System.Drawing.Size(41, 19);
            this.lblExitBtn.TabIndex = 48;
            this.lblExitBtn.Text = "Exit";
            this.lblExitBtn.Visible = false;
            // 
            // lblUpgradesBtn
            // 
            this.lblUpgradesBtn.AutoSize = true;
            this.lblUpgradesBtn.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpgradesBtn.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblUpgradesBtn.Location = new System.Drawing.Point(91, 104);
            this.lblUpgradesBtn.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUpgradesBtn.Name = "lblUpgradesBtn";
            this.lblUpgradesBtn.Size = new System.Drawing.Size(86, 19);
            this.lblUpgradesBtn.TabIndex = 44;
            this.lblUpgradesBtn.Text = "Upgrades";
            this.lblUpgradesBtn.Visible = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel3.Location = new System.Drawing.Point(-4, 73);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1000, 3);
            this.panel3.TabIndex = 32;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.pb1);
            this.panel2.Location = new System.Drawing.Point(-3, -10);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(990, 75);
            this.panel2.TabIndex = 42;
            // 
            // pb1
            // 
            this.pb1.Image = global::ScreenDesigns.Properties.Resources.Logo;
            this.pb1.Location = new System.Drawing.Point(-66, 6);
            this.pb1.Margin = new System.Windows.Forms.Padding(2);
            this.pb1.Name = "pb1";
            this.pb1.Size = new System.Drawing.Size(804, 70);
            this.pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb1.TabIndex = 0;
            this.pb1.TabStop = false;
            // 
            // bannerTimer
            // 
            this.bannerTimer.Enabled = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel1.Location = new System.Drawing.Point(-13, -13);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1000, 2);
            this.panel1.TabIndex = 35;
            // 
            // pnlTopMenuBar
            // 
            this.pnlTopMenuBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.pnlTopMenuBar.Location = new System.Drawing.Point(-3, -73);
            this.pnlTopMenuBar.Margin = new System.Windows.Forms.Padding(2);
            this.pnlTopMenuBar.Name = "pnlTopMenuBar";
            this.pnlTopMenuBar.Size = new System.Drawing.Size(1000, 2);
            this.pnlTopMenuBar.TabIndex = 32;
            // 
            // btnExit
            // 
            this.btnExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnExit.BackgroundImage")));
            this.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(8, 221);
            this.btnExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(65, 65);
            this.btnExit.TabIndex = 41;
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ScreenDesigns.Properties.Resources.Logo;
            this.pictureBox1.Location = new System.Drawing.Point(-101, -71);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1088, 55);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            // 
            // btnMaintenance
            // 
            this.btnMaintenance.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMaintenance.BackgroundImage")));
            this.btnMaintenance.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMaintenance.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMaintenance.Location = new System.Drawing.Point(8, 79);
            this.btnMaintenance.Margin = new System.Windows.Forms.Padding(2);
            this.btnMaintenance.Name = "btnMaintenance";
            this.btnMaintenance.Size = new System.Drawing.Size(65, 65);
            this.btnMaintenance.TabIndex = 37;
            this.btnMaintenance.UseVisualStyleBackColor = true;
            this.btnMaintenance.Click += new System.EventHandler(this.btnMaintenance_Click);
            this.btnMaintenance.MouseLeave += new System.EventHandler(this.btnMaintenance_MouseLeave);
            this.btnMaintenance.MouseHover += new System.EventHandler(this.btnMaintenance_MouseHover);
            // 
            // btnCars
            // 
            this.btnCars.Location = new System.Drawing.Point(0, 0);
            this.btnCars.Name = "btnCars";
            this.btnCars.Size = new System.Drawing.Size(75, 23);
            this.btnCars.TabIndex = 59;
            // 
            // btnDisplayEdit
            // 
            this.btnDisplayEdit.BackgroundImage = global::ScreenDesigns.Properties.Resources.icons8_edit_100;
            this.btnDisplayEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDisplayEdit.Location = new System.Drawing.Point(8, 151);
            this.btnDisplayEdit.Name = "btnDisplayEdit";
            this.btnDisplayEdit.Size = new System.Drawing.Size(65, 65);
            this.btnDisplayEdit.TabIndex = 57;
            this.btnDisplayEdit.UseVisualStyleBackColor = true;
            this.btnDisplayEdit.Click += new System.EventHandler(this.btnDisplayEdit_Click);
            this.btnDisplayEdit.MouseLeave += new System.EventHandler(this.btnDisplayEdit_MouseLeave);
            this.btnDisplayEdit.MouseHover += new System.EventHandler(this.btnDisplayEdit_MouseHover);
            // 
            // lblEditBtns
            // 
            this.lblEditBtns.AutoSize = true;
            this.lblEditBtns.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditBtns.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblEditBtns.Location = new System.Drawing.Point(87, 172);
            this.lblEditBtns.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEditBtns.Name = "lblEditBtns";
            this.lblEditBtns.Size = new System.Drawing.Size(100, 19);
            this.lblEditBtns.TabIndex = 58;
            this.lblEditBtns.Text = "Edit Orders";
            this.lblEditBtns.Visible = false;
            // 
            // frmMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(337, 296);
            this.ControlBox = false;
            this.Controls.Add(this.lblEditBtns);
            this.Controls.Add(this.btnDisplayEdit);
            this.Controls.Add(this.lblExitBtn);
            this.Controls.Add(this.lblUpgradesBtn);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnMaintenance);
            this.Controls.Add(this.pnlTopMenuBar);
            this.Controls.Add(this.btnCars);
            this.Name = "frmMaintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMaintenance";
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblExitBtn;
        private System.Windows.Forms.Label lblUpgradesBtn;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Timer bannerTimer;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnMaintenance;
        private System.Windows.Forms.Panel pnlTopMenuBar;
        private System.Windows.Forms.Button btnCars;
        private System.Windows.Forms.PictureBox pb1;
        private System.Windows.Forms.Button btnDisplayEdit;
        private System.Windows.Forms.Label lblEditBtns;
    }
}