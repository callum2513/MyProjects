﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScreenDesigns
{
    public partial class frmCustomer : Form
    {
        SqlDataAdapter daCustomer, daOrders;
        DataSet dsDesmonds = new DataSet();
        SqlCommandBuilder cmdBCustomer, cmdBOrder;
        DataRow drCustomer;
        String connStr, sqlCustomer, sqlOrders;
        int selectedTab = 0;
        bool custSelected = false;
        string custNoSelected = "";

        public frmCustomer()
        {
            InitializeComponent();
        }
        private void frmCustomer_Shown(object sender, EventArgs e)
        {
            tabCustomer.TabPages[0].CausesValidation = true;
            tabCustomer.TabPages[0].Validating += new CancelEventHandler(AddTabValidate);

        }
        private void frmCustomer_Load(object sender, EventArgs e)
        {
            connStr = @"Data Source = .; Initial Catalog = desmonds; Integrated Security = true";
            sqlCustomer = @"select * from customer";
            daCustomer = new SqlDataAdapter(sqlCustomer, connStr);
            cmdBCustomer = new SqlCommandBuilder(daCustomer);
            daCustomer.FillSchema(dsDesmonds, SchemaType.Source, "Customer");
            daCustomer.Fill(dsDesmonds, "Customer"); // Naming the table in VS //

            sqlOrders = @"SELECT * FROM orders";
            daOrders = new SqlDataAdapter(sqlOrders, connStr);
            cmdBOrder = new SqlCommandBuilder(daOrders);
            daOrders.FillSchema(dsDesmonds, SchemaType.Source, "Orders");
            daOrders.Fill(dsDesmonds, "Orders");


            dgvCustomer.DataSource = dsDesmonds.Tables["Customer"];
            // Resize the dgv columns to fit the newly loaded content //
            dgvCustomer.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

            tabCustomer.SelectedIndex = 1;
            tabCustomer.SelectedIndex = 0;
			
        }
        

        // Form Button Click Events //
        private void btnAddCust_Click(object sender, EventArgs e)
        {
            tabCustomer.SelectedIndex = 1;
        }
        private void btnCustEdit_Click(object sender, EventArgs e)
        {
            tabCustomer.SelectedIndex = 2;
        }
        private void btnCustDelete_Click(object sender, EventArgs e)
        {
            if (dgvCustomer.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a customer from the list", "Customer");
            }
            else
            {
                bool okDelete = true;
                foreach (DataRow dr in dsDesmonds.Tables["orders"].Rows)
                {
                    if (dr["CustID"].ToString() == dgvCustomer.SelectedRows[0].Cells[0].Value.ToString())
                    {
                        okDelete = false;
                    }
                }

                if (okDelete == true)
                {
                    drCustomer = dsDesmonds.Tables["Customer"].Rows.Find(dgvCustomer.SelectedRows[0].Cells[0].Value);
                    string tempName = drCustomer["CustForename"].ToString() + " " + drCustomer["CustSurname"].ToString() + "\'s";

                    if (MessageBox.Show("Are you sure you want to delete" + tempName + " details?", "Add Customer", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                    {
                        drCustomer.Delete();
                        daCustomer.Update(dsDesmonds, "Customer");
                    }
                }
                else
                    MessageBox.Show("Customer can't be deleted as they are linked to an order");
            }
        }
        private void btnCustExit_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
        private void btnAddCustAdd_Click(object sender, EventArgs e)
        {
            errP.Clear();
            MyCustomer myCustomer = new MyCustomer();
            bool Ok = true;
            String invalMessage = "Invalid data entry for: ";
            //errP.clear();

            try
            {
                myCustomer.CustomerNo = lblAddCustNoShow.Text.Trim(); // passed to customer class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(lblAddCustNoShow, MyEx.toString());
            }

            try
            {
                myCustomer.Title = cmbAddCustTitle.Text.Trim();
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(cmbAddCustTitle, MyEx.toString());
                invalMessage += " Title |";
            }

            try
            {
                myCustomer.Forename = txtAddCustForename.Text.Trim();
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtAddCustForename, MyEx.toString());
                invalMessage += " Forename |";
            }

            try
            {
                myCustomer.Surname = txtAddCustSurname.Text.Trim();
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtAddCustSurname, MyEx.toString());
                invalMessage += " Surname |";
            }

            try
            {
                myCustomer.Street = txtAddCustStreet.Text.Trim();
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtAddCustStreet, MyEx.toString());
                invalMessage += " Street |";
            }

            try
            {
                myCustomer.Town = txtAddCustTown.Text.Trim();
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtAddCustTown, MyEx.toString());
                invalMessage += " Town |";
            }

            try
            {
                myCustomer.County = txtAddCustCounty.Text.Trim();
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtAddCustCounty, MyEx.toString());
                invalMessage += " County |";
            }

            try
            {
                myCustomer.Postcode = txtAddCustPostcode.Text.Trim();
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtAddCustPostcode, MyEx.toString());
                invalMessage += " Postcode |";
            }

            try
            {
                myCustomer.TelNo = txtAddCustTelNum.Text.Trim();
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtAddCustTelNum, MyEx.toString());
                invalMessage += " TelNum |";
            }

            try
            {
                myCustomer.Email = txtAddCustEmail.Text.Trim();
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtAddCustEmail, MyEx.toString());
                invalMessage += " Email |";
            }

            try
            {
                myCustomer.CreditRating = cmbAddCustCreditRating.Text.Trim();
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(cmbAddCustCreditRating, MyEx.toString());
                invalMessage += " Credit Rating |";
            }

            if (Ok == false)
                stLabel.Text = invalMessage;

            try
            {
                if (Ok)
                {
                    drCustomer = dsDesmonds.Tables["Customer"].NewRow();

                    drCustomer["CustID"] = myCustomer.CustomerNo;
                    drCustomer["CustTitle"] = myCustomer.Title;
                    drCustomer["CustForename"] = myCustomer.Forename;
                    drCustomer["CustSurname"] = myCustomer.Surname;
                    drCustomer["CustStreet"] = myCustomer.Street;
                    drCustomer["CustTown"] = myCustomer.Town;
                    drCustomer["CustCounty"] = myCustomer.County;
                    drCustomer["CustPostcode"] = myCustomer.Postcode;
                    drCustomer["CustEmail"] = myCustomer.Email;
                    drCustomer["TelNo"] = myCustomer.TelNo;
                    drCustomer["CreditRating"] = myCustomer.CreditRating;

                    dsDesmonds.Tables["Customer"].Rows.Add(drCustomer);
                    daCustomer.Update(dsDesmonds, "Customer");

                    MessageBox.Show("Customer Added");

                    if (MessageBox.Show("Do you want to add another customer?", "Add Customer", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                    {
                        clearAddForm();
                        getTotalNum(dsDesmonds.Tables["Customer"].Rows.Count);
						errP.Clear();
						clearTxtError();
                    }
                    else
                        tabCustomer.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex.TargetSite + "" + ex.Message, "Error!", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
            }




        }
        private void btnAddCustClear_Click(object sender, EventArgs e)
        {
            clearAddForm();
        }
        private void btnEditCustEdit_Click(object sender, EventArgs e)
        {

            if (lblEditCustEdit.Text == "Edit")
            {
                cmbEditCustTitle.Enabled = true;
                txtEditCustForename.Enabled = true;
                txtEditCustSurname.Enabled = true;
                txtEditCustStreet.Enabled = true;
                txtEditCustTown.Enabled = true;
                txtEditCustCounty.Enabled = true;
                txtEditCustPostcode.Enabled = true;
                txtEditCustEmail.Enabled = true;
                txtEditCustTelNum.Enabled = true;
                cmbEditCustCreditRating.Enabled = true;

                lblEditCustEdit.Text = "Save";
            }
            else
            {
                MyCustomer myCustomer = new MyCustomer();
                bool Ok = true;
                errP.Clear();

                try
                {
                    myCustomer.CustomerNo = (lblEditCustNoShow.Text.Trim()); // passed to customer class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(lblEditCustNoShow, MyEx.toString());
                }

                try
                {
                    myCustomer.Title = cmbEditCustTitle.Text.Trim();
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(cmbEditCustTitle, MyEx.toString());
                }

                try
                {
                    myCustomer.Forename = txtEditCustForename.Text.Trim();
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(txtEditCustForename, MyEx.toString());
                }

                try
                {
                    myCustomer.Surname = txtEditCustSurname.Text.Trim();
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(txtEditCustSurname, MyEx.toString());
                }

                try
                {
                    myCustomer.Street = txtEditCustStreet.Text.Trim();
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(txtEditCustStreet, MyEx.toString());
                }

                try
                {
                    myCustomer.Town = txtEditCustTown.Text.Trim();
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(txtEditCustTown, MyEx.toString());
                }

                try
                {
                    myCustomer.County = txtEditCustCounty.Text.Trim();
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(txtEditCustCounty, MyEx.toString());
                }

                try
                {
                    myCustomer.Postcode = txtEditCustPostcode.Text.Trim();
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(txtEditCustPostcode, MyEx.toString());
                }

                try
                {
                    myCustomer.TelNo = txtEditCustTelNum.Text.Trim();
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(txtEditCustTelNum, MyEx.toString());
                }

                try
                {
                    myCustomer.Email = txtEditCustEmail.Text.Trim();
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(txtEditCustEmail, MyEx.toString());
                }

                try
                {
                    myCustomer.CreditRating = cmbEditCustCreditRating.Text.Trim();
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(cmbEditCustCreditRating, MyEx.toString());
                }

                try
                {
                    if (Ok)
                    {
                        drCustomer.BeginEdit();

                        drCustomer["CustID"] = myCustomer.CustomerNo;
                        drCustomer["CustTitle"] = myCustomer.Title;
                        drCustomer["CustForename"] = myCustomer.Forename;
                        drCustomer["CustSurname"] = myCustomer.Surname;
                        drCustomer["CustStreet"] = myCustomer.Street;
                        drCustomer["CustTown"] = myCustomer.Town;
                        drCustomer["CustCounty"] = myCustomer.County;
                        drCustomer["CustPostcode"] = myCustomer.Postcode;
                        drCustomer["CustEmail"] = myCustomer.Email;
                        drCustomer["TelNo"] = myCustomer.TelNo;
                        drCustomer["CreditRating"] = myCustomer.CreditRating;

                        drCustomer.EndEdit();
                        daCustomer.Update(dsDesmonds, "Customer");
                        MessageBox.Show("Customer Details Updated", "Customer");

                        cmbEditCustTitle.Enabled = false;
                        txtEditCustForename.Enabled = false;
                        txtEditCustSurname.Enabled = false;
                        txtEditCustStreet.Enabled = false;
                        txtEditCustTown.Enabled = false;
                        txtEditCustCounty.Enabled = false;
                        txtEditCustPostcode.Enabled = false;
                        txtEditCustEmail.Enabled = false;
                        txtEditCustTelNum.Enabled = false;
                        cmbEditCustCreditRating.Enabled = false;

                        lblEditCustEdit.Text = "Edit";
                        tabCustomer.SelectedIndex = 0;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("" + ex.TargetSite + "" + ex.Message, "Error!", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
                }
            }
        }


        // Custom Methods //
        private void getTotalNum(int noRows)
        {
            drCustomer = dsDesmonds.Tables["Customer"].Rows[noRows - 1];
            int temp = int.Parse(drCustomer["CustID"].ToString().Substring(2, 6)) + 1;
            lblAddCustNoShow.Text = "CN" + temp;
        }
        void clearAddForm()
        {
            cmbAddCustTitle.SelectedIndex = -1;
            txtAddCustForename.Clear();
            txtAddCustSurname.Clear();
            txtAddCustStreet.Clear();
            txtAddCustTown.Clear();
            txtAddCustCounty.Clear();
            txtAddCustPostcode.Clear();
            txtAddCustEmail.Clear();
            txtAddCustTelNum.Clear();
            cmbAddCustCreditRating.SelectedIndex = -1;
        }
        void AddTabValidate(object sender, CancelEventArgs e)
        {
            if (dgvCustomer.SelectedRows.Count == 0)
            {
                custSelected = false;
                custNoSelected = "";
            }
            else if (dgvCustomer.SelectedRows.Count == 1)
            {
                custSelected = true;
                custNoSelected = dgvCustomer.SelectedRows[0].Cells[0].Value.ToString();
            }
        }
        void EditTabValidate(object sender, CancelEventArgs e)
        {
            if (custSelected == false && custNoSelected == "")
            {
                // have to do this bit //
                // reset tab to display and put out a message to select customer
                custSelected = false;
                custNoSelected = "";
            }
            else if (dgvCustomer.SelectedRows.Count == 1)
            {
                custSelected = true;
                custNoSelected = dgvCustomer.SelectedRows[0].Cells[0].ToString();
            }
        }
		void clearTxtError ()
		{
			cmbAddCustTitle.BackColor = Color.White;
			txtAddCustForename.BackColor = Color.White;
			txtAddCustSurname.BackColor = Color.White;
			txtAddCustStreet.BackColor = Color.White;
			txtAddCustTown.BackColor = Color.White;
			txtAddCustCounty.BackColor = Color.White;
			txtAddCustPostcode.BackColor = Color.White;
			txtAddCustEmail.BackColor = Color.White;
			txtAddCustTelNum.BackColor = Color.White;
			cmbAddCustCreditRating.BackColor = Color.White;
		}



		// Add Form Error Feedback - TextBox color changes to red if invalid //
		private void txtAddCustForename_TextChanged(object sender, EventArgs e)
		{
			if (txtAddCustForename.Text.Length >= 2 && txtAddCustForename.Text.Length <= 15)
			{
				txtAddCustForename.BackColor = Color.White;
			}
			else
			{
				txtAddCustForename.BackColor = Color.LightCoral;
			}
		}
		private void txtAddCustSurname_TextChanged(object sender, EventArgs e)
		{
			if (txtAddCustSurname.Text.Length >= 2 && txtAddCustSurname.Text.Length <= 15)
			{
				txtAddCustSurname.BackColor = Color.White;
			}
			else
			{
				txtAddCustSurname.BackColor = Color.LightCoral;
			}
		}
		private void txtAddCustStreet_TextChanged(object sender, EventArgs e)
		{
			if (txtAddCustStreet.Text.Length >= 5 && txtAddCustStreet.Text.Length <= 40)
			{
				txtAddCustStreet.BackColor = Color.White;
			}
			else
			{
				txtAddCustStreet.BackColor = Color.LightCoral;
			}
		}
		private void txtAddCustTown_TextChanged(object sender, EventArgs e)
		{
			if (txtAddCustTown.Text.Length >= 2 && txtAddCustTown.Text.Length <= 20)
			{
				txtAddCustTown.BackColor = Color.White;
			}
			else
			{
				txtAddCustTown.BackColor = Color.LightCoral;
			}
		}
		private void txtAddCustCounty_TextChanged(object sender, EventArgs e)
		{
			if (txtAddCustCounty.Text.Length >= 2 && txtAddCustCounty.Text.Length <= 20)
			{
				txtAddCustCounty.BackColor = Color.White;
			}
			else
			{
				txtAddCustCounty.BackColor = Color.LightCoral;
			}
		}
		private void txtAddCustPostcode_TextChanged(object sender, EventArgs e)
		{
			if (txtAddCustPostcode.Text.Length >= 7 && txtAddCustPostcode.Text.Length <= 8)
			{
				txtAddCustPostcode.BackColor = Color.White;
			}
			else
			{
				txtAddCustPostcode.BackColor = Color.LightCoral;
			}
		}
		private void txtAddCustEmail_TextChanged(object sender, EventArgs e)
		{
			if (txtAddCustEmail.Text.Length >= 7 && txtAddCustPostcode.Text.Length <= 25)
			{
				txtAddCustEmail.BackColor = Color.White;
			}
			else
			{
				txtAddCustEmail.BackColor = Color.LightCoral;
			}
		}
		private void txtAddCustTelNum_TextChanged(object sender, EventArgs e)
		{
			if (txtAddCustTelNum.Text.Length >= 11 && txtAddCustTelNum.Text.Length <= 15)
			{
				txtAddCustTelNum.BackColor = Color.White;
			}
			else
			{
				txtAddCustTelNum.BackColor = Color.LightCoral;
			}
		}


		// Edit Form Error Feedback - TextBox color changes to red if invalid //
		private void txtEditCustForename_TextChanged(object sender, EventArgs e)
		{
			if (txtEditCustForename.Text.Length >= 2 && txtEditCustForename.Text.Length <= 15)
			{
				txtEditCustForename.BackColor = Color.White;
			}
			else
			{
				txtEditCustForename.BackColor = Color.LightCoral;
			}
		}
		private void txtEditCustSurname_TextChanged_1(object sender, EventArgs e)
		{
			if (txtEditCustSurname.Text.Length >= 2 && txtEditCustSurname.Text.Length <= 15)
			{
				txtEditCustSurname.BackColor = Color.White;
			}
			else
			{
				txtEditCustSurname.BackColor = Color.LightCoral;
			}
		}
		private void txtEditCustStreet_TextChanged_1(object sender, EventArgs e)
		{
			if (txtEditCustStreet.Text.Length >= 5 && txtEditCustStreet.Text.Length <= 40)
			{
				txtEditCustStreet.BackColor = Color.White;
			}
			else
			{
				txtEditCustStreet.BackColor = Color.LightCoral;
			}
		}
		private void txtEditCustTown_TextChanged_1(object sender, EventArgs e)
		{
			if (txtEditCustTown.Text.Length >= 2 && txtEditCustTown.Text.Length <= 20)
			{
				txtEditCustTown.BackColor = Color.White;
			}
			else
			{
				txtEditCustTown.BackColor = Color.LightCoral;
			}
		}
		private void txtEditCustCounty_TextChanged_1(object sender, EventArgs e)
		{
			if (txtEditCustCounty.Text.Length >= 2 && txtEditCustCounty.Text.Length <= 20)
			{
				txtEditCustCounty.BackColor = Color.White;
			}
			else
			{
				txtEditCustCounty.BackColor = Color.LightCoral;
			}
		}
		private void txtEditCustPostcode_TextChanged_1(object sender, EventArgs e)
		{
			if (txtEditCustPostcode.Text.Length >= 7 && txtEditCustPostcode.Text.Length <= 8)
			{
				txtEditCustPostcode.BackColor = Color.White;
			}
			else
			{
				txtEditCustPostcode.BackColor = Color.LightCoral;
			}
		}

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtEditCustEmail_TextChanged_1(object sender, EventArgs e)
		{
			if (txtEditCustEmail.Text.Length >= 7 && txtEditCustEmail.Text.Length <= 25)
			{
				txtEditCustEmail.BackColor = Color.White;
			}
			else
			{
				txtEditCustEmail.BackColor = Color.LightCoral;
			}
		}
		private void txtEditCustTelNum_TextChanged_1(object sender, EventArgs e)
		{
			if (txtEditCustTelNum.Text.Length >= 11 && txtEditCustTelNum.Text.Length <= 15)
			{
				txtEditCustTelNum.BackColor = Color.White;
			}
			else
			{
				txtEditCustTelNum.BackColor = Color.LightCoral;
			}
		}

        private void btnCustHome_Click(object sender, EventArgs e)
        {
            GlobalVar.tradeInCar = false;
            this.Hide();
            frmMainMenu menuForm = new frmMainMenu();
            menuForm.ShowDialog();
        }

        private void tabCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedTab = tabCustomer.SelectedIndex;

            tabCustomer.TabPages[tabCustomer.SelectedIndex].Focus();
            tabCustomer.TabPages[tabCustomer.SelectedIndex].CausesValidation = true;


            switch (tabCustomer.SelectedIndex)
            {
                case 0:
                    {
                        dsDesmonds.Tables["Customer"].Clear();
                        daCustomer.Fill(dsDesmonds, "Customer");
                        break;
                    }

                case 1:
                    {
                        int noRows = dsDesmonds.Tables["Customer"].Rows.Count;

                        if (noRows == 0)
                        {
                            lblAddCustNoShow.Text = "CN100000";
                        }
                        else
                        {
                            getTotalNum(noRows);
                        }
                        txtAddCustPostcode.Enabled = true;
                        errP.Clear();
                        clearAddForm();
                        break;
                    }

                case 2:
                    {
                        if (custNoSelected == "")
                        {
                            tabCustomer.SelectedIndex = 0;
                        }
                        else
                        {
                            lblEditCustNoShow.Text = custNoSelected.ToString();
                            drCustomer = dsDesmonds.Tables["Customer"].Rows.Find(lblEditCustNoShow.Text);

                            if (drCustomer["CustTitle"].ToString() == "Mr")
                            {
                                cmbEditCustTitle.SelectedIndex = 0;
                            }
                            else if (drCustomer["CustTitle"].ToString() == "Mrs")
                            {
                                cmbEditCustTitle.SelectedIndex = 1;
                            }
                            else if (drCustomer["CustTitle"].ToString() == "Miss")
                            {
                                cmbEditCustTitle.SelectedIndex = 2;
                            }
                            else if (drCustomer["CustTitle"].ToString() == "Ms")
                            {
                                cmbEditCustTitle.SelectedIndex = 3;
                            }

                            txtEditCustForename.Text = drCustomer["CustForename"].ToString();
                            txtEditCustSurname.Text = drCustomer["CustSurname"].ToString();
                            txtEditCustStreet.Text = drCustomer["CustStreet"].ToString();
                            txtEditCustTown.Text = drCustomer["CustTown"].ToString();
                            txtEditCustCounty.Text = drCustomer["CustCounty"].ToString();
                            txtEditCustPostcode.Text = drCustomer["CustPostcode"].ToString();
                            txtEditCustEmail.Text = drCustomer["CustEmail"].ToString();
                            txtEditCustTelNum.Text = drCustomer["TelNo"].ToString();


                            if (drCustomer["CreditRating"].ToString() == "Poor")
                            {
                                cmbEditCustCreditRating.SelectedIndex = 0;
                            }
                            else if (drCustomer["CreditRating"].ToString() == "Very Poor")
                            {
                                cmbEditCustCreditRating.SelectedIndex = 1;
                            }
                            else if (drCustomer["CreditRating"].ToString() == "Average")
                            {
                                cmbEditCustCreditRating.SelectedIndex = 2;
                            }
                            else if (drCustomer["CreditRating"].ToString() == "Good")
                            {
                                cmbEditCustCreditRating.SelectedIndex = 3;
                            }
                            else if (drCustomer["CreditRating"].ToString() == "Very Good")
                            {
                                cmbEditCustCreditRating.SelectedIndex = 4;
                            }
                            else if (drCustomer["CreditRating"].ToString() == "Excellent")
                            {
                                cmbEditCustCreditRating.SelectedIndex = 5;
                            }
                        }
                        break;
                    }
            }

        }

        // Clear Add Form Input //
        
        

        

        
    }
}
