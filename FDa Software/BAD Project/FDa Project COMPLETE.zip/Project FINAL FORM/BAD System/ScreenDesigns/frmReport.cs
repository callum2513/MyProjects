﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScreenDesigns
{
    public partial class frmReport : Form
    {
        invoice inv = new invoice();

        public string upgradeOrderID = "";
        public frmReport()
        {
            InitializeComponent();
        }

        private void frmReport_Load(object sender, EventArgs e)
        {
            inv.SetParameterValue("upgradeOrderID", upgradeOrderID);
            crystalReportViewer1.ReportSource = inv;
        }
    }
}
