﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ScreenDesigns
{
    public partial class frmStaff : Form
    {


        SqlDataAdapter daStaff, daStaffSearch, daStaffTest, daTest;
        DataSet dsDesmonds = new DataSet();
        SqlCommandBuilder cmdBStaff, cmdbStaffSearch, cmdBTest;
        DataRow drStaff, drTest;
        String connStr, sqlStaff, sqlStaffSearch, sqlTest;
        int selectedTab = 0;
        bool staffSelected = false;
        int staffNoSelected = 0;
        String staffID = "SF";
        String tempstaff = "";
        int tempStaffID = 0;
        String[] staffTempArray = new String[8];
        String[] allCountys = new String[6];

        public frmStaff()
        {
            InitializeComponent();
        }

        private void btnDisplayAdd_Click(object sender, EventArgs e)
        {
            tabStaff.SelectedIndex = 1;
        }

        private void tabAdd_Click(object sender, EventArgs e)
        {

        }

        private void getNumber(int noRows)
        {
            drStaff = dsDesmonds.Tables["staff"].Rows[noRows - 1];
            tempstaff = drStaff["StaffID"].ToString();
            tempstaff = tempstaff.Substring(2,5);
            tempStaffID = Int32.Parse(tempstaff);
            tempStaffID++;
            String strStaffID = (staffID + (tempStaffID));
            lblAddDisplayStaffNo.Text = (strStaffID);
        }


        void clearAddForm()
        {
            txtAddForename.Clear();
            txtAddSurname.Clear();
            txtAddStreet.Clear();
            txtAddTown.Clear();
            txtAddCounty.Clear();
            txtAddPostcode.Clear();
            txtAddEmail.Clear();
            txtAddMobile.Clear();
        }


        private void tabStaff_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (lblEditEdit.Text.Equals("Save"))
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to cancel any changes?", "Cancel Changes", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    txtEditForename.Text = staffTempArray[0];
                    txtEditSurname.Text = staffTempArray[1];
                    txtEditStreet.Text = staffTempArray[2];
                    txtEditTown.Text = staffTempArray[3];
                    txtEditPostcode.Text = staffTempArray[4];
                    txtEditCounty.Text = staffTempArray[5];
                    txtEditEmail.Text = staffTempArray[6];
                    txtEditMobileNo.Text = staffTempArray[7];

                    txtEditForename.Enabled = false;
                    txtEditSurname.Enabled = false;
                    txtEditStreet.Enabled = false;
                    txtEditTown.Enabled = false;
                    txtEditPostcode.Enabled = false;
                    txtEditCounty.Enabled = false;
                    txtEditEmail.Enabled = false;
                    txtEditMobileNo.Enabled = false;
                    btnEditCancel.Enabled = false;

                    lblEditEdit.Text = "Edit";

                    btnDisplayAdd.Enabled = true;
                    btnDisplayDelete.Enabled = true;
                    btnDisplayEdit.Enabled = true;
                    btnHome.Enabled = true;
                }
                else if (dialogResult == DialogResult.No)
                {
                    tabStaff.SelectedIndex = 2;
                }
            }
            else
            {
                selectedTab = tabStaff.SelectedIndex;
                tabStaff.TabPages[tabStaff.SelectedIndex].Focus();
                tabStaff.TabPages[tabStaff.SelectedIndex].CausesValidation = true;



                switch (tabStaff.SelectedIndex)
                {
                    case 0: //When display tab selected
                        {
                            this.Size = new Size(919, 593);
                            tabStaff.Size = new Size(776, 451);
                            dsDesmonds.Tables["staff"].Clear();
                            daStaff.Fill(dsDesmonds, "staff");

                            Array.Clear(staffTempArray, 0, 8);
                            btnEditCancel.Enabled = false;

                            cmbDisplaySearch.Visible = true;
                            txtDisplaySearch.Visible = true;

                            txtEditForename.Clear();
                            txtEditSurname.Clear();
                            txtEditStreet.Clear();
                            txtEditTown.Clear();
                            txtEditCounty.Clear();
                            txtEditPostcode.Clear();
                            txtEditEmail.Clear();
                            txtEditMobileNo.Clear();

                            txtEditForename.Enabled = false;
                            txtEditSurname.Enabled = false;
                            txtEditStreet.Enabled = false;
                            txtEditTown.Enabled = false;
                            txtEditCounty.Enabled = false;
                            txtEditPostcode.Enabled = false;
                            txtEditEmail.Enabled = false;
                            txtEditMobileNo.Enabled = false;

                            lblEditEdit.Text = "Edit";
                            btnEditCancel.Enabled = false;


                            break;
                        }

                    case 1: //When add tab selected
                        {
                            this.Size = new Size(919, 593);
                            tabStaff.Size = new Size(776, 451);
                            cmbDisplaySearch.Visible = false;
                            txtDisplaySearch.Visible = false;
                            int noRows = dsDesmonds.Tables["staff"].Rows.Count;

                            if (noRows == 0)
                            {
                                lblAddDisplayStaffNo.Text = "10000";

                            }
                            else
                            {
                                getNumber(noRows);
                            }

                            errP.Clear();
                            clearAddForm();


                            break;
                        }
                    case 2: //When edit tab selected
                        {
                            this.Size = new Size(919, 593);
                            tabStaff.Size = new Size(776, 451);
                            cmbDisplaySearch.Visible = false;
                            txtDisplaySearch.Visible = false;

                            if (staffNoSelected == 0)
                            {
                                tabStaff.SelectedIndex = 2;
                                break;
                            }
                            else
                            {
                                lblEditDisplayStaffNo.Text = (staffID + staffNoSelected.ToString());
                                drStaff = dsDesmonds.Tables["staff"].Rows.Find(lblEditDisplayStaffNo.Text);




                                txtEditForename.Text = drStaff["Forename"].ToString();
                                txtEditSurname.Text = drStaff["Surname"].ToString();
                                txtEditStreet.Text = drStaff["Street"].ToString();
                                txtEditCounty.Text = drStaff["County"].ToString();
                                txtEditPostcode.Text = drStaff["Postcode"].ToString();
                                txtEditEmail.Text = drStaff["Email"].ToString();
                                txtEditTown.Text = drStaff["Town"].ToString();
                                txtEditMobileNo.Text = drStaff["TelNo"].ToString();

                                break;
                            }

                        }
                    case 3: //When reports tab selected
                        {
                            this.Size = new Size(1200, 623);
                            tabStaff.Size = new Size(1100, 454);
                            cmbDisplaySearch.Visible = false;
                            txtDisplaySearch.Visible = false;






                            break;

                        }
                    default:
                        break;
                }
            }

            
        }

        private void btnAddAdd_Click(object sender, EventArgs e)
        {
            MyStaff myStaff = new MyStaff(); // makes a new staff instance
            bool ok = true;
            errP.Clear();

            try
            {
                myStaff.StaffID = (lblAddDisplayStaffNo.Text.Trim());
            }
            catch (MyException MyEx)
            {
                ok = false;
                errP.SetError(lblAddDisplayStaffNo, MyEx.toString());
            }

            try
            {
                myStaff.Surname = txtAddSurname.Text.Trim();
            }
            catch (MyException MyEx)
            {

                ok = false;
                errP.SetError(txtAddSurname, MyEx.toString());
            }

            try
            {
                myStaff.Forename = txtAddForename.Text.Trim();
            }
            catch (MyException MyEx)
            {
                ok = false;
                errP.SetError(txtAddForename, MyEx.toString());
            }

            try
            {
                myStaff.Street = txtAddStreet.Text.Trim();
            }
            catch (MyException MyEx)
            {
                ok = false;
                errP.SetError(txtAddStreet, MyEx.toString());
            }

            try
            {
                myStaff.Town = txtAddTown.Text.Trim();
            }
            catch (MyException MyEx)
            {
                ok = false;
                errP.SetError(txtAddTown, MyEx.toString());
            }

            try
            {
                myStaff.County = txtAddCounty.Text.Trim();
            }
            catch (MyException MyEx)
            {
                ok = false;
                errP.SetError(txtAddCounty, MyEx.toString());

            }

            try
            {
                myStaff.Postcode = txtAddPostcode.Text.Trim();
            }
            catch (MyException MyEx)
            {
                ok = false;
                errP.SetError(txtAddPostcode, MyEx.toString());

            }

            try
            {
                myStaff.Email = txtAddEmail.Text.Trim();
            }
            catch (MyException MyEx)
            {

                ok = false;
                errP.SetError(txtAddEmail, MyEx.toString());
            }

            try
            {
                myStaff.TelNo = txtAddMobile.Text.Trim();
            }
            catch (MyException MyEx)
            {
                ok = false;
                errP.SetError(txtAddMobile, MyEx.toString());

            }

            try
            {
                if (ok)
                {
                    drStaff = dsDesmonds.Tables["staff"].NewRow();

                    drStaff["StaffID"] = myStaff.StaffID;
                    drStaff["Forename"] = myStaff.Forename;
                    drStaff["Surname"] = myStaff.Surname;
                    drStaff["Street"] = myStaff.Street;
                    drStaff["Town"] = myStaff.Town;
                    drStaff["County"] = myStaff.County;
                    drStaff["Postcode"] = myStaff.Postcode;
                    drStaff["Email"] = myStaff.Email;
                    drStaff["TelNo"] = myStaff.TelNo;

                    dsDesmonds.Tables["staff"].Rows.Add(drStaff);
                    daStaff.Update(dsDesmonds, "staff");

                    MessageBox.Show("Staff Added.");

                    cmbCounty.DataSource = null;
                    populateCombo();

                    if (MessageBox.Show("Would you like to add another staff?", "Add Staff", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes) 
                    {
                        clearAddForm();
                        getNumber(dsDesmonds.Tables["staff"].Rows.Count);
                    }

                }
                else
                {


                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("" + ex.TargetSite + "" + ex.Message, "Error!", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);

            }
           
        }

        private void btnDisplayExit_Click(object sender, EventArgs e)
        {
            
        }

        private void btnDisplayEdit_Click(object sender, EventArgs e)
        {
            tabStaff.SelectedIndex = 2;
        }

        private void txtAddForename_Validating(object sender, CancelEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnAddClear_Click(object sender, EventArgs e)
        {
            txtAddCounty.Text = "";
            txtAddForename.Text = "";
            txtAddMobile.Text = "";
            txtAddPostcode.Text = "";
            txtAddEmail.Text = "";
            txtAddStreet.Text = "";
            txtAddSurname.Text = "";
            txtAddTown.Text = "";
        }


        void EditTabValidate(object sender, CancelEventArgs e) //This is to ensure that the correct customer number is displayed in the edit tab when a customer is selected
        {

            if (dgvDisplayStaff.SelectedRows.Count == 0)
            {
                staffSelected = false;
                staffNoSelected = 0;
            }
            else if (dgvDisplayStaff.SelectedRows.Count == 1)
            {
                staffSelected = true;


                tempstaff = (dgvDisplayStaff.SelectedRows[0].Cells[0].Value).ToString();
                tempstaff = tempstaff.Substring(2, 5);
                tempStaffID = Int32.Parse(tempstaff);

                staffNoSelected = tempStaffID;
            }
        }



        void AddTabValidate(object sender, CancelEventArgs e) //This is to ensure that the correct staff number is displayed in the add tab when a staff is selected
        {
            if (dgvDisplayStaff.SelectedRows.Count == 0)
            {
                staffSelected = false;
                staffNoSelected = 0;
            }
            else if (dgvDisplayStaff.SelectedRows.Count == 1)
            {
                staffSelected = true;

                tempstaff = (dgvDisplayStaff.SelectedRows[0].Cells[0].Value).ToString();
                tempstaff = tempstaff.Substring(2, 5);
                tempStaffID = Int32.Parse(tempstaff);

                staffNoSelected = tempStaffID;
            }

        }

        private void tabEdit_Click(object sender, EventArgs e)
        {

        }

        private void frmStaff_Shown(object sender, EventArgs e)
        {
            tabStaff.TabPages[0].CausesValidation = true;
            tabStaff.TabPages[0].Validating += new CancelEventHandler(AddTabValidate);

            tabStaff.TabPages[2].CausesValidation = true;
            tabStaff.TabPages[2].Validating += new CancelEventHandler(EditTabValidate);
        }

        private void btnEditEdit_Click(object sender, EventArgs e)
        {
           

            if (lblEditEdit.Text.Equals("Edit"))
            {
                btnDisplayAdd.Enabled = false;
                btnDisplayDelete.Enabled = false;
                btnDisplayEdit.Enabled = false;
                btnHome.Enabled = false;

                staffTempArray[0] = txtEditForename.Text;
                staffTempArray[1] = txtEditSurname.Text;
                staffTempArray[2] = txtEditStreet.Text;
                staffTempArray[3] = txtEditTown.Text;
                staffTempArray[4] = txtEditPostcode.Text;
                staffTempArray[5] = txtEditCounty.Text;
                staffTempArray[6] = txtEditEmail.Text;
                staffTempArray[7] = txtEditMobileNo.Text;


                txtEditForename.Enabled = true;
                txtEditSurname.Enabled = true;
                txtEditStreet.Enabled = true;
                txtEditTown.Enabled = true;
                txtEditPostcode.Enabled = true;
                txtEditCounty.Enabled = true;
                txtEditEmail.Enabled = true;
                btnEditCancel.Enabled = true;
                txtEditMobileNo.Enabled = true;


                lblEditEdit.Text = "Save";
            }
            else if (lblEditEdit.Text.Equals("Save"))
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to save your changes?", "Save Changes", MessageBoxButtons.YesNo);

                if (dialogResult == DialogResult.Yes)
                {
                    MyStaff myStaff = new MyStaff(); // makes a new staff instance
                    bool okay = true;
                    errP.Clear();

                    try
                    {
                        myStaff.Surname = txtEditSurname.Text.Trim();
                    }
                    catch (MyException MyEx)
                    {

                        okay = false;
                        errP.SetError(txtEditSurname, MyEx.toString());
                    }

                    try
                    {
                        myStaff.Forename = txtEditForename.Text.Trim();
                    }
                    catch (MyException MyEx)
                    {
                        okay = false;
                        errP.SetError(txtEditForename, MyEx.toString());
                    }

                    try
                    {
                        myStaff.Street = txtEditStreet.Text.Trim();
                    }
                    catch (MyException MyEx)
                    {
                        okay = false;
                        errP.SetError(txtEditStreet, MyEx.toString());
                    }

                    try
                    {
                        myStaff.Town = txtEditTown.Text.Trim();
                    }
                    catch (MyException MyEx)
                    {
                        okay = false;
                        errP.SetError(txtEditTown, MyEx.toString());
                    }

                    try
                    {
                        myStaff.County = txtEditCounty.Text.Trim();
                    }
                    catch (MyException MyEx)
                    {
                        okay = false;
                        errP.SetError(txtEditCounty, MyEx.toString());

                    }

                    try
                    {
                        myStaff.Postcode = txtEditPostcode.Text.Trim();
                    }
                    catch (MyException MyEx)
                    {
                        okay = false;
                        errP.SetError(txtEditPostcode, MyEx.toString());

                    }

                    try
                    {
                        myStaff.Email = txtEditEmail.Text.Trim();
                    }
                    catch (MyException MyEx)
                    {

                        okay = false;
                        errP.SetError(txtEditEmail, MyEx.toString());
                    }

                    try
                    {
                        myStaff.TelNo = txtEditMobileNo.Text.Trim();
                    }
                    catch (MyException MyEx)
                    {
                        okay = false;
                        errP.SetError(txtEditMobileNo, MyEx.toString());

                    }

                    try
                    {
                        if (okay)
                        {
                            drStaff.BeginEdit();


                            drStaff["Forename"] = myStaff.Forename;
                            drStaff["Surname"] = myStaff.Surname;
                            drStaff["Street"] = myStaff.Street;
                            drStaff["Town"] = myStaff.Town;
                            drStaff["County"] = myStaff.County;
                            drStaff["Postcode"] = myStaff.Postcode;
                            drStaff["Email"] = myStaff.Email;
                            drStaff["TelNo"] = myStaff.TelNo;

                            drStaff.EndEdit();
                            daStaff.Update(dsDesmonds, "staff");

                            MessageBox.Show("Staff Details Updated", "staff");

                            cmbCounty.DataSource = null;
                            populateCombo();


                            txtEditForename.Enabled = false;
                            txtEditSurname.Enabled = false;
                            txtEditStreet.Enabled = false;
                            txtEditTown.Enabled = false;
                            txtEditPostcode.Enabled = false;
                            txtEditCounty.Enabled = false;
                            txtEditEmail.Enabled = false;
                            txtEditMobileNo.Enabled = false;
                            btnEditCancel.Enabled = false;

                            btnDisplayAdd.Enabled = true;
                            btnDisplayDelete.Enabled = true;
                            btnDisplayEdit.Enabled = true;
                            btnHome.Enabled = true;

                            lblEditEdit.Text = "Edit";
                            tabStaff.SelectedIndex = 0;
                        }
                       
                    }
                    catch (MyException MyEx)
                    {
                        MessageBox.Show("" + MyEx.TargetSite + "" + MyEx.Message, "Error!", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to cancel any changes?", "Cancel Changes", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                txtEditForename.Text = staffTempArray[0];
                txtEditSurname.Text = staffTempArray[1];
                txtEditStreet.Text = staffTempArray[2];
                txtEditTown.Text = staffTempArray[3];
                txtEditPostcode.Text = staffTempArray[4];
                txtEditCounty.Text = staffTempArray[5];
                txtEditEmail.Text = staffTempArray[6];
                txtEditMobileNo.Text = staffTempArray[7];

                txtEditForename.Enabled = false;
                txtEditSurname.Enabled = false;
                txtEditStreet.Enabled = false;
                txtEditTown.Enabled = false;
                txtEditPostcode.Enabled = false;
                txtEditCounty.Enabled = false;
                txtEditEmail.Enabled = false;
                txtEditMobileNo.Enabled = false;
                btnEditCancel.Enabled = false;

                lblEditEdit.Text = "Edit";

                btnDisplayAdd.Enabled = true;
                btnDisplayDelete.Enabled = true;
                btnDisplayEdit.Enabled = true;
                btnHome.Enabled = true;
            }
            else if (dialogResult == DialogResult.No)
            {
                //do something else
            }

        }

        private void btnDisplayExit_Click_1(object sender, EventArgs e)
        {
            this.Close();
            Environment.Exit(1);
        }

        private void btnHome_Click(object sender, EventArgs e)
        {


            frmMainMenu mainMenu = new frmMainMenu();
            this.Hide();
            mainMenu.Show();

            
            


        }

        private void txtEditEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEditCounty_TextChanged(object sender, EventArgs e)
        {

        }

        private void cptReports_Load(object sender, EventArgs e)
        {

        }

        private void cmbCounty_SelectedIndexChanged(object sender, EventArgs e)
        {
          //  StaffReportrpt staff = new StaffReportrpt();

          //  staff.SetParameterValue("County", cmbCounty.Text.Trim());
          // cptReports.ReportSource = staff;
        }

        private void btnDisplayDisplay_Click(object sender, EventArgs e)
        {
            if (dgvDisplayStaff.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a staff member from the list", "Staff");
            }
            else
            {
                drStaff = dsDesmonds.Tables["staff"].Rows.Find(dgvDisplayStaff.SelectedRows[0].Cells[0].Value);

                string tempName = drStaff["Forename"].ToString() + " " + drStaff["Surname"].ToString() + "\'s";

                if (MessageBox.Show("Are you sure you want to delete " + tempName + " details?", "Delete Staff", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    try
                    {
                        drStaff.Delete();
                        daStaff.Update(dsDesmonds, "staff");
                        
                    }
                    catch (SqlException)
                    {

                        MessageBox.Show("Can't Delete this staff member, they may be involved in another order or upgrade!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        drStaff.RejectChanges();
                    }
                    cmbCounty.DataSource = null;
                    populateCombo();
                }
            }
        }

        private void staffReport_InitReport(object sender, EventArgs e)
        {

        }

        private void StaffReportrpt1_InitReport(object sender, EventArgs e)
        {

        }

        private void dgvDisplayStaff_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cmbDisplaySearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtDisplaySearch.Enabled = true;
        }

        private void txtDisplaySearch_TextChanged(object sender, EventArgs e)
        {
            updateDataGrid();
        }

        private void populateCombo()
        {
            try
            {
                dsDesmonds.Tables["staffTest"].Clear();
            }
            catch (NullReferenceException MyEx)
            { } 
            

            sqlTest = @"select distinct County from staff";
            daTest = new SqlDataAdapter(sqlTest, connStr);
            cmdBTest = new SqlCommandBuilder(daTest);
            daTest.FillSchema(dsDesmonds, SchemaType.Source, "staffTest");
            daTest.Fill(dsDesmonds, "staffTest");

            Array.Clear(allCountys, 0, allCountys.Length);
            cmbCounty.DataSource = null;

            for (int i = 0; i < dsDesmonds.Tables["staffTest"].Rows.Count; i++)
            {
                drTest = dsDesmonds.Tables["staffTest"].Rows[i];
                tempstaff = drTest["County"].ToString();

                allCountys[i] = tempstaff;
            }

            ListViewItem lst = new ListViewItem(allCountys);

            int testLength = 0;

            for (int i = 5; i >= 0; --i)
            {
                if (allCountys[i] != null)
                {
                    testLength++;
                }
            }

            cmbCounty.DataSource = dsDesmonds.Tables["staffTest"];
            cmbCounty.DisplayMember = "County";
            cmbCounty.ValueMember = "County";

        }

        private void updateDataGrid()
        {
            dgvDisplayStaff.DataSource = null;
            dgvDisplayStaff.Refresh();

            String tempPara = ("'%" + txtDisplaySearch.Text.ToString() + "%'");
            String tempAtt = cmbDisplaySearch.Text.ToString();

            sqlStaffSearch = @"select * from staff where " + tempAtt + " like " + tempPara;
            daStaffSearch = new SqlDataAdapter(sqlStaffSearch, connStr);
            cmdbStaffSearch = new SqlCommandBuilder(daStaffSearch);
            dsDesmonds.Tables["staff"].Clear();
            daStaffSearch.FillSchema(dsDesmonds, SchemaType.Source, "staff");
            daStaffSearch.Fill(dsDesmonds, "staff");



            
            dgvDisplayStaff.DataSource = dsDesmonds.Tables["staff"];

            dgvDisplayStaff.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            dgvDisplayStaff.Refresh();
        }
        private void frmStaff_Load(object sender, EventArgs e)
        {
            connStr = @"Data Source = .; Initial Catalog = Desmonds; Integrated Security = true";

            sqlStaff = @"select * from staff";
            daStaff = new SqlDataAdapter(sqlStaff, connStr);
            cmdBStaff = new SqlCommandBuilder(daStaff);
            daStaff.FillSchema(dsDesmonds, SchemaType.Source, "staff");
            daStaff.Fill(dsDesmonds, "staff");
            dgvDisplayStaff.DataSource = dsDesmonds.Tables["staff"];
            dgvDisplayStaff.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);


            
            populateCombo();
            cmbCounty.SelectedIndex = 1;


            txtDisplaySearch.Enabled = false;
            txtEditForename.Enabled = false;
            txtEditSurname.Enabled = false;
            txtEditStreet.Enabled = false;
            txtEditTown.Enabled = false;
            txtEditPostcode.Enabled = false;
            txtEditCounty.Enabled = false;
            txtEditEmail.Enabled = false;
            txtEditMobileNo.Enabled = false;
            btnEditCancel.Enabled = false;

            //staffReport.SetDataSource 
            
            tabStaff.SelectedIndex = 1;
            tabStaff.SelectedIndex = 0;



        }
    }
}
