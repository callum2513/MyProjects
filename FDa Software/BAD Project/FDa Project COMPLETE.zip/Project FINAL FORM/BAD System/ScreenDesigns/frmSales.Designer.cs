﻿namespace ScreenDesigns
{
    partial class frmSales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Button btnFinanceSubmit;
            System.Windows.Forms.Button btnEditFinanceEdit;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSales));
            this.panel3 = new System.Windows.Forms.Panel();
            this.tabSales = new System.Windows.Forms.TabControl();
            this.tabSalesDisplay = new System.Windows.Forms.TabPage();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dgvOrders = new System.Windows.Forms.DataGridView();
            this.tabSalesAdd = new System.Windows.Forms.TabPage();
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.btnA = new System.Windows.Forms.Button();
            this.btnZ = new System.Windows.Forms.Button();
            this.btnB = new System.Windows.Forms.Button();
            this.btnY = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.btnX = new System.Windows.Forms.Button();
            this.btnD = new System.Windows.Forms.Button();
            this.btnW = new System.Windows.Forms.Button();
            this.btnE = new System.Windows.Forms.Button();
            this.btnV = new System.Windows.Forms.Button();
            this.btnF = new System.Windows.Forms.Button();
            this.btnU = new System.Windows.Forms.Button();
            this.btnG = new System.Windows.Forms.Button();
            this.btnT = new System.Windows.Forms.Button();
            this.btnH = new System.Windows.Forms.Button();
            this.btnS = new System.Windows.Forms.Button();
            this.btnI = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.btnJ = new System.Windows.Forms.Button();
            this.btnQ = new System.Windows.Forms.Button();
            this.btnK = new System.Windows.Forms.Button();
            this.btnP = new System.Windows.Forms.Button();
            this.btnL = new System.Windows.Forms.Button();
            this.btnO = new System.Windows.Forms.Button();
            this.btnM = new System.Windows.Forms.Button();
            this.btnN = new System.Windows.Forms.Button();
            this.pnlListBoxes = new System.Windows.Forms.Panel();
            this.lblSaleOrderNoShow = new System.Windows.Forms.Label();
            this.lblSaleOrderNo = new System.Windows.Forms.Label();
            this.lblCarTradeValue = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.rbCheque = new System.Windows.Forms.RadioButton();
            this.rbCard = new System.Windows.Forms.RadioButton();
            this.rbFinance = new System.Windows.Forms.RadioButton();
            this.rbCash = new System.Windows.Forms.RadioButton();
            this.lblPaymentMethod = new System.Windows.Forms.Label();
            this.btnSaleTradeIn = new System.Windows.Forms.Button();
            this.txtSaleDeposit = new System.Windows.Forms.NumericUpDown();
            this.lblSaleTradeIn = new System.Windows.Forms.Label();
            this.lblSaleDeposit = new System.Windows.Forms.Label();
            this.lstCar = new System.Windows.Forms.ListBox();
            this.lstCustomer = new System.Windows.Forms.ListBox();
            this.lblSaleOrderDateShow = new System.Windows.Forms.Label();
            this.lblListCar = new System.Windows.Forms.Label();
            this.lblOrderDate = new System.Windows.Forms.Label();
            this.lblListCustomer = new System.Windows.Forms.Label();
            this.lblSaleCarDetailsTitle = new System.Windows.Forms.Label();
            this.lblSaleCustDetailsTitle = new System.Windows.Forms.Label();
            this.pnlSaleCarDetails = new System.Windows.Forms.Panel();
            this.lblSaleCarPriceShow = new System.Windows.Forms.Label();
            this.lblCarPrice = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblSaleCarMileageShow = new System.Windows.Forms.Label();
            this.lblSaleCarBodyShow = new System.Windows.Forms.Label();
            this.lblSaleCarColourShow = new System.Windows.Forms.Label();
            this.lblSaleCarInteriorShow = new System.Windows.Forms.Label();
            this.lblSaleCarTransmissionShow = new System.Windows.Forms.Label();
            this.lblSaleCarModelShow = new System.Windows.Forms.Label();
            this.lblSaleCarMakeShow = new System.Windows.Forms.Label();
            this.pnlSaleCustDetails = new System.Windows.Forms.Panel();
            this.lblSaleCustNoShow = new System.Windows.Forms.Label();
            this.lblSaleCustNo = new System.Windows.Forms.Label();
            this.lblSaleCustTelNumShow = new System.Windows.Forms.Label();
            this.lblSaleCustEmailShow = new System.Windows.Forms.Label();
            this.lblSaleCustTelNum = new System.Windows.Forms.Label();
            this.lblSaleCustEmail = new System.Windows.Forms.Label();
            this.lblSaleCustCreditRatingShow = new System.Windows.Forms.Label();
            this.lblSaleCustPostcodeShow = new System.Windows.Forms.Label();
            this.lblSaleCustCountyShow = new System.Windows.Forms.Label();
            this.lblSaleCustTownShow = new System.Windows.Forms.Label();
            this.lblSaleCustAddressShow = new System.Windows.Forms.Label();
            this.lblSaleCustNameShow = new System.Windows.Forms.Label();
            this.lblSaleCustCreditRating = new System.Windows.Forms.Label();
            this.lblSaleCustPostcode = new System.Windows.Forms.Label();
            this.lblSaleCustCounty = new System.Windows.Forms.Label();
            this.lblSaleCustTown = new System.Windows.Forms.Label();
            this.lblSaleCustAddress = new System.Windows.Forms.Label();
            this.lblSaleCustName = new System.Windows.Forms.Label();
            this.lblAddCarReset = new System.Windows.Forms.Label();
            this.btnAddSaleReset = new System.Windows.Forms.Button();
            this.lblAddSaleAdd = new System.Windows.Forms.Label();
            this.btnAddSaleAdd = new System.Windows.Forms.Button();
            this.lblCarAddHeader = new System.Windows.Forms.Label();
            this.tabSalesFinance = new System.Windows.Forms.TabPage();
            this.lblFinanceTotalInterest = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblFinanceInterestPriceShow = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lblFinanceInterestRateShow = new System.Windows.Forms.Label();
            this.lblFinanceInterestRate = new System.Windows.Forms.Label();
            this.lblFinanceMonthlyPaymentShow = new System.Windows.Forms.Label();
            this.lblFinanceMonthlyPayment = new System.Windows.Forms.Label();
            this.lblFinanceNumPaymentsShow = new System.Windows.Forms.Label();
            this.lblFinanceNumPayments = new System.Windows.Forms.Label();
            this.lblFinanceAgreeDateShow = new System.Windows.Forms.Label();
            this.lblFinanceAgreeDate = new System.Windows.Forms.Label();
            this.lblFinanceAgreementIDShow = new System.Windows.Forms.Label();
            this.lblFinanceID = new System.Windows.Forms.Label();
            this.lblFinancePriceShow = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblFinanceTradeValueShow = new System.Windows.Forms.Label();
            this.lblFinanceTradeInValue = new System.Windows.Forms.Label();
            this.lblFinanceDepositShow = new System.Windows.Forms.Label();
            this.lblFinanceDeposit = new System.Windows.Forms.Label();
            this.cmbFinancePlanLength = new System.Windows.Forms.ComboBox();
            this.lblFinancePlanLength = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.lblFinanceRegNoShow = new System.Windows.Forms.Label();
            this.lblFinanceRegNo = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lblFinanceMake = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.lblFinanceModel = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.lblFinanceColour = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.lblFinanceMileage = new System.Windows.Forms.Label();
            this.lblFinanceBodyStyle = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lblFinanceInterior = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblFinanceTransmission = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.lblFinanceCustName = new System.Windows.Forms.Label();
            this.lblFinanceTelNum = new System.Windows.Forms.Label();
            this.lblFinanceCustNo = new System.Windows.Forms.Label();
            this.lblFinanceCustEmail = new System.Windows.Forms.Label();
            this.lblFinanceCustAddress = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lblFinanceCustTown = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lblFinanceCustCounty = new System.Windows.Forms.Label();
            this.lblFinanceCustCreditRating = new System.Windows.Forms.Label();
            this.lblFinancePostcode = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.lblCarEditHeader = new System.Windows.Forms.Label();
            this.lblEditCarEdit = new System.Windows.Forms.Label();
            this.tabDisplayFinance = new System.Windows.Forms.TabPage();
            this.dgvFinanceAgreements = new System.Windows.Forms.DataGridView();
            this.tabSalesFinanceEdit = new System.Windows.Forms.TabPage();
            this.txtFinanceDepositEdit = new System.Windows.Forms.NumericUpDown();
            this.label88 = new System.Windows.Forms.Label();
            this.lblFinanceInterestDueEdit = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.lblFinanceTotalInterestEdit = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.lblFinanceInterestRateEdit = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.lblFinanceMonthlyPaymentEdit = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.lblFinanceNumPaymentsEdit = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.lblFinanceAgreementDateEdit = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.lblFinanceFinanceIDEdit = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.lblFinanceTotalNoInterestEdit = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.lblFinanceTradeInEdit = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.cmbFinancePlanLengthEdit = new System.Windows.Forms.ComboBox();
            this.label52 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.lblFinancePriceEdit = new System.Windows.Forms.Label();
            this.lblFinancePriceEdit2 = new System.Windows.Forms.Label();
            this.lblFinanceRegNoEdit = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.lblFinanceMakeEdit = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.lblFinanceModelEdit = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.lblFinanceColourEdit = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.lblFinanceMileageEdit = new System.Windows.Forms.Label();
            this.lblFinanceBodyEdit = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.lblFinanceInteriorEdit = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.lblFinanceTransmissionEdit = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.lblFinanceCustNameEdit = new System.Windows.Forms.Label();
            this.lblFinanceTelNumEdit = new System.Windows.Forms.Label();
            this.lblFinanceCustNoEdit = new System.Windows.Forms.Label();
            this.lblFinanceCustEmailEdit = new System.Windows.Forms.Label();
            this.lblFinanceCustAddressEdit = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.lblFinanceCustTownEdit = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.lblFinanceCustCountyEdit = new System.Windows.Forms.Label();
            this.lblFinanceCustCreditEdit = new System.Windows.Forms.Label();
            this.lblFinanceCustPostcodeEdit = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.lblEditFinanceEdit = new System.Windows.Forms.Label();
            this.tabReport = new System.Windows.Forms.TabPage();
            this.label13 = new System.Windows.Forms.Label();
            this.lblSearchOrders = new System.Windows.Forms.Label();
            this.cmbRepOrderSearch = new System.Windows.Forms.ComboBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pnlTopMenuBar = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblCarTitle = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.errP = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnSalesEdit = new System.Windows.Forms.Button();
            this.btnSalesDelete = new System.Windows.Forms.Button();
            this.btnSalesAdd = new System.Windows.Forms.Button();
            this.btnSalesHome = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnSalesExit = new System.Windows.Forms.Button();
            this.lblSalesTitle = new System.Windows.Forms.Label();
            btnFinanceSubmit = new System.Windows.Forms.Button();
            btnEditFinanceEdit = new System.Windows.Forms.Button();
            this.tabSales.SuspendLayout();
            this.tabSalesDisplay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrders)).BeginInit();
            this.tabSalesAdd.SuspendLayout();
            this.pnlButtons.SuspendLayout();
            this.pnlListBoxes.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSaleDeposit)).BeginInit();
            this.pnlSaleCarDetails.SuspendLayout();
            this.pnlSaleCustDetails.SuspendLayout();
            this.tabSalesFinance.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tabDisplayFinance.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFinanceAgreements)).BeginInit();
            this.tabSalesFinanceEdit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtFinanceDepositEdit)).BeginInit();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.tabReport.SuspendLayout();
            this.panel4.SuspendLayout();
            this.pnlTopMenuBar.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnFinanceSubmit
            // 
            btnFinanceSubmit.Location = new System.Drawing.Point(23, 385);
            btnFinanceSubmit.Name = "btnFinanceSubmit";
            btnFinanceSubmit.Size = new System.Drawing.Size(50, 50);
            btnFinanceSubmit.TabIndex = 55;
            btnFinanceSubmit.UseVisualStyleBackColor = true;
            btnFinanceSubmit.Click += new System.EventHandler(this.btnFinanceSubmit_Click);
            // 
            // btnEditFinanceEdit
            // 
            btnEditFinanceEdit.Location = new System.Drawing.Point(13, 391);
            btnEditFinanceEdit.Name = "btnEditFinanceEdit";
            btnEditFinanceEdit.Size = new System.Drawing.Size(50, 50);
            btnEditFinanceEdit.TabIndex = 199;
            btnEditFinanceEdit.UseVisualStyleBackColor = true;
            btnEditFinanceEdit.Click += new System.EventHandler(this.btnEditFinanceEdit_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel3.Location = new System.Drawing.Point(95, 57);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(3, 520);
            this.panel3.TabIndex = 91;
            // 
            // tabSales
            // 
            this.tabSales.CausesValidation = false;
            this.tabSales.Controls.Add(this.tabSalesDisplay);
            this.tabSales.Controls.Add(this.tabSalesAdd);
            this.tabSales.Controls.Add(this.tabSalesFinance);
            this.tabSales.Controls.Add(this.tabDisplayFinance);
            this.tabSales.Controls.Add(this.tabSalesFinanceEdit);
            this.tabSales.Controls.Add(this.tabReport);
            this.tabSales.Location = new System.Drawing.Point(110, 74);
            this.tabSales.Name = "tabSales";
            this.tabSales.SelectedIndex = 0;
            this.tabSales.Size = new System.Drawing.Size(865, 478);
            this.tabSales.TabIndex = 94;
            this.tabSales.SelectedIndexChanged += new System.EventHandler(this.tabSales_SelectedIndexChanged);
            // 
            // tabSalesDisplay
            // 
            this.tabSalesDisplay.Controls.Add(this.label12);
            this.tabSalesDisplay.Controls.Add(this.label11);
            this.tabSalesDisplay.Controls.Add(this.label10);
            this.tabSalesDisplay.Controls.Add(this.label9);
            this.tabSalesDisplay.Controls.Add(this.label8);
            this.tabSalesDisplay.Controls.Add(this.dgvOrders);
            this.tabSalesDisplay.Location = new System.Drawing.Point(4, 22);
            this.tabSalesDisplay.Name = "tabSalesDisplay";
            this.tabSalesDisplay.Size = new System.Drawing.Size(857, 452);
            this.tabSalesDisplay.TabIndex = 4;
            this.tabSalesDisplay.Text = "Display Orders";
            this.tabSalesDisplay.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label12.Location = new System.Drawing.Point(619, 292);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(108, 23);
            this.label12.TabIndex = 106;
            this.label12.Text = "4.   Cheque";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label11.Location = new System.Drawing.Point(619, 255);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(109, 23);
            this.label11.TabIndex = 105;
            this.label11.Text = "3.   Finance";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label10.Location = new System.Drawing.Point(619, 217);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 23);
            this.label10.TabIndex = 104;
            this.label10.Text = "2.   Card";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label9.Location = new System.Drawing.Point(619, 180);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 23);
            this.label9.TabIndex = 103;
            this.label9.Text = "1.   Cash";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label8.Location = new System.Drawing.Point(618, 138);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(160, 27);
            this.label8.TabIndex = 102;
            this.label8.Text = "Payment Types";
            // 
            // dgvOrders
            // 
            this.dgvOrders.AllowUserToAddRows = false;
            this.dgvOrders.AllowUserToDeleteRows = false;
            this.dgvOrders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrders.Location = new System.Drawing.Point(17, 35);
            this.dgvOrders.Name = "dgvOrders";
            this.dgvOrders.ReadOnly = true;
            this.dgvOrders.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvOrders.Size = new System.Drawing.Size(516, 411);
            this.dgvOrders.TabIndex = 0;
            // 
            // tabSalesAdd
            // 
            this.tabSalesAdd.Controls.Add(this.pnlButtons);
            this.tabSalesAdd.Controls.Add(this.pnlListBoxes);
            this.tabSalesAdd.Controls.Add(this.lblSaleCarDetailsTitle);
            this.tabSalesAdd.Controls.Add(this.lblSaleCustDetailsTitle);
            this.tabSalesAdd.Controls.Add(this.pnlSaleCarDetails);
            this.tabSalesAdd.Controls.Add(this.pnlSaleCustDetails);
            this.tabSalesAdd.Controls.Add(this.lblAddCarReset);
            this.tabSalesAdd.Controls.Add(this.btnAddSaleReset);
            this.tabSalesAdd.Controls.Add(this.lblAddSaleAdd);
            this.tabSalesAdd.Controls.Add(this.btnAddSaleAdd);
            this.tabSalesAdd.Controls.Add(this.lblCarAddHeader);
            this.tabSalesAdd.Location = new System.Drawing.Point(4, 22);
            this.tabSalesAdd.Name = "tabSalesAdd";
            this.tabSalesAdd.Padding = new System.Windows.Forms.Padding(3);
            this.tabSalesAdd.Size = new System.Drawing.Size(857, 452);
            this.tabSalesAdd.TabIndex = 1;
            this.tabSalesAdd.Text = "Add Order";
            this.tabSalesAdd.UseVisualStyleBackColor = true;
            // 
            // pnlButtons
            // 
            this.pnlButtons.Controls.Add(this.btnA);
            this.pnlButtons.Controls.Add(this.btnZ);
            this.pnlButtons.Controls.Add(this.btnB);
            this.pnlButtons.Controls.Add(this.btnY);
            this.pnlButtons.Controls.Add(this.btnC);
            this.pnlButtons.Controls.Add(this.btnX);
            this.pnlButtons.Controls.Add(this.btnD);
            this.pnlButtons.Controls.Add(this.btnW);
            this.pnlButtons.Controls.Add(this.btnE);
            this.pnlButtons.Controls.Add(this.btnV);
            this.pnlButtons.Controls.Add(this.btnF);
            this.pnlButtons.Controls.Add(this.btnU);
            this.pnlButtons.Controls.Add(this.btnG);
            this.pnlButtons.Controls.Add(this.btnT);
            this.pnlButtons.Controls.Add(this.btnH);
            this.pnlButtons.Controls.Add(this.btnS);
            this.pnlButtons.Controls.Add(this.btnI);
            this.pnlButtons.Controls.Add(this.btnR);
            this.pnlButtons.Controls.Add(this.btnJ);
            this.pnlButtons.Controls.Add(this.btnQ);
            this.pnlButtons.Controls.Add(this.btnK);
            this.pnlButtons.Controls.Add(this.btnP);
            this.pnlButtons.Controls.Add(this.btnL);
            this.pnlButtons.Controls.Add(this.btnO);
            this.pnlButtons.Controls.Add(this.btnM);
            this.pnlButtons.Controls.Add(this.btnN);
            this.pnlButtons.Location = new System.Drawing.Point(198, 5);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(656, 32);
            this.pnlButtons.TabIndex = 128;
            // 
            // btnA
            // 
            this.btnA.BackColor = System.Drawing.Color.Transparent;
            this.btnA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnA.Location = new System.Drawing.Point(0, 3);
            this.btnA.Name = "btnA";
            this.btnA.Size = new System.Drawing.Size(23, 23);
            this.btnA.TabIndex = 102;
            this.btnA.Text = "A";
            this.btnA.UseVisualStyleBackColor = false;
            this.btnA.Click += new System.EventHandler(this.btnA_Click);
            // 
            // btnZ
            // 
            this.btnZ.BackColor = System.Drawing.Color.Transparent;
            this.btnZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnZ.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnZ.Location = new System.Drawing.Point(25, 3);
            this.btnZ.Name = "btnZ";
            this.btnZ.Size = new System.Drawing.Size(23, 23);
            this.btnZ.TabIndex = 127;
            this.btnZ.Text = "Z";
            this.btnZ.UseVisualStyleBackColor = false;
            // 
            // btnB
            // 
            this.btnB.BackColor = System.Drawing.Color.Transparent;
            this.btnB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnB.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnB.Location = new System.Drawing.Point(50, 3);
            this.btnB.Name = "btnB";
            this.btnB.Size = new System.Drawing.Size(23, 23);
            this.btnB.TabIndex = 103;
            this.btnB.Text = "B";
            this.btnB.UseVisualStyleBackColor = false;
            // 
            // btnY
            // 
            this.btnY.BackColor = System.Drawing.Color.Transparent;
            this.btnY.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnY.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnY.Location = new System.Drawing.Point(75, 3);
            this.btnY.Name = "btnY";
            this.btnY.Size = new System.Drawing.Size(23, 23);
            this.btnY.TabIndex = 126;
            this.btnY.Text = "Y";
            this.btnY.UseVisualStyleBackColor = false;
            // 
            // btnC
            // 
            this.btnC.BackColor = System.Drawing.Color.Transparent;
            this.btnC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnC.Location = new System.Drawing.Point(100, 3);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(23, 23);
            this.btnC.TabIndex = 104;
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = false;
            // 
            // btnX
            // 
            this.btnX.BackColor = System.Drawing.Color.Transparent;
            this.btnX.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnX.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnX.Location = new System.Drawing.Point(125, 3);
            this.btnX.Name = "btnX";
            this.btnX.Size = new System.Drawing.Size(23, 23);
            this.btnX.TabIndex = 125;
            this.btnX.Text = "X";
            this.btnX.UseVisualStyleBackColor = false;
            // 
            // btnD
            // 
            this.btnD.BackColor = System.Drawing.Color.Transparent;
            this.btnD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnD.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnD.Location = new System.Drawing.Point(150, 3);
            this.btnD.Name = "btnD";
            this.btnD.Size = new System.Drawing.Size(23, 23);
            this.btnD.TabIndex = 105;
            this.btnD.Text = "D";
            this.btnD.UseVisualStyleBackColor = false;
            // 
            // btnW
            // 
            this.btnW.BackColor = System.Drawing.Color.Transparent;
            this.btnW.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnW.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnW.Location = new System.Drawing.Point(175, 3);
            this.btnW.Name = "btnW";
            this.btnW.Size = new System.Drawing.Size(23, 23);
            this.btnW.TabIndex = 124;
            this.btnW.Text = "W";
            this.btnW.UseVisualStyleBackColor = false;
            // 
            // btnE
            // 
            this.btnE.BackColor = System.Drawing.Color.Transparent;
            this.btnE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnE.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnE.Location = new System.Drawing.Point(200, 3);
            this.btnE.Name = "btnE";
            this.btnE.Size = new System.Drawing.Size(23, 23);
            this.btnE.TabIndex = 106;
            this.btnE.Text = "E";
            this.btnE.UseVisualStyleBackColor = false;
            // 
            // btnV
            // 
            this.btnV.BackColor = System.Drawing.Color.Transparent;
            this.btnV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnV.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnV.Location = new System.Drawing.Point(225, 3);
            this.btnV.Name = "btnV";
            this.btnV.Size = new System.Drawing.Size(23, 23);
            this.btnV.TabIndex = 123;
            this.btnV.Text = "V";
            this.btnV.UseVisualStyleBackColor = false;
            // 
            // btnF
            // 
            this.btnF.BackColor = System.Drawing.Color.Transparent;
            this.btnF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnF.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnF.Location = new System.Drawing.Point(250, 3);
            this.btnF.Name = "btnF";
            this.btnF.Size = new System.Drawing.Size(23, 23);
            this.btnF.TabIndex = 107;
            this.btnF.Text = "F";
            this.btnF.UseVisualStyleBackColor = false;
            // 
            // btnU
            // 
            this.btnU.BackColor = System.Drawing.Color.Transparent;
            this.btnU.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnU.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnU.Location = new System.Drawing.Point(275, 3);
            this.btnU.Name = "btnU";
            this.btnU.Size = new System.Drawing.Size(23, 23);
            this.btnU.TabIndex = 122;
            this.btnU.Text = "U";
            this.btnU.UseVisualStyleBackColor = false;
            // 
            // btnG
            // 
            this.btnG.BackColor = System.Drawing.Color.Transparent;
            this.btnG.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnG.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnG.Location = new System.Drawing.Point(300, 3);
            this.btnG.Name = "btnG";
            this.btnG.Size = new System.Drawing.Size(23, 23);
            this.btnG.TabIndex = 108;
            this.btnG.Text = "G";
            this.btnG.UseVisualStyleBackColor = false;
            // 
            // btnT
            // 
            this.btnT.BackColor = System.Drawing.Color.Transparent;
            this.btnT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnT.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnT.Location = new System.Drawing.Point(325, 3);
            this.btnT.Name = "btnT";
            this.btnT.Size = new System.Drawing.Size(23, 23);
            this.btnT.TabIndex = 121;
            this.btnT.Text = "T";
            this.btnT.UseVisualStyleBackColor = false;
            // 
            // btnH
            // 
            this.btnH.BackColor = System.Drawing.Color.Transparent;
            this.btnH.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnH.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnH.Location = new System.Drawing.Point(350, 3);
            this.btnH.Name = "btnH";
            this.btnH.Size = new System.Drawing.Size(23, 23);
            this.btnH.TabIndex = 109;
            this.btnH.Text = "H";
            this.btnH.UseVisualStyleBackColor = false;
            // 
            // btnS
            // 
            this.btnS.BackColor = System.Drawing.Color.Transparent;
            this.btnS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnS.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnS.Location = new System.Drawing.Point(375, 3);
            this.btnS.Name = "btnS";
            this.btnS.Size = new System.Drawing.Size(23, 23);
            this.btnS.TabIndex = 120;
            this.btnS.Text = "S";
            this.btnS.UseVisualStyleBackColor = false;
            // 
            // btnI
            // 
            this.btnI.BackColor = System.Drawing.Color.Transparent;
            this.btnI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnI.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnI.Location = new System.Drawing.Point(400, 3);
            this.btnI.Name = "btnI";
            this.btnI.Size = new System.Drawing.Size(23, 23);
            this.btnI.TabIndex = 110;
            this.btnI.Text = "I";
            this.btnI.UseVisualStyleBackColor = false;
            // 
            // btnR
            // 
            this.btnR.BackColor = System.Drawing.Color.Transparent;
            this.btnR.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnR.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnR.Location = new System.Drawing.Point(425, 3);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(23, 23);
            this.btnR.TabIndex = 119;
            this.btnR.Text = "R";
            this.btnR.UseVisualStyleBackColor = false;
            // 
            // btnJ
            // 
            this.btnJ.BackColor = System.Drawing.Color.Transparent;
            this.btnJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJ.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnJ.Location = new System.Drawing.Point(450, 3);
            this.btnJ.Name = "btnJ";
            this.btnJ.Size = new System.Drawing.Size(23, 23);
            this.btnJ.TabIndex = 111;
            this.btnJ.Text = "J";
            this.btnJ.UseVisualStyleBackColor = false;
            // 
            // btnQ
            // 
            this.btnQ.BackColor = System.Drawing.Color.Transparent;
            this.btnQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQ.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnQ.Location = new System.Drawing.Point(475, 3);
            this.btnQ.Name = "btnQ";
            this.btnQ.Size = new System.Drawing.Size(23, 23);
            this.btnQ.TabIndex = 118;
            this.btnQ.Text = "Q";
            this.btnQ.UseVisualStyleBackColor = false;
            // 
            // btnK
            // 
            this.btnK.BackColor = System.Drawing.Color.Transparent;
            this.btnK.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnK.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnK.Location = new System.Drawing.Point(500, 3);
            this.btnK.Name = "btnK";
            this.btnK.Size = new System.Drawing.Size(23, 23);
            this.btnK.TabIndex = 112;
            this.btnK.Text = "K";
            this.btnK.UseVisualStyleBackColor = false;
            // 
            // btnP
            // 
            this.btnP.BackColor = System.Drawing.Color.Transparent;
            this.btnP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnP.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnP.Location = new System.Drawing.Point(525, 3);
            this.btnP.Name = "btnP";
            this.btnP.Size = new System.Drawing.Size(23, 23);
            this.btnP.TabIndex = 117;
            this.btnP.Text = "P";
            this.btnP.UseVisualStyleBackColor = false;
            // 
            // btnL
            // 
            this.btnL.BackColor = System.Drawing.Color.Transparent;
            this.btnL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnL.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnL.Location = new System.Drawing.Point(550, 3);
            this.btnL.Name = "btnL";
            this.btnL.Size = new System.Drawing.Size(23, 23);
            this.btnL.TabIndex = 113;
            this.btnL.Text = "L";
            this.btnL.UseVisualStyleBackColor = false;
            // 
            // btnO
            // 
            this.btnO.BackColor = System.Drawing.Color.Transparent;
            this.btnO.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnO.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnO.Location = new System.Drawing.Point(575, 3);
            this.btnO.Name = "btnO";
            this.btnO.Size = new System.Drawing.Size(23, 23);
            this.btnO.TabIndex = 116;
            this.btnO.Text = "O";
            this.btnO.UseVisualStyleBackColor = false;
            // 
            // btnM
            // 
            this.btnM.BackColor = System.Drawing.Color.Transparent;
            this.btnM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnM.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnM.Location = new System.Drawing.Point(600, 3);
            this.btnM.Name = "btnM";
            this.btnM.Size = new System.Drawing.Size(23, 23);
            this.btnM.TabIndex = 114;
            this.btnM.Text = "M";
            this.btnM.UseVisualStyleBackColor = false;
            // 
            // btnN
            // 
            this.btnN.BackColor = System.Drawing.Color.Transparent;
            this.btnN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnN.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnN.Location = new System.Drawing.Point(625, 3);
            this.btnN.Name = "btnN";
            this.btnN.Size = new System.Drawing.Size(23, 23);
            this.btnN.TabIndex = 115;
            this.btnN.Text = "N";
            this.btnN.UseVisualStyleBackColor = false;
            // 
            // pnlListBoxes
            // 
            this.pnlListBoxes.BackColor = System.Drawing.Color.White;
            this.pnlListBoxes.Controls.Add(this.lblSaleOrderNoShow);
            this.pnlListBoxes.Controls.Add(this.lblSaleOrderNo);
            this.pnlListBoxes.Controls.Add(this.lblCarTradeValue);
            this.pnlListBoxes.Controls.Add(this.panel7);
            this.pnlListBoxes.Controls.Add(this.btnSaleTradeIn);
            this.pnlListBoxes.Controls.Add(this.txtSaleDeposit);
            this.pnlListBoxes.Controls.Add(this.lblSaleTradeIn);
            this.pnlListBoxes.Controls.Add(this.lblSaleDeposit);
            this.pnlListBoxes.Controls.Add(this.lstCar);
            this.pnlListBoxes.Controls.Add(this.lstCustomer);
            this.pnlListBoxes.Controls.Add(this.lblSaleOrderDateShow);
            this.pnlListBoxes.Controls.Add(this.lblListCar);
            this.pnlListBoxes.Controls.Add(this.lblOrderDate);
            this.pnlListBoxes.Controls.Add(this.lblListCustomer);
            this.pnlListBoxes.Location = new System.Drawing.Point(6, 44);
            this.pnlListBoxes.Name = "pnlListBoxes";
            this.pnlListBoxes.Size = new System.Drawing.Size(396, 347);
            this.pnlListBoxes.TabIndex = 101;
            // 
            // lblSaleOrderNoShow
            // 
            this.lblSaleOrderNoShow.AutoSize = true;
            this.lblSaleOrderNoShow.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleOrderNoShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleOrderNoShow.Location = new System.Drawing.Point(103, 177);
            this.lblSaleOrderNoShow.Name = "lblSaleOrderNoShow";
            this.lblSaleOrderNoShow.Size = new System.Drawing.Size(127, 19);
            this.lblSaleOrderNoShow.TabIndex = 137;
            this.lblSaleOrderNoShow.Text = "ORDER NO HERE";
            // 
            // lblSaleOrderNo
            // 
            this.lblSaleOrderNo.AutoSize = true;
            this.lblSaleOrderNo.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleOrderNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleOrderNo.Location = new System.Drawing.Point(12, 178);
            this.lblSaleOrderNo.Name = "lblSaleOrderNo";
            this.lblSaleOrderNo.Size = new System.Drawing.Size(78, 19);
            this.lblSaleOrderNo.TabIndex = 136;
            this.lblSaleOrderNo.Text = "Order No:";
            // 
            // lblCarTradeValue
            // 
            this.lblCarTradeValue.AutoSize = true;
            this.lblCarTradeValue.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarTradeValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblCarTradeValue.Location = new System.Drawing.Point(103, 243);
            this.lblCarTradeValue.Name = "lblCarTradeValue";
            this.lblCarTradeValue.Size = new System.Drawing.Size(18, 19);
            this.lblCarTradeValue.TabIndex = 135;
            this.lblCarTradeValue.Text = "0";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.rbCheque);
            this.panel7.Controls.Add(this.rbCard);
            this.panel7.Controls.Add(this.rbFinance);
            this.panel7.Controls.Add(this.rbCash);
            this.panel7.Controls.Add(this.lblPaymentMethod);
            this.panel7.Location = new System.Drawing.Point(16, 263);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(198, 72);
            this.panel7.TabIndex = 134;
            // 
            // rbCheque
            // 
            this.rbCheque.AutoSize = true;
            this.rbCheque.Location = new System.Drawing.Point(67, 49);
            this.rbCheque.Name = "rbCheque";
            this.rbCheque.Size = new System.Drawing.Size(62, 17);
            this.rbCheque.TabIndex = 139;
            this.rbCheque.TabStop = true;
            this.rbCheque.Text = "Cheque";
            this.rbCheque.UseVisualStyleBackColor = true;
            this.rbCheque.Click += new System.EventHandler(this.rbCheque_Click);
            // 
            // rbCard
            // 
            this.rbCard.AutoSize = true;
            this.rbCard.Location = new System.Drawing.Point(67, 25);
            this.rbCard.Name = "rbCard";
            this.rbCard.Size = new System.Drawing.Size(47, 17);
            this.rbCard.TabIndex = 138;
            this.rbCard.TabStop = true;
            this.rbCard.Text = "Card";
            this.rbCard.UseVisualStyleBackColor = true;
            this.rbCard.Click += new System.EventHandler(this.rbCard_Click);
            // 
            // rbFinance
            // 
            this.rbFinance.AutoSize = true;
            this.rbFinance.Location = new System.Drawing.Point(3, 49);
            this.rbFinance.Name = "rbFinance";
            this.rbFinance.Size = new System.Drawing.Size(63, 17);
            this.rbFinance.TabIndex = 137;
            this.rbFinance.TabStop = true;
            this.rbFinance.Text = "Finance";
            this.rbFinance.UseVisualStyleBackColor = true;
            this.rbFinance.Click += new System.EventHandler(this.rbFinance_Click);
            // 
            // rbCash
            // 
            this.rbCash.AutoSize = true;
            this.rbCash.Location = new System.Drawing.Point(3, 25);
            this.rbCash.Name = "rbCash";
            this.rbCash.Size = new System.Drawing.Size(49, 17);
            this.rbCash.TabIndex = 136;
            this.rbCash.TabStop = true;
            this.rbCash.Text = "Cash";
            this.rbCash.UseVisualStyleBackColor = true;
            this.rbCash.Click += new System.EventHandler(this.rbCash_Click);
            // 
            // lblPaymentMethod
            // 
            this.lblPaymentMethod.AutoSize = true;
            this.lblPaymentMethod.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPaymentMethod.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblPaymentMethod.Location = new System.Drawing.Point(-4, 3);
            this.lblPaymentMethod.Name = "lblPaymentMethod";
            this.lblPaymentMethod.Size = new System.Drawing.Size(130, 19);
            this.lblPaymentMethod.TabIndex = 135;
            this.lblPaymentMethod.Text = "Payment Method";
            // 
            // btnSaleTradeIn
            // 
            this.btnSaleTradeIn.Location = new System.Drawing.Point(230, 284);
            this.btnSaleTradeIn.Name = "btnSaleTradeIn";
            this.btnSaleTradeIn.Size = new System.Drawing.Size(153, 51);
            this.btnSaleTradeIn.TabIndex = 133;
            this.btnSaleTradeIn.Text = "Enter Trade In Details";
            this.btnSaleTradeIn.UseVisualStyleBackColor = true;
            this.btnSaleTradeIn.Click += new System.EventHandler(this.btnSaleTradeIn_Click);
            // 
            // txtSaleDeposit
            // 
            this.txtSaleDeposit.Location = new System.Drawing.Point(107, 219);
            this.txtSaleDeposit.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.txtSaleDeposit.Name = "txtSaleDeposit";
            this.txtSaleDeposit.Size = new System.Drawing.Size(115, 20);
            this.txtSaleDeposit.TabIndex = 132;
            this.txtSaleDeposit.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            // 
            // lblSaleTradeIn
            // 
            this.lblSaleTradeIn.AutoSize = true;
            this.lblSaleTradeIn.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleTradeIn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleTradeIn.Location = new System.Drawing.Point(12, 243);
            this.lblSaleTradeIn.Name = "lblSaleTradeIn";
            this.lblSaleTradeIn.Size = new System.Drawing.Size(71, 19);
            this.lblSaleTradeIn.TabIndex = 131;
            this.lblSaleTradeIn.Text = "Trade In:";
            // 
            // lblSaleDeposit
            // 
            this.lblSaleDeposit.AutoSize = true;
            this.lblSaleDeposit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleDeposit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleDeposit.Location = new System.Drawing.Point(12, 222);
            this.lblSaleDeposit.Name = "lblSaleDeposit";
            this.lblSaleDeposit.Size = new System.Drawing.Size(67, 19);
            this.lblSaleDeposit.TabIndex = 19;
            this.lblSaleDeposit.Text = "Deposit:";
            // 
            // lstCar
            // 
            this.lstCar.Enabled = false;
            this.lstCar.FormattingEnabled = true;
            this.lstCar.Location = new System.Drawing.Point(195, 29);
            this.lstCar.Name = "lstCar";
            this.lstCar.Size = new System.Drawing.Size(188, 134);
            this.lstCar.TabIndex = 130;
            this.lstCar.Click += new System.EventHandler(this.lstCar_Click);
            // 
            // lstCustomer
            // 
            this.lstCustomer.FormattingEnabled = true;
            this.lstCustomer.Location = new System.Drawing.Point(7, 29);
            this.lstCustomer.Name = "lstCustomer";
            this.lstCustomer.Size = new System.Drawing.Size(182, 134);
            this.lstCustomer.TabIndex = 129;
            this.lstCustomer.Click += new System.EventHandler(this.lstCustomer_Click);
            // 
            // lblSaleOrderDateShow
            // 
            this.lblSaleOrderDateShow.AutoSize = true;
            this.lblSaleOrderDateShow.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleOrderDateShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleOrderDateShow.Location = new System.Drawing.Point(103, 196);
            this.lblSaleOrderDateShow.Name = "lblSaleOrderDateShow";
            this.lblSaleOrderDateShow.Size = new System.Drawing.Size(143, 19);
            this.lblSaleOrderDateShow.TabIndex = 128;
            this.lblSaleOrderDateShow.Text = "ORDER DATE HERE";
            // 
            // lblListCar
            // 
            this.lblListCar.AutoSize = true;
            this.lblListCar.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblListCar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblListCar.Location = new System.Drawing.Point(198, 5);
            this.lblListCar.Name = "lblListCar";
            this.lblListCar.Size = new System.Drawing.Size(32, 19);
            this.lblListCar.TabIndex = 101;
            this.lblListCar.Text = "Car";
            // 
            // lblOrderDate
            // 
            this.lblOrderDate.AutoSize = true;
            this.lblOrderDate.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrderDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblOrderDate.Location = new System.Drawing.Point(12, 197);
            this.lblOrderDate.Name = "lblOrderDate";
            this.lblOrderDate.Size = new System.Drawing.Size(90, 19);
            this.lblOrderDate.TabIndex = 17;
            this.lblOrderDate.Text = "Order Date:";
            // 
            // lblListCustomer
            // 
            this.lblListCustomer.AutoSize = true;
            this.lblListCustomer.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblListCustomer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblListCustomer.Location = new System.Drawing.Point(3, 7);
            this.lblListCustomer.Name = "lblListCustomer";
            this.lblListCustomer.Size = new System.Drawing.Size(77, 19);
            this.lblListCustomer.TabIndex = 17;
            this.lblListCustomer.Text = "Customer";
            // 
            // lblSaleCarDetailsTitle
            // 
            this.lblSaleCarDetailsTitle.AutoSize = true;
            this.lblSaleCarDetailsTitle.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCarDetailsTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCarDetailsTitle.Location = new System.Drawing.Point(436, 310);
            this.lblSaleCarDetailsTitle.Name = "lblSaleCarDetailsTitle";
            this.lblSaleCarDetailsTitle.Size = new System.Drawing.Size(116, 27);
            this.lblSaleCarDetailsTitle.TabIndex = 98;
            this.lblSaleCarDetailsTitle.Text = "Car Details";
            // 
            // lblSaleCustDetailsTitle
            // 
            this.lblSaleCustDetailsTitle.AutoSize = true;
            this.lblSaleCustDetailsTitle.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustDetailsTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustDetailsTitle.Location = new System.Drawing.Point(431, 48);
            this.lblSaleCustDetailsTitle.Name = "lblSaleCustDetailsTitle";
            this.lblSaleCustDetailsTitle.Size = new System.Drawing.Size(178, 27);
            this.lblSaleCustDetailsTitle.TabIndex = 3;
            this.lblSaleCustDetailsTitle.Text = "Customer Details";
            // 
            // pnlSaleCarDetails
            // 
            this.pnlSaleCarDetails.Controls.Add(this.lblSaleCarPriceShow);
            this.pnlSaleCarDetails.Controls.Add(this.lblCarPrice);
            this.pnlSaleCarDetails.Controls.Add(this.label1);
            this.pnlSaleCarDetails.Controls.Add(this.label2);
            this.pnlSaleCarDetails.Controls.Add(this.label3);
            this.pnlSaleCarDetails.Controls.Add(this.label4);
            this.pnlSaleCarDetails.Controls.Add(this.label5);
            this.pnlSaleCarDetails.Controls.Add(this.label6);
            this.pnlSaleCarDetails.Controls.Add(this.label7);
            this.pnlSaleCarDetails.Controls.Add(this.lblSaleCarMileageShow);
            this.pnlSaleCarDetails.Controls.Add(this.lblSaleCarBodyShow);
            this.pnlSaleCarDetails.Controls.Add(this.lblSaleCarColourShow);
            this.pnlSaleCarDetails.Controls.Add(this.lblSaleCarInteriorShow);
            this.pnlSaleCarDetails.Controls.Add(this.lblSaleCarTransmissionShow);
            this.pnlSaleCarDetails.Controls.Add(this.lblSaleCarModelShow);
            this.pnlSaleCarDetails.Controls.Add(this.lblSaleCarMakeShow);
            this.pnlSaleCarDetails.Location = new System.Drawing.Point(429, 346);
            this.pnlSaleCarDetails.Name = "pnlSaleCarDetails";
            this.pnlSaleCarDetails.Size = new System.Drawing.Size(422, 96);
            this.pnlSaleCarDetails.TabIndex = 97;
            // 
            // lblSaleCarPriceShow
            // 
            this.lblSaleCarPriceShow.AutoSize = true;
            this.lblSaleCarPriceShow.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCarPriceShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCarPriceShow.Location = new System.Drawing.Point(290, 69);
            this.lblSaleCarPriceShow.Name = "lblSaleCarPriceShow";
            this.lblSaleCarPriceShow.Size = new System.Drawing.Size(16, 21);
            this.lblSaleCarPriceShow.TabIndex = 114;
            this.lblSaleCarPriceShow.Text = "-";
            // 
            // lblCarPrice
            // 
            this.lblCarPrice.AutoSize = true;
            this.lblCarPrice.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarPrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblCarPrice.Location = new System.Drawing.Point(234, 69);
            this.lblCarPrice.Name = "lblCarPrice";
            this.lblCarPrice.Size = new System.Drawing.Size(52, 21);
            this.lblCarPrice.TabIndex = 113;
            this.lblCarPrice.Text = "Price:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label1.Location = new System.Drawing.Point(234, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 21);
            this.label1.TabIndex = 112;
            this.label1.Text = "Mileage:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label2.Location = new System.Drawing.Point(234, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 21);
            this.label2.TabIndex = 111;
            this.label2.Text = "Body Style:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label3.Location = new System.Drawing.Point(234, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 21);
            this.label3.TabIndex = 110;
            this.label3.Text = "Colour:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label4.Location = new System.Drawing.Point(9, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 21);
            this.label4.TabIndex = 109;
            this.label4.Text = "Interior:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label5.Location = new System.Drawing.Point(9, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 21);
            this.label5.TabIndex = 108;
            this.label5.Text = "Transmission:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label6.Location = new System.Drawing.Point(9, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 21);
            this.label6.TabIndex = 107;
            this.label6.Text = "Model:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label7.Location = new System.Drawing.Point(9, 6);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 21);
            this.label7.TabIndex = 106;
            this.label7.Text = "Make:";
            // 
            // lblSaleCarMileageShow
            // 
            this.lblSaleCarMileageShow.AutoSize = true;
            this.lblSaleCarMileageShow.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCarMileageShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCarMileageShow.Location = new System.Drawing.Point(316, 48);
            this.lblSaleCarMileageShow.Name = "lblSaleCarMileageShow";
            this.lblSaleCarMileageShow.Size = new System.Drawing.Size(16, 21);
            this.lblSaleCarMileageShow.TabIndex = 105;
            this.lblSaleCarMileageShow.Text = "-";
            // 
            // lblSaleCarBodyShow
            // 
            this.lblSaleCarBodyShow.AutoSize = true;
            this.lblSaleCarBodyShow.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCarBodyShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCarBodyShow.Location = new System.Drawing.Point(324, 6);
            this.lblSaleCarBodyShow.Name = "lblSaleCarBodyShow";
            this.lblSaleCarBodyShow.Size = new System.Drawing.Size(16, 21);
            this.lblSaleCarBodyShow.TabIndex = 104;
            this.lblSaleCarBodyShow.Text = "-";
            // 
            // lblSaleCarColourShow
            // 
            this.lblSaleCarColourShow.AutoSize = true;
            this.lblSaleCarColourShow.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCarColourShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCarColourShow.Location = new System.Drawing.Point(299, 27);
            this.lblSaleCarColourShow.Name = "lblSaleCarColourShow";
            this.lblSaleCarColourShow.Size = new System.Drawing.Size(16, 21);
            this.lblSaleCarColourShow.TabIndex = 103;
            this.lblSaleCarColourShow.Text = "-";
            // 
            // lblSaleCarInteriorShow
            // 
            this.lblSaleCarInteriorShow.AutoSize = true;
            this.lblSaleCarInteriorShow.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCarInteriorShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCarInteriorShow.Location = new System.Drawing.Point(77, 71);
            this.lblSaleCarInteriorShow.Name = "lblSaleCarInteriorShow";
            this.lblSaleCarInteriorShow.Size = new System.Drawing.Size(16, 21);
            this.lblSaleCarInteriorShow.TabIndex = 102;
            this.lblSaleCarInteriorShow.Text = "-";
            // 
            // lblSaleCarTransmissionShow
            // 
            this.lblSaleCarTransmissionShow.AutoSize = true;
            this.lblSaleCarTransmissionShow.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCarTransmissionShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCarTransmissionShow.Location = new System.Drawing.Point(119, 50);
            this.lblSaleCarTransmissionShow.Name = "lblSaleCarTransmissionShow";
            this.lblSaleCarTransmissionShow.Size = new System.Drawing.Size(16, 21);
            this.lblSaleCarTransmissionShow.TabIndex = 101;
            this.lblSaleCarTransmissionShow.Text = "-";
            // 
            // lblSaleCarModelShow
            // 
            this.lblSaleCarModelShow.AutoSize = true;
            this.lblSaleCarModelShow.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCarModelShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCarModelShow.Location = new System.Drawing.Point(69, 30);
            this.lblSaleCarModelShow.Name = "lblSaleCarModelShow";
            this.lblSaleCarModelShow.Size = new System.Drawing.Size(16, 21);
            this.lblSaleCarModelShow.TabIndex = 100;
            this.lblSaleCarModelShow.Text = "-";
            // 
            // lblSaleCarMakeShow
            // 
            this.lblSaleCarMakeShow.AutoSize = true;
            this.lblSaleCarMakeShow.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCarMakeShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCarMakeShow.Location = new System.Drawing.Point(62, 6);
            this.lblSaleCarMakeShow.Name = "lblSaleCarMakeShow";
            this.lblSaleCarMakeShow.Size = new System.Drawing.Size(16, 21);
            this.lblSaleCarMakeShow.TabIndex = 99;
            this.lblSaleCarMakeShow.Text = "-";
            // 
            // pnlSaleCustDetails
            // 
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustNoShow);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustNo);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustTelNumShow);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustEmailShow);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustTelNum);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustEmail);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustCreditRatingShow);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustPostcodeShow);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustCountyShow);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustTownShow);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustAddressShow);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustNameShow);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustCreditRating);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustPostcode);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustCounty);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustTown);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustAddress);
            this.pnlSaleCustDetails.Controls.Add(this.lblSaleCustName);
            this.pnlSaleCustDetails.Location = new System.Drawing.Point(429, 90);
            this.pnlSaleCustDetails.Name = "pnlSaleCustDetails";
            this.pnlSaleCustDetails.Size = new System.Drawing.Size(425, 216);
            this.pnlSaleCustDetails.TabIndex = 96;
            // 
            // lblSaleCustNoShow
            // 
            this.lblSaleCustNoShow.AutoSize = true;
            this.lblSaleCustNoShow.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustNoShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustNoShow.Location = new System.Drawing.Point(79, 9);
            this.lblSaleCustNoShow.Name = "lblSaleCustNoShow";
            this.lblSaleCustNoShow.Size = new System.Drawing.Size(15, 19);
            this.lblSaleCustNoShow.TabIndex = 20;
            this.lblSaleCustNoShow.Text = "-";
            // 
            // lblSaleCustNo
            // 
            this.lblSaleCustNo.AutoSize = true;
            this.lblSaleCustNo.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustNo.Location = new System.Drawing.Point(4, 9);
            this.lblSaleCustNo.Name = "lblSaleCustNo";
            this.lblSaleCustNo.Size = new System.Drawing.Size(69, 19);
            this.lblSaleCustNo.TabIndex = 19;
            this.lblSaleCustNo.Text = "Cust No:";
            // 
            // lblSaleCustTelNumShow
            // 
            this.lblSaleCustTelNumShow.AutoSize = true;
            this.lblSaleCustTelNumShow.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustTelNumShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustTelNumShow.Location = new System.Drawing.Point(77, 194);
            this.lblSaleCustTelNumShow.Name = "lblSaleCustTelNumShow";
            this.lblSaleCustTelNumShow.Size = new System.Drawing.Size(15, 19);
            this.lblSaleCustTelNumShow.TabIndex = 18;
            this.lblSaleCustTelNumShow.Text = "-";
            // 
            // lblSaleCustEmailShow
            // 
            this.lblSaleCustEmailShow.AutoSize = true;
            this.lblSaleCustEmailShow.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustEmailShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustEmailShow.Location = new System.Drawing.Point(49, 170);
            this.lblSaleCustEmailShow.Name = "lblSaleCustEmailShow";
            this.lblSaleCustEmailShow.Size = new System.Drawing.Size(15, 19);
            this.lblSaleCustEmailShow.TabIndex = 17;
            this.lblSaleCustEmailShow.Text = "-";
            // 
            // lblSaleCustTelNum
            // 
            this.lblSaleCustTelNum.AutoSize = true;
            this.lblSaleCustTelNum.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustTelNum.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustTelNum.Location = new System.Drawing.Point(3, 194);
            this.lblSaleCustTelNum.Name = "lblSaleCustTelNum";
            this.lblSaleCustTelNum.Size = new System.Drawing.Size(69, 19);
            this.lblSaleCustTelNum.TabIndex = 16;
            this.lblSaleCustTelNum.Text = "TelNum:";
            // 
            // lblSaleCustEmail
            // 
            this.lblSaleCustEmail.AutoSize = true;
            this.lblSaleCustEmail.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustEmail.Location = new System.Drawing.Point(3, 170);
            this.lblSaleCustEmail.Name = "lblSaleCustEmail";
            this.lblSaleCustEmail.Size = new System.Drawing.Size(51, 19);
            this.lblSaleCustEmail.TabIndex = 15;
            this.lblSaleCustEmail.Text = "Email:";
            // 
            // lblSaleCustCreditRatingShow
            // 
            this.lblSaleCustCreditRatingShow.AutoSize = true;
            this.lblSaleCustCreditRatingShow.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustCreditRatingShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustCreditRatingShow.Location = new System.Drawing.Point(105, 146);
            this.lblSaleCustCreditRatingShow.Name = "lblSaleCustCreditRatingShow";
            this.lblSaleCustCreditRatingShow.Size = new System.Drawing.Size(15, 19);
            this.lblSaleCustCreditRatingShow.TabIndex = 14;
            this.lblSaleCustCreditRatingShow.Text = "-";
            // 
            // lblSaleCustPostcodeShow
            // 
            this.lblSaleCustPostcodeShow.AutoSize = true;
            this.lblSaleCustPostcodeShow.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustPostcodeShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustPostcodeShow.Location = new System.Drawing.Point(79, 123);
            this.lblSaleCustPostcodeShow.Name = "lblSaleCustPostcodeShow";
            this.lblSaleCustPostcodeShow.Size = new System.Drawing.Size(15, 19);
            this.lblSaleCustPostcodeShow.TabIndex = 13;
            this.lblSaleCustPostcodeShow.Text = "-";
            // 
            // lblSaleCustCountyShow
            // 
            this.lblSaleCustCountyShow.AutoSize = true;
            this.lblSaleCustCountyShow.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustCountyShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustCountyShow.Location = new System.Drawing.Point(64, 100);
            this.lblSaleCustCountyShow.Name = "lblSaleCustCountyShow";
            this.lblSaleCustCountyShow.Size = new System.Drawing.Size(15, 19);
            this.lblSaleCustCountyShow.TabIndex = 12;
            this.lblSaleCustCountyShow.Text = "-";
            // 
            // lblSaleCustTownShow
            // 
            this.lblSaleCustTownShow.AutoSize = true;
            this.lblSaleCustTownShow.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustTownShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustTownShow.Location = new System.Drawing.Point(50, 77);
            this.lblSaleCustTownShow.Name = "lblSaleCustTownShow";
            this.lblSaleCustTownShow.Size = new System.Drawing.Size(15, 19);
            this.lblSaleCustTownShow.TabIndex = 11;
            this.lblSaleCustTownShow.Text = "-";
            // 
            // lblSaleCustAddressShow
            // 
            this.lblSaleCustAddressShow.AutoSize = true;
            this.lblSaleCustAddressShow.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustAddressShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustAddressShow.Location = new System.Drawing.Point(71, 52);
            this.lblSaleCustAddressShow.Name = "lblSaleCustAddressShow";
            this.lblSaleCustAddressShow.Size = new System.Drawing.Size(15, 19);
            this.lblSaleCustAddressShow.TabIndex = 10;
            this.lblSaleCustAddressShow.Text = "-";
            // 
            // lblSaleCustNameShow
            // 
            this.lblSaleCustNameShow.AutoSize = true;
            this.lblSaleCustNameShow.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustNameShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustNameShow.Location = new System.Drawing.Point(57, 28);
            this.lblSaleCustNameShow.Name = "lblSaleCustNameShow";
            this.lblSaleCustNameShow.Size = new System.Drawing.Size(15, 19);
            this.lblSaleCustNameShow.TabIndex = 8;
            this.lblSaleCustNameShow.Text = "-";
            // 
            // lblSaleCustCreditRating
            // 
            this.lblSaleCustCreditRating.AutoSize = true;
            this.lblSaleCustCreditRating.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustCreditRating.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustCreditRating.Location = new System.Drawing.Point(3, 146);
            this.lblSaleCustCreditRating.Name = "lblSaleCustCreditRating";
            this.lblSaleCustCreditRating.Size = new System.Drawing.Size(105, 19);
            this.lblSaleCustCreditRating.TabIndex = 7;
            this.lblSaleCustCreditRating.Text = "Credit Rating:";
            // 
            // lblSaleCustPostcode
            // 
            this.lblSaleCustPostcode.AutoSize = true;
            this.lblSaleCustPostcode.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustPostcode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustPostcode.Location = new System.Drawing.Point(4, 123);
            this.lblSaleCustPostcode.Name = "lblSaleCustPostcode";
            this.lblSaleCustPostcode.Size = new System.Drawing.Size(77, 19);
            this.lblSaleCustPostcode.TabIndex = 6;
            this.lblSaleCustPostcode.Text = "Postcode:";
            // 
            // lblSaleCustCounty
            // 
            this.lblSaleCustCounty.AutoSize = true;
            this.lblSaleCustCounty.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustCounty.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustCounty.Location = new System.Drawing.Point(4, 100);
            this.lblSaleCustCounty.Name = "lblSaleCustCounty";
            this.lblSaleCustCounty.Size = new System.Drawing.Size(63, 19);
            this.lblSaleCustCounty.TabIndex = 5;
            this.lblSaleCustCounty.Text = "County:";
            // 
            // lblSaleCustTown
            // 
            this.lblSaleCustTown.AutoSize = true;
            this.lblSaleCustTown.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustTown.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustTown.Location = new System.Drawing.Point(4, 77);
            this.lblSaleCustTown.Name = "lblSaleCustTown";
            this.lblSaleCustTown.Size = new System.Drawing.Size(52, 19);
            this.lblSaleCustTown.TabIndex = 4;
            this.lblSaleCustTown.Text = "Town:";
            // 
            // lblSaleCustAddress
            // 
            this.lblSaleCustAddress.AutoSize = true;
            this.lblSaleCustAddress.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustAddress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustAddress.Location = new System.Drawing.Point(4, 52);
            this.lblSaleCustAddress.Name = "lblSaleCustAddress";
            this.lblSaleCustAddress.Size = new System.Drawing.Size(70, 19);
            this.lblSaleCustAddress.TabIndex = 3;
            this.lblSaleCustAddress.Text = "Address:";
            // 
            // lblSaleCustName
            // 
            this.lblSaleCustName.AutoSize = true;
            this.lblSaleCustName.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaleCustName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSaleCustName.Location = new System.Drawing.Point(4, 28);
            this.lblSaleCustName.Name = "lblSaleCustName";
            this.lblSaleCustName.Size = new System.Drawing.Size(55, 19);
            this.lblSaleCustName.TabIndex = 1;
            this.lblSaleCustName.Text = "Name:";
            // 
            // lblAddCarReset
            // 
            this.lblAddCarReset.AutoSize = true;
            this.lblAddCarReset.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold);
            this.lblAddCarReset.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblAddCarReset.Location = new System.Drawing.Point(180, 421);
            this.lblAddCarReset.Name = "lblAddCarReset";
            this.lblAddCarReset.Size = new System.Drawing.Size(94, 21);
            this.lblAddCarReset.TabIndex = 54;
            this.lblAddCarReset.Text = "Reset Form";
            // 
            // btnAddSaleReset
            // 
            this.btnAddSaleReset.Location = new System.Drawing.Point(137, 411);
            this.btnAddSaleReset.Name = "btnAddSaleReset";
            this.btnAddSaleReset.Size = new System.Drawing.Size(37, 35);
            this.btnAddSaleReset.TabIndex = 53;
            this.btnAddSaleReset.UseVisualStyleBackColor = true;
            this.btnAddSaleReset.Click += new System.EventHandler(this.btnAddSaleReset_Click);
            // 
            // lblAddSaleAdd
            // 
            this.lblAddSaleAdd.AutoSize = true;
            this.lblAddSaleAdd.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold);
            this.lblAddSaleAdd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblAddSaleAdd.Location = new System.Drawing.Point(54, 418);
            this.lblAddSaleAdd.Name = "lblAddSaleAdd";
            this.lblAddSaleAdd.Size = new System.Drawing.Size(65, 21);
            this.lblAddSaleAdd.TabIndex = 52;
            this.lblAddSaleAdd.Text = "Submit";
            // 
            // btnAddSaleAdd
            // 
            this.btnAddSaleAdd.Location = new System.Drawing.Point(11, 411);
            this.btnAddSaleAdd.Name = "btnAddSaleAdd";
            this.btnAddSaleAdd.Size = new System.Drawing.Size(37, 35);
            this.btnAddSaleAdd.TabIndex = 51;
            this.btnAddSaleAdd.UseVisualStyleBackColor = true;
            this.btnAddSaleAdd.Click += new System.EventHandler(this.btnAddSaleAdd_Click);
            // 
            // lblCarAddHeader
            // 
            this.lblCarAddHeader.AutoSize = true;
            this.lblCarAddHeader.BackColor = System.Drawing.Color.White;
            this.lblCarAddHeader.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarAddHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblCarAddHeader.Location = new System.Drawing.Point(0, 0);
            this.lblCarAddHeader.Name = "lblCarAddHeader";
            this.lblCarAddHeader.Size = new System.Drawing.Size(195, 45);
            this.lblCarAddHeader.TabIndex = 48;
            this.lblCarAddHeader.Text = "Add Order";
            // 
            // tabSalesFinance
            // 
            this.tabSalesFinance.Controls.Add(this.lblFinanceTotalInterest);
            this.tabSalesFinance.Controls.Add(this.label18);
            this.tabSalesFinance.Controls.Add(this.lblFinanceInterestPriceShow);
            this.tabSalesFinance.Controls.Add(this.label16);
            this.tabSalesFinance.Controls.Add(this.lblFinanceInterestRateShow);
            this.tabSalesFinance.Controls.Add(this.lblFinanceInterestRate);
            this.tabSalesFinance.Controls.Add(this.lblFinanceMonthlyPaymentShow);
            this.tabSalesFinance.Controls.Add(this.lblFinanceMonthlyPayment);
            this.tabSalesFinance.Controls.Add(this.lblFinanceNumPaymentsShow);
            this.tabSalesFinance.Controls.Add(this.lblFinanceNumPayments);
            this.tabSalesFinance.Controls.Add(this.lblFinanceAgreeDateShow);
            this.tabSalesFinance.Controls.Add(this.lblFinanceAgreeDate);
            this.tabSalesFinance.Controls.Add(this.lblFinanceAgreementIDShow);
            this.tabSalesFinance.Controls.Add(this.lblFinanceID);
            this.tabSalesFinance.Controls.Add(this.lblFinancePriceShow);
            this.tabSalesFinance.Controls.Add(this.label14);
            this.tabSalesFinance.Controls.Add(this.lblFinanceTradeValueShow);
            this.tabSalesFinance.Controls.Add(this.lblFinanceTradeInValue);
            this.tabSalesFinance.Controls.Add(this.lblFinanceDepositShow);
            this.tabSalesFinance.Controls.Add(this.lblFinanceDeposit);
            this.tabSalesFinance.Controls.Add(this.cmbFinancePlanLength);
            this.tabSalesFinance.Controls.Add(this.lblFinancePlanLength);
            this.tabSalesFinance.Controls.Add(this.panel9);
            this.tabSalesFinance.Controls.Add(this.panel8);
            this.tabSalesFinance.Controls.Add(this.lblCarEditHeader);
            this.tabSalesFinance.Controls.Add(this.lblEditCarEdit);
            this.tabSalesFinance.Controls.Add(btnFinanceSubmit);
            this.tabSalesFinance.Location = new System.Drawing.Point(4, 22);
            this.tabSalesFinance.Name = "tabSalesFinance";
            this.tabSalesFinance.Size = new System.Drawing.Size(857, 452);
            this.tabSalesFinance.TabIndex = 2;
            this.tabSalesFinance.Text = "Add Finance";
            this.tabSalesFinance.UseVisualStyleBackColor = true;
            // 
            // lblFinanceTotalInterest
            // 
            this.lblFinanceTotalInterest.AutoSize = true;
            this.lblFinanceTotalInterest.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceTotalInterest.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceTotalInterest.Location = new System.Drawing.Point(762, 342);
            this.lblFinanceTotalInterest.Name = "lblFinanceTotalInterest";
            this.lblFinanceTotalInterest.Size = new System.Drawing.Size(16, 21);
            this.lblFinanceTotalInterest.TabIndex = 198;
            this.lblFinanceTotalInterest.Text = "-";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label18.Location = new System.Drawing.Point(561, 342);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(150, 21);
            this.label18.TabIndex = 197;
            this.label18.Text = "Total Interest Due:";
            // 
            // lblFinanceInterestPriceShow
            // 
            this.lblFinanceInterestPriceShow.AutoSize = true;
            this.lblFinanceInterestPriceShow.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceInterestPriceShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceInterestPriceShow.Location = new System.Drawing.Point(762, 300);
            this.lblFinanceInterestPriceShow.Name = "lblFinanceInterestPriceShow";
            this.lblFinanceInterestPriceShow.Size = new System.Drawing.Size(16, 21);
            this.lblFinanceInterestPriceShow.TabIndex = 196;
            this.lblFinanceInterestPriceShow.Text = "-";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label16.Location = new System.Drawing.Point(561, 300);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(168, 21);
            this.label16.TabIndex = 195;
            this.label16.Text = "Total (With Interest):";
            // 
            // lblFinanceInterestRateShow
            // 
            this.lblFinanceInterestRateShow.AutoSize = true;
            this.lblFinanceInterestRateShow.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceInterestRateShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceInterestRateShow.Location = new System.Drawing.Point(700, 240);
            this.lblFinanceInterestRateShow.Name = "lblFinanceInterestRateShow";
            this.lblFinanceInterestRateShow.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceInterestRateShow.TabIndex = 194;
            this.lblFinanceInterestRateShow.Text = "-";
            // 
            // lblFinanceInterestRate
            // 
            this.lblFinanceInterestRate.AutoSize = true;
            this.lblFinanceInterestRate.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceInterestRate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceInterestRate.Location = new System.Drawing.Point(565, 240);
            this.lblFinanceInterestRate.Name = "lblFinanceInterestRate";
            this.lblFinanceInterestRate.Size = new System.Drawing.Size(104, 19);
            this.lblFinanceInterestRate.TabIndex = 193;
            this.lblFinanceInterestRate.Text = "Interest Rate:";
            // 
            // lblFinanceMonthlyPaymentShow
            // 
            this.lblFinanceMonthlyPaymentShow.AutoSize = true;
            this.lblFinanceMonthlyPaymentShow.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceMonthlyPaymentShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceMonthlyPaymentShow.Location = new System.Drawing.Point(742, 392);
            this.lblFinanceMonthlyPaymentShow.Name = "lblFinanceMonthlyPaymentShow";
            this.lblFinanceMonthlyPaymentShow.Size = new System.Drawing.Size(18, 23);
            this.lblFinanceMonthlyPaymentShow.TabIndex = 192;
            this.lblFinanceMonthlyPaymentShow.Text = "-";
            // 
            // lblFinanceMonthlyPayment
            // 
            this.lblFinanceMonthlyPayment.AutoSize = true;
            this.lblFinanceMonthlyPayment.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceMonthlyPayment.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceMonthlyPayment.Location = new System.Drawing.Point(563, 390);
            this.lblFinanceMonthlyPayment.Name = "lblFinanceMonthlyPayment";
            this.lblFinanceMonthlyPayment.Size = new System.Drawing.Size(173, 23);
            this.lblFinanceMonthlyPayment.TabIndex = 191;
            this.lblFinanceMonthlyPayment.Text = "Monthly Payment:";
            // 
            // lblFinanceNumPaymentsShow
            // 
            this.lblFinanceNumPaymentsShow.AutoSize = true;
            this.lblFinanceNumPaymentsShow.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceNumPaymentsShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceNumPaymentsShow.Location = new System.Drawing.Point(702, 261);
            this.lblFinanceNumPaymentsShow.Name = "lblFinanceNumPaymentsShow";
            this.lblFinanceNumPaymentsShow.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceNumPaymentsShow.TabIndex = 190;
            this.lblFinanceNumPaymentsShow.Text = "-";
            // 
            // lblFinanceNumPayments
            // 
            this.lblFinanceNumPayments.AutoSize = true;
            this.lblFinanceNumPayments.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceNumPayments.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceNumPayments.Location = new System.Drawing.Point(565, 261);
            this.lblFinanceNumPayments.Name = "lblFinanceNumPayments";
            this.lblFinanceNumPayments.Size = new System.Drawing.Size(128, 19);
            this.lblFinanceNumPayments.TabIndex = 189;
            this.lblFinanceNumPayments.Text = "No Of Payments:";
            // 
            // lblFinanceAgreeDateShow
            // 
            this.lblFinanceAgreeDateShow.AutoSize = true;
            this.lblFinanceAgreeDateShow.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceAgreeDateShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceAgreeDateShow.Location = new System.Drawing.Point(699, 204);
            this.lblFinanceAgreeDateShow.Name = "lblFinanceAgreeDateShow";
            this.lblFinanceAgreeDateShow.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceAgreeDateShow.TabIndex = 188;
            this.lblFinanceAgreeDateShow.Text = "-";
            // 
            // lblFinanceAgreeDate
            // 
            this.lblFinanceAgreeDate.AutoSize = true;
            this.lblFinanceAgreeDate.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceAgreeDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceAgreeDate.Location = new System.Drawing.Point(564, 203);
            this.lblFinanceAgreeDate.Name = "lblFinanceAgreeDate";
            this.lblFinanceAgreeDate.Size = new System.Drawing.Size(129, 19);
            this.lblFinanceAgreeDate.TabIndex = 187;
            this.lblFinanceAgreeDate.Text = "Agreement Date:";
            // 
            // lblFinanceAgreementIDShow
            // 
            this.lblFinanceAgreementIDShow.AutoSize = true;
            this.lblFinanceAgreementIDShow.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceAgreementIDShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceAgreementIDShow.Location = new System.Drawing.Point(701, 180);
            this.lblFinanceAgreementIDShow.Name = "lblFinanceAgreementIDShow";
            this.lblFinanceAgreementIDShow.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceAgreementIDShow.TabIndex = 186;
            this.lblFinanceAgreementIDShow.Text = "-";
            // 
            // lblFinanceID
            // 
            this.lblFinanceID.AutoSize = true;
            this.lblFinanceID.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceID.Location = new System.Drawing.Point(565, 180);
            this.lblFinanceID.Name = "lblFinanceID";
            this.lblFinanceID.Size = new System.Drawing.Size(86, 19);
            this.lblFinanceID.TabIndex = 185;
            this.lblFinanceID.Text = "Finance ID:";
            // 
            // lblFinancePriceShow
            // 
            this.lblFinancePriceShow.AutoSize = true;
            this.lblFinancePriceShow.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinancePriceShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinancePriceShow.Location = new System.Drawing.Point(762, 321);
            this.lblFinancePriceShow.Name = "lblFinancePriceShow";
            this.lblFinancePriceShow.Size = new System.Drawing.Size(16, 21);
            this.lblFinancePriceShow.TabIndex = 184;
            this.lblFinancePriceShow.Text = "-";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label14.Location = new System.Drawing.Point(561, 321);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(194, 21);
            this.label14.TabIndex = 183;
            this.label14.Text = "Total (Without Interest):";
            // 
            // lblFinanceTradeValueShow
            // 
            this.lblFinanceTradeValueShow.AutoSize = true;
            this.lblFinanceTradeValueShow.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceTradeValueShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceTradeValueShow.Location = new System.Drawing.Point(698, 157);
            this.lblFinanceTradeValueShow.Name = "lblFinanceTradeValueShow";
            this.lblFinanceTradeValueShow.Size = new System.Drawing.Size(16, 21);
            this.lblFinanceTradeValueShow.TabIndex = 182;
            this.lblFinanceTradeValueShow.Text = "-";
            // 
            // lblFinanceTradeInValue
            // 
            this.lblFinanceTradeInValue.AutoSize = true;
            this.lblFinanceTradeInValue.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceTradeInValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceTradeInValue.Location = new System.Drawing.Point(563, 157);
            this.lblFinanceTradeInValue.Name = "lblFinanceTradeInValue";
            this.lblFinanceTradeInValue.Size = new System.Drawing.Size(124, 21);
            this.lblFinanceTradeInValue.TabIndex = 181;
            this.lblFinanceTradeInValue.Text = "Trade In Value:";
            // 
            // lblFinanceDepositShow
            // 
            this.lblFinanceDepositShow.AutoSize = true;
            this.lblFinanceDepositShow.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceDepositShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceDepositShow.Location = new System.Drawing.Point(698, 132);
            this.lblFinanceDepositShow.Name = "lblFinanceDepositShow";
            this.lblFinanceDepositShow.Size = new System.Drawing.Size(16, 21);
            this.lblFinanceDepositShow.TabIndex = 180;
            this.lblFinanceDepositShow.Text = "-";
            // 
            // lblFinanceDeposit
            // 
            this.lblFinanceDeposit.AutoSize = true;
            this.lblFinanceDeposit.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceDeposit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceDeposit.Location = new System.Drawing.Point(563, 132);
            this.lblFinanceDeposit.Name = "lblFinanceDeposit";
            this.lblFinanceDeposit.Size = new System.Drawing.Size(73, 21);
            this.lblFinanceDeposit.TabIndex = 179;
            this.lblFinanceDeposit.Text = "Deposit:";
            // 
            // cmbFinancePlanLength
            // 
            this.cmbFinancePlanLength.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFinancePlanLength.FormattingEnabled = true;
            this.cmbFinancePlanLength.Items.AddRange(new object[] {
            "12 Months",
            "24 Months",
            "36 Months",
            "48 Months",
            "60 Months"});
            this.cmbFinancePlanLength.Location = new System.Drawing.Point(672, 109);
            this.cmbFinancePlanLength.Name = "cmbFinancePlanLength";
            this.cmbFinancePlanLength.Size = new System.Drawing.Size(115, 21);
            this.cmbFinancePlanLength.TabIndex = 178;
            this.cmbFinancePlanLength.SelectedIndexChanged += new System.EventHandler(this.cmbFinancePlanLength_SelectedIndexChanged);
            // 
            // lblFinancePlanLength
            // 
            this.lblFinancePlanLength.AutoSize = true;
            this.lblFinancePlanLength.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinancePlanLength.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinancePlanLength.Location = new System.Drawing.Point(561, 109);
            this.lblFinancePlanLength.Name = "lblFinancePlanLength";
            this.lblFinancePlanLength.Size = new System.Drawing.Size(105, 21);
            this.lblFinancePlanLength.TabIndex = 177;
            this.lblFinancePlanLength.Text = "Plan Length:";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.lblFinanceRegNoShow);
            this.panel9.Controls.Add(this.lblFinanceRegNo);
            this.panel9.Controls.Add(this.label23);
            this.panel9.Controls.Add(this.lblFinanceMake);
            this.panel9.Controls.Add(this.label39);
            this.panel9.Controls.Add(this.lblFinanceModel);
            this.panel9.Controls.Add(this.label41);
            this.panel9.Controls.Add(this.lblFinanceColour);
            this.panel9.Controls.Add(this.label42);
            this.panel9.Controls.Add(this.lblFinanceMileage);
            this.panel9.Controls.Add(this.lblFinanceBodyStyle);
            this.panel9.Controls.Add(this.label22);
            this.panel9.Controls.Add(this.lblFinanceInterior);
            this.panel9.Controls.Add(this.label19);
            this.panel9.Controls.Add(this.lblFinanceTransmission);
            this.panel9.Controls.Add(this.label17);
            this.panel9.Location = new System.Drawing.Point(294, 109);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(226, 193);
            this.panel9.TabIndex = 163;
            // 
            // lblFinanceRegNoShow
            // 
            this.lblFinanceRegNoShow.AutoSize = true;
            this.lblFinanceRegNoShow.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceRegNoShow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceRegNoShow.Location = new System.Drawing.Point(116, 5);
            this.lblFinanceRegNoShow.Name = "lblFinanceRegNoShow";
            this.lblFinanceRegNoShow.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceRegNoShow.TabIndex = 163;
            this.lblFinanceRegNoShow.Text = "-";
            // 
            // lblFinanceRegNo
            // 
            this.lblFinanceRegNo.AutoSize = true;
            this.lblFinanceRegNo.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceRegNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceRegNo.Location = new System.Drawing.Point(3, 5);
            this.lblFinanceRegNo.Name = "lblFinanceRegNo";
            this.lblFinanceRegNo.Size = new System.Drawing.Size(61, 19);
            this.lblFinanceRegNo.TabIndex = 162;
            this.lblFinanceRegNo.Text = "RegNo:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label23.Location = new System.Drawing.Point(3, 25);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(51, 19);
            this.label23.TabIndex = 124;
            this.label23.Text = "Make:";
            // 
            // lblFinanceMake
            // 
            this.lblFinanceMake.AutoSize = true;
            this.lblFinanceMake.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceMake.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceMake.Location = new System.Drawing.Point(116, 28);
            this.lblFinanceMake.Name = "lblFinanceMake";
            this.lblFinanceMake.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceMake.TabIndex = 117;
            this.lblFinanceMake.Text = "-";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label39.Location = new System.Drawing.Point(3, 161);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(87, 19);
            this.label39.TabIndex = 161;
            this.label39.Text = "Body Style:";
            // 
            // lblFinanceModel
            // 
            this.lblFinanceModel.AutoSize = true;
            this.lblFinanceModel.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceModel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceModel.Location = new System.Drawing.Point(116, 48);
            this.lblFinanceModel.Name = "lblFinanceModel";
            this.lblFinanceModel.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceModel.TabIndex = 118;
            this.lblFinanceModel.Text = "-";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label41.Location = new System.Drawing.Point(3, 139);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(66, 19);
            this.label41.TabIndex = 159;
            this.label41.Text = "Interior:";
            // 
            // lblFinanceColour
            // 
            this.lblFinanceColour.AutoSize = true;
            this.lblFinanceColour.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceColour.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceColour.Location = new System.Drawing.Point(116, 69);
            this.lblFinanceColour.Name = "lblFinanceColour";
            this.lblFinanceColour.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceColour.TabIndex = 121;
            this.lblFinanceColour.Text = "-";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label42.Location = new System.Drawing.Point(3, 116);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(106, 19);
            this.label42.TabIndex = 158;
            this.label42.Text = "Transmission:";
            // 
            // lblFinanceMileage
            // 
            this.lblFinanceMileage.AutoSize = true;
            this.lblFinanceMileage.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceMileage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceMileage.Location = new System.Drawing.Point(116, 93);
            this.lblFinanceMileage.Name = "lblFinanceMileage";
            this.lblFinanceMileage.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceMileage.TabIndex = 123;
            this.lblFinanceMileage.Text = "-";
            // 
            // lblFinanceBodyStyle
            // 
            this.lblFinanceBodyStyle.AutoSize = true;
            this.lblFinanceBodyStyle.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceBodyStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceBodyStyle.Location = new System.Drawing.Point(116, 161);
            this.lblFinanceBodyStyle.Name = "lblFinanceBodyStyle";
            this.lblFinanceBodyStyle.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceBodyStyle.TabIndex = 154;
            this.lblFinanceBodyStyle.Text = "-";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label22.Location = new System.Drawing.Point(3, 48);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(57, 19);
            this.label22.TabIndex = 125;
            this.label22.Text = "Model:";
            // 
            // lblFinanceInterior
            // 
            this.lblFinanceInterior.AutoSize = true;
            this.lblFinanceInterior.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceInterior.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceInterior.Location = new System.Drawing.Point(116, 139);
            this.lblFinanceInterior.Name = "lblFinanceInterior";
            this.lblFinanceInterior.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceInterior.TabIndex = 152;
            this.lblFinanceInterior.Text = "-";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label19.Location = new System.Drawing.Point(3, 70);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(59, 19);
            this.label19.TabIndex = 128;
            this.label19.Text = "Colour:";
            // 
            // lblFinanceTransmission
            // 
            this.lblFinanceTransmission.AutoSize = true;
            this.lblFinanceTransmission.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceTransmission.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceTransmission.Location = new System.Drawing.Point(116, 116);
            this.lblFinanceTransmission.Name = "lblFinanceTransmission";
            this.lblFinanceTransmission.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceTransmission.TabIndex = 151;
            this.lblFinanceTransmission.Text = "-";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label17.Location = new System.Drawing.Point(3, 93);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(68, 19);
            this.label17.TabIndex = 130;
            this.label17.Text = "Mileage:";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label15);
            this.panel8.Controls.Add(this.label36);
            this.panel8.Controls.Add(this.label35);
            this.panel8.Controls.Add(this.label34);
            this.panel8.Controls.Add(this.label33);
            this.panel8.Controls.Add(this.label32);
            this.panel8.Controls.Add(this.lblFinanceCustName);
            this.panel8.Controls.Add(this.lblFinanceTelNum);
            this.panel8.Controls.Add(this.lblFinanceCustNo);
            this.panel8.Controls.Add(this.lblFinanceCustEmail);
            this.panel8.Controls.Add(this.lblFinanceCustAddress);
            this.panel8.Controls.Add(this.label20);
            this.panel8.Controls.Add(this.lblFinanceCustTown);
            this.panel8.Controls.Add(this.label21);
            this.panel8.Controls.Add(this.lblFinanceCustCounty);
            this.panel8.Controls.Add(this.lblFinanceCustCreditRating);
            this.panel8.Controls.Add(this.lblFinancePostcode);
            this.panel8.Controls.Add(this.label31);
            this.panel8.Location = new System.Drawing.Point(14, 109);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(258, 193);
            this.panel8.TabIndex = 162;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label15.Location = new System.Drawing.Point(2, 5);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(69, 19);
            this.label15.TabIndex = 147;
            this.label15.Text = "Cust No:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label36.Location = new System.Drawing.Point(3, 25);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(55, 19);
            this.label36.TabIndex = 131;
            this.label36.Text = "Name:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label35.Location = new System.Drawing.Point(3, 48);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(70, 19);
            this.label35.TabIndex = 132;
            this.label35.Text = "Address:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label34.Location = new System.Drawing.Point(3, 70);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(52, 19);
            this.label34.TabIndex = 133;
            this.label34.Text = "Town:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label33.Location = new System.Drawing.Point(3, 91);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(63, 19);
            this.label33.TabIndex = 134;
            this.label33.Text = "County:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label32.Location = new System.Drawing.Point(4, 111);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(77, 19);
            this.label32.TabIndex = 135;
            this.label32.Text = "Postcode:";
            // 
            // lblFinanceCustName
            // 
            this.lblFinanceCustName.AutoSize = true;
            this.lblFinanceCustName.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceCustName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceCustName.Location = new System.Drawing.Point(109, 25);
            this.lblFinanceCustName.Name = "lblFinanceCustName";
            this.lblFinanceCustName.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceCustName.TabIndex = 137;
            this.lblFinanceCustName.Text = "-";
            // 
            // lblFinanceTelNum
            // 
            this.lblFinanceTelNum.AutoSize = true;
            this.lblFinanceTelNum.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceTelNum.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceTelNum.Location = new System.Drawing.Point(109, 172);
            this.lblFinanceTelNum.Name = "lblFinanceTelNum";
            this.lblFinanceTelNum.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceTelNum.TabIndex = 146;
            this.lblFinanceTelNum.Text = "-";
            // 
            // lblFinanceCustNo
            // 
            this.lblFinanceCustNo.AutoSize = true;
            this.lblFinanceCustNo.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceCustNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceCustNo.Location = new System.Drawing.Point(109, 5);
            this.lblFinanceCustNo.Name = "lblFinanceCustNo";
            this.lblFinanceCustNo.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceCustNo.TabIndex = 148;
            this.lblFinanceCustNo.Text = "-";
            // 
            // lblFinanceCustEmail
            // 
            this.lblFinanceCustEmail.AutoSize = true;
            this.lblFinanceCustEmail.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceCustEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceCustEmail.Location = new System.Drawing.Point(109, 150);
            this.lblFinanceCustEmail.Name = "lblFinanceCustEmail";
            this.lblFinanceCustEmail.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceCustEmail.TabIndex = 145;
            this.lblFinanceCustEmail.Text = "-";
            // 
            // lblFinanceCustAddress
            // 
            this.lblFinanceCustAddress.AutoSize = true;
            this.lblFinanceCustAddress.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceCustAddress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceCustAddress.Location = new System.Drawing.Point(109, 48);
            this.lblFinanceCustAddress.Name = "lblFinanceCustAddress";
            this.lblFinanceCustAddress.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceCustAddress.TabIndex = 138;
            this.lblFinanceCustAddress.Text = "-";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label20.Location = new System.Drawing.Point(5, 172);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(69, 19);
            this.label20.TabIndex = 144;
            this.label20.Text = "TelNum:";
            // 
            // lblFinanceCustTown
            // 
            this.lblFinanceCustTown.AutoSize = true;
            this.lblFinanceCustTown.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceCustTown.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceCustTown.Location = new System.Drawing.Point(109, 70);
            this.lblFinanceCustTown.Name = "lblFinanceCustTown";
            this.lblFinanceCustTown.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceCustTown.TabIndex = 139;
            this.lblFinanceCustTown.Text = "-";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label21.Location = new System.Drawing.Point(5, 150);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(51, 19);
            this.label21.TabIndex = 143;
            this.label21.Text = "Email:";
            // 
            // lblFinanceCustCounty
            // 
            this.lblFinanceCustCounty.AutoSize = true;
            this.lblFinanceCustCounty.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceCustCounty.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceCustCounty.Location = new System.Drawing.Point(109, 90);
            this.lblFinanceCustCounty.Name = "lblFinanceCustCounty";
            this.lblFinanceCustCounty.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceCustCounty.TabIndex = 140;
            this.lblFinanceCustCounty.Text = "-";
            // 
            // lblFinanceCustCreditRating
            // 
            this.lblFinanceCustCreditRating.AutoSize = true;
            this.lblFinanceCustCreditRating.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceCustCreditRating.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceCustCreditRating.Location = new System.Drawing.Point(109, 130);
            this.lblFinanceCustCreditRating.Name = "lblFinanceCustCreditRating";
            this.lblFinanceCustCreditRating.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceCustCreditRating.TabIndex = 142;
            this.lblFinanceCustCreditRating.Text = "-";
            // 
            // lblFinancePostcode
            // 
            this.lblFinancePostcode.AutoSize = true;
            this.lblFinancePostcode.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinancePostcode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinancePostcode.Location = new System.Drawing.Point(109, 111);
            this.lblFinancePostcode.Name = "lblFinancePostcode";
            this.lblFinancePostcode.Size = new System.Drawing.Size(15, 19);
            this.lblFinancePostcode.TabIndex = 141;
            this.lblFinancePostcode.Text = "-";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label31.Location = new System.Drawing.Point(4, 130);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(105, 19);
            this.label31.TabIndex = 136;
            this.label31.Text = "Credit Rating:";
            // 
            // lblCarEditHeader
            // 
            this.lblCarEditHeader.AutoSize = true;
            this.lblCarEditHeader.BackColor = System.Drawing.Color.White;
            this.lblCarEditHeader.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarEditHeader.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblCarEditHeader.Location = new System.Drawing.Point(-7, 0);
            this.lblCarEditHeader.Name = "lblCarEditHeader";
            this.lblCarEditHeader.Size = new System.Drawing.Size(145, 45);
            this.lblCarEditHeader.TabIndex = 108;
            this.lblCarEditHeader.Text = "Finance";
            // 
            // lblEditCarEdit
            // 
            this.lblEditCarEdit.AutoSize = true;
            this.lblEditCarEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold);
            this.lblEditCarEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblEditCarEdit.Location = new System.Drawing.Point(79, 400);
            this.lblEditCarEdit.Name = "lblEditCarEdit";
            this.lblEditCarEdit.Size = new System.Drawing.Size(65, 21);
            this.lblEditCarEdit.TabIndex = 56;
            this.lblEditCarEdit.Text = "Submit";
            // 
            // tabDisplayFinance
            // 
            this.tabDisplayFinance.Controls.Add(this.dgvFinanceAgreements);
            this.tabDisplayFinance.Location = new System.Drawing.Point(4, 22);
            this.tabDisplayFinance.Name = "tabDisplayFinance";
            this.tabDisplayFinance.Size = new System.Drawing.Size(857, 452);
            this.tabDisplayFinance.TabIndex = 5;
            this.tabDisplayFinance.Text = "Display Finance";
            this.tabDisplayFinance.UseVisualStyleBackColor = true;
            // 
            // dgvFinanceAgreements
            // 
            this.dgvFinanceAgreements.AllowUserToAddRows = false;
            this.dgvFinanceAgreements.AllowUserToDeleteRows = false;
            this.dgvFinanceAgreements.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFinanceAgreements.Location = new System.Drawing.Point(19, 24);
            this.dgvFinanceAgreements.Name = "dgvFinanceAgreements";
            this.dgvFinanceAgreements.ReadOnly = true;
            this.dgvFinanceAgreements.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvFinanceAgreements.Size = new System.Drawing.Size(813, 411);
            this.dgvFinanceAgreements.TabIndex = 1;
            this.dgvFinanceAgreements.SelectionChanged += new System.EventHandler(this.dgvFinanceAgreements_SelectionChanged);
            // 
            // tabSalesFinanceEdit
            // 
            this.tabSalesFinanceEdit.Controls.Add(this.txtFinanceDepositEdit);
            this.tabSalesFinanceEdit.Controls.Add(this.label88);
            this.tabSalesFinanceEdit.Controls.Add(this.lblFinanceInterestDueEdit);
            this.tabSalesFinanceEdit.Controls.Add(this.label24);
            this.tabSalesFinanceEdit.Controls.Add(this.lblFinanceTotalInterestEdit);
            this.tabSalesFinanceEdit.Controls.Add(this.label26);
            this.tabSalesFinanceEdit.Controls.Add(this.lblFinanceInterestRateEdit);
            this.tabSalesFinanceEdit.Controls.Add(this.label28);
            this.tabSalesFinanceEdit.Controls.Add(this.lblFinanceMonthlyPaymentEdit);
            this.tabSalesFinanceEdit.Controls.Add(this.label30);
            this.tabSalesFinanceEdit.Controls.Add(this.lblFinanceNumPaymentsEdit);
            this.tabSalesFinanceEdit.Controls.Add(this.label38);
            this.tabSalesFinanceEdit.Controls.Add(this.lblFinanceAgreementDateEdit);
            this.tabSalesFinanceEdit.Controls.Add(this.label43);
            this.tabSalesFinanceEdit.Controls.Add(this.lblFinanceFinanceIDEdit);
            this.tabSalesFinanceEdit.Controls.Add(this.label45);
            this.tabSalesFinanceEdit.Controls.Add(this.lblFinanceTotalNoInterestEdit);
            this.tabSalesFinanceEdit.Controls.Add(this.label47);
            this.tabSalesFinanceEdit.Controls.Add(this.lblFinanceTradeInEdit);
            this.tabSalesFinanceEdit.Controls.Add(this.label49);
            this.tabSalesFinanceEdit.Controls.Add(this.label51);
            this.tabSalesFinanceEdit.Controls.Add(this.cmbFinancePlanLengthEdit);
            this.tabSalesFinanceEdit.Controls.Add(this.label52);
            this.tabSalesFinanceEdit.Controls.Add(this.panel10);
            this.tabSalesFinanceEdit.Controls.Add(this.panel11);
            this.tabSalesFinanceEdit.Controls.Add(this.lblEditFinanceEdit);
            this.tabSalesFinanceEdit.Controls.Add(btnEditFinanceEdit);
            this.tabSalesFinanceEdit.Location = new System.Drawing.Point(4, 22);
            this.tabSalesFinanceEdit.Name = "tabSalesFinanceEdit";
            this.tabSalesFinanceEdit.Size = new System.Drawing.Size(857, 452);
            this.tabSalesFinanceEdit.TabIndex = 3;
            this.tabSalesFinanceEdit.Text = "Manage Finance";
            this.tabSalesFinanceEdit.UseVisualStyleBackColor = true;
            // 
            // txtFinanceDepositEdit
            // 
            this.txtFinanceDepositEdit.Enabled = false;
            this.txtFinanceDepositEdit.Location = new System.Drawing.Point(672, 136);
            this.txtFinanceDepositEdit.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.txtFinanceDepositEdit.Name = "txtFinanceDepositEdit";
            this.txtFinanceDepositEdit.Size = new System.Drawing.Size(115, 20);
            this.txtFinanceDepositEdit.TabIndex = 226;
            this.txtFinanceDepositEdit.ValueChanged += new System.EventHandler(this.txtFinanceDepositEdit_ValueChanged);
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.BackColor = System.Drawing.Color.White;
            this.label88.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label88.Location = new System.Drawing.Point(3, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(289, 45);
            this.label88.TabIndex = 225;
            this.label88.Text = "Manage Finance";
            // 
            // lblFinanceInterestDueEdit
            // 
            this.lblFinanceInterestDueEdit.AutoSize = true;
            this.lblFinanceInterestDueEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceInterestDueEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceInterestDueEdit.Location = new System.Drawing.Point(762, 342);
            this.lblFinanceInterestDueEdit.Name = "lblFinanceInterestDueEdit";
            this.lblFinanceInterestDueEdit.Size = new System.Drawing.Size(16, 21);
            this.lblFinanceInterestDueEdit.TabIndex = 224;
            this.lblFinanceInterestDueEdit.Text = "-";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label24.Location = new System.Drawing.Point(561, 342);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(150, 21);
            this.label24.TabIndex = 223;
            this.label24.Text = "Total Interest Due:";
            // 
            // lblFinanceTotalInterestEdit
            // 
            this.lblFinanceTotalInterestEdit.AutoSize = true;
            this.lblFinanceTotalInterestEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceTotalInterestEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceTotalInterestEdit.Location = new System.Drawing.Point(762, 300);
            this.lblFinanceTotalInterestEdit.Name = "lblFinanceTotalInterestEdit";
            this.lblFinanceTotalInterestEdit.Size = new System.Drawing.Size(16, 21);
            this.lblFinanceTotalInterestEdit.TabIndex = 222;
            this.lblFinanceTotalInterestEdit.Text = "-";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label26.Location = new System.Drawing.Point(561, 300);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(168, 21);
            this.label26.TabIndex = 221;
            this.label26.Text = "Total (With Interest):";
            // 
            // lblFinanceInterestRateEdit
            // 
            this.lblFinanceInterestRateEdit.AutoSize = true;
            this.lblFinanceInterestRateEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceInterestRateEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceInterestRateEdit.Location = new System.Drawing.Point(702, 240);
            this.lblFinanceInterestRateEdit.Name = "lblFinanceInterestRateEdit";
            this.lblFinanceInterestRateEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceInterestRateEdit.TabIndex = 220;
            this.lblFinanceInterestRateEdit.Text = "-";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label28.Location = new System.Drawing.Point(565, 240);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(104, 19);
            this.label28.TabIndex = 219;
            this.label28.Text = "Interest Rate:";
            // 
            // lblFinanceMonthlyPaymentEdit
            // 
            this.lblFinanceMonthlyPaymentEdit.AutoSize = true;
            this.lblFinanceMonthlyPaymentEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceMonthlyPaymentEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceMonthlyPaymentEdit.Location = new System.Drawing.Point(742, 392);
            this.lblFinanceMonthlyPaymentEdit.Name = "lblFinanceMonthlyPaymentEdit";
            this.lblFinanceMonthlyPaymentEdit.Size = new System.Drawing.Size(18, 23);
            this.lblFinanceMonthlyPaymentEdit.TabIndex = 218;
            this.lblFinanceMonthlyPaymentEdit.Text = "-";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label30.Location = new System.Drawing.Point(563, 390);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(173, 23);
            this.label30.TabIndex = 217;
            this.label30.Text = "Monthly Payment:";
            // 
            // lblFinanceNumPaymentsEdit
            // 
            this.lblFinanceNumPaymentsEdit.AutoSize = true;
            this.lblFinanceNumPaymentsEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceNumPaymentsEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceNumPaymentsEdit.Location = new System.Drawing.Point(702, 261);
            this.lblFinanceNumPaymentsEdit.Name = "lblFinanceNumPaymentsEdit";
            this.lblFinanceNumPaymentsEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceNumPaymentsEdit.TabIndex = 216;
            this.lblFinanceNumPaymentsEdit.Text = "-";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label38.Location = new System.Drawing.Point(565, 261);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(128, 19);
            this.label38.TabIndex = 215;
            this.label38.Text = "No Of Payments:";
            // 
            // lblFinanceAgreementDateEdit
            // 
            this.lblFinanceAgreementDateEdit.AutoSize = true;
            this.lblFinanceAgreementDateEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceAgreementDateEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceAgreementDateEdit.Location = new System.Drawing.Point(702, 203);
            this.lblFinanceAgreementDateEdit.Name = "lblFinanceAgreementDateEdit";
            this.lblFinanceAgreementDateEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceAgreementDateEdit.TabIndex = 214;
            this.lblFinanceAgreementDateEdit.Text = "-";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label43.Location = new System.Drawing.Point(564, 203);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(129, 19);
            this.label43.TabIndex = 213;
            this.label43.Text = "Agreement Date:";
            // 
            // lblFinanceFinanceIDEdit
            // 
            this.lblFinanceFinanceIDEdit.AutoSize = true;
            this.lblFinanceFinanceIDEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceFinanceIDEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceFinanceIDEdit.Location = new System.Drawing.Point(702, 184);
            this.lblFinanceFinanceIDEdit.Name = "lblFinanceFinanceIDEdit";
            this.lblFinanceFinanceIDEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceFinanceIDEdit.TabIndex = 212;
            this.lblFinanceFinanceIDEdit.Text = "-";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label45.Location = new System.Drawing.Point(565, 180);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(86, 19);
            this.label45.TabIndex = 211;
            this.label45.Text = "Finance ID:";
            // 
            // lblFinanceTotalNoInterestEdit
            // 
            this.lblFinanceTotalNoInterestEdit.AutoSize = true;
            this.lblFinanceTotalNoInterestEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceTotalNoInterestEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceTotalNoInterestEdit.Location = new System.Drawing.Point(762, 321);
            this.lblFinanceTotalNoInterestEdit.Name = "lblFinanceTotalNoInterestEdit";
            this.lblFinanceTotalNoInterestEdit.Size = new System.Drawing.Size(16, 21);
            this.lblFinanceTotalNoInterestEdit.TabIndex = 210;
            this.lblFinanceTotalNoInterestEdit.Text = "-";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label47.Location = new System.Drawing.Point(561, 321);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(194, 21);
            this.label47.TabIndex = 209;
            this.label47.Text = "Total (Without Interest):";
            // 
            // lblFinanceTradeInEdit
            // 
            this.lblFinanceTradeInEdit.AutoSize = true;
            this.lblFinanceTradeInEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceTradeInEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceTradeInEdit.Location = new System.Drawing.Point(702, 157);
            this.lblFinanceTradeInEdit.Name = "lblFinanceTradeInEdit";
            this.lblFinanceTradeInEdit.Size = new System.Drawing.Size(16, 21);
            this.lblFinanceTradeInEdit.TabIndex = 208;
            this.lblFinanceTradeInEdit.Text = "-";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label49.Location = new System.Drawing.Point(563, 157);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(124, 21);
            this.label49.TabIndex = 207;
            this.label49.Text = "Trade In Value:";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label51.Location = new System.Drawing.Point(563, 132);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(73, 21);
            this.label51.TabIndex = 205;
            this.label51.Text = "Deposit:";
            // 
            // cmbFinancePlanLengthEdit
            // 
            this.cmbFinancePlanLengthEdit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFinancePlanLengthEdit.Enabled = false;
            this.cmbFinancePlanLengthEdit.FormattingEnabled = true;
            this.cmbFinancePlanLengthEdit.Items.AddRange(new object[] {
            "12 Months",
            "24 Months",
            "36 Months",
            "48 Months",
            "60 Months"});
            this.cmbFinancePlanLengthEdit.Location = new System.Drawing.Point(672, 109);
            this.cmbFinancePlanLengthEdit.Name = "cmbFinancePlanLengthEdit";
            this.cmbFinancePlanLengthEdit.Size = new System.Drawing.Size(115, 21);
            this.cmbFinancePlanLengthEdit.TabIndex = 204;
            this.cmbFinancePlanLengthEdit.SelectedIndexChanged += new System.EventHandler(this.cmbFinancePlanLengthEdit_SelectedIndexChanged_1);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label52.Location = new System.Drawing.Point(561, 109);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(105, 21);
            this.label52.TabIndex = 203;
            this.label52.Text = "Plan Length:";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.lblFinancePriceEdit);
            this.panel10.Controls.Add(this.lblFinancePriceEdit2);
            this.panel10.Controls.Add(this.lblFinanceRegNoEdit);
            this.panel10.Controls.Add(this.label54);
            this.panel10.Controls.Add(this.label55);
            this.panel10.Controls.Add(this.lblFinanceMakeEdit);
            this.panel10.Controls.Add(this.label57);
            this.panel10.Controls.Add(this.lblFinanceModelEdit);
            this.panel10.Controls.Add(this.label59);
            this.panel10.Controls.Add(this.lblFinanceColourEdit);
            this.panel10.Controls.Add(this.label61);
            this.panel10.Controls.Add(this.lblFinanceMileageEdit);
            this.panel10.Controls.Add(this.lblFinanceBodyEdit);
            this.panel10.Controls.Add(this.label64);
            this.panel10.Controls.Add(this.lblFinanceInteriorEdit);
            this.panel10.Controls.Add(this.label66);
            this.panel10.Controls.Add(this.lblFinanceTransmissionEdit);
            this.panel10.Controls.Add(this.label68);
            this.panel10.Location = new System.Drawing.Point(294, 109);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(226, 200);
            this.panel10.TabIndex = 202;
            // 
            // lblFinancePriceEdit
            // 
            this.lblFinancePriceEdit.AutoSize = true;
            this.lblFinancePriceEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinancePriceEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinancePriceEdit.Location = new System.Drawing.Point(116, 181);
            this.lblFinancePriceEdit.Name = "lblFinancePriceEdit";
            this.lblFinancePriceEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinancePriceEdit.TabIndex = 165;
            this.lblFinancePriceEdit.Text = "-";
            // 
            // lblFinancePriceEdit2
            // 
            this.lblFinancePriceEdit2.AutoSize = true;
            this.lblFinancePriceEdit2.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinancePriceEdit2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinancePriceEdit2.Location = new System.Drawing.Point(3, 181);
            this.lblFinancePriceEdit2.Name = "lblFinancePriceEdit2";
            this.lblFinancePriceEdit2.Size = new System.Drawing.Size(47, 19);
            this.lblFinancePriceEdit2.TabIndex = 164;
            this.lblFinancePriceEdit2.Text = "Price:";
            // 
            // lblFinanceRegNoEdit
            // 
            this.lblFinanceRegNoEdit.AutoSize = true;
            this.lblFinanceRegNoEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceRegNoEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceRegNoEdit.Location = new System.Drawing.Point(116, 5);
            this.lblFinanceRegNoEdit.Name = "lblFinanceRegNoEdit";
            this.lblFinanceRegNoEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceRegNoEdit.TabIndex = 163;
            this.lblFinanceRegNoEdit.Text = "-";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label54.Location = new System.Drawing.Point(3, 5);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(61, 19);
            this.label54.TabIndex = 162;
            this.label54.Text = "RegNo:";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label55.Location = new System.Drawing.Point(3, 25);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(51, 19);
            this.label55.TabIndex = 124;
            this.label55.Text = "Make:";
            // 
            // lblFinanceMakeEdit
            // 
            this.lblFinanceMakeEdit.AutoSize = true;
            this.lblFinanceMakeEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceMakeEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceMakeEdit.Location = new System.Drawing.Point(116, 28);
            this.lblFinanceMakeEdit.Name = "lblFinanceMakeEdit";
            this.lblFinanceMakeEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceMakeEdit.TabIndex = 117;
            this.lblFinanceMakeEdit.Text = "-";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label57.Location = new System.Drawing.Point(3, 161);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(87, 19);
            this.label57.TabIndex = 161;
            this.label57.Text = "Body Style:";
            // 
            // lblFinanceModelEdit
            // 
            this.lblFinanceModelEdit.AutoSize = true;
            this.lblFinanceModelEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceModelEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceModelEdit.Location = new System.Drawing.Point(116, 48);
            this.lblFinanceModelEdit.Name = "lblFinanceModelEdit";
            this.lblFinanceModelEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceModelEdit.TabIndex = 118;
            this.lblFinanceModelEdit.Text = "-";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label59.Location = new System.Drawing.Point(3, 139);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(66, 19);
            this.label59.TabIndex = 159;
            this.label59.Text = "Interior:";
            // 
            // lblFinanceColourEdit
            // 
            this.lblFinanceColourEdit.AutoSize = true;
            this.lblFinanceColourEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceColourEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceColourEdit.Location = new System.Drawing.Point(116, 69);
            this.lblFinanceColourEdit.Name = "lblFinanceColourEdit";
            this.lblFinanceColourEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceColourEdit.TabIndex = 121;
            this.lblFinanceColourEdit.Text = "-";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label61.Location = new System.Drawing.Point(3, 116);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(106, 19);
            this.label61.TabIndex = 158;
            this.label61.Text = "Transmission:";
            // 
            // lblFinanceMileageEdit
            // 
            this.lblFinanceMileageEdit.AutoSize = true;
            this.lblFinanceMileageEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceMileageEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceMileageEdit.Location = new System.Drawing.Point(116, 93);
            this.lblFinanceMileageEdit.Name = "lblFinanceMileageEdit";
            this.lblFinanceMileageEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceMileageEdit.TabIndex = 123;
            this.lblFinanceMileageEdit.Text = "-";
            // 
            // lblFinanceBodyEdit
            // 
            this.lblFinanceBodyEdit.AutoSize = true;
            this.lblFinanceBodyEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceBodyEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceBodyEdit.Location = new System.Drawing.Point(116, 161);
            this.lblFinanceBodyEdit.Name = "lblFinanceBodyEdit";
            this.lblFinanceBodyEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceBodyEdit.TabIndex = 154;
            this.lblFinanceBodyEdit.Text = "-";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label64.Location = new System.Drawing.Point(3, 48);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(57, 19);
            this.label64.TabIndex = 125;
            this.label64.Text = "Model:";
            // 
            // lblFinanceInteriorEdit
            // 
            this.lblFinanceInteriorEdit.AutoSize = true;
            this.lblFinanceInteriorEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceInteriorEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceInteriorEdit.Location = new System.Drawing.Point(116, 139);
            this.lblFinanceInteriorEdit.Name = "lblFinanceInteriorEdit";
            this.lblFinanceInteriorEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceInteriorEdit.TabIndex = 152;
            this.lblFinanceInteriorEdit.Text = "-";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label66.Location = new System.Drawing.Point(3, 70);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(59, 19);
            this.label66.TabIndex = 128;
            this.label66.Text = "Colour:";
            // 
            // lblFinanceTransmissionEdit
            // 
            this.lblFinanceTransmissionEdit.AutoSize = true;
            this.lblFinanceTransmissionEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceTransmissionEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceTransmissionEdit.Location = new System.Drawing.Point(116, 116);
            this.lblFinanceTransmissionEdit.Name = "lblFinanceTransmissionEdit";
            this.lblFinanceTransmissionEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceTransmissionEdit.TabIndex = 151;
            this.lblFinanceTransmissionEdit.Text = "-";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label68.Location = new System.Drawing.Point(3, 93);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(68, 19);
            this.label68.TabIndex = 130;
            this.label68.Text = "Mileage:";
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.label69);
            this.panel11.Controls.Add(this.label70);
            this.panel11.Controls.Add(this.label71);
            this.panel11.Controls.Add(this.label72);
            this.panel11.Controls.Add(this.label73);
            this.panel11.Controls.Add(this.label74);
            this.panel11.Controls.Add(this.lblFinanceCustNameEdit);
            this.panel11.Controls.Add(this.lblFinanceTelNumEdit);
            this.panel11.Controls.Add(this.lblFinanceCustNoEdit);
            this.panel11.Controls.Add(this.lblFinanceCustEmailEdit);
            this.panel11.Controls.Add(this.lblFinanceCustAddressEdit);
            this.panel11.Controls.Add(this.label80);
            this.panel11.Controls.Add(this.lblFinanceCustTownEdit);
            this.panel11.Controls.Add(this.label82);
            this.panel11.Controls.Add(this.lblFinanceCustCountyEdit);
            this.panel11.Controls.Add(this.lblFinanceCustCreditEdit);
            this.panel11.Controls.Add(this.lblFinanceCustPostcodeEdit);
            this.panel11.Controls.Add(this.label86);
            this.panel11.Location = new System.Drawing.Point(14, 109);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(258, 200);
            this.panel11.TabIndex = 201;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label69.Location = new System.Drawing.Point(2, 5);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(69, 19);
            this.label69.TabIndex = 147;
            this.label69.Text = "Cust No:";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label70.Location = new System.Drawing.Point(3, 25);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(55, 19);
            this.label70.TabIndex = 131;
            this.label70.Text = "Name:";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label71.Location = new System.Drawing.Point(3, 48);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(70, 19);
            this.label71.TabIndex = 132;
            this.label71.Text = "Address:";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label72.Location = new System.Drawing.Point(3, 70);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(52, 19);
            this.label72.TabIndex = 133;
            this.label72.Text = "Town:";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label73.Location = new System.Drawing.Point(3, 91);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(63, 19);
            this.label73.TabIndex = 134;
            this.label73.Text = "County:";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label74.Location = new System.Drawing.Point(4, 111);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(77, 19);
            this.label74.TabIndex = 135;
            this.label74.Text = "Postcode:";
            // 
            // lblFinanceCustNameEdit
            // 
            this.lblFinanceCustNameEdit.AutoSize = true;
            this.lblFinanceCustNameEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceCustNameEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceCustNameEdit.Location = new System.Drawing.Point(109, 25);
            this.lblFinanceCustNameEdit.Name = "lblFinanceCustNameEdit";
            this.lblFinanceCustNameEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceCustNameEdit.TabIndex = 137;
            this.lblFinanceCustNameEdit.Text = "-";
            // 
            // lblFinanceTelNumEdit
            // 
            this.lblFinanceTelNumEdit.AutoSize = true;
            this.lblFinanceTelNumEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceTelNumEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceTelNumEdit.Location = new System.Drawing.Point(109, 172);
            this.lblFinanceTelNumEdit.Name = "lblFinanceTelNumEdit";
            this.lblFinanceTelNumEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceTelNumEdit.TabIndex = 146;
            this.lblFinanceTelNumEdit.Text = "-";
            // 
            // lblFinanceCustNoEdit
            // 
            this.lblFinanceCustNoEdit.AutoSize = true;
            this.lblFinanceCustNoEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceCustNoEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceCustNoEdit.Location = new System.Drawing.Point(109, 5);
            this.lblFinanceCustNoEdit.Name = "lblFinanceCustNoEdit";
            this.lblFinanceCustNoEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceCustNoEdit.TabIndex = 148;
            this.lblFinanceCustNoEdit.Text = "-";
            // 
            // lblFinanceCustEmailEdit
            // 
            this.lblFinanceCustEmailEdit.AutoSize = true;
            this.lblFinanceCustEmailEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceCustEmailEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceCustEmailEdit.Location = new System.Drawing.Point(109, 150);
            this.lblFinanceCustEmailEdit.Name = "lblFinanceCustEmailEdit";
            this.lblFinanceCustEmailEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceCustEmailEdit.TabIndex = 145;
            this.lblFinanceCustEmailEdit.Text = "-";
            // 
            // lblFinanceCustAddressEdit
            // 
            this.lblFinanceCustAddressEdit.AutoSize = true;
            this.lblFinanceCustAddressEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceCustAddressEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceCustAddressEdit.Location = new System.Drawing.Point(109, 48);
            this.lblFinanceCustAddressEdit.Name = "lblFinanceCustAddressEdit";
            this.lblFinanceCustAddressEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceCustAddressEdit.TabIndex = 138;
            this.lblFinanceCustAddressEdit.Text = "-";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label80.Location = new System.Drawing.Point(5, 172);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(69, 19);
            this.label80.TabIndex = 144;
            this.label80.Text = "TelNum:";
            // 
            // lblFinanceCustTownEdit
            // 
            this.lblFinanceCustTownEdit.AutoSize = true;
            this.lblFinanceCustTownEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceCustTownEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceCustTownEdit.Location = new System.Drawing.Point(109, 70);
            this.lblFinanceCustTownEdit.Name = "lblFinanceCustTownEdit";
            this.lblFinanceCustTownEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceCustTownEdit.TabIndex = 139;
            this.lblFinanceCustTownEdit.Text = "-";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label82.Location = new System.Drawing.Point(5, 150);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(51, 19);
            this.label82.TabIndex = 143;
            this.label82.Text = "Email:";
            // 
            // lblFinanceCustCountyEdit
            // 
            this.lblFinanceCustCountyEdit.AutoSize = true;
            this.lblFinanceCustCountyEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceCustCountyEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceCustCountyEdit.Location = new System.Drawing.Point(109, 90);
            this.lblFinanceCustCountyEdit.Name = "lblFinanceCustCountyEdit";
            this.lblFinanceCustCountyEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceCustCountyEdit.TabIndex = 140;
            this.lblFinanceCustCountyEdit.Text = "-";
            // 
            // lblFinanceCustCreditEdit
            // 
            this.lblFinanceCustCreditEdit.AutoSize = true;
            this.lblFinanceCustCreditEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceCustCreditEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceCustCreditEdit.Location = new System.Drawing.Point(109, 130);
            this.lblFinanceCustCreditEdit.Name = "lblFinanceCustCreditEdit";
            this.lblFinanceCustCreditEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceCustCreditEdit.TabIndex = 142;
            this.lblFinanceCustCreditEdit.Text = "-";
            // 
            // lblFinanceCustPostcodeEdit
            // 
            this.lblFinanceCustPostcodeEdit.AutoSize = true;
            this.lblFinanceCustPostcodeEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinanceCustPostcodeEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblFinanceCustPostcodeEdit.Location = new System.Drawing.Point(109, 111);
            this.lblFinanceCustPostcodeEdit.Name = "lblFinanceCustPostcodeEdit";
            this.lblFinanceCustPostcodeEdit.Size = new System.Drawing.Size(15, 19);
            this.lblFinanceCustPostcodeEdit.TabIndex = 141;
            this.lblFinanceCustPostcodeEdit.Text = "-";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label86.Location = new System.Drawing.Point(4, 130);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(105, 19);
            this.label86.TabIndex = 136;
            this.label86.Text = "Credit Rating:";
            // 
            // lblEditFinanceEdit
            // 
            this.lblEditFinanceEdit.AutoSize = true;
            this.lblEditFinanceEdit.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold);
            this.lblEditFinanceEdit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblEditFinanceEdit.Location = new System.Drawing.Point(69, 406);
            this.lblEditFinanceEdit.Name = "lblEditFinanceEdit";
            this.lblEditFinanceEdit.Size = new System.Drawing.Size(40, 21);
            this.lblEditFinanceEdit.TabIndex = 200;
            this.lblEditFinanceEdit.Text = "Edit";
            // 
            // tabReport
            // 
            this.tabReport.Controls.Add(this.label13);
            this.tabReport.Controls.Add(this.lblSearchOrders);
            this.tabReport.Controls.Add(this.cmbRepOrderSearch);
            this.tabReport.Location = new System.Drawing.Point(4, 22);
            this.tabReport.Name = "tabReport";
            this.tabReport.Size = new System.Drawing.Size(857, 452);
            this.tabReport.TabIndex = 6;
            this.tabReport.Text = "Reports";
            this.tabReport.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label13.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.label13.Location = new System.Drawing.Point(551, 30);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(168, 19);
            this.label13.TabIndex = 163;
            this.label13.Text = "Filter By Customer No:";
            // 
            // lblSearchOrders
            // 
            this.lblSearchOrders.AutoSize = true;
            this.lblSearchOrders.Location = new System.Drawing.Point(626, 36);
            this.lblSearchOrders.Name = "lblSearchOrders";
            this.lblSearchOrders.Size = new System.Drawing.Size(0, 13);
            this.lblSearchOrders.TabIndex = 4;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.White;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(770, 9);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(108, 42);
            this.flowLayoutPanel1.TabIndex = 100;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel5.Location = new System.Drawing.Point(-42, 8);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1000, 2);
            this.panel5.TabIndex = 49;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(-41, 7);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1000, 2);
            this.panel4.TabIndex = 50;
            // 
            // pnlTopMenuBar
            // 
            this.pnlTopMenuBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.pnlTopMenuBar.Controls.Add(this.panel4);
            this.pnlTopMenuBar.Location = new System.Drawing.Point(1, 1);
            this.pnlTopMenuBar.Margin = new System.Windows.Forms.Padding(2);
            this.pnlTopMenuBar.Name = "pnlTopMenuBar";
            this.pnlTopMenuBar.Size = new System.Drawing.Size(1000, 3);
            this.pnlTopMenuBar.TabIndex = 88;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel2.Location = new System.Drawing.Point(-42, 8);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1000, 2);
            this.panel2.TabIndex = 49;
            // 
            // lblCarTitle
            // 
            this.lblCarTitle.AutoSize = true;
            this.lblCarTitle.BackColor = System.Drawing.Color.White;
            this.lblCarTitle.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblCarTitle.Location = new System.Drawing.Point(885, 7);
            this.lblCarTitle.Name = "lblCarTitle";
            this.lblCarTitle.Size = new System.Drawing.Size(87, 45);
            this.lblCarTitle.TabIndex = 93;
            this.lblCarTitle.Text = "Cars";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(-12, 56);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1000, 2);
            this.panel1.TabIndex = 90;
            // 
            // errP
            // 
            this.errP.ContainerControl = this;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel6.Location = new System.Drawing.Point(0, 1);
            this.panel6.Margin = new System.Windows.Forms.Padding(2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1000, 2);
            this.panel6.TabIndex = 92;
            // 
            // btnSalesEdit
            // 
            this.btnSalesEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSalesEdit.BackgroundImage")));
            this.btnSalesEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSalesEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalesEdit.Location = new System.Drawing.Point(9, 186);
            this.btnSalesEdit.Margin = new System.Windows.Forms.Padding(2);
            this.btnSalesEdit.Name = "btnSalesEdit";
            this.btnSalesEdit.Size = new System.Drawing.Size(75, 75);
            this.btnSalesEdit.TabIndex = 96;
            this.btnSalesEdit.UseVisualStyleBackColor = true;
            this.btnSalesEdit.Click += new System.EventHandler(this.btnCarEdit_Click);
            // 
            // btnSalesDelete
            // 
            this.btnSalesDelete.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSalesDelete.BackgroundImage")));
            this.btnSalesDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSalesDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalesDelete.Location = new System.Drawing.Point(9, 276);
            this.btnSalesDelete.Margin = new System.Windows.Forms.Padding(2);
            this.btnSalesDelete.Name = "btnSalesDelete";
            this.btnSalesDelete.Size = new System.Drawing.Size(75, 75);
            this.btnSalesDelete.TabIndex = 95;
            this.btnSalesDelete.UseVisualStyleBackColor = true;
            this.btnSalesDelete.Click += new System.EventHandler(this.btnSalesDelete_Click);
            // 
            // btnSalesAdd
            // 
            this.btnSalesAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSalesAdd.BackgroundImage")));
            this.btnSalesAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSalesAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalesAdd.Location = new System.Drawing.Point(9, 96);
            this.btnSalesAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btnSalesAdd.Name = "btnSalesAdd";
            this.btnSalesAdd.Size = new System.Drawing.Size(75, 75);
            this.btnSalesAdd.TabIndex = 97;
            this.btnSalesAdd.UseVisualStyleBackColor = true;
            // 
            // btnSalesHome
            // 
            this.btnSalesHome.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSalesHome.BackgroundImage")));
            this.btnSalesHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSalesHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalesHome.Location = new System.Drawing.Point(9, 366);
            this.btnSalesHome.Margin = new System.Windows.Forms.Padding(2);
            this.btnSalesHome.Name = "btnSalesHome";
            this.btnSalesHome.Size = new System.Drawing.Size(75, 75);
            this.btnSalesHome.TabIndex = 99;
            this.btnSalesHome.UseVisualStyleBackColor = true;
            this.btnSalesHome.Click += new System.EventHandler(this.btnCarHome_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(-103, -2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1089, 55);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 89;
            this.pictureBox1.TabStop = false;
            // 
            // btnSalesExit
            // 
            this.btnSalesExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSalesExit.BackgroundImage")));
            this.btnSalesExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSalesExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalesExit.Location = new System.Drawing.Point(9, 456);
            this.btnSalesExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnSalesExit.Name = "btnSalesExit";
            this.btnSalesExit.Size = new System.Drawing.Size(75, 75);
            this.btnSalesExit.TabIndex = 98;
            this.btnSalesExit.UseVisualStyleBackColor = true;
            // 
            // lblSalesTitle
            // 
            this.lblSalesTitle.AutoSize = true;
            this.lblSalesTitle.BackColor = System.Drawing.Color.White;
            this.lblSalesTitle.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalesTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblSalesTitle.Location = new System.Drawing.Point(888, 7);
            this.lblSalesTitle.Name = "lblSalesTitle";
            this.lblSalesTitle.Size = new System.Drawing.Size(98, 45);
            this.lblSalesTitle.TabIndex = 101;
            this.lblSalesTitle.Text = "Sales";
            // 
            // frmSales
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.lblSalesTitle);
            this.Controls.Add(this.btnSalesEdit);
            this.Controls.Add(this.btnSalesDelete);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.tabSales);
            this.Controls.Add(this.btnSalesAdd);
            this.Controls.Add(this.btnSalesHome);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.pnlTopMenuBar);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblCarTitle);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnSalesExit);
            this.Controls.Add(this.panel6);
            this.Name = "frmSales";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Desmond Motors | Sales Management System | © PLAB Software Solutions 2020";
            this.Activated += new System.EventHandler(this.frmSales_Activated);
            this.Load += new System.EventHandler(this.frmSales_Load);
            this.Shown += new System.EventHandler(this.frmSales_Shown);
            this.tabSales.ResumeLayout(false);
            this.tabSalesDisplay.ResumeLayout(false);
            this.tabSalesDisplay.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrders)).EndInit();
            this.tabSalesAdd.ResumeLayout(false);
            this.tabSalesAdd.PerformLayout();
            this.pnlButtons.ResumeLayout(false);
            this.pnlListBoxes.ResumeLayout(false);
            this.pnlListBoxes.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSaleDeposit)).EndInit();
            this.pnlSaleCarDetails.ResumeLayout(false);
            this.pnlSaleCarDetails.PerformLayout();
            this.pnlSaleCustDetails.ResumeLayout(false);
            this.pnlSaleCustDetails.PerformLayout();
            this.tabSalesFinance.ResumeLayout(false);
            this.tabSalesFinance.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.tabDisplayFinance.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFinanceAgreements)).EndInit();
            this.tabSalesFinanceEdit.ResumeLayout(false);
            this.tabSalesFinanceEdit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtFinanceDepositEdit)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.tabReport.ResumeLayout(false);
            this.tabReport.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.pnlTopMenuBar.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnSalesEdit;
        private System.Windows.Forms.Button btnSalesDelete;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TabControl tabSales;
        private System.Windows.Forms.TabPage tabSalesAdd;
        private System.Windows.Forms.Label lblAddCarReset;
        private System.Windows.Forms.Button btnAddSaleReset;
        private System.Windows.Forms.Label lblAddSaleAdd;
        private System.Windows.Forms.Button btnAddSaleAdd;
        private System.Windows.Forms.Label lblCarAddHeader;
        private System.Windows.Forms.TabPage tabSalesFinance;
        private System.Windows.Forms.Label lblCarEditHeader;
        private System.Windows.Forms.Label lblEditCarEdit;
        private System.Windows.Forms.Button btnSalesAdd;
        private System.Windows.Forms.Button btnSalesHome;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel pnlTopMenuBar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblCarTitle;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSalesExit;
        private System.Windows.Forms.ErrorProvider errP;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lblSalesTitle;
        private System.Windows.Forms.Panel pnlSaleCarDetails;
        private System.Windows.Forms.Panel pnlSaleCustDetails;
        private System.Windows.Forms.Label lblSaleCustName;
        private System.Windows.Forms.Label lblSaleCustDetailsTitle;
        private System.Windows.Forms.Label lblSaleCustAddress;
        private System.Windows.Forms.Label lblSaleCustTown;
        private System.Windows.Forms.Label lblSaleCustPostcode;
        private System.Windows.Forms.Label lblSaleCustCounty;
        private System.Windows.Forms.Label lblSaleCarDetailsTitle;
        private System.Windows.Forms.Label lblSaleCustCreditRating;
        private System.Windows.Forms.Label lblSaleCustCreditRatingShow;
        private System.Windows.Forms.Label lblSaleCustPostcodeShow;
        private System.Windows.Forms.Label lblSaleCustCountyShow;
        private System.Windows.Forms.Label lblSaleCustTownShow;
        private System.Windows.Forms.Label lblSaleCustAddressShow;
        private System.Windows.Forms.Label lblSaleCustNameShow;
        private System.Windows.Forms.Label lblSaleCarMileageShow;
        private System.Windows.Forms.Label lblSaleCarBodyShow;
        private System.Windows.Forms.Label lblSaleCarColourShow;
        private System.Windows.Forms.Label lblSaleCarInteriorShow;
        private System.Windows.Forms.Label lblSaleCarTransmissionShow;
        private System.Windows.Forms.Label lblSaleCarModelShow;
        private System.Windows.Forms.Label lblSaleCarMakeShow;
        private System.Windows.Forms.Label lblSaleCustTelNum;
        private System.Windows.Forms.Label lblSaleCustEmail;
        private System.Windows.Forms.TabPage tabSalesFinanceEdit;
        private System.Windows.Forms.Panel pnlListBoxes;
        private System.Windows.Forms.Label lblListCar;
        private System.Windows.Forms.Label lblListCustomer;
        private System.Windows.Forms.Button btnP;
        private System.Windows.Forms.Button btnO;
        private System.Windows.Forms.Button btnN;
        private System.Windows.Forms.Button btnM;
        private System.Windows.Forms.Button btnL;
        private System.Windows.Forms.Button btnK;
        private System.Windows.Forms.Button btnJ;
        private System.Windows.Forms.Button btnI;
        private System.Windows.Forms.Button btnH;
        private System.Windows.Forms.Button btnG;
        private System.Windows.Forms.Button btnF;
        private System.Windows.Forms.Button btnE;
        private System.Windows.Forms.Button btnD;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Button btnB;
        private System.Windows.Forms.Button btnA;
        private System.Windows.Forms.Button btnZ;
        private System.Windows.Forms.Button btnY;
        private System.Windows.Forms.Button btnX;
        private System.Windows.Forms.Button btnW;
        private System.Windows.Forms.Button btnV;
        private System.Windows.Forms.Button btnU;
        private System.Windows.Forms.Button btnT;
        private System.Windows.Forms.Button btnS;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnQ;
        private System.Windows.Forms.Label lblSaleOrderDateShow;
        private System.Windows.Forms.Label lblOrderDate;
        private System.Windows.Forms.Panel pnlButtons;
        private System.Windows.Forms.ListBox lstCar;
        private System.Windows.Forms.ListBox lstCustomer;
        private System.Windows.Forms.Label lblSaleCustTelNumShow;
        private System.Windows.Forms.Label lblSaleCustEmailShow;
        private System.Windows.Forms.Label lblSaleTradeIn;
        private System.Windows.Forms.Label lblSaleDeposit;
        private System.Windows.Forms.Button btnSaleTradeIn;
        private System.Windows.Forms.NumericUpDown txtSaleDeposit;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.RadioButton rbCheque;
        private System.Windows.Forms.RadioButton rbCard;
        private System.Windows.Forms.RadioButton rbFinance;
        private System.Windows.Forms.RadioButton rbCash;
        private System.Windows.Forms.Label lblPaymentMethod;
        private System.Windows.Forms.Label lblCarTradeValue;
        private System.Windows.Forms.Label lblSaleOrderNoShow;
        private System.Windows.Forms.Label lblSaleOrderNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblSaleCustNoShow;
        private System.Windows.Forms.Label lblSaleCustNo;
        private System.Windows.Forms.TabPage tabSalesDisplay;
        private System.Windows.Forms.DataGridView dgvOrders;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblSaleCarPriceShow;
        private System.Windows.Forms.Label lblCarPrice;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lblFinanceMileage;
        private System.Windows.Forms.Label lblFinanceColour;
        private System.Windows.Forms.Label lblFinanceModel;
        private System.Windows.Forms.Label lblFinanceMake;
        private System.Windows.Forms.Label lblFinanceCustNo;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblFinanceTelNum;
        private System.Windows.Forms.Label lblFinanceCustEmail;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblFinanceCustCreditRating;
        private System.Windows.Forms.Label lblFinancePostcode;
        private System.Windows.Forms.Label lblFinanceCustCounty;
        private System.Windows.Forms.Label lblFinanceCustTown;
        private System.Windows.Forms.Label lblFinanceCustAddress;
        private System.Windows.Forms.Label lblFinanceCustName;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label lblFinanceBodyStyle;
        private System.Windows.Forms.Label lblFinanceInterior;
        private System.Windows.Forms.Label lblFinanceTransmission;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label lblFinanceRegNoShow;
        private System.Windows.Forms.Label lblFinanceRegNo;
        private System.Windows.Forms.Label lblFinanceTotalInterest;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblFinanceInterestPriceShow;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblFinanceInterestRateShow;
        private System.Windows.Forms.Label lblFinanceInterestRate;
        private System.Windows.Forms.Label lblFinanceMonthlyPaymentShow;
        private System.Windows.Forms.Label lblFinanceMonthlyPayment;
        private System.Windows.Forms.Label lblFinanceNumPaymentsShow;
        private System.Windows.Forms.Label lblFinanceNumPayments;
        private System.Windows.Forms.Label lblFinanceAgreeDateShow;
        private System.Windows.Forms.Label lblFinanceAgreeDate;
        private System.Windows.Forms.Label lblFinanceAgreementIDShow;
        private System.Windows.Forms.Label lblFinanceID;
        private System.Windows.Forms.Label lblFinancePriceShow;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblFinanceTradeValueShow;
        private System.Windows.Forms.Label lblFinanceTradeInValue;
        private System.Windows.Forms.Label lblFinanceDepositShow;
        private System.Windows.Forms.Label lblFinanceDeposit;
        private System.Windows.Forms.ComboBox cmbFinancePlanLength;
        private System.Windows.Forms.Label lblFinancePlanLength;
        private System.Windows.Forms.TabPage tabDisplayFinance;
        private System.Windows.Forms.DataGridView dgvFinanceAgreements;
        private System.Windows.Forms.TabPage tabReport;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label lblFinanceInterestDueEdit;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lblFinanceTotalInterestEdit;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label lblFinanceInterestRateEdit;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label lblFinanceMonthlyPaymentEdit;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label lblFinanceNumPaymentsEdit;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label lblFinanceAgreementDateEdit;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label lblFinanceFinanceIDEdit;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label lblFinanceTotalNoInterestEdit;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label lblFinanceTradeInEdit;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.ComboBox cmbFinancePlanLengthEdit;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label lblFinanceRegNoEdit;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label lblFinanceMakeEdit;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label lblFinanceModelEdit;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label lblFinanceColourEdit;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label lblFinanceMileageEdit;
        private System.Windows.Forms.Label lblFinanceBodyEdit;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label lblFinanceInteriorEdit;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label lblFinanceTransmissionEdit;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label lblFinanceCustNameEdit;
        private System.Windows.Forms.Label lblFinanceTelNumEdit;
        private System.Windows.Forms.Label lblFinanceCustNoEdit;
        private System.Windows.Forms.Label lblFinanceCustEmailEdit;
        private System.Windows.Forms.Label lblFinanceCustAddressEdit;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label lblFinanceCustTownEdit;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label lblFinanceCustCountyEdit;
        private System.Windows.Forms.Label lblFinanceCustCreditEdit;
        private System.Windows.Forms.Label lblFinanceCustPostcodeEdit;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label lblEditFinanceEdit;
        private System.Windows.Forms.NumericUpDown txtFinanceDepositEdit;
        private System.Windows.Forms.Label lblFinancePriceEdit;
        private System.Windows.Forms.Label lblFinancePriceEdit2;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblSearchOrders;
        private System.Windows.Forms.ComboBox cmbRepOrderSearch;
    }
}