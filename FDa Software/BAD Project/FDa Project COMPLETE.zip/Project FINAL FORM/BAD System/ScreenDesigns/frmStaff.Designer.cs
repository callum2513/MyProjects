﻿using System;

namespace ScreenDesigns
{
    partial class frmStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmStaff));
            this.tabStaff = new System.Windows.Forms.TabControl();
            this.tabDisplay = new System.Windows.Forms.TabPage();
            this.dgvDisplayStaff = new System.Windows.Forms.DataGridView();
            this.tabAdd = new System.Windows.Forms.TabPage();
            this.txtAddEmail = new System.Windows.Forms.TextBox();
            this.lblAddEmail = new System.Windows.Forms.Label();
            this.lblAddClear = new System.Windows.Forms.Label();
            this.btnAddClear = new System.Windows.Forms.Button();
            this.txtAddMobile = new System.Windows.Forms.TextBox();
            this.txtAddPostcode = new System.Windows.Forms.TextBox();
            this.txtAddCounty = new System.Windows.Forms.TextBox();
            this.txtAddTown = new System.Windows.Forms.TextBox();
            this.txtAddStreet = new System.Windows.Forms.TextBox();
            this.txtAddForename = new System.Windows.Forms.TextBox();
            this.lblAddDisplayStaffNo = new System.Windows.Forms.Label();
            this.lblAddMobileNo = new System.Windows.Forms.Label();
            this.lblAddPostcode = new System.Windows.Forms.Label();
            this.lblAddCounty = new System.Windows.Forms.Label();
            this.lblAddTown = new System.Windows.Forms.Label();
            this.lblAddStreet = new System.Windows.Forms.Label();
            this.lblAddForename = new System.Windows.Forms.Label();
            this.lblAddSurname = new System.Windows.Forms.Label();
            this.lblAddStaffNo = new System.Windows.Forms.Label();
            this.lblAddBtnAdd = new System.Windows.Forms.Label();
            this.btnAddAdd = new System.Windows.Forms.Button();
            this.txtAddSurname = new System.Windows.Forms.TextBox();
            this.tabEdit = new System.Windows.Forms.TabPage();
            this.lblEditCancel = new System.Windows.Forms.Label();
            this.btnEditCancel = new System.Windows.Forms.Button();
            this.txtEditEmail = new System.Windows.Forms.TextBox();
            this.lblEditEmail = new System.Windows.Forms.Label();
            this.txtEditMobileNo = new System.Windows.Forms.TextBox();
            this.txtEditPostcode = new System.Windows.Forms.TextBox();
            this.txtEditCounty = new System.Windows.Forms.TextBox();
            this.txtEditTown = new System.Windows.Forms.TextBox();
            this.txtEditStreet = new System.Windows.Forms.TextBox();
            this.txtEditForename = new System.Windows.Forms.TextBox();
            this.lblEditDisplayStaffNo = new System.Windows.Forms.Label();
            this.lblEditMobileNo = new System.Windows.Forms.Label();
            this.lblEditPostcode = new System.Windows.Forms.Label();
            this.lblEditCounty = new System.Windows.Forms.Label();
            this.lblEditTown = new System.Windows.Forms.Label();
            this.lblEditStreet = new System.Windows.Forms.Label();
            this.lblEditForename = new System.Windows.Forms.Label();
            this.lblEditSurname = new System.Windows.Forms.Label();
            this.lblEditStaffNo = new System.Windows.Forms.Label();
            this.lblEditEdit = new System.Windows.Forms.Label();
            this.btnEditEdit = new System.Windows.Forms.Button();
            this.txtEditSurname = new System.Windows.Forms.TextBox();
            this.tabReports = new System.Windows.Forms.TabPage();
            this.cmbCounty = new System.Windows.Forms.ComboBox();
            this.cptReports = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.errP = new System.Windows.Forms.ErrorProvider(this.components);
            this.cmbDisplaySearch = new System.Windows.Forms.ComboBox();
            this.txtDisplaySearch = new System.Windows.Forms.TextBox();
            this.lblCustomerTitle = new System.Windows.Forms.Label();
            this.btnDisplayExit = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.btnDisplayDelete = new System.Windows.Forms.Button();
            this.btnDisplayEdit = new System.Windows.Forms.Button();
            this.btnDisplayAdd = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblSearchOptions = new System.Windows.Forms.Label();
            this.tabStaff.SuspendLayout();
            this.tabDisplay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDisplayStaff)).BeginInit();
            this.tabAdd.SuspendLayout();
            this.tabEdit.SuspendLayout();
            this.tabReports.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabStaff
            // 
            this.tabStaff.Controls.Add(this.tabDisplay);
            this.tabStaff.Controls.Add(this.tabAdd);
            this.tabStaff.Controls.Add(this.tabEdit);
            this.tabStaff.Controls.Add(this.tabReports);
            this.tabStaff.Location = new System.Drawing.Point(130, 107);
            this.tabStaff.Name = "tabStaff";
            this.tabStaff.SelectedIndex = 0;
            this.tabStaff.Size = new System.Drawing.Size(776, 451);
            this.tabStaff.TabIndex = 0;
            this.tabStaff.SelectedIndexChanged += new System.EventHandler(this.tabStaff_SelectedIndexChanged);
            // 
            // tabDisplay
            // 
            this.tabDisplay.Controls.Add(this.dgvDisplayStaff);
            this.tabDisplay.Location = new System.Drawing.Point(4, 22);
            this.tabDisplay.Name = "tabDisplay";
            this.tabDisplay.Padding = new System.Windows.Forms.Padding(3);
            this.tabDisplay.Size = new System.Drawing.Size(768, 425);
            this.tabDisplay.TabIndex = 0;
            this.tabDisplay.Text = "Display";
            this.tabDisplay.UseVisualStyleBackColor = true;
            // 
            // dgvDisplayStaff
            // 
            this.dgvDisplayStaff.AllowUserToAddRows = false;
            this.dgvDisplayStaff.AllowUserToDeleteRows = false;
            this.dgvDisplayStaff.AllowUserToResizeColumns = false;
            this.dgvDisplayStaff.AllowUserToResizeRows = false;
            this.dgvDisplayStaff.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDisplayStaff.Location = new System.Drawing.Point(6, 6);
            this.dgvDisplayStaff.Name = "dgvDisplayStaff";
            this.dgvDisplayStaff.ReadOnly = true;
            this.dgvDisplayStaff.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDisplayStaff.Size = new System.Drawing.Size(752, 407);
            this.dgvDisplayStaff.TabIndex = 0;
            this.dgvDisplayStaff.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDisplayStaff_CellContentClick);
            // 
            // tabAdd
            // 
            this.tabAdd.Controls.Add(this.txtAddEmail);
            this.tabAdd.Controls.Add(this.lblAddEmail);
            this.tabAdd.Controls.Add(this.lblAddClear);
            this.tabAdd.Controls.Add(this.btnAddClear);
            this.tabAdd.Controls.Add(this.txtAddMobile);
            this.tabAdd.Controls.Add(this.txtAddPostcode);
            this.tabAdd.Controls.Add(this.txtAddCounty);
            this.tabAdd.Controls.Add(this.txtAddTown);
            this.tabAdd.Controls.Add(this.txtAddStreet);
            this.tabAdd.Controls.Add(this.txtAddForename);
            this.tabAdd.Controls.Add(this.lblAddDisplayStaffNo);
            this.tabAdd.Controls.Add(this.lblAddMobileNo);
            this.tabAdd.Controls.Add(this.lblAddPostcode);
            this.tabAdd.Controls.Add(this.lblAddCounty);
            this.tabAdd.Controls.Add(this.lblAddTown);
            this.tabAdd.Controls.Add(this.lblAddStreet);
            this.tabAdd.Controls.Add(this.lblAddForename);
            this.tabAdd.Controls.Add(this.lblAddSurname);
            this.tabAdd.Controls.Add(this.lblAddStaffNo);
            this.tabAdd.Controls.Add(this.lblAddBtnAdd);
            this.tabAdd.Controls.Add(this.btnAddAdd);
            this.tabAdd.Controls.Add(this.txtAddSurname);
            this.tabAdd.Location = new System.Drawing.Point(4, 22);
            this.tabAdd.Name = "tabAdd";
            this.tabAdd.Padding = new System.Windows.Forms.Padding(3);
            this.tabAdd.Size = new System.Drawing.Size(768, 425);
            this.tabAdd.TabIndex = 1;
            this.tabAdd.Text = "Add";
            this.tabAdd.UseVisualStyleBackColor = true;
            this.tabAdd.Click += new System.EventHandler(this.tabAdd_Click);
            // 
            // txtAddEmail
            // 
            this.txtAddEmail.Location = new System.Drawing.Point(202, 244);
            this.txtAddEmail.Name = "txtAddEmail";
            this.txtAddEmail.Size = new System.Drawing.Size(231, 20);
            this.txtAddEmail.TabIndex = 7;
            // 
            // lblAddEmail
            // 
            this.lblAddEmail.AutoSize = true;
            this.lblAddEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddEmail.Location = new System.Drawing.Point(57, 242);
            this.lblAddEmail.Name = "lblAddEmail";
            this.lblAddEmail.Size = new System.Drawing.Size(48, 20);
            this.lblAddEmail.TabIndex = 90;
            this.lblAddEmail.Text = "Email";
            // 
            // lblAddClear
            // 
            this.lblAddClear.AutoSize = true;
            this.lblAddClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddClear.Location = new System.Drawing.Point(218, 320);
            this.lblAddClear.Name = "lblAddClear";
            this.lblAddClear.Size = new System.Drawing.Size(46, 20);
            this.lblAddClear.TabIndex = 89;
            this.lblAddClear.Text = "Clear";
            // 
            // btnAddClear
            // 
            this.btnAddClear.Location = new System.Drawing.Point(176, 312);
            this.btnAddClear.Name = "btnAddClear";
            this.btnAddClear.Size = new System.Drawing.Size(36, 31);
            this.btnAddClear.TabIndex = 10;
            this.btnAddClear.UseVisualStyleBackColor = true;
            this.btnAddClear.Click += new System.EventHandler(this.btnAddClear_Click);
            // 
            // txtAddMobile
            // 
            this.txtAddMobile.Location = new System.Drawing.Point(202, 276);
            this.txtAddMobile.Name = "txtAddMobile";
            this.txtAddMobile.Size = new System.Drawing.Size(231, 20);
            this.txtAddMobile.TabIndex = 8;
            // 
            // txtAddPostcode
            // 
            this.txtAddPostcode.Location = new System.Drawing.Point(202, 215);
            this.txtAddPostcode.Name = "txtAddPostcode";
            this.txtAddPostcode.Size = new System.Drawing.Size(231, 20);
            this.txtAddPostcode.TabIndex = 6;
            // 
            // txtAddCounty
            // 
            this.txtAddCounty.Location = new System.Drawing.Point(202, 183);
            this.txtAddCounty.Name = "txtAddCounty";
            this.txtAddCounty.Size = new System.Drawing.Size(231, 20);
            this.txtAddCounty.TabIndex = 5;
            // 
            // txtAddTown
            // 
            this.txtAddTown.Location = new System.Drawing.Point(202, 150);
            this.txtAddTown.Name = "txtAddTown";
            this.txtAddTown.Size = new System.Drawing.Size(231, 20);
            this.txtAddTown.TabIndex = 4;
            // 
            // txtAddStreet
            // 
            this.txtAddStreet.Location = new System.Drawing.Point(202, 116);
            this.txtAddStreet.Name = "txtAddStreet";
            this.txtAddStreet.Size = new System.Drawing.Size(231, 20);
            this.txtAddStreet.TabIndex = 3;
            // 
            // txtAddForename
            // 
            this.txtAddForename.Location = new System.Drawing.Point(202, 49);
            this.txtAddForename.Name = "txtAddForename";
            this.txtAddForename.Size = new System.Drawing.Size(231, 20);
            this.txtAddForename.TabIndex = 0;
            this.txtAddForename.Validating += new System.ComponentModel.CancelEventHandler(this.txtAddForename_Validating);
            // 
            // lblAddDisplayStaffNo
            // 
            this.lblAddDisplayStaffNo.AutoSize = true;
            this.lblAddDisplayStaffNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddDisplayStaffNo.Location = new System.Drawing.Point(198, 13);
            this.lblAddDisplayStaffNo.Name = "lblAddDisplayStaffNo";
            this.lblAddDisplayStaffNo.Size = new System.Drawing.Size(14, 20);
            this.lblAddDisplayStaffNo.TabIndex = 81;
            this.lblAddDisplayStaffNo.Text = "-";
            // 
            // lblAddMobileNo
            // 
            this.lblAddMobileNo.AutoSize = true;
            this.lblAddMobileNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddMobileNo.Location = new System.Drawing.Point(59, 274);
            this.lblAddMobileNo.Name = "lblAddMobileNo";
            this.lblAddMobileNo.Size = new System.Drawing.Size(79, 20);
            this.lblAddMobileNo.TabIndex = 80;
            this.lblAddMobileNo.Text = "Mobile No";
            // 
            // lblAddPostcode
            // 
            this.lblAddPostcode.AutoSize = true;
            this.lblAddPostcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddPostcode.Location = new System.Drawing.Point(57, 213);
            this.lblAddPostcode.Name = "lblAddPostcode";
            this.lblAddPostcode.Size = new System.Drawing.Size(76, 20);
            this.lblAddPostcode.TabIndex = 79;
            this.lblAddPostcode.Text = "Postcode";
            // 
            // lblAddCounty
            // 
            this.lblAddCounty.AutoSize = true;
            this.lblAddCounty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddCounty.Location = new System.Drawing.Point(59, 181);
            this.lblAddCounty.Name = "lblAddCounty";
            this.lblAddCounty.Size = new System.Drawing.Size(59, 20);
            this.lblAddCounty.TabIndex = 78;
            this.lblAddCounty.Text = "County";
            // 
            // lblAddTown
            // 
            this.lblAddTown.AutoSize = true;
            this.lblAddTown.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddTown.Location = new System.Drawing.Point(59, 148);
            this.lblAddTown.Name = "lblAddTown";
            this.lblAddTown.Size = new System.Drawing.Size(47, 20);
            this.lblAddTown.TabIndex = 77;
            this.lblAddTown.Text = "Town";
            // 
            // lblAddStreet
            // 
            this.lblAddStreet.AutoSize = true;
            this.lblAddStreet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddStreet.Location = new System.Drawing.Point(59, 114);
            this.lblAddStreet.Name = "lblAddStreet";
            this.lblAddStreet.Size = new System.Drawing.Size(53, 20);
            this.lblAddStreet.TabIndex = 76;
            this.lblAddStreet.Text = "Street";
            // 
            // lblAddForename
            // 
            this.lblAddForename.AutoSize = true;
            this.lblAddForename.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddForename.Location = new System.Drawing.Point(59, 47);
            this.lblAddForename.Name = "lblAddForename";
            this.lblAddForename.Size = new System.Drawing.Size(82, 20);
            this.lblAddForename.TabIndex = 75;
            this.lblAddForename.Text = "Forename";
            // 
            // lblAddSurname
            // 
            this.lblAddSurname.AutoSize = true;
            this.lblAddSurname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddSurname.Location = new System.Drawing.Point(59, 83);
            this.lblAddSurname.Name = "lblAddSurname";
            this.lblAddSurname.Size = new System.Drawing.Size(74, 20);
            this.lblAddSurname.TabIndex = 74;
            this.lblAddSurname.Text = "Surname";
            // 
            // lblAddStaffNo
            // 
            this.lblAddStaffNo.AutoSize = true;
            this.lblAddStaffNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddStaffNo.Location = new System.Drawing.Point(38, 13);
            this.lblAddStaffNo.Name = "lblAddStaffNo";
            this.lblAddStaffNo.Size = new System.Drawing.Size(68, 20);
            this.lblAddStaffNo.TabIndex = 73;
            this.lblAddStaffNo.Text = "Staff No";
            // 
            // lblAddBtnAdd
            // 
            this.lblAddBtnAdd.AutoSize = true;
            this.lblAddBtnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddBtnAdd.Location = new System.Drawing.Point(115, 320);
            this.lblAddBtnAdd.Name = "lblAddBtnAdd";
            this.lblAddBtnAdd.Size = new System.Drawing.Size(38, 20);
            this.lblAddBtnAdd.TabIndex = 72;
            this.lblAddBtnAdd.Text = "Add";
            // 
            // btnAddAdd
            // 
            this.btnAddAdd.Location = new System.Drawing.Point(73, 312);
            this.btnAddAdd.Name = "btnAddAdd";
            this.btnAddAdd.Size = new System.Drawing.Size(36, 31);
            this.btnAddAdd.TabIndex = 9;
            this.btnAddAdd.UseVisualStyleBackColor = true;
            this.btnAddAdd.Click += new System.EventHandler(this.btnAddAdd_Click);
            // 
            // txtAddSurname
            // 
            this.txtAddSurname.Location = new System.Drawing.Point(202, 85);
            this.txtAddSurname.Name = "txtAddSurname";
            this.txtAddSurname.Size = new System.Drawing.Size(231, 20);
            this.txtAddSurname.TabIndex = 1;
            // 
            // tabEdit
            // 
            this.tabEdit.Controls.Add(this.lblEditCancel);
            this.tabEdit.Controls.Add(this.btnEditCancel);
            this.tabEdit.Controls.Add(this.txtEditEmail);
            this.tabEdit.Controls.Add(this.lblEditEmail);
            this.tabEdit.Controls.Add(this.txtEditMobileNo);
            this.tabEdit.Controls.Add(this.txtEditPostcode);
            this.tabEdit.Controls.Add(this.txtEditCounty);
            this.tabEdit.Controls.Add(this.txtEditTown);
            this.tabEdit.Controls.Add(this.txtEditStreet);
            this.tabEdit.Controls.Add(this.txtEditForename);
            this.tabEdit.Controls.Add(this.lblEditDisplayStaffNo);
            this.tabEdit.Controls.Add(this.lblEditMobileNo);
            this.tabEdit.Controls.Add(this.lblEditPostcode);
            this.tabEdit.Controls.Add(this.lblEditCounty);
            this.tabEdit.Controls.Add(this.lblEditTown);
            this.tabEdit.Controls.Add(this.lblEditStreet);
            this.tabEdit.Controls.Add(this.lblEditForename);
            this.tabEdit.Controls.Add(this.lblEditSurname);
            this.tabEdit.Controls.Add(this.lblEditStaffNo);
            this.tabEdit.Controls.Add(this.lblEditEdit);
            this.tabEdit.Controls.Add(this.btnEditEdit);
            this.tabEdit.Controls.Add(this.txtEditSurname);
            this.tabEdit.Location = new System.Drawing.Point(4, 22);
            this.tabEdit.Name = "tabEdit";
            this.tabEdit.Size = new System.Drawing.Size(768, 425);
            this.tabEdit.TabIndex = 2;
            this.tabEdit.Text = "Edit";
            this.tabEdit.UseVisualStyleBackColor = true;
            this.tabEdit.Click += new System.EventHandler(this.tabEdit_Click);
            // 
            // lblEditCancel
            // 
            this.lblEditCancel.AutoSize = true;
            this.lblEditCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditCancel.Location = new System.Drawing.Point(222, 316);
            this.lblEditCancel.Name = "lblEditCancel";
            this.lblEditCancel.Size = new System.Drawing.Size(58, 20);
            this.lblEditCancel.TabIndex = 95;
            this.lblEditCancel.Text = "Cancel";
            // 
            // btnEditCancel
            // 
            this.btnEditCancel.Location = new System.Drawing.Point(180, 308);
            this.btnEditCancel.Name = "btnEditCancel";
            this.btnEditCancel.Size = new System.Drawing.Size(36, 31);
            this.btnEditCancel.TabIndex = 94;
            this.btnEditCancel.UseVisualStyleBackColor = true;
            this.btnEditCancel.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtEditEmail
            // 
            this.txtEditEmail.Location = new System.Drawing.Point(180, 226);
            this.txtEditEmail.Name = "txtEditEmail";
            this.txtEditEmail.Size = new System.Drawing.Size(231, 20);
            this.txtEditEmail.TabIndex = 91;
            this.txtEditEmail.TextChanged += new System.EventHandler(this.txtEditEmail_TextChanged);
            // 
            // lblEditEmail
            // 
            this.lblEditEmail.AutoSize = true;
            this.lblEditEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditEmail.Location = new System.Drawing.Point(37, 225);
            this.lblEditEmail.Name = "lblEditEmail";
            this.lblEditEmail.Size = new System.Drawing.Size(48, 20);
            this.lblEditEmail.TabIndex = 92;
            this.lblEditEmail.Text = "Email";
            // 
            // txtEditMobileNo
            // 
            this.txtEditMobileNo.Location = new System.Drawing.Point(180, 254);
            this.txtEditMobileNo.Name = "txtEditMobileNo";
            this.txtEditMobileNo.Size = new System.Drawing.Size(231, 20);
            this.txtEditMobileNo.TabIndex = 69;
            // 
            // txtEditPostcode
            // 
            this.txtEditPostcode.Location = new System.Drawing.Point(180, 198);
            this.txtEditPostcode.Name = "txtEditPostcode";
            this.txtEditPostcode.Size = new System.Drawing.Size(231, 20);
            this.txtEditPostcode.TabIndex = 68;
            // 
            // txtEditCounty
            // 
            this.txtEditCounty.Location = new System.Drawing.Point(180, 171);
            this.txtEditCounty.Name = "txtEditCounty";
            this.txtEditCounty.Size = new System.Drawing.Size(231, 20);
            this.txtEditCounty.TabIndex = 67;
            this.txtEditCounty.TextChanged += new System.EventHandler(this.txtEditCounty_TextChanged);
            // 
            // txtEditTown
            // 
            this.txtEditTown.Location = new System.Drawing.Point(180, 144);
            this.txtEditTown.Name = "txtEditTown";
            this.txtEditTown.Size = new System.Drawing.Size(231, 20);
            this.txtEditTown.TabIndex = 66;
            this.txtEditTown.TextChanged += new System.EventHandler(this.txtEditTown_TextChanged);
            // 
            // txtEditStreet
            // 
            this.txtEditStreet.Location = new System.Drawing.Point(180, 116);
            this.txtEditStreet.Name = "txtEditStreet";
            this.txtEditStreet.Size = new System.Drawing.Size(231, 20);
            this.txtEditStreet.TabIndex = 65;
            // 
            // txtEditForename
            // 
            this.txtEditForename.Location = new System.Drawing.Point(180, 56);
            this.txtEditForename.Name = "txtEditForename";
            this.txtEditForename.Size = new System.Drawing.Size(231, 20);
            this.txtEditForename.TabIndex = 64;
            // 
            // lblEditDisplayStaffNo
            // 
            this.lblEditDisplayStaffNo.AutoSize = true;
            this.lblEditDisplayStaffNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditDisplayStaffNo.Location = new System.Drawing.Point(190, 20);
            this.lblEditDisplayStaffNo.Name = "lblEditDisplayStaffNo";
            this.lblEditDisplayStaffNo.Size = new System.Drawing.Size(14, 20);
            this.lblEditDisplayStaffNo.TabIndex = 63;
            this.lblEditDisplayStaffNo.Text = "-";
            // 
            // lblEditMobileNo
            // 
            this.lblEditMobileNo.AutoSize = true;
            this.lblEditMobileNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditMobileNo.Location = new System.Drawing.Point(37, 252);
            this.lblEditMobileNo.Name = "lblEditMobileNo";
            this.lblEditMobileNo.Size = new System.Drawing.Size(79, 20);
            this.lblEditMobileNo.TabIndex = 62;
            this.lblEditMobileNo.Text = "Mobile No";
            // 
            // lblEditPostcode
            // 
            this.lblEditPostcode.AutoSize = true;
            this.lblEditPostcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditPostcode.Location = new System.Drawing.Point(35, 196);
            this.lblEditPostcode.Name = "lblEditPostcode";
            this.lblEditPostcode.Size = new System.Drawing.Size(76, 20);
            this.lblEditPostcode.TabIndex = 61;
            this.lblEditPostcode.Text = "Postcode";
            // 
            // lblEditCounty
            // 
            this.lblEditCounty.AutoSize = true;
            this.lblEditCounty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditCounty.Location = new System.Drawing.Point(37, 169);
            this.lblEditCounty.Name = "lblEditCounty";
            this.lblEditCounty.Size = new System.Drawing.Size(59, 20);
            this.lblEditCounty.TabIndex = 60;
            this.lblEditCounty.Text = "County";
            // 
            // lblEditTown
            // 
            this.lblEditTown.AutoSize = true;
            this.lblEditTown.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditTown.Location = new System.Drawing.Point(37, 142);
            this.lblEditTown.Name = "lblEditTown";
            this.lblEditTown.Size = new System.Drawing.Size(47, 20);
            this.lblEditTown.TabIndex = 59;
            this.lblEditTown.Text = "Town";
            this.lblEditTown.Click += new System.EventHandler(this.lblEditTown_Click);
            // 
            // lblEditStreet
            // 
            this.lblEditStreet.AutoSize = true;
            this.lblEditStreet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditStreet.Location = new System.Drawing.Point(37, 114);
            this.lblEditStreet.Name = "lblEditStreet";
            this.lblEditStreet.Size = new System.Drawing.Size(53, 20);
            this.lblEditStreet.TabIndex = 58;
            this.lblEditStreet.Text = "Street";
            // 
            // lblEditForename
            // 
            this.lblEditForename.AutoSize = true;
            this.lblEditForename.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditForename.Location = new System.Drawing.Point(37, 56);
            this.lblEditForename.Name = "lblEditForename";
            this.lblEditForename.Size = new System.Drawing.Size(82, 20);
            this.lblEditForename.TabIndex = 57;
            this.lblEditForename.Text = "Forename";
            // 
            // lblEditSurname
            // 
            this.lblEditSurname.AutoSize = true;
            this.lblEditSurname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditSurname.Location = new System.Drawing.Point(37, 88);
            this.lblEditSurname.Name = "lblEditSurname";
            this.lblEditSurname.Size = new System.Drawing.Size(74, 20);
            this.lblEditSurname.TabIndex = 56;
            this.lblEditSurname.Text = "Surname";
            // 
            // lblEditStaffNo
            // 
            this.lblEditStaffNo.AutoSize = true;
            this.lblEditStaffNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditStaffNo.Location = new System.Drawing.Point(30, 20);
            this.lblEditStaffNo.Name = "lblEditStaffNo";
            this.lblEditStaffNo.Size = new System.Drawing.Size(68, 20);
            this.lblEditStaffNo.TabIndex = 54;
            this.lblEditStaffNo.Text = "Staff No";
            // 
            // lblEditEdit
            // 
            this.lblEditEdit.AutoSize = true;
            this.lblEditEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEditEdit.Location = new System.Drawing.Point(96, 316);
            this.lblEditEdit.Name = "lblEditEdit";
            this.lblEditEdit.Size = new System.Drawing.Size(37, 20);
            this.lblEditEdit.TabIndex = 53;
            this.lblEditEdit.Text = "Edit";
            // 
            // btnEditEdit
            // 
            this.btnEditEdit.Location = new System.Drawing.Point(54, 308);
            this.btnEditEdit.Name = "btnEditEdit";
            this.btnEditEdit.Size = new System.Drawing.Size(36, 31);
            this.btnEditEdit.TabIndex = 50;
            this.btnEditEdit.UseVisualStyleBackColor = true;
            this.btnEditEdit.Click += new System.EventHandler(this.btnEditEdit_Click);
            // 
            // txtEditSurname
            // 
            this.txtEditSurname.Location = new System.Drawing.Point(180, 90);
            this.txtEditSurname.Name = "txtEditSurname";
            this.txtEditSurname.Size = new System.Drawing.Size(231, 20);
            this.txtEditSurname.TabIndex = 48;
            // 
            // tabReports
            // 
            this.tabReports.Controls.Add(this.lblSearchOptions);
            this.tabReports.Controls.Add(this.cmbCounty);
            this.tabReports.Controls.Add(this.cptReports);
            this.tabReports.Location = new System.Drawing.Point(4, 22);
            this.tabReports.Name = "tabReports";
            this.tabReports.Size = new System.Drawing.Size(768, 425);
            this.tabReports.TabIndex = 3;
            this.tabReports.Text = "Reports";
            this.tabReports.UseVisualStyleBackColor = true;
            // 
            // cmbCounty
            // 
            this.cmbCounty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCounty.FormattingEnabled = true;
            this.cmbCounty.Location = new System.Drawing.Point(34, 140);
            this.cmbCounty.Name = "cmbCounty";
            this.cmbCounty.Size = new System.Drawing.Size(121, 21);
            this.cmbCounty.TabIndex = 1;
            this.cmbCounty.SelectedIndexChanged += new System.EventHandler(this.cmbCounty_SelectedIndexChanged);
            // 
            // cptReports
            // 
            this.cptReports.ActiveViewIndex = 0;
            this.cptReports.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cptReports.Cursor = System.Windows.Forms.Cursors.Default;
            this.cptReports.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cptReports.Location = new System.Drawing.Point(0, 0);
            this.cptReports.Name = "cptReports";
            this.cptReports.Size = new System.Drawing.Size(768, 425);
            this.cptReports.TabIndex = 0;
            this.cptReports.Load += new System.EventHandler(this.cptReports_Load);
            // 
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel1.Location = new System.Drawing.Point(-1, 55);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1000, 2);
            this.panel1.TabIndex = 38;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Location = new System.Drawing.Point(0, 38);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(3, 520);
            this.panel3.TabIndex = 40;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel2.Location = new System.Drawing.Point(-31, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(3, 520);
            this.panel2.TabIndex = 38;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(122, 41);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(3, 520);
            this.panel4.TabIndex = 39;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel5.Location = new System.Drawing.Point(-31, 0);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(3, 520);
            this.panel5.TabIndex = 38;
            // 
            // errP
            // 
            this.errP.ContainerControl = this;
            // 
            // cmbDisplaySearch
            // 
            this.cmbDisplaySearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDisplaySearch.FormattingEnabled = true;
            this.cmbDisplaySearch.Items.AddRange(new object[] {
            "StaffID",
            "Forename",
            "Surname",
            "Street",
            "Town",
            "County",
            "Postcode",
            "Email",
            "TelNo"});
            this.cmbDisplaySearch.Location = new System.Drawing.Point(440, 85);
            this.cmbDisplaySearch.Name = "cmbDisplaySearch";
            this.cmbDisplaySearch.Size = new System.Drawing.Size(121, 21);
            this.cmbDisplaySearch.TabIndex = 44;
            this.cmbDisplaySearch.SelectedIndexChanged += new System.EventHandler(this.cmbDisplaySearch_SelectedIndexChanged);
            // 
            // txtDisplaySearch
            // 
            this.txtDisplaySearch.Location = new System.Drawing.Point(567, 85);
            this.txtDisplaySearch.Name = "txtDisplaySearch";
            this.txtDisplaySearch.Size = new System.Drawing.Size(120, 20);
            this.txtDisplaySearch.TabIndex = 45;
            this.txtDisplaySearch.TextChanged += new System.EventHandler(this.txtDisplaySearch_TextChanged);
            // 
            // lblCustomerTitle
            // 
            this.lblCustomerTitle.AutoSize = true;
            this.lblCustomerTitle.BackColor = System.Drawing.Color.White;
            this.lblCustomerTitle.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.lblCustomerTitle.Location = new System.Drawing.Point(792, 10);
            this.lblCustomerTitle.Name = "lblCustomerTitle";
            this.lblCustomerTitle.Size = new System.Drawing.Size(91, 45);
            this.lblCustomerTitle.TabIndex = 51;
            this.lblCustomerTitle.Text = "Staff";
            // 
            // btnDisplayExit
            // 
            this.btnDisplayExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDisplayExit.BackgroundImage")));
            this.btnDisplayExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDisplayExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplayExit.Location = new System.Drawing.Point(24, 463);
            this.btnDisplayExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnDisplayExit.Name = "btnDisplayExit";
            this.btnDisplayExit.Size = new System.Drawing.Size(75, 75);
            this.btnDisplayExit.TabIndex = 50;
            this.btnDisplayExit.UseVisualStyleBackColor = true;
            this.btnDisplayExit.Click += new System.EventHandler(this.btnDisplayExit_Click_1);
            // 
            // btnHome
            // 
            this.btnHome.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHome.BackgroundImage")));
            this.btnHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.Location = new System.Drawing.Point(24, 373);
            this.btnHome.Margin = new System.Windows.Forms.Padding(2);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(75, 75);
            this.btnHome.TabIndex = 49;
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // btnDisplayDelete
            // 
            this.btnDisplayDelete.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDisplayDelete.BackgroundImage")));
            this.btnDisplayDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDisplayDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplayDelete.Location = new System.Drawing.Point(24, 281);
            this.btnDisplayDelete.Margin = new System.Windows.Forms.Padding(2);
            this.btnDisplayDelete.Name = "btnDisplayDelete";
            this.btnDisplayDelete.Size = new System.Drawing.Size(75, 75);
            this.btnDisplayDelete.TabIndex = 48;
            this.btnDisplayDelete.UseVisualStyleBackColor = true;
            this.btnDisplayDelete.Click += new System.EventHandler(this.btnDisplayDisplay_Click);
            // 
            // btnDisplayEdit
            // 
            this.btnDisplayEdit.BackgroundImage = global::ScreenDesigns.Properties.Resources.icons8_edit_100;
            this.btnDisplayEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDisplayEdit.Location = new System.Drawing.Point(24, 187);
            this.btnDisplayEdit.Name = "btnDisplayEdit";
            this.btnDisplayEdit.Size = new System.Drawing.Size(75, 77);
            this.btnDisplayEdit.TabIndex = 41;
            this.btnDisplayEdit.UseVisualStyleBackColor = true;
            this.btnDisplayEdit.Click += new System.EventHandler(this.btnDisplayEdit_Click);
            // 
            // btnDisplayAdd
            // 
            this.btnDisplayAdd.BackgroundImage = global::ScreenDesigns.Properties.Resources.icons8_add_100;
            this.btnDisplayAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDisplayAdd.Location = new System.Drawing.Point(24, 93);
            this.btnDisplayAdd.Name = "btnDisplayAdd";
            this.btnDisplayAdd.Size = new System.Drawing.Size(75, 77);
            this.btnDisplayAdd.TabIndex = 39;
            this.btnDisplayAdd.UseVisualStyleBackColor = true;
            this.btnDisplayAdd.Click += new System.EventHandler(this.btnDisplayAdd_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(-88, 2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1093, 55);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 34;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // lblSearchOptions
            // 
            this.lblSearchOptions.AutoSize = true;
            this.lblSearchOptions.Location = new System.Drawing.Point(31, 122);
            this.lblSearchOptions.Name = "lblSearchOptions";
            this.lblSearchOptions.Size = new System.Drawing.Size(124, 13);
            this.lblSearchOptions.TabIndex = 53;
            this.lblSearchOptions.Text = "Search by county below:";
            // 
            // frmStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(917, 554);
            this.Controls.Add(this.lblCustomerTitle);
            this.Controls.Add(this.btnDisplayExit);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.btnDisplayDelete);
            this.Controls.Add(this.txtDisplaySearch);
            this.Controls.Add(this.cmbDisplaySearch);
            this.Controls.Add(this.btnDisplayEdit);
            this.Controls.Add(this.btnDisplayAdd);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tabStaff);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Name = "frmStaff";
            this.Text = "frmStaff";
            this.Load += new System.EventHandler(this.frmStaff_Load);
            this.Shown += new System.EventHandler(this.frmStaff_Shown);
            this.tabStaff.ResumeLayout(false);
            this.tabDisplay.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDisplayStaff)).EndInit();
            this.tabAdd.ResumeLayout(false);
            this.tabAdd.PerformLayout();
            this.tabEdit.ResumeLayout(false);
            this.tabEdit.PerformLayout();
            this.tabReports.ResumeLayout(false);
            this.tabReports.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void lblEditTown_Click(object sender, EventArgs e)
        {
            
        }

        private void txtEditTown_TextChanged(object sender, EventArgs e)
        {
            
        }

        #endregion

        private System.Windows.Forms.TabControl tabStaff;
        private System.Windows.Forms.TabPage tabDisplay;
        private System.Windows.Forms.TabPage tabAdd;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dgvDisplayStaff;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnDisplayAdd;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txtAddMobile;
        private System.Windows.Forms.TextBox txtAddPostcode;
        private System.Windows.Forms.TextBox txtAddCounty;
        private System.Windows.Forms.TextBox txtAddTown;
        private System.Windows.Forms.TextBox txtAddStreet;
        private System.Windows.Forms.TextBox txtAddForename;
        private System.Windows.Forms.Label lblAddDisplayStaffNo;
        private System.Windows.Forms.Label lblAddMobileNo;
        private System.Windows.Forms.Label lblAddPostcode;
        private System.Windows.Forms.Label lblAddCounty;
        private System.Windows.Forms.Label lblAddTown;
        private System.Windows.Forms.Label lblAddStreet;
        private System.Windows.Forms.Label lblAddForename;
        private System.Windows.Forms.Label lblAddSurname;
        private System.Windows.Forms.Label lblAddStaffNo;
        private System.Windows.Forms.Label lblAddBtnAdd;
        private System.Windows.Forms.Button btnAddAdd;
        private System.Windows.Forms.TextBox txtAddSurname;
        private System.Windows.Forms.ErrorProvider errP;
        private System.Windows.Forms.Label lblAddClear;
        private System.Windows.Forms.Button btnAddClear;
        private System.Windows.Forms.TextBox txtAddEmail;
        private System.Windows.Forms.Label lblAddEmail;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDisplaySearch;
        private System.Windows.Forms.ComboBox cmbDisplaySearch;
        private System.Windows.Forms.Button btnDisplayEdit;
        private System.Windows.Forms.Button btnDisplayDelete;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button btnDisplayExit;
        private System.Windows.Forms.TabPage tabReports;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer cptReports;
        private System.Windows.Forms.Label lblCustomerTitle;
        private System.Windows.Forms.TabPage tabEdit;
        private System.Windows.Forms.Label lblEditCancel;
        private System.Windows.Forms.Button btnEditCancel;
        private System.Windows.Forms.TextBox txtEditEmail;
        private System.Windows.Forms.Label lblEditEmail;
        private System.Windows.Forms.TextBox txtEditMobileNo;
        private System.Windows.Forms.TextBox txtEditPostcode;
        private System.Windows.Forms.TextBox txtEditCounty;
        private System.Windows.Forms.TextBox txtEditTown;
        private System.Windows.Forms.TextBox txtEditStreet;
        private System.Windows.Forms.TextBox txtEditForename;
        private System.Windows.Forms.Label lblEditDisplayStaffNo;
        private System.Windows.Forms.Label lblEditMobileNo;
        private System.Windows.Forms.Label lblEditPostcode;
        private System.Windows.Forms.Label lblEditCounty;
        private System.Windows.Forms.Label lblEditTown;
        private System.Windows.Forms.Label lblEditStreet;
        private System.Windows.Forms.Label lblEditForename;
        private System.Windows.Forms.Label lblEditSurname;
        private System.Windows.Forms.Label lblEditStaffNo;
        private System.Windows.Forms.Label lblEditEdit;
        private System.Windows.Forms.Button btnEditEdit;
        private System.Windows.Forms.TextBox txtEditSurname;
        private System.Windows.Forms.ComboBox cmbCounty;
        private System.Windows.Forms.Label lblSearchOptions;
    }
}
