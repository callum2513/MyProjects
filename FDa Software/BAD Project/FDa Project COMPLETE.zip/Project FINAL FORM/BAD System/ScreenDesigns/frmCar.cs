﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScreenDesigns
{
    public partial class frmCar : Form
    {
		SqlDataAdapter daCar, daMake, daSearch, daOrderDetails, daFinanceAgreement2;
		DataSet dsDesmonds = new DataSet();
        DataTable dtDesmonds = new DataTable();
        SqlCommandBuilder cmdBCar, cmdBMake, cmdBSearch, cmdBOrderDet, cmdBFinanceAgreement2;
        DataRow drCar;
		String connStr, sqlCar, sqlMake, sqlOrderDetails, sqlFinanceDetails2;
		int selectedTab = 0, tabCount = 0;
		bool carSelected = false;
		string carRegSelected = "", connSearch;


        Color clrTheme = Color.FromArgb(50, 115, 165);

		public frmCar()
        {
            InitializeComponent();
            dtpAddCarYear.Format = DateTimePickerFormat.Custom;
            dtpAddCarYear.CustomFormat = "yyyy";
            dtpAddCarYear.ShowUpDown = true;

            dtpEditCarYear.Format = DateTimePickerFormat.Custom;
            dtpEditCarYear.CustomFormat = "yyyy";
            dtpEditCarYear.ShowUpDown = true;
        }
		private void frmCar_Shown(object sender, EventArgs e)
		{
			tabCar.TabPages[0].CausesValidation = true;
			tabCar.TabPages[0].Validating += new CancelEventHandler(AddTabValidate);
		}
		private void frmCar_Load(object sender, EventArgs e)
        {
			connStr = @"Data Source = .; Initial Catalog = desmonds; Integrated Security = true";
            

			sqlCar = @"select * from car";
			daCar = new SqlDataAdapter(sqlCar, connStr);
			cmdBCar = new SqlCommandBuilder(daCar);
			daCar.FillSchema(dsDesmonds, SchemaType.Source, "Car");
			daCar.Fill(dsDesmonds, "Car"); // Naming the table in VS //

            sqlMake = @"select DISTINCT MakeID, MakeDesc from make";
            daMake = new SqlDataAdapter(sqlMake, connStr);
            cmdBMake = new SqlCommandBuilder(daMake);
            daMake.FillSchema(dsDesmonds, SchemaType.Source, "Make");
            daMake.Fill(dsDesmonds, "Make"); // Naming the table in VS //

            sqlOrderDetails = @"SELECT * FROM orderDetails";
            daOrderDetails = new SqlDataAdapter(sqlOrderDetails, connStr);
            cmdBOrderDet = new SqlCommandBuilder(daOrderDetails);
            daOrderDetails.FillSchema(dsDesmonds, SchemaType.Source, "OrderDetails");
            daOrderDetails.Fill(dsDesmonds, "OrderDetails");

            sqlFinanceDetails2 = @"SELECT * FROM financeAgreement";
            daFinanceAgreement2 = new SqlDataAdapter(sqlFinanceDetails2, connStr);
            cmdBFinanceAgreement2 = new SqlCommandBuilder(daFinanceAgreement2);
            daFinanceAgreement2.FillSchema(dsDesmonds, SchemaType.Source, "financeAgreement2");
            daFinanceAgreement2.Fill(dsDesmonds, "financeAgreement2");



            dgvCar.DataSource = dsDesmonds.Tables["Car"];
			// Resize the dgv columns to fit the newly loaded content //
			dgvCar.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

          
            cmbAddCarMake.DataSource = dsDesmonds.Tables["Make"];
            cmbAddCarMake.DisplayMember = "MakeDesc";
            cmbAddCarMake.ValueMember = "MakeID";

            tabCar.SelectedIndex = 1;
			tabCar.SelectedIndex = 0;

            cmbAddCarMake.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbAddCarTransmission.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbAddCarBody.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbAddCarCondition.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbAddCarDoorNo.DropDownStyle = ComboBoxStyle.DropDownList;

            cmbEditCarMake.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbEditCarTransmission.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbEditCarBody.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbEditCarCondition.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbEditCarDoorNo.DropDownStyle = ComboBoxStyle.DropDownList;

            
        }

       // For Button Click events //
        private void btnCarAdd_Click(object sender, EventArgs e)
		{
			tabCar.SelectedIndex = 1;
		}
		private void btnCarEdit_Click(object sender, EventArgs e)
		{
			tabCar.SelectedIndex = 2;
		}
		private void btnCarDelete_Click(object sender, EventArgs e)
		{
            if (dgvCar.SelectedRows.Count == 0)
			{
				MessageBox.Show("Please select a car from the list", "Car");
			}
			else
			{
                bool okDelete = true;
                foreach (DataRow dr in dsDesmonds.Tables["orderDetails"].Rows)
                {
                    if (dr["regNo"].ToString() == dgvCar.SelectedRows[0].Cells[0].Value.ToString())
                    {
                        okDelete = false;
                    }
                }

                foreach (DataRow dr in dsDesmonds.Tables["financeAgreement2"].Rows)
                {
                    if (dr["regNo"].ToString() == dgvCar.SelectedRows[0].Cells[0].Value.ToString())
                    {
                        okDelete = false;
                    }
                }


                if (okDelete == true)
                {
                    drCar = dsDesmonds.Tables["Car"].Rows.Find(dgvCar.SelectedRows[0].Cells[0].Value);
                    string tempName = drCar["MakeID"].ToString() + " " + drCar["Model"].ToString() + "\'s";

                    if (MessageBox.Show("Are you sure you want to delete " + tempName + " details?", "Delete Car", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                    {

                        drCar.Delete();
                        daCar.Update(dsDesmonds, "Car");
                    }
                }
                else
                    MessageBox.Show("Car can't be deleted as it is linked to an order and/or Finance Agreement");
            }
		}
		private void btnCarExit_Click(object sender, EventArgs e)
		{
			System.Windows.Forms.Application.Exit();
		}
     
        private void btnAddCarReset_Click(object sender, EventArgs e)
        {

        }
        private void btnEditCarEdit_Click(object sender, EventArgs e)
        {
            if (lblEditCarEdit.Text == "Edit")
            {
                txtAddCarReg.Enabled = true;
                cmbEditCarMake.Enabled = true;
                txtEditCarModel.Enabled = true;
                txtEditCarInterior.Enabled = true;
                cmbEditCarTransmission.Enabled = true;
                cmbEditCarBody.Enabled = true;
                txtEditCarColour.Enabled = true;
                cmbEditCarCondition.Enabled = true;
                dtpEditCarYear.Enabled = true;
                cmbEditCarDoorNo.Enabled = true;
                txtEditCarMileage.Enabled = true;
                txtEditCarPurchasePrice.Enabled = true;
                txtEditCarSalePrice.Enabled = true;

                lblEditCarEdit.Text = "Save";
            }
            else
            {
                MyCar myCar = new MyCar();
                bool Ok = true;
                errP.Clear();

                try
                {
                    myCar.RegNo = txtEditCarRegNo.Text.Trim(); // passed to car class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(txtEditCarRegNo, MyEx.toString());
                }

                try
                {
                    myCar.MakeID = cmbEditCarMake.Text.Trim(); // passed to car class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(cmbEditCarMake, MyEx.toString());
                }

                try
                {
                    myCar.Model = txtEditCarModel.Text.Trim(); // passed to car class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(txtEditCarModel, MyEx.toString());
                }

                try
                {
                    myCar.Interior = txtEditCarInterior.Text.Trim(); // passed to car class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(txtEditCarInterior, MyEx.toString());
                }

                try
                {
                    myCar.Transmission = cmbEditCarTransmission.Text.Trim(); // passed to car class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(cmbEditCarTransmission, MyEx.toString());
                }
                try
                {
                    myCar.BodyStyle = cmbEditCarBody.Text.Trim(); // passed to car class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(cmbEditCarBody, MyEx.toString());
                }
                try
                {
                    myCar.Colour = txtEditCarColour.Text.Trim(); // passed to car class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(txtEditCarColour, MyEx.toString());
                }

                try
                {
                    myCar.Condition = cmbEditCarCondition.Text.Trim(); // passed to car class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(cmbEditCarCondition, MyEx.toString());
                }

                try
                {
                    myCar.ModelYear = dtpEditCarYear.Text.Trim(); // passed to car class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(dtpEditCarYear, MyEx.toString());
                }

                try
                {
                    myCar.DoorNo = cmbEditCarDoorNo.Text.Trim(); // passed to car class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(cmbEditCarDoorNo, MyEx.toString());
                }
                try
                {
                    myCar.Mileage = int.Parse(txtEditCarMileage.Text.Trim()); // passed to car class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(txtEditCarMileage, MyEx.toString());
                }

                try
                {
                    myCar.PurchasePrice = Double.Parse(txtEditCarPurchasePrice.Text.Trim()); // passed to car class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(txtEditCarPurchasePrice, MyEx.toString());
                }

                try
                {
                    myCar.SalePrice = Double.Parse(txtEditCarSalePrice.Text.Trim()); // passed to car class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(txtEditCarSalePrice, MyEx.toString());
                }

                try
                {
                    if (Ok)
                    {
                        drCar.BeginEdit();

                        drCar["RegNo"] = myCar.RegNo;
                        drCar["MakeID"] = myCar.MakeID;
                        drCar["Model"] = myCar.Model;
                        drCar["SalePrice"] = myCar.SalePrice;
                        drCar["Interior"] = myCar.Interior;
                        drCar["Transmission"] = myCar.Transmission;
                        drCar["BodyStyle"] = myCar.BodyStyle;
                        drCar["Colour"] = myCar.Colour;
                        drCar["Mileage"] = myCar.Mileage;
                        drCar["Condition"] = myCar.Condition;
                        drCar["ModelYear"] = myCar.ModelYear;
                        drCar["PurchasePrice"] = myCar.PurchasePrice;
                        drCar["DoorNo"] = myCar.DoorNo;


                        drCar.EndEdit();
                        daCar.Update(dsDesmonds, "Car");
                        MessageBox.Show("Car Details Updated", "Car");

                        MessageBox.Show("Car Edit Complete");

                        cmbEditCarMake.Enabled = false;
                        txtEditCarModel.Enabled = false;
                        txtEditCarInterior.Enabled = false;
                        cmbEditCarTransmission.Enabled = false;
                        cmbEditCarBody.Enabled = false;
                        txtEditCarColour.Enabled = false;
                        cmbEditCarCondition.Enabled = false;
                        dtpEditCarYear.Enabled = false;
                        cmbEditCarDoorNo.Enabled = false;
                        txtEditCarMileage.Enabled = false;
                        txtEditCarPurchasePrice.Enabled = false;
                        txtEditCarSalePrice.Enabled = false;

                        lblEditCarEdit.Text = "Edit";
                        tabCar.SelectedIndex = 0;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("" + ex.TargetSite + "" + ex.Message, "Error!", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
                }
            }
        }

        // Custom Methods //
        void clearAddForm()
        {
            txtAddCarReg.Clear();
            cmbAddCarMake.SelectedIndex = -1;
            txtAddCarModel.Clear();
            txtAddCarInterior.Clear();
            cmbAddCarTransmission.SelectedIndex = -1;
            cmbAddCarBody.SelectedIndex = -1;
            txtAddCarColour.Clear();
            cmbAddCarCondition.SelectedIndex = -1;
            dtpAddCarYear.ResetText();
            cmbAddCarDoorNo.SelectedIndex = -1;
            txtAddCarMileage.ResetText();
            txtAddCarPurchasePrice.Clear();
            txtAddCarSalePrice.Clear();
        }
        void AddTabValidate(object sender, CancelEventArgs e)
        {
            if (dgvCar.SelectedRows.Count == 0)
            {
                carSelected = false;
                carRegSelected = "";
            }
            else if (dgvCar.SelectedRows.Count == 1)
            {
                carSelected = true;
                carRegSelected = dgvCar.SelectedRows[0].Cells[0].Value.ToString();
            }
        }
        void EditTabValidate(object sender, CancelEventArgs e)
        {
            if (carSelected == false && carRegSelected == "")
            {
                // have to do this bit //
                // reset tab to display and put out a message to select customer
                carSelected = false;
                carRegSelected = "";
            }
            else if (dgvCar.SelectedRows.Count == 1)
            {
                carSelected = true;
                carRegSelected = dgvCar.SelectedRows[0].Cells[0].ToString();
            }
        }
        void clearTxtError()
        {
            txtAddCarReg.BackColor = Color.White;
            cmbAddCarMake.BackColor = Color.White;
            txtAddCarModel.BackColor = Color.White;
            txtAddCarInterior.BackColor = Color.White;
            cmbAddCarTransmission.BackColor = Color.White;
            cmbAddCarBody.BackColor = Color.White;
            txtAddCarColour.BackColor = Color.White;
            cmbAddCarCondition.BackColor = Color.White;
            dtpAddCarYear.BackColor = Color.White;
            cmbAddCarDoorNo.BackColor = Color.White;
            txtAddCarMileage.BackColor = Color.White;
            txtAddCarPurchasePrice.BackColor = Color.White;
            txtAddCarSalePrice.BackColor = Color.White;
        }
        void searchString()
        {
            connSearch = (@"select * from car where RegNo LIKE '" +  txtSearchMake.Text + "%'");

            daSearch = new SqlDataAdapter(connSearch, connStr);
            cmdBSearch = new SqlCommandBuilder(daSearch);
            dsDesmonds.Tables["Car"].Clear();
            daSearch.FillSchema(dsDesmonds, SchemaType.Source, "Car");
            daSearch.Fill(dsDesmonds, "Car"); // Naming the table in VS /

            dgvCar.DataSource = dsDesmonds.Tables["Car"];
        }


        // Add Form Error Feedback - TextBox color changes to red if invalid //
        private void txtAddCarReg_TextChanged(object sender, EventArgs e)
        {
            if (txtAddCarReg.Text.Length == 7)
            {
                txtAddCarReg.BackColor = Color.White;
            }
            else
            {
                txtAddCarReg.BackColor = clrTheme;
            }
        }
        private void cmbAddCarMake_TextChanged(object sender, EventArgs e)
        {
            if (cmbAddCarMake.Text.Length == 0)
            { 
                cmbAddCarMake.BackColor = Color.White;
            }
            else
            {
                cmbAddCarMake.BackColor = clrTheme;
            }
        }
        private void txtAddCarModel_TextChanged(object sender, EventArgs e)
        {
            if (txtAddCarModel.Text.Length >= 2 && txtAddCarModel.Text.Length <= 20)
            {
                txtAddCarModel.BackColor = Color.White;
            }
            else
            {
                txtAddCarModel.BackColor = clrTheme;
            }
        }
        private void txtAddCarInterior_TextChanged(object sender, EventArgs e)
        {
            if (txtAddCarInterior.Text.Length >= 3 && txtAddCarInterior.Text.Length <= 20)
            {
                txtAddCarInterior.BackColor = Color.White;
            }
            else
            {
                txtAddCarInterior.BackColor = clrTheme;
            }
        }
        private void cmbAddCarTransmission_TextChanged(object sender, EventArgs e)
        {
            if (cmbAddCarTransmission.Text.Length < 6 && cmbAddCarTransmission.Text.Length > 9)
            {
                cmbAddCarTransmission.BackColor = Color.White;
            }
            else
            {
                cmbAddCarTransmission.BackColor = clrTheme;
            }
        }
        private void cmbAddCarBody_TextChanged(object sender, EventArgs e)
        {
            if (cmbAddCarBody.Text.Length < 3 && cmbAddCarBody.Text.Length > 20)
            {
                cmbAddCarBody.BackColor = Color.White;
            }
            else
            {
                cmbAddCarBody.BackColor = clrTheme;
            }
        }
        private void txtAddCarColour_TextChanged(object sender, EventArgs e)
        {
            if (txtAddCarColour.Text.Length >= 3 && txtAddCarColour.Text.Length <= 20)
            {
                txtAddCarColour.BackColor = Color.White;
            }
            else
            {
                txtAddCarColour.BackColor = clrTheme;
            }
        }
        private void cmbAddCarCondition_TextChanged(object sender, EventArgs e)
        {
            if (cmbAddCarCondition.Text.Length >= 3 && cmbAddCarCondition.Text.Length <= 5)
            {
                cmbAddCarCondition.BackColor = Color.White;
            }
            else
            {
                cmbAddCarCondition.BackColor = clrTheme;
            }
        }
        private void cmbAddCarDoorNo_TextChanged(object sender, EventArgs e)
        {
            if (cmbAddCarDoorNo.SelectedIndex == -1)
            {
                cmbAddCarDoorNo.BackColor = Color.White;
            }
            else
            {
                cmbAddCarDoorNo.BackColor = clrTheme;
            }
        }
        private void txtAddCarMileage_TextChanged(object sender, EventArgs e)
        {
            if (int.Parse(txtAddCarMileage.Text) > 0)
            {
                txtAddCarMileage.BackColor = Color.White;
            }
            else
            {
                txtAddCarMileage.BackColor = clrTheme;
            }
        }
        private void txtAddCarPurchasePrice_TextChanged(object sender, EventArgs e)
        {
            if(int.Parse(txtAddCarPurchasePrice.Text) > 0)
            {
                txtAddCarPurchasePrice.BackColor = Color.White;
            }
            else
            {
                txtAddCarPurchasePrice.BackColor = clrTheme;
            }
        }
        private void txtAddCarSalePrice_TextChanged(object sender, EventArgs e)
        {
            if (int.Parse(txtAddCarSalePrice.Text) > 0)
            {
                txtAddCarSalePrice.BackColor = Color.White;
            }
            else
            {
                txtAddCarSalePrice.BackColor = clrTheme;
            }
        }
        

       // Edit Form Error Feedback - TextBox color changes to red if invalid //
        private void txtEditCarReg_TextChanged(object sender, EventArgs e)
        {
            if (txtAddCarReg.Text.Length == 7)
            {
                txtAddCarReg.BackColor = Color.White;
            }
            else
            {
                txtAddCarReg.BackColor = clrTheme;
            }
        }
        private void cmbEditCarMake_TextChanged(object sender, EventArgs e)
        {
            if (cmbAddCarMake.Text.Length == 3)
            {
                cmbAddCarMake.BackColor = Color.White;
            }
            else
            {
                cmbAddCarMake.BackColor = clrTheme;
            }
        }
        private void txtEditCarModel_TextChanged(object sender, EventArgs e)
        {
            if (txtAddCarModel.Text.Length >= 1 || txtAddCarModel.Text.Length <= 20)
            {
                txtAddCarModel.BackColor = Color.White;
            }
            else
            {
                cmbAddCarMake.BackColor = clrTheme;
            }
        }
        private void txtEditCarInterior_TextChanged(object sender, EventArgs e)
        {
            if (txtAddCarInterior.Text.Length >= 3 || txtAddCarInterior.Text.Length <= 20)
            {
                txtAddCarInterior.BackColor = Color.White;
            }
            else
            {
                txtAddCarInterior.BackColor = clrTheme;
            }
        }
        private void cmbEditCarTransmission_TextChanged(object sender, EventArgs e)
        {
            if (cmbAddCarTransmission.Text.Length >=6 || cmbAddCarTransmission.Text.Length <=9)
            {
                cmbAddCarTransmission.BackColor = Color.White;
            }
            else
            {
                cmbAddCarTransmission.BackColor = clrTheme;
            }
        }
        private void cmbEditCarBody_TextChanged(object sender, EventArgs e)
        {
            if (cmbAddCarBody.Text.Length >= 3 || cmbAddCarBody.Text.Length <= 20)
            {
                cmbAddCarBody.BackColor = Color.White;
            }
            else
            {
                cmbAddCarBody.BackColor = clrTheme;
            }
        }
        private void txtEditCarColour_TextChanged(object sender, EventArgs e)
        {
            if (txtAddCarColour.Text.Length >= 3 || txtAddCarColour.Text.Length <= 20)
            {
                txtAddCarColour.BackColor = Color.White;
            }
            else
            {
                txtAddCarColour.BackColor = clrTheme;
            }
        }
        private void cmbEditCarCondition_TextChanged(object sender, EventArgs e)
        {
            if (cmbAddCarCondition.Text.Length >= 3 || cmbAddCarCondition.Text.Length <= 5)
            {
                cmbAddCarCondition.BackColor = Color.White;
            }
            else
            {
                cmbAddCarCondition.BackColor = clrTheme;
            }
        }

        private void btnCarHome_Click(object sender, EventArgs e)
        {
            GlobalVar.tradeInCar = false;
            this.Hide();
            frmMainMenu menuForm = new frmMainMenu();
            menuForm.ShowDialog();
        }

        private void dgvCar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lblSearchReg_Click(object sender, EventArgs e)
        {

        }

        private void btnAddCarAdd_Click(object sender, EventArgs e)
        {
            MyCar myCar = new MyCar();
            bool Ok = true;
            String invalMessage = "Invalid data entry for: ";
            errP.Clear();


            foreach (DataRow dr in dsDesmonds.Tables["Car"].Rows)
            {
                if (dr["regNo"].ToString() == txtAddCarReg.Text.Trim())
                {
                    Ok = false;
                    errP.SetError(txtAddCarReg, ("RegNo already exists, please enter another"));
                }
            }

            try
            {
                myCar.RegNo = txtAddCarReg.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtAddCarReg, MyEx.toString());
            }

            try
            {
                if (cmbAddCarMake.SelectedIndex != -1)
                {
                    myCar.MakeID = cmbAddCarMake.SelectedValue.ToString(); // passed to car class to check //
                }
                else
                    throw new MyException("Please select a car Make");
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(cmbAddCarMake, MyEx.toString());
            }

            try
            {
                myCar.Model = txtAddCarModel.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtAddCarModel, MyEx.toString());
            }

            try
            {
                myCar.Interior = txtAddCarInterior.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtAddCarInterior, MyEx.toString());
            }

            try
            {
                myCar.Transmission = cmbAddCarTransmission.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(cmbAddCarTransmission, MyEx.toString());
            }
            try
            {
                myCar.BodyStyle = cmbAddCarBody.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(cmbAddCarBody, MyEx.toString());
            }
            try
            {
                myCar.Colour = txtAddCarColour.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtAddCarColour, MyEx.toString());
            }

            try
            {
                myCar.Condition = cmbAddCarCondition.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(cmbAddCarCondition, MyEx.toString());
            }

            try
            {
                if (int.Parse(dtpAddCarYear.Text.Trim()) > 1900 || int.Parse(dtpAddCarYear.Text.Trim()) < DateTime.Now.Year)
                {
                    myCar.ModelYear = dtpAddCarYear.Text.Trim(); // passed to car class to check //
                }
                else 
                {
                    throw new MyException("Please enter a year between 1900 and " + DateTime.Now.Year.ToString());
                }
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(dtpAddCarYear, MyEx.toString());
            }

            try
            {
                myCar.DoorNo = cmbAddCarDoorNo.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(cmbAddCarDoorNo, MyEx.toString());
            }
            try
            {
                myCar.Mileage = int.Parse(txtAddCarMileage.Text.Trim()); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtAddCarMileage, MyEx.toString());
            }
            catch (System.FormatException)
            {
                Ok = false;
                errP.SetError(txtAddCarMileage, "Invalid Mileage");
            }

            try
            {
                myCar.PurchasePrice = Double.Parse(txtAddCarPurchasePrice.Text.Trim()); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtAddCarPurchasePrice, MyEx.toString());
            }
            catch (System.FormatException)
            {
                Ok = false;
                errP.SetError(txtAddCarPurchasePrice, "Invalid Purchase Price");
            }

            try
            {
                myCar.SalePrice = Double.Parse(txtAddCarSalePrice.Text); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                Ok = false;
                errP.SetError(txtAddCarSalePrice, MyEx.toString());
            }
            catch (System.FormatException)
            {
                Ok = false;
                errP.SetError(txtAddCarSalePrice, "Invalid Sale Price");
            }


            try
            {
                if (Ok)
                {
                    drCar = dsDesmonds.Tables["Car"].NewRow();

                    drCar["RegNo"] = myCar.RegNo;
                    drCar["MakeID"] = myCar.MakeID;
                    drCar["Model"] = myCar.Model;
                    drCar["SalePrice"] = myCar.SalePrice;
                    drCar["Interior"] = myCar.Interior;
                    drCar["Transmission"] = myCar.Transmission;
                    drCar["BodyStyle"] = myCar.BodyStyle;
                    drCar["Colour"] = myCar.Colour;
                    drCar["Mileage"] = myCar.Mileage;
                    drCar["Condition"] = myCar.Condition;
                    drCar["ModelYear"] = myCar.ModelYear;
                    drCar["PurchasePrice"] = myCar.PurchasePrice;
                    drCar["DoorNo"] = myCar.DoorNo;
                    drCar["Sold"] = 0;

                    dsDesmonds.Tables["Car"].Rows.Add(drCar);
                    daCar.Update(dsDesmonds, "Car");
                    if (GlobalVar.tradeInCar == false)
                    {
                        MessageBox.Show("Car Added");
                    }
                    else if ((GlobalVar.tradeInCar == true))
                    {
                        MessageBox.Show("Trade In Value Saved and Car has been Added");
                    }

                    if (GlobalVar.tradeInCar == false)
                    {
                        if (MessageBox.Show("Do you want to add another Car?", "Add Car", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                        {
                            errP.Clear();
                            clearAddForm();
                            clearTxtError();
                        }
                        else
                            tabCar.SelectedIndex = 0;
                    }
                    else if (GlobalVar.tradeInCar == true)
                    {
                       this.Close();
                       GlobalVar.tradeInFormClose = true;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex.TargetSite + "" + ex.Message, "Error!", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
            }

            if (GlobalVar.tradeInCar == true)
            {
                GlobalVar.purchasePriceGlobal = int.Parse(txtAddCarPurchasePrice.Text);
                this.Close();
            }
        }

        private void txtSearchSurname_TextChanged(object sender, EventArgs e)
        {
            searchString();
        }

        private void cmbEditCarDoorNo_TextChanged(object sender, EventArgs e)
        {
            if (cmbAddCarDoorNo.Text == "3" || cmbAddCarDoorNo.Text == "5")
            {
                cmbAddCarDoorNo.BackColor = Color.White;
            }
            else
            {
                cmbAddCarDoorNo.BackColor = clrTheme;
            }
        }
        private void txtEditCarMileage_TextChanged(object sender, EventArgs e)
        {
            if (txtAddCarMileage.Text.Length > 0)
                {
                    if (int.Parse(txtAddCarMileage.Text) < 1)
                {
                    txtAddCarMileage.BackColor = Color.White;
                }
                else
                {
                    txtAddCarMileage.BackColor = clrTheme;
                }
            }
        }
        private void txtEditCarPurchasePrice_TextChanged(object sender, EventArgs e)
        {
            if (txtEditCarPurchasePrice.Text.Length > 0)
            {
                if (double.Parse(txtEditCarPurchasePrice.Text) > 0)
                {
                    txtEditCarPurchasePrice.BackColor = Color.White;
                }
                else
                {
                    txtEditCarPurchasePrice.BackColor = clrTheme;
                }
            }
        }
        private void txtEditCarSalePrice_TextChanged(object sender, EventArgs e)
        {
           if (double.Parse(txtEditCarSalePrice.Text) > 0)
            {
                txtEditCarSalePrice.BackColor = Color.White;
            }
            else
            {
                txtEditCarSalePrice.BackColor = clrTheme;
            }
        }

        private void tabCar_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (GlobalVar.tradeInCar == true)
            {
                if (tabCar.SelectedIndex == 0 || tabCar.SelectedIndex == 2)
                {
                    
                    tabCar.SelectedIndex = 1;
                    if (tabCount >= 1)
                    {
                        MessageBox.Show("Error: You cannot view or edit other entries at this time. Please enter trade in details", "Enter Trade In Details");
                    }
                    tabCount++;
                }
            }
    
            selectedTab = tabCar.SelectedIndex;

            tabCar.TabPages[tabCar.SelectedIndex].Focus();
            tabCar.TabPages[tabCar.SelectedIndex].CausesValidation = true;


            switch (tabCar.SelectedIndex)
            {
                case 0:
                    {
                        txtSearchMake.Text = "";
                        dsDesmonds.Tables["Car"].Clear();
                        daCar.Fill(dsDesmonds, "Car");
                        break;
                    }

                case 1:
                    {
                        txtSearchMake.Text = "";
                        int noRows = dsDesmonds.Tables["Car"].Rows.Count;

                        errP.Clear();
                        clearAddForm();
                        clearTxtError();
                        break;
                    }

                case 2:
                    {
                        txtSearchMake.Text = "";
                        if (carRegSelected == "")
                        {
                            tabCar.SelectedIndex = 0;
                        }
                        else
                        {
                            // Sets RegNo textbox on edit page equal to the selected records //
                            txtEditCarRegNo.Text = carRegSelected.ToString();
                            // Finds the car using the selected records regNo //
                            drCar = dsDesmonds.Tables["Car"].Rows.Find(txtEditCarRegNo.Text);

                            // Checks to see which Make ID code matches the selected record and changes the combo box to the appropriate index //
                            if (drCar["MakeID"].ToString() == "FRD")
                            {
                                cmbEditCarMake.SelectedIndex = 0;
                            }
                            else if (drCar["MakeID"].ToString() == "REN")
                            {
                                cmbEditCarMake.SelectedIndex = 1;
                            }
                            else if (drCar["MakeID"].ToString() == "AUD")
                            {
                                cmbEditCarMake.SelectedIndex = 2;
                            }
                            else if (drCar["MakeID"].ToString() == "NIS")
                            {
                                cmbEditCarMake.SelectedIndex = 3;
                            }
                            else if (drCar["MakeID"].ToString() == "HON")
                            {
                                cmbEditCarMake.SelectedIndex = 4;
                            }
                            else if (drCar["MakeID"].ToString() == "FIA")
                            {
                                cmbEditCarMake.SelectedIndex = 5;
                            }

                            // Sets model textbox on edit page equal to the selected records //
                            txtEditCarModel.Text = drCar["Model"].ToString();
                            // Sets interior textbox on edit page equal to the selected records //
                            txtEditCarInterior.Text = drCar["Interior"].ToString();

                            // Checks to see which transmission matches the selected record and changes the combo box to the appropriate index //
                            if (drCar["Transmission"].ToString() == "Manual")
                            {
                                cmbEditCarTransmission.SelectedIndex = 0;
                            }
                            else if (drCar["Transmission"].ToString() == "Automatic")
                            {
                                cmbEditCarTransmission.SelectedIndex = 1;
                            }

                            // Checks to see which Body Style matches the selected record and changes the combo box to the appropriate index //
                            if (drCar["BodyStyle"].ToString() == "Sedan")
                            {
                                cmbEditCarBody.SelectedIndex = 0;
                            }
                            else if (drCar["BodyStyle"].ToString() == "Coupe")
                            {
                                cmbEditCarBody.SelectedIndex = 1;
                            }
                            else if (drCar["BodyStyle"].ToString() == "SUV")
                            {
                                cmbEditCarBody.SelectedIndex = 2;
                            }
                            else if (drCar["BodyStyle"].ToString() == "Hatchback")
                            {
                                cmbEditCarBody.SelectedIndex = 3;
                            }
                            else if (drCar["BodyStyle"].ToString() == "Sport")
                            {
                                cmbEditCarBody.SelectedIndex = 4;
                            }
                            else if (drCar["BodyStyle"].ToString() == "Van")
                            {
                                cmbEditCarBody.SelectedIndex = 5;
                            }

                            // Sets colour textbox on edit page equal to the selected records //
                            txtEditCarColour.Text = drCar["Colour"].ToString();

                            // Checks to see which Conidition matches the selected record and changes the combo box to the appropriate index //
                            if (drCar["Condition"].ToString() == "New")
                            {
                                cmbEditCarCondition.SelectedIndex = 0;
                            }
                            else if (drCar["Condition"].ToString() == "Used")
                            {
                                cmbEditCarCondition.SelectedIndex = 1;
                            }

                            // How to fill year on edit page when select a car //

                            // Checks to see which DoorNo matches the selected record and changes the combo box to the appropriate index //
                            if (drCar["DoorNo"].ToString() == "3")
                            {
                                cmbEditCarDoorNo.SelectedIndex = 0;
                            }
                            else if (drCar["DoorNo"].ToString() == "5")
                            {
                                cmbEditCarDoorNo.SelectedIndex = 1;
                            }

                            // Sets Mileage textbox on edit page equal to the selected records //
                            txtEditCarMileage.Text = drCar["Mileage"].ToString();

                            // Sets Purchase Price textbox on edit page equal to the selected records //
                            txtEditCarPurchasePrice.Text = drCar["PurchasePrice"].ToString();

                            // Sets Sale Price textbox on edit page equal to the selected records //
                            txtEditCarSalePrice.Text = drCar["SalePrice"].ToString();
                        }
                        break;
                    }
            }
        }
    }
}
