﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScreenDesigns
{
    public partial class frmSales : Form
    {
        double carPrice = 0, carDeposit = 0, tradeValue = 0, interestRate = 0, costNoInterest = 0, costWithInterest = 0, totalInterest = 0, numPayments = 0, monthlyPayment = 0;

        Button[] btns = new Button[26];
        String sqlNames, sqlCustomerDetails, sqlCustomerDetails2, sqlCarDetails, sqlOrders, sqlOrderDetails, sqlFinanceDetails, sqlFinanceDetails2;
        String strCarReg = "";
        string financeNoSelected = "";
        bool financeSelected = false;

        SqlDataAdapter daNames, daCustomers, daCustomers2, daCars, daOrders, daOrderDetails, daFinanceAgreement, daFinanceAgreement2;
        DataSet dsDesmonds = new DataSet();
        SqlConnection conn;
        String connStr;

        SqlCommand cmdCustomerDetails, cmdCustomerDetails2;
        SqlCommandBuilder cmdBCustomer2, cmdBOrder, cmdBOrderDet, cmdBFinanceAgreement, cmdBFinanceAgreement2, cmdBCars;

        DataRow drOrder, drCustomer, drCar, drFinanceAgreement;

        private void cmbFinancePlanLengthEdit_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            

            if (cmbFinancePlanLengthEdit.SelectedIndex == 0)
            {
                lblFinanceNumPaymentsEdit.Text = "12";
            }
            else if (cmbFinancePlanLengthEdit.SelectedIndex == 1)
            {
                lblFinanceNumPaymentsEdit.Text = "24";
            }
            else if (cmbFinancePlanLengthEdit.SelectedIndex == 2)
            {
                lblFinanceNumPaymentsEdit.Text = "36";
            }
            else if (cmbFinancePlanLengthEdit.SelectedIndex == 3)
            {
                lblFinanceNumPaymentsEdit.Text = "48";
            }
            else if (cmbFinancePlanLengthEdit.SelectedIndex == 4)
            {
                lblFinanceNumPaymentsEdit.Text = "60";
            }

            object[] pk = new object[2];

            pk[0] = dgvFinanceAgreements.SelectedRows[0].Cells[0].Value;
            pk[1] = dgvFinanceAgreements.SelectedRows[0].Cells[1].Value;


            drCar = dsDesmonds.Tables["Car"].Rows.Find(dgvFinanceAgreements.CurrentRow.Cells[1].Value.ToString());
            drFinanceAgreement = dsDesmonds.Tables["FinanceAgreement2"].Rows.Find(pk);

            carPrice = double.Parse(drCar["SalePrice"].ToString());
            lblFinancePriceEdit.Text = carPrice.ToString();
            carDeposit = double.Parse(drFinanceAgreement["Deposit"].ToString());
            tradeValue = double.Parse(drFinanceAgreement["TradeInValue"].ToString());
            interestRate = double.Parse(drFinanceAgreement["InterestRate"].ToString()) + 1;

            costNoInterest = ((carPrice - carDeposit) - tradeValue);
            costWithInterest = ((carPrice - carDeposit) - tradeValue) * interestRate;
            totalInterest = costWithInterest - costNoInterest;

            numPayments = int.Parse(lblFinanceNumPaymentsEdit.Text);
            monthlyPayment = costWithInterest / numPayments;


            lblFinanceTotalInterestEdit.Text = costWithInterest.ToString();
            lblFinanceTotalNoInterestEdit.Text = costNoInterest.ToString();
            lblFinanceInterestDueEdit.Text = totalInterest.ToString();
            lblFinanceMonthlyPaymentEdit.Text = monthlyPayment.ToString();

           
        }

        private void frmSales_Activated(object sender, EventArgs e)
        {
            lblCarTradeValue.Text = GlobalVar.purchasePriceGlobal.ToString();
        }


        private void btnSalesDelete_Click(object sender, EventArgs e)
        {
            if (dgvFinanceAgreements.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a Finance Agreement from the list", "Car");
            }
            else
            {
                financeNoSelected = dgvFinanceAgreements.SelectedRows[0].Cells[0].Value.ToString();
                strCarReg = dgvFinanceAgreements.SelectedRows[0].Cells[1].Value.ToString();

                Object[] args = new object[2];
                args[0] = financeNoSelected;
                args[1] = strCarReg;


                drFinanceAgreement = dsDesmonds.Tables["financeAgreement2"].Rows.Find(args);

                string tempName = drFinanceAgreement["FinanceID"].ToString();

                if (MessageBox.Show("Are you sure you want to delete Finance Agreement : " + tempName, "Delete FinanceAgreement", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                {
                    drFinanceAgreement.Delete();
                    daFinanceAgreement2.Update(dsDesmonds, "Car");
                }
            }
        }

        private void txtFinanceDepositEdit_ValueChanged(object sender, EventArgs e)
        {
            financeNoSelected = dgvFinanceAgreements.SelectedRows[0].Cells[0].Value.ToString();
            strCarReg = dgvFinanceAgreements.SelectedRows[0].Cells[1].Value.ToString();

            Object[] args = new object[2];
            args[0] = financeNoSelected;
            args[1] = strCarReg;

            drCar = dsDesmonds.Tables["Car"].Rows.Find(dgvFinanceAgreements.CurrentRow.Cells[1].Value.ToString());
            drFinanceAgreement = dsDesmonds.Tables["financeAgreement2"].Rows.Find(args);



            carPrice = double.Parse(drCar["SalePrice"].ToString());
            lblFinancePriceEdit.Text = carPrice.ToString();
            carDeposit = double.Parse(txtFinanceDepositEdit.Value.ToString());
            tradeValue = double.Parse(drFinanceAgreement["TradeInValue"].ToString());
            interestRate = double.Parse(drFinanceAgreement["InterestRate"].ToString()) + 1;

            costNoInterest = ((carPrice - carDeposit) - tradeValue);
            costWithInterest = ((carPrice - carDeposit) - tradeValue) * interestRate;
            totalInterest = costWithInterest - costNoInterest;

            numPayments = GlobalVar.noOfMonths;
            monthlyPayment = costWithInterest / numPayments;


            lblFinanceTotalInterestEdit.Text = costWithInterest.ToString("0.00");
            lblFinanceTotalNoInterestEdit.Text = costNoInterest.ToString("0.00");
            lblFinanceInterestDueEdit.Text = totalInterest.ToString("0.00");
            lblFinanceMonthlyPaymentEdit.Text = monthlyPayment.ToString("0.00");

            //HERE ARE THE CHECKS AND VALIDATION YOU HAVE TO DO YOU  //
            double check1 = 0, check2 = 0, check3 = 0, check4 = 0;
           check1 = double.Parse(lblFinanceTotalInterestEdit.Text);

            if (check1 <= 0)
            {
                MessageBox.Show("CANNOT BE 0 OR BELOW");
            }
        }

        private void btnEditFinanceEdit_Click(object sender, EventArgs e)
        {
            if (lblEditFinanceEdit.Text == "Edit")
            {
                cmbFinancePlanLengthEdit.Enabled = true;
                txtFinanceDepositEdit.Enabled = true;

                lblEditFinanceEdit.Text = "Save";
            }
            else
            {
                MyFinanceAgreement myFinanceAgreement = new MyFinanceAgreement();
                bool okFinance = true;
                errP.Clear();

                try
                {
                    myFinanceAgreement.FinanceID = lblFinanceFinanceIDEdit.Text.Trim(); // passed to Finance agreement class to check //
                }
                catch (MyException MyEx)
                {
                    okFinance = false;
                    errP.SetError(lblFinanceFinanceIDEdit, MyEx.toString());
                }

                try
                {
                    myFinanceAgreement.RegNo = lblFinanceRegNoEdit.Text.Trim(); // passed to Finance agreement class to check //
                }
                catch (MyException MyEx)
                {
                    okFinance = false;
                    errP.SetError(lblFinanceRegNoEdit, MyEx.toString());
                }

                try
                {
                    myFinanceAgreement.AgreementDate = Convert.ToDateTime(DateTime.Now.ToShortDateString()); // passed to Finance agreement class to check //
                }
                catch (MyException MyEx)
                {
                    okFinance = false;
                    errP.SetError(lblFinanceAgreementDateEdit, MyEx.toString());
                }

                try
                {
                    myFinanceAgreement.NoOfPayments = int.Parse(lblFinanceNumPaymentsEdit.Text); // passed to Finance agreement class to check //
                }
                catch (MyException MyEx)
                {
                    okFinance = false;
                    errP.SetError(lblFinanceNumPaymentsEdit, MyEx.toString());
                }

                try
                {
                    myFinanceAgreement.MonthlyPayment = double.Parse(lblFinanceMonthlyPaymentEdit.Text); // passed to Finance agreement class to check //
                }
                catch (MyException MyEx)
                {
                    okFinance = false;
                    errP.SetError(lblFinanceMonthlyPaymentEdit, MyEx.toString());
                }

                try
                {
                    myFinanceAgreement.Deposit = double.Parse(txtFinanceDepositEdit.Text); // passed to Finance agreement class to check //
                }
                catch (MyException MyEx)
                {
                    okFinance = false;
                    errP.SetError(txtFinanceDepositEdit, MyEx.toString());
                }

                try
                {
                    myFinanceAgreement.TradeInValue = double.Parse(lblFinanceTradeInEdit.Text); // passed to Finance agreement class to check //
                }
                catch (MyException MyEx)
                {
                    okFinance = false;
                    errP.SetError(lblFinanceTradeInEdit, MyEx.toString());
                }

                try
                {
                    myFinanceAgreement.InterestRate = double.Parse(lblFinanceInterestRateEdit.Text); // passed to Finance agreement class to check //
                }
                catch (MyException MyEx)
                {
                    okFinance = false;
                    errP.SetError(lblFinanceInterestRateEdit, MyEx.toString());
                }

                try
                {
                    if (okFinance)
                    {
                        drFinanceAgreement.BeginEdit();

                        drFinanceAgreement["FinanceID"] = myFinanceAgreement.FinanceID;
                        drFinanceAgreement["RegNo"] = myFinanceAgreement.RegNo;
                        drFinanceAgreement["AgreementDate"] = myFinanceAgreement.AgreementDate;
                        drFinanceAgreement["NoOfPayments"] = myFinanceAgreement.NoOfPayments;
                        drFinanceAgreement["MonthlyPayment"] = myFinanceAgreement.MonthlyPayment;
                        drFinanceAgreement["Deposit"] = myFinanceAgreement.Deposit;
                        drFinanceAgreement["TradeInValue"] = myFinanceAgreement.TradeInValue;
                        drFinanceAgreement["InterestRate"] = myFinanceAgreement.InterestRate;

                        drFinanceAgreement.EndEdit();
                        daFinanceAgreement2.Update(dsDesmonds, "FinanceAgreement2");

                        MessageBox.Show("Finance Agreement Updated", "Finance Edit");

                        cmbFinancePlanLengthEdit.Enabled = false;
                        txtFinanceDepositEdit.Enabled = false;

                        lblEditFinanceEdit.Text = "Edit";
                        tabSales.SelectedIndex = 0;
                        GlobalVar.noOfMonths = 0;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("" + ex.TargetSite + "" + ex.Message, "Error!", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
                }
            }
        }



        // Form Events //
        public frmSales()
        {
            InitializeComponent();
        }
        private void frmSales_Load(object sender, EventArgs e)
        {
            btnSalesEdit.Enabled = false;
            btnSalesDelete.Enabled = true;
            cmbFinancePlanLength.DropDownStyle = ComboBoxStyle.DropDownList;
            lstCar.Enabled = false;
            clearSale();

            GlobalVar.tradeInFormClose = false;
            btnAddSaleReset.Enabled = true;
            lblSaleOrderDateShow.Text = DateTime.Now.ToShortDateString();

            pnlListBoxes.Enabled = true;

            for (int count = 0; count < 26; count++)
            {
                btns[count] = (Button)pnlButtons.Controls[count];
                btns[count].Text = "" + (char)(65 + count);
                btns[count].Enabled = false;
                btns[count].Click += new EventHandler(btnA_Click);
            }

            connStr = @"Data Source = .; Initial Catalog = desmonds; Integrated Security = true";
            // Get Surnames for Letter Buttons //
            sqlNames = @"Select CustSurname from customer order by CustSurname";
            daNames = new SqlDataAdapter(sqlNames, connStr);
            daNames.Fill(dsDesmonds, "Names");

            int no;
            // Enable relevant alpha buttons //
            foreach (DataRow dr in dsDesmonds.Tables["Names"].Rows)
            {
                no = (int)dr["CustSurname"].ToString()[0] - 65; // -65 to get the index of the button, enables and disables buttons and changes colour //
                btns[no].Enabled = true;
                btns[no].BackColor = Color.Transparent;
                btns[no].ForeColor = Color.FromArgb(50, 115, 165);
            }


            sqlCustomerDetails = @"Select CustID, CustTitle, CustForename, CustSurname, CustSurname + ',' + CustForename as name, CustStreet, CustTown, CustCounty, CustPostcode, CreditRating, TelNo, CustEmail FROM customer WHERE CustSurname LIKE @Letter order by CustSurname, CustForename";
            conn = new SqlConnection(connStr);
            cmdCustomerDetails = new SqlCommand(sqlCustomerDetails, conn);
            cmdCustomerDetails.Parameters.Add("@Letter", SqlDbType.VarChar);
            daCustomers = new SqlDataAdapter(cmdCustomerDetails);
            daCustomers.FillSchema(dsDesmonds, SchemaType.Source, "customer");

            sqlCustomerDetails2 = @"SELECT * FROM customer";
            daCustomers2 = new SqlDataAdapter(sqlCustomerDetails2, conn);
            cmdBCustomer2 = new SqlCommandBuilder(daCustomers2);
            daCustomers2.FillSchema(dsDesmonds, SchemaType.Source, "customer2");
            daCustomers2.Fill(dsDesmonds, "customer2");


            sqlOrders = @"SELECT * FROM orders";
            daOrders = new SqlDataAdapter(sqlOrders, conn);
            cmdBOrder = new SqlCommandBuilder(daOrders);
            daOrders.FillSchema(dsDesmonds, SchemaType.Source, "Orders");
            daOrders.Fill(dsDesmonds, "Orders");

            sqlOrderDetails = @"SELECT * FROM orderDetails";
            daOrderDetails = new SqlDataAdapter(sqlOrderDetails, conn);
            cmdBOrderDet = new SqlCommandBuilder(daOrderDetails);
            daOrderDetails.FillSchema(dsDesmonds, SchemaType.Source, "OrderDetails");
            daOrderDetails.Fill(dsDesmonds, "OrderDetails");

            sqlCarDetails = @"SELECT * FROM car";
            daCars = new SqlDataAdapter(sqlCarDetails, conn);
            cmdBCars = new SqlCommandBuilder(daCars);
            daCars.FillSchema(dsDesmonds, SchemaType.Source, "Car");
            daCars.Fill(dsDesmonds, "Car");

            sqlFinanceDetails2 = @"SELECT * FROM financeAgreement";
            daFinanceAgreement2 = new SqlDataAdapter(sqlFinanceDetails2, conn);
            cmdBFinanceAgreement2 = new SqlCommandBuilder(daFinanceAgreement2);
            daFinanceAgreement2.FillSchema(dsDesmonds, SchemaType.Source, "financeAgreement2");
            daFinanceAgreement2.Fill(dsDesmonds, "financeAgreement2");

            sqlFinanceDetails = @"SELECT fa.FinanceID, fa.RegNo, cst.CustID, cst.CustSurname + ',' + cst.CustForename as name, cst.CustStreet, cst.CustTown, cst.CustCounty, cst.CustPostcode, cst.CreditRating, cst.TelNo, cst.CustEmail, fa.AgreementDate, fa.NoOfPayments, fa.MonthlyPayment, fa.Deposit, fa.TradeInValue, fa.InterestRate, c.MakeID, c.Model, c.Colour, c. Mileage, c.Transmission, c.Interior, c.BodyStyle, c.SalePrice FROM financeAgreement fa
            JOIN car c ON fa.RegNo = c.RegNo
            JOIN orderDetails od ON c.RegNo = od.RegNo
            JOIN orders o ON od.OrderID = o.OrderID
            JOIN customer cst ON o.CustID = cst.CustID order by fa.FinanceID ASC";
            daFinanceAgreement = new SqlDataAdapter(sqlFinanceDetails, conn);
            cmdBFinanceAgreement = new SqlCommandBuilder(daFinanceAgreement);
            daFinanceAgreement.FillSchema(dsDesmonds, SchemaType.Source, "financeAgreement");
            daFinanceAgreement.Fill(dsDesmonds, "financeAgreement");


            int noRows = dsDesmonds.Tables["Orders"].Rows.Count;

            if (noRows == 0)
            {
                lblSaleOrderNoShow.Text = "OD100000";
            }
            else
            {
                getTotalNumOrders(noRows);
            }

            dgvOrders.DataSource = dsDesmonds.Tables["Orders"];
            // Resize the dgv columns to fit the newly loaded content //
            dgvOrders.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

            //////////////////// HERE //////////////////// //////////////////// HERE ////////////////////V//////////////////// HERE //////////////////////////////////////// HERE ////
            dgvFinanceAgreements.DataSource = dsDesmonds.Tables["FinanceAgreement2"];
            // Resize the dgv columns to fit the newly loaded content //
            dgvFinanceAgreements.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

        }
        private void btnCarEdit_Click(object sender, EventArgs e)
        {
            tabSales.SelectedIndex = 4;
        }
        private void btnFinanceSubmit_Click(object sender, EventArgs e)
        {
            GlobalVar.addFinance = false;
            GlobalVar.noOfMonths = int.Parse(lblFinanceNumPaymentsShow.Text);

            MySales myOrders = new MySales();
            bool OkOrder = true;
            String invalMessage = "Invalid data entry for: ";
            errP.Clear();

            try
            {
                myOrders.OrderID = lblSaleOrderNoShow.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                OkOrder = false;
                errP.SetError(lblSaleOrderNoShow, MyEx.toString());
            }

            try
            {
                myOrders.OrderDate = Convert.ToDateTime(DateTime.Now.ToShortDateString()); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                OkOrder = false;
                errP.SetError(lblSaleOrderDateShow, MyEx.toString());
            }

            try
            {
                myOrders.CustID = lblSaleCustNoShow.Text.Trim(); // passed to car class to check //
            }
            catch (MyException MyEx)
            {
                OkOrder = false;
                errP.SetError(lblSaleCustNoShow, MyEx.toString());
            }

            try
            {
                if (rbCash.Checked == true)
                {
                    myOrders.PaymentTypeID = 1;
                }
                if (rbCard.Checked == true)
                {
                    myOrders.PaymentTypeID = 2;
                }
                if (rbFinance.Checked == true)
                {
                    myOrders.PaymentTypeID = 3;
                }
                if (rbCheque.Checked == true)
                {
                    myOrders.PaymentTypeID = 4;
                }

            }
            catch (MyException MyEx)
            {
                OkOrder = false;
                errP.SetError(rbCash, MyEx.toString());
                errP.SetError(rbCard, MyEx.toString());
                errP.SetError(rbFinance, MyEx.toString());
                errP.SetError(rbCheque, MyEx.toString());
            }

            try
            {
                if (OkOrder)
                {
                    drCar.BeginEdit();
                    drCar["Sold"] = 1;
                    drCar.EndEdit();
                    daCars.Update(dsDesmonds, "Car");

                    drOrder = dsDesmonds.Tables["Orders"].NewRow();

                    drOrder["OrderID"] = myOrders.OrderID;
                    drOrder["OrderDate"] = myOrders.OrderDate;
                    drOrder["CustID"] = myOrders.CustID;
                    drOrder["PaymentTypeID"] = myOrders.PaymentTypeID;

                    dsDesmonds.Tables["Orders"].Rows.Add(drOrder);
                    daOrders.Update(dsDesmonds, "Orders");

                    MessageBox.Show("Order Added");

                    clearSale();
                    tabSales.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex.TargetSite + "" + ex.Message, "Error!", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
            }


            /////////////////////// ADDING FINANCE AGREEMENT ///////////////////////
            bool okAgreement = true;
            MyFinanceAgreement myFinanceAgreement = new MyFinanceAgreement();
            errP.Clear();

            try
            {
                myFinanceAgreement.FinanceID = lblFinanceAgreementIDShow.Text.Trim(); // passed to Finance agreement class to check //
            }
            catch (MyException MyEx)
            {
                okAgreement = false;
                errP.SetError(lblFinanceAgreementIDShow, MyEx.toString());
            }

            try
            {
                myFinanceAgreement.RegNo = lblFinanceRegNoShow.Text.Trim(); // passed to Finance agreement class to check //
            }
            catch (MyException MyEx)
            {
                okAgreement = false;
                errP.SetError(lblFinanceRegNoShow, MyEx.toString());
            }

            try
            {
                myFinanceAgreement.AgreementDate = Convert.ToDateTime(DateTime.Now.ToShortDateString()); // passed to Finance agreement class to check //
            }
            catch (MyException MyEx)
            {
                okAgreement = false;
                errP.SetError(lblFinanceAgreeDateShow, MyEx.toString());
            }

            try
            {
                myFinanceAgreement.NoOfPayments = GlobalVar.noOfMonths; // passed to Finance agreement class to check //
            }
            catch (MyException MyEx)
            {
                okAgreement = false;
                errP.SetError(lblFinanceNumPaymentsShow, MyEx.toString());
            }

            try
            {
                myFinanceAgreement.MonthlyPayment = double.Parse(lblFinanceMonthlyPaymentShow.Text); // passed to Finance agreement class to check //
            }
            catch (MyException MyEx)
            {
                okAgreement = false;
                errP.SetError(lblFinanceMonthlyPaymentShow, MyEx.toString());
            }

            try
            {
                myFinanceAgreement.Deposit = double.Parse(lblFinanceDepositShow.Text); // passed to Finance agreement class to check //
            }
            catch (MyException MyEx)
            {
                okAgreement = false;
                errP.SetError(lblFinanceDepositShow, MyEx.toString());
            }

            try
            {
                myFinanceAgreement.TradeInValue = double.Parse(lblFinanceTradeValueShow.Text); // passed to Finance agreement class to check //
            }
            catch (MyException MyEx)
            {
                okAgreement = false;
                errP.SetError(lblFinanceTradeValueShow, MyEx.toString());
            }

            try
            {
                myFinanceAgreement.InterestRate = double.Parse(lblFinanceInterestRateShow.Text); // passed to Finance agreement class to check //
            }
            catch (MyException MyEx)
            {
                okAgreement = false;
                errP.SetError(lblFinanceInterestRateShow, MyEx.toString());
            }

            try
            {
                if (okAgreement)
                {
                    drFinanceAgreement = dsDesmonds.Tables["FinanceAgreement2"].NewRow();

                    drFinanceAgreement["FinanceID"] = myFinanceAgreement.FinanceID;
                    drFinanceAgreement["RegNo"] = myFinanceAgreement.RegNo;
                    drFinanceAgreement["AgreementDate"] = myFinanceAgreement.AgreementDate;
                    drFinanceAgreement["NoOfPayments"] = myFinanceAgreement.NoOfPayments;
                    drFinanceAgreement["MonthlyPayment"] = myFinanceAgreement.MonthlyPayment;
                    drFinanceAgreement["Deposit"] = myFinanceAgreement.Deposit;
                    drFinanceAgreement["TradeInValue"] = myFinanceAgreement.TradeInValue;
                    drFinanceAgreement["InterestRate"] = myFinanceAgreement.InterestRate;

                    dsDesmonds.Tables["FinanceAgreement2"].Rows.Add(drFinanceAgreement);
                    daFinanceAgreement2.Update(dsDesmonds, "FinanceAgreement2");

                    MessageBox.Show("Finance Agreement Added");

                    clearSale();
                    tabSales.SelectedIndex = 0;
                    GlobalVar.noOfMonths = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex.TargetSite + "" + ex.Message, "Error!", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
            }
        }
        private void frmSales_Shown(object sender, EventArgs e)
        {

            tabSales.TabPages[0].CausesValidation = true;
            tabSales.TabPages[0].Validating += new CancelEventHandler(AddTabValidate);

            tabSales.TabPages[2].CausesValidation = true;
            tabSales.TabPages[2].Validating += new CancelEventHandler(EditTabValidate);
        }
        private void cmbFinancePlanLength_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbFinancePlanLength.SelectedIndex == 0)
            {
                lblFinanceNumPaymentsShow.Text = "12";
            }
            else if (cmbFinancePlanLength.SelectedIndex == 1)
            {
                lblFinanceNumPaymentsShow.Text = "24";
            }
            else if (cmbFinancePlanLength.SelectedIndex == 2)
            {
                lblFinanceNumPaymentsShow.Text = "36";
            }
           else if (cmbFinancePlanLength.SelectedIndex == 3)
            {
                lblFinanceNumPaymentsShow.Text = "48";
            }
           else if (cmbFinancePlanLength.SelectedIndex == 4)
            {
                lblFinanceNumPaymentsShow.Text = "60";
            }
 

            if (GlobalVar.counter > 0)
            {
                carPrice = double.Parse(lblSaleCarPriceShow.Text);
                carDeposit = double.Parse(txtSaleDeposit.Text);
                tradeValue = double.Parse(lblCarTradeValue.Text);
                interestRate = double.Parse(lblFinanceInterestRateShow.Text) + 1;

                costNoInterest = ((carPrice - carDeposit) - tradeValue);
                costWithInterest = ((carPrice - carDeposit) - tradeValue) * interestRate;
                totalInterest = costWithInterest - costNoInterest;

                numPayments = int.Parse(lblFinanceNumPaymentsShow.Text);
                monthlyPayment = costWithInterest / numPayments;


                lblFinanceInterestPriceShow.Text = costWithInterest.ToString("0.00");
                lblFinancePriceShow.Text = costNoInterest.ToString("0.00");
                lblFinanceTotalInterest.Text = totalInterest.ToString("0.00");
                lblFinanceMonthlyPaymentShow.Text = monthlyPayment.ToString("0.00");


            }
            GlobalVar.counter++;
        }
        private void cmbFinancePlanLengthEdit_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbFinancePlanLengthEdit.SelectedIndex)
            {
                case 0:
                    {
                        lblFinanceNumPaymentsEdit.Text = "12";
                        break;
                    }
                case 1:
                    {
                        lblFinanceNumPaymentsEdit.Text = "24";
                        break;
                    }
                case 2:
                    {
                        lblFinanceNumPaymentsEdit.Text = "36";
                        break;
                    }
                case 3:
                    {
                        lblFinanceNumPaymentsEdit.Text = "48";
                        break;
                    }
                case 4:
                    {
                        lblFinanceNumPaymentsEdit.Text = "60";
                        break;
                    }
            }

            if (GlobalVar.counter > 0)
            {
                try
                {
                    carPrice = double.Parse(lblSaleCarPriceShow.Text);
                    carDeposit = double.Parse(txtSaleDeposit.Text);
                    tradeValue = double.Parse(lblCarTradeValue.Text);
                    interestRate = double.Parse(lblFinanceInterestRateShow.Text) + 1;

                    costNoInterest = ((carPrice - carDeposit) - tradeValue);
                    costWithInterest = ((carPrice - carDeposit) - tradeValue) * interestRate;
                    totalInterest = costWithInterest - costNoInterest;

                    numPayments = int.Parse(lblFinanceNumPaymentsShow.Text);
                    monthlyPayment = costWithInterest / numPayments;


                    lblFinanceInterestPriceShow.Text = costWithInterest.ToString();
                    lblFinancePriceShow.Text = costNoInterest.ToString();
                    lblFinanceTotalInterest.Text = totalInterest.ToString();
                    lblFinanceMonthlyPaymentShow.Text = monthlyPayment.ToString();
                }
                catch (Exception)
                {  
                }
            }
            GlobalVar.counter++;
        }
        private void dgvFinanceAgreements_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                financeNoSelected = dgvFinanceAgreements.SelectedRows[0].Cells[0].Value.ToString();
                strCarReg = dgvFinanceAgreements.SelectedRows[0].Cells[1].Value.ToString();
            }
            catch (Exception)
            {

                
            }
            
        }


        // Radio Button Click Events //
        private void rbCash_Click(object sender, EventArgs e)
        {
            txtSaleDeposit.Enabled = false;
        }
        private void rbCard_Click(object sender, EventArgs e)
        {
            txtSaleDeposit.Enabled = false;
        }
        private void rbCheque_Click(object sender, EventArgs e)
        {
            txtSaleDeposit.Enabled = false;
        }
        private void rbFinance_Click(object sender, EventArgs e)
        {
            txtSaleDeposit.Enabled = true;
        }


        // TabControl Events //
        private void tabSales_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbFinancePlanLength.SelectedIndex = 0;
            lstCar.SelectedIndex = -1;
            lstCustomer.SelectedIndex = -1;

            if (tabSales.SelectedIndex == 0)
            {
                lstCar.Items.Clear();

                btnSalesEdit.Enabled = true;
                btnSalesDelete.Enabled = true;
                tabSales.TabPages[tabSales.SelectedIndex].Focus();
                tabSales.TabPages[tabSales.SelectedIndex].CausesValidation = true;

                dsDesmonds.Tables["Orders"].Clear();
                daOrders.Fill(dsDesmonds, "Orders");
            }

            else if (tabSales.SelectedIndex == 1)
            {
                int noRows = dsDesmonds.Tables["Orders"].Rows.Count;

                if (noRows == 0)
                {
                    lblSaleOrderNoShow.Text = "OD100000";
                }
                else
                {
                    getTotalNumOrders(noRows);
                }
                btnSalesEdit.Enabled = false;
                btnSalesDelete.Enabled = false;
            }

            if (tabSales.SelectedIndex == 2)
            {
                lstCar.Items.Clear();
                btnSalesEdit.Enabled = false;
                btnSalesDelete.Enabled = false;
            }


            if (tabSales.SelectedIndex == 2 && GlobalVar.addFinance == false)
            {
                MessageBox.Show("Cannot add finance agreement until an order is added, select the Add Order Tab ");
                tabSales.SelectedIndex = 0;
            }
            else
            {
                btnSalesEdit.Enabled = false;
                btnSalesDelete.Enabled = false;

                lblFinanceAgreeDateShow.Text = DateTime.Now.ToShortDateString();
                lblFinanceDepositShow.Text = txtSaleDeposit.Text;
                lblFinanceTradeValueShow.Text = lblCarTradeValue.Text;

                lblFinancePriceShow.Text = lblSaleCarPriceShow.Text;

                if (txtSaleDeposit.Value <= 0)
                {
                    lblFinanceDepositShow.Text = "No Deposit";
                }
                else
                {
                    lblFinanceDepositShow.Text = txtSaleDeposit.Text;
                }
                lblFinanceTradeValueShow.Text = lblFinanceTradeValueShow.Text;


                lblFinanceMake.Text = lblSaleCarMakeShow.Text;
                lblFinanceModel.Text = lblSaleCarModelShow.Text;
                lblFinanceColour.Text = lblSaleCarColourShow.Text;
                lblFinanceMileage.Text = lblSaleCarMileageShow.Text;
                lblFinanceTransmission.Text = lblSaleCarTransmissionShow.Text;
                lblFinanceInterior.Text = lblSaleCarInteriorShow.Text;
                lblFinanceBodyStyle.Text = lblSaleCarBodyShow.Text;


                lblFinanceCustNo.Text = lblSaleCustNoShow.Text;
                lblFinanceCustName.Text = lblSaleCustNameShow.Text;
                lblFinanceCustAddress.Text = lblSaleCustAddressShow.Text;
                lblFinanceCustTown.Text = lblSaleCustTownShow.Text;
                lblFinanceCustCounty.Text = lblSaleCustCountyShow.Text;
                lblFinancePostcode.Text = lblSaleCustPostcodeShow.Text;
                lblFinanceCustCreditRating.Text = lblSaleCustCreditRatingShow.Text;
                lblFinanceCustEmail.Text = lblSaleCustEmailShow.Text;
                lblFinanceTelNum.Text = lblSaleCustTelNumShow.Text;

                if (lblFinanceCustCreditRating.Text == "Very Poor")
                {
                    lblFinanceInterestRateShow.Text = "0.09";
                }
                else if (lblFinanceCustCreditRating.Text == "Poor")
                {
                    lblFinanceInterestRateShow.Text = "0.085";
                }
                else if (lblFinanceCustCreditRating.Text == "Average")
                {
                    lblFinanceInterestRateShow.Text = "0.08";
                }
                else if (lblFinanceCustCreditRating.Text == "Good")
                {
                    lblFinanceInterestRateShow.Text = "0.075";
                }
                else if (lblFinanceCustCreditRating.Text == "Very Good")
                {
                    lblFinanceInterestRateShow.Text = "0.07";
                }
                else if (lblFinanceCustCreditRating.Text == "Excellent")
                {
                    lblFinanceInterestRateShow.Text = "0.065";
                }

                int noRows = dsDesmonds.Tables["financeAgreement2"].Rows.Count;

                if (noRows == 0)
                {
                    lblFinanceAgreementIDShow.Text = "FA100000";
                }
                else
                {
                    getTotalNumFinanceAgreements(noRows);
                }
                try
                {
                    carPrice = double.Parse(lblFinancePriceShow.Text);
                    carDeposit = double.Parse(lblFinanceDepositShow.Text);
                    tradeValue = double.Parse(lblFinanceTradeValueShow.Text);
                    interestRate = double.Parse(lblFinanceInterestRateShow.Text) + 1;

                    costNoInterest = ((carPrice - carDeposit) - tradeValue);
                    costWithInterest = ((carPrice - carDeposit) - tradeValue) * interestRate;
                    totalInterest = costWithInterest - costNoInterest;

                    numPayments = int.Parse(lblFinanceNumPaymentsShow.Text);
                    monthlyPayment = costWithInterest / numPayments;

                    lblFinanceInterestPriceShow.Text = costWithInterest.ToString();
                    lblFinancePriceShow.Text = costNoInterest.ToString();
                    lblFinanceTotalInterest.Text = totalInterest.ToString();
                    lblFinanceMonthlyPaymentShow.Text = monthlyPayment.ToString();
                }
                catch (Exception ex1)
                {
                    
                }

            }
            if (tabSales.SelectedIndex == 3)
            {
                btnSalesEdit.Enabled = true;
                btnSalesDelete.Enabled = true;

                lstCar.Items.Clear();
            }

            if (tabSales.SelectedIndex == 4)
            {
                btnSalesEdit.Enabled = false;
                btnSalesDelete.Enabled = false;

                lstCar.Items.Clear();

                daFinanceAgreement.Fill(dsDesmonds, "FinanceAgreement");

                if (financeNoSelected == "")
                {
                    tabSales.SelectedIndex = 0;
                    MessageBox.Show("Please select a finance agreement from the Display Finanace tab in order to use the manage finance tab");
                }
                else
                {
                    foreach (DataRow dr in dsDesmonds.Tables["FinanceAgreement"].Rows)
                    {
                        if (dr["FinanceID"].ToString() == dgvFinanceAgreements.CurrentRow.Cells[0].Value.ToString())
                        {
                            string tempNum = dr["NoOfPayments"].ToString();
                            lblFinanceCustNoEdit.Text = dr["CustID"].ToString();
                            lblFinanceRegNoEdit.Text = dr["RegNo"].ToString();
                            lblFinanceMakeEdit.Text = dr["MakeID"].ToString();
                            lblFinanceModelEdit.Text = dr["Model"].ToString();
                            lblFinanceColourEdit.Text = dr["Colour"].ToString();
                            lblFinanceMileageEdit.Text = dr["Mileage"].ToString();
                            lblFinanceTransmissionEdit.Text = dr["Transmission"].ToString();
                            lblFinanceInteriorEdit.Text = dr["Interior"].ToString();
                            lblFinanceBodyEdit.Text = dr["BodyStyle"].ToString();



                            lblFinanceCustNameEdit.Text = dr["name"].ToString();
                            lblFinanceCustAddressEdit.Text = dr["CustStreet"].ToString();
                            lblFinanceCustTownEdit.Text = dr["CustTown"].ToString();
                            lblFinanceCustCountyEdit.Text = dr["CustCounty"].ToString();
                            lblFinanceCustPostcodeEdit.Text = dr["CustPostcode"].ToString();
                            lblFinanceCustEmailEdit.Text = dr["CustEmail"].ToString();
                            lblFinanceCustCreditEdit.Text = dr["CreditRating"].ToString();
                            lblFinanceTelNumEdit.Text = dr["TelNo"].ToString();


                            if (tempNum == "12")
                            {
                                cmbFinancePlanLengthEdit.SelectedIndex = 0;
                            }
                            else if (tempNum == "24")
                            {
                                cmbFinancePlanLengthEdit.SelectedIndex = 1;
                            }
                            else if (tempNum == "36")
                            {
                                cmbFinancePlanLengthEdit.SelectedIndex = 2;
                            }
                            else if (tempNum == "48")
                            {
                                cmbFinancePlanLengthEdit.SelectedIndex = 3;
                            }
                            else if (tempNum == "60")
                            {
                                cmbFinancePlanLengthEdit.SelectedIndex = 4;
                            }

                            txtFinanceDepositEdit.Value = int.Parse(dr["Deposit"].ToString());
                            lblFinanceTradeInEdit.Text = dr["TradeInValue"].ToString();
                            lblFinanceFinanceIDEdit.Text = dr["FinanceID"].ToString();
                            lblFinanceAgreementDateEdit.Text = dr["AgreementDate"].ToString();
                            lblFinanceInterestRateEdit.Text = dr["InterestRate"].ToString();
                            

                                if (cmbFinancePlanLengthEdit.SelectedIndex == 0)
                            {
                                lblFinanceNumPaymentsEdit.Text = "12";
                            }
                            else if (cmbFinancePlanLengthEdit.SelectedIndex == 1)
                            {
                                lblFinanceNumPaymentsEdit.Text = "24";
                            }
                            else if (cmbFinancePlanLengthEdit.SelectedIndex == 2)
                            {
                                lblFinanceNumPaymentsEdit.Text = "36";
                            }
                            else if (cmbFinancePlanLengthEdit.SelectedIndex == 3)
                            {
                                lblFinanceNumPaymentsEdit.Text = "48";
                            }
                            else if (cmbFinancePlanLengthEdit.SelectedIndex == 4)
                            {
                                lblFinanceNumPaymentsEdit.Text = "60";
                            }

                            try
                            {
                                carPrice = double.Parse(lblFinancePriceEdit.Text);
                                carDeposit = double.Parse(txtFinanceDepositEdit.Text);
                                tradeValue = double.Parse(lblFinanceTradeInEdit.Text);
                                interestRate = double.Parse(lblFinanceInterestRateEdit.Text) + 1;

                                costNoInterest = ((carPrice - carDeposit) - tradeValue);
                                costWithInterest = ((carPrice - carDeposit) - tradeValue) * interestRate;
                                totalInterest = costWithInterest - costNoInterest;

                                numPayments = int.Parse(lblFinanceNumPaymentsEdit.Text);
                                monthlyPayment = costWithInterest / numPayments;

                                lblFinanceTotalInterestEdit.Text = costWithInterest.ToString();
                                lblFinanceTotalNoInterestEdit.Text = costNoInterest.ToString();
                                lblFinanceInterestDueEdit.Text = totalInterest.ToString();
                                lblFinanceMonthlyPaymentEdit.Text = monthlyPayment.ToString();
                            }
                            catch (Exception ex1)
                            {

                            }


                        }
                    }
                }
                
            }
            if (tabSales.SelectedIndex == 5)
            {
                btnSalesEdit.Enabled = false;
                btnSalesDelete.Enabled = false;

                lstCar.Items.Clear();

                cmbRepOrderSearch.DataSource = dsDesmonds.Tables["customer2"];
                cmbRepOrderSearch.DisplayMember = "CustID";
                cmbRepOrderSearch.ValueMember = "CustID";

                cmbRepOrderSearch.SelectedIndex = 0;
            }
        }

        // List Events //
        private void lstCustomer_Click(object sender, EventArgs e)
        {
            lstCar.Items.Clear();
            lstCar.SelectedIndex = -1;

            if (lstCar.SelectedIndex == -1)
            {
                pnlSaleCarDetails.Visible = false;
                pnlSaleCustDetails.Visible = false;
            }

            if (lstCustomer.SelectedIndex == -1)
            {
                var confirmResult = MessageBox.Show("Please select a customer", "Select Customer", MessageBoxButtons.OK);
            }
            else
            {
                String title = "";
                drCustomer = dsDesmonds.Tables["customer"].Rows.Find(lstCustomer.SelectedValue);

                if (drCustomer["CustTitle"].ToString() == "Mr")
                {
                    title = "Mr";
                }
                if (drCustomer["CustTitle"].ToString() == "Mrs")
                {
                    title = "Mrs";
                }
                if (drCustomer["CustTitle"].ToString() == "Miss")
                {
                    title = "Miss";
                }
                if (drCustomer["CustTitle"].ToString() == "Ms")
                {
                    title = "Ms";
                }

                lblSaleCustNoShow.Text = drCustomer["CustID"].ToString();
                lblSaleCustNameShow.Text = title + " " + drCustomer["CustForename"].ToString() + " " + drCustomer["CustSurname"].ToString();
                lblSaleCustAddressShow.Text = drCustomer["CustStreet"].ToString();
                lblSaleCustTownShow.Text = drCustomer["CustTown"].ToString();
                lblSaleCustCountyShow.Text = drCustomer["CustCounty"].ToString();
                lblSaleCustPostcodeShow.Text = drCustomer["CustPostcode"].ToString();
                lblSaleCustCreditRatingShow.Text = drCustomer["CreditRating"].ToString();
                lblSaleCustEmailShow.Text = drCustomer["CustEmail"].ToString();
                lblSaleCustTelNumShow.Text = drCustomer["TelNo"].ToString();

                pnlSaleCarDetails.Visible = true;
                pnlSaleCustDetails.Visible = true;


                
                daCars.Fill(dsDesmonds, "Car");

                // fill list box
                foreach (DataRow dr in dsDesmonds.Tables["Car"].Rows)
                {
                    if (Convert.ToBoolean(dr["Sold"]) == false)
                    {
                        lstCar.Items.Add(dr["RegNo"].ToString());
                    }
                }   

                lstCar.SelectedIndex = -1;
                lstCar.Enabled = true;

            }
        }
        private void lstCar_Click(object sender, EventArgs e)
        {
            if (lstCustomer.SelectedIndex == -1)
            {
                var confirmResult = MessageBox.Show("Please select a Car Registration", "Select Car Registration", MessageBoxButtons.OK);
            }
            else
            {

                drCar = dsDesmonds.Tables["Car"].Rows.Find(lstCar.SelectedItem.ToString());

                lblFinanceRegNoShow.Text = drCar["RegNo"].ToString();
                lblSaleCarMakeShow.Text = drCar["MakeID"].ToString();
                lblSaleCarModelShow.Text = drCar["Model"].ToString();
                lblSaleCarTransmissionShow.Text = drCar["Transmission"].ToString();
                lblSaleCarInteriorShow.Text = drCar["Interior"].ToString();
                lblSaleCarBodyShow.Text = drCar["BodyStyle"].ToString();
                lblSaleCarColourShow.Text = drCar["Colour"].ToString();
                lblSaleCarMileageShow.Text = drCar["Mileage"].ToString();
                lblSaleCarPriceShow.Text = drCar["SalePrice"].ToString();

                pnlSaleCarDetails.Visible = true;
                pnlSaleCustDetails.Visible = true;
            }
        }


        // Button Events //
        private void btnA_Click(object sender, EventArgs e)
        {
            pnlListBoxes.Enabled = true;
            Button b = (Button)sender;
            // get customer details for listbox - use selected button letter for parameter //
            String str = b.Text;

            // empty dataset table customer
            dsDesmonds.Tables["customer"].Clear();

            fillListBoxCustomers(str);

            // clear any previously selected cars/orders by emptying the dataset tables //
            dsDesmonds.Tables["Car"].Clear();
            dsDesmonds.Tables["Orders"].Clear();



            clearSale();
        }
        private void btnCarHome_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMainMenu menuForm = new frmMainMenu();
            menuForm.ShowDialog();
        }
        private void btnSearchCustIDOrders_Click(object sender, EventArgs e)
        {

        }
        private void btnAddSaleAdd_Click(object sender, EventArgs e)
        {
            if (rbFinance.Checked == false)
            {
                MySales myOrders = new MySales();
                bool Ok = true;
                String invalMessage = "Invalid data entry for: ";
                errP.Clear();

                try
                {
                    myOrders.OrderID = lblSaleOrderNoShow.Text.Trim(); // passed to car class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(lblSaleOrderNoShow, MyEx.toString());
                }

                try
                {
                    myOrders.OrderDate = Convert.ToDateTime(DateTime.Now.ToShortDateString()); // passed to car class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(lblSaleOrderDateShow, MyEx.toString());
                }

                try
                {
                    myOrders.CustID = lblSaleCustNoShow.Text.Trim(); // passed to car class to check //
                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(lblSaleCustNoShow, MyEx.toString());
                }

                try
                {
                    if (rbCash.Checked == true)
                    {
                        myOrders.PaymentTypeID = 1;
                    }
                    if (rbCard.Checked == true)
                    {
                        myOrders.PaymentTypeID = 2;
                    }
                    if (rbFinance.Checked == true)
                    {
                        myOrders.PaymentTypeID = 3;
                    }
                    if (rbCheque.Checked == true)
                    {
                        myOrders.PaymentTypeID = 4;
                    }

                }
                catch (MyException MyEx)
                {
                    Ok = false;
                    errP.SetError(rbCash, MyEx.toString());
                    errP.SetError(rbCard, MyEx.toString());
                    errP.SetError(rbFinance, MyEx.toString());
                    errP.SetError(rbCheque, MyEx.toString());
                }

                try
                {
                    if (Ok)
                    {
                        drCar.BeginEdit();
                        drCar["Sold"] = 1;
                        drCar.EndEdit();
                        daCars.Update(dsDesmonds, "Car");

                        drOrder = dsDesmonds.Tables["Orders"].NewRow();

                        drOrder["OrderID"] = myOrders.OrderID;
                        drOrder["OrderDate"] = myOrders.OrderDate;
                        drOrder["CustID"] = myOrders.CustID;
                        drOrder["PaymentTypeID"] = myOrders.PaymentTypeID;

                        dsDesmonds.Tables["Orders"].Rows.Add(drOrder);
                        
                        MessageBox.Show("Order Added");

                        clearSale();
                        tabSales.SelectedIndex = 0;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("" + ex.TargetSite + "" + ex.Message, "Error!", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
                }
            }
            else
            {
                GlobalVar.addFinance = true;
                tabSales.SelectedIndex = 2;
            }
        }
        private void btnAddSaleReset_Click(object sender, EventArgs e)
        {
            lstCustomer.SelectedIndex = -1;
            lstCar.SelectedIndex = -1;
            lblSaleOrderDateShow.Text = DateTime.Now.ToShortDateString();
            txtSaleDeposit.Value = 0;
            rbCard.Checked = false;
            rbCash.Checked = false;
            rbCheque.Checked = false;
            rbFinance.Checked = false;

        }
        private void btnSaleTradeIn_Click(object sender, EventArgs e)
        {
            GlobalVar.tradeInCar = true;
            frmCar tradeInForm = new frmCar();
            tradeInForm.ShowDialog(this);


            // frmTradeIn TradeInForm = new frmTradeIn();
            // TradeInForm.ShowDialog(this);
        }


        // Custom Methods //
        private void clearSale()
        {
            lstCustomer.SelectedIndex = -1;

            lblSaleCustNameShow.Text = "";
            lblSaleCustAddressShow.Text = "";
            lblSaleCustTownShow.Text = "";
            lblSaleCustCountyShow.Text = "";
            lblSaleCustPostcodeShow.Text = "";
            lblSaleCustCreditRatingShow.Text = "";
            lblSaleCustEmailShow.Text = "";
            lblSaleCustTelNumShow.Text = "";

            lblSaleCarBodyShow.Text = "";
            lblSaleCarColourShow.Text = "";
            lblSaleCarDetailsTitle.Text = "";
            lblSaleCarInteriorShow.Text = "";
            lblSaleCarMakeShow.Text = "";
            lblSaleCarMileageShow.Text = "";
            lblSaleCarModelShow.Text = "";
            lblSaleCarTransmissionShow.Text = "";

            rbCard.Checked = false;
            rbCash.Checked = false;
            rbFinance.Checked = false;
            rbCheque.Checked = false;

        }
        private void getTotalNumOrders(int noRows)
        {
            drOrder = dsDesmonds.Tables["Orders"].Rows[noRows - 1];
            int temp = int.Parse(drOrder["OrderID"].ToString().Substring(2, 6)) + 1;
            lblSaleOrderNoShow.Text = "OD" + temp;
        }
        private void getTotalNumFinanceAgreements(int noRows)
        {
            drOrder = dsDesmonds.Tables["financeAgreement2"].Rows[noRows - 1];
            int temp = int.Parse(drOrder["FinanceID"].ToString().Substring(2, 6)) + 1;
            lblFinanceAgreementIDShow.Text = "FA" + temp;
        }
        private void fillListBoxCustomers(String str)
        {
            // get all customer details for listbox - use wildcard for parameter //
            cmdCustomerDetails.Parameters["@Letter"].Value = str + "%";
            daCustomers.Fill(dsDesmonds, "customer");

            // fill listbox //
            lstCustomer.DataSource = dsDesmonds.Tables["customer"];
            lstCustomer.DisplayMember = "name";
            lstCustomer.ValueMember = "CustID";

        }
        void EditTabValidate(object sender, CancelEventArgs e)
        {
            if (financeSelected == false) // && financeNoSelected == "")
            {
                // have to do this bit //
                // reset tab to display and put out a message to select customer
                financeSelected = false;
                financeNoSelected = "";
            }
            else if (dgvFinanceAgreements.SelectedRows.Count == 1)
            {
                financeSelected = true;
                financeNoSelected = dgvFinanceAgreements.SelectedRows[0].Cells[0].Value.ToString();
            }
        }
        void AddTabValidate(object sender, CancelEventArgs e)
        {
            if (dgvFinanceAgreements.SelectedRows.Count == 0)
            {
                financeSelected = false;
                financeNoSelected = "";
            }
            else if (dgvFinanceAgreements.SelectedRows.Count == 1)
            {
                financeSelected = true;
                financeNoSelected = dgvFinanceAgreements.SelectedRows[0].Cells[0].ToString();
            }
        }



    }
}
