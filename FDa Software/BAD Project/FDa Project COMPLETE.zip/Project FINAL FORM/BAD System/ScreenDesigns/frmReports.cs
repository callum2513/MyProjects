﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScreenDesigns
{
    public partial class frmReports : Form
    {
        DataSet dsDesmonds = new DataSet();
        SqlCommandBuilder cmdBMake;
        String connStr, sqlMake;
        SqlDataAdapter daMake;

        lowStock ls = new lowStock();
        allStock alls = new allStock();

        public frmReports()
        {
            InitializeComponent();
        }

        private void btnAllStock_Click(object sender, EventArgs e)
        {
            
        }

        private void btnLowStock_Click(object sender, EventArgs e)
        {
            try
            {
                
                ls.SetParameterValue("MakeCK", cmbMake.SelectedValue.ToString());
                crystalReportViewer1.ReportSource = ls;

                if (txtLowStock.Text.Trim().Equals(""))
                {
                    ls.SetParameterValue("QtyCheck", 1000);
                    crystalReportViewer1.ReportSource = ls;
                }
                else
                {
                    ls.SetParameterValue("QtyCheck", txtLowStock.Text.Trim());
                    crystalReportViewer1.ReportSource = ls;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid input!");
            }
            
        }

        private void frmReports_Load(object sender, EventArgs e)
        {
            connStr = @"Data Source = .; Initial Catalog = Desmonds; Integrated Security = true";
            sqlMake = @"select * from make";
            daMake = new SqlDataAdapter(sqlMake, connStr);
            cmdBMake = new SqlCommandBuilder(daMake);
            daMake.FillSchema(dsDesmonds, SchemaType.Source, "make");
            daMake.Fill(dsDesmonds, "make");


            cmbMake.DataSource = dsDesmonds.Tables["make"];
            cmbMake.DisplayMember = "MakeDesc";
            cmbMake.ValueMember = "MakeID";

            crystalReportViewer1.ReportSource = alls;   
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            crystalReportViewer1.ReportSource = alls;
        }

        private void lowStockReport_InitReport(object sender, EventArgs e)
        {

        }

        private void cmbMake_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblDescSort_Click(object sender, EventArgs e)
        {

        }

        private void lblStockSearch_Click(object sender, EventArgs e)
        {

        }

        private void txtLowStock_TextChanged(object sender, EventArgs e)
        {

        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
