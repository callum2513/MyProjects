﻿namespace ScreenDesigns
{
    partial class frmEditDelUpgradeOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEditDelUpgradeOrder));
            this.btnNewBooking = new System.Windows.Forms.Button();
            this.dgvStock = new System.Windows.Forms.DataGridView();
            this.txtDisplaySearch = new System.Windows.Forms.TextBox();
            this.cmbDisplaySearch = new System.Windows.Forms.ComboBox();
            this.lblStockDetails = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlStock = new System.Windows.Forms.TableLayoutPanel();
            this.pnlStockDGV = new System.Windows.Forms.Panel();
            this.btnDecreaseQty = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btnIncreaseQty = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dgvOrderDetails = new System.Windows.Forms.DataGridView();
            this.lblOrderDetails = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.pnlBookingItemsDGV = new System.Windows.Forms.Panel();
            this.btnDelBooking = new System.Windows.Forms.Button();
            this.pnlAddItems = new System.Windows.Forms.Panel();
            this.btnReport = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.lblCar = new System.Windows.Forms.Label();
            this.lstCar = new System.Windows.Forms.ListBox();
            this.pnlDisplayCarDetails = new System.Windows.Forms.Panel();
            this.picTEST = new System.Windows.Forms.PictureBox();
            this.lblMileage = new System.Windows.Forms.Label();
            this.lblCondition = new System.Windows.Forms.Label();
            this.lblSalePrice = new System.Windows.Forms.Label();
            this.lblModel = new System.Windows.Forms.Label();
            this.lblMakeID = new System.Windows.Forms.Label();
            this.lblDisplayMileage = new System.Windows.Forms.Label();
            this.lblDisplayCondition = new System.Windows.Forms.Label();
            this.lblDisplaySalePrice = new System.Windows.Forms.Label();
            this.lblDisplayModel = new System.Windows.Forms.Label();
            this.lblDisplayMakeID = new System.Windows.Forms.Label();
            this.lblDisplayRegNo = new System.Windows.Forms.Label();
            this.lblRegNo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lstUpgradeIDs = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnHome = new System.Windows.Forms.Button();
            this.errP = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel6 = new System.Windows.Forms.Panel();
            this.btns0 = new System.Windows.Forms.Button();
            this.btns23 = new System.Windows.Forms.Button();
            this.btns25 = new System.Windows.Forms.Button();
            this.btns22 = new System.Windows.Forms.Button();
            this.btns24 = new System.Windows.Forms.Button();
            this.btns21 = new System.Windows.Forms.Button();
            this.btns20 = new System.Windows.Forms.Button();
            this.btns19 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btns18 = new System.Windows.Forms.Button();
            this.btns16 = new System.Windows.Forms.Button();
            this.btns15 = new System.Windows.Forms.Button();
            this.btns14 = new System.Windows.Forms.Button();
            this.btns13 = new System.Windows.Forms.Button();
            this.btns12 = new System.Windows.Forms.Button();
            this.btnDisplayExit = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btns17 = new System.Windows.Forms.Button();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.btnDeleteItem = new System.Windows.Forms.Button();
            this.btnAddItem = new System.Windows.Forms.Button();
            this.btns11 = new System.Windows.Forms.Button();
            this.btns10 = new System.Windows.Forms.Button();
            this.btns9 = new System.Windows.Forms.Button();
            this.btns8 = new System.Windows.Forms.Button();
            this.btns7 = new System.Windows.Forms.Button();
            this.btns5 = new System.Windows.Forms.Button();
            this.btns4 = new System.Windows.Forms.Button();
            this.btns3 = new System.Windows.Forms.Button();
            this.btns2 = new System.Windows.Forms.Button();
            this.btns1 = new System.Windows.Forms.Button();
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.btns6 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStock)).BeginInit();
            this.panel1.SuspendLayout();
            this.pnlStock.SuspendLayout();
            this.pnlStockDGV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderDetails)).BeginInit();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.pnlBookingItemsDGV.SuspendLayout();
            this.pnlAddItems.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.pnlDisplayCarDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picTEST)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errP)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.pnlButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnNewBooking
            // 
            this.btnNewBooking.Location = new System.Drawing.Point(999, 95);
            this.btnNewBooking.Name = "btnNewBooking";
            this.btnNewBooking.Size = new System.Drawing.Size(115, 23);
            this.btnNewBooking.TabIndex = 74;
            this.btnNewBooking.Text = "New Booking";
            this.btnNewBooking.UseVisualStyleBackColor = true;
            // 
            // dgvStock
            // 
            this.dgvStock.AllowUserToAddRows = false;
            this.dgvStock.AllowUserToDeleteRows = false;
            this.dgvStock.AllowUserToResizeColumns = false;
            this.dgvStock.AllowUserToResizeRows = false;
            this.dgvStock.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvStock.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStock.Location = new System.Drawing.Point(3, 41);
            this.dgvStock.MultiSelect = false;
            this.dgvStock.Name = "dgvStock";
            this.dgvStock.ReadOnly = true;
            this.dgvStock.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvStock.Size = new System.Drawing.Size(507, 177);
            this.dgvStock.TabIndex = 4;
            // 
            // txtDisplaySearch
            // 
            this.txtDisplaySearch.Location = new System.Drawing.Point(346, 9);
            this.txtDisplaySearch.Name = "txtDisplaySearch";
            this.txtDisplaySearch.Size = new System.Drawing.Size(120, 20);
            this.txtDisplaySearch.TabIndex = 65;
            // 
            // cmbDisplaySearch
            // 
            this.cmbDisplaySearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDisplaySearch.FormattingEnabled = true;
            this.cmbDisplaySearch.Items.AddRange(new object[] {
            "UpgradeID",
            "UpgradeDesc",
            "SellPrice",
            "QtyInStock",
            "SupplierID",
            "PurchasePrice",
            "MakeID"});
            this.cmbDisplaySearch.Location = new System.Drawing.Point(219, 8);
            this.cmbDisplaySearch.Name = "cmbDisplaySearch";
            this.cmbDisplaySearch.Size = new System.Drawing.Size(121, 21);
            this.cmbDisplaySearch.TabIndex = 64;
            // 
            // lblStockDetails
            // 
            this.lblStockDetails.AutoSize = true;
            this.lblStockDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStockDetails.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblStockDetails.Location = new System.Drawing.Point(3, 9);
            this.lblStockDetails.Name = "lblStockDetails";
            this.lblStockDetails.Size = new System.Drawing.Size(103, 20);
            this.lblStockDetails.TabIndex = 63;
            this.lblStockDetails.Text = "Stock Details";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtDisplaySearch);
            this.panel1.Controls.Add(this.cmbDisplaySearch);
            this.panel1.Controls.Add(this.lblStockDetails);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(507, 32);
            this.panel1.TabIndex = 3;
            // 
            // pnlStock
            // 
            this.pnlStock.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnlStock.ColumnCount = 1;
            this.pnlStock.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.pnlStock.Controls.Add(this.panel1, 0, 0);
            this.pnlStock.Controls.Add(this.dgvStock, 0, 1);
            this.pnlStock.Location = new System.Drawing.Point(11, 0);
            this.pnlStock.Name = "pnlStock";
            this.pnlStock.RowCount = 2;
            this.pnlStock.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.pnlStock.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 183F));
            this.pnlStock.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 221F));
            this.pnlStock.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.pnlStock.Size = new System.Drawing.Size(513, 221);
            this.pnlStock.TabIndex = 38;
            // 
            // pnlStockDGV
            // 
            this.pnlStockDGV.Controls.Add(this.pnlStock);
            this.pnlStockDGV.Location = new System.Drawing.Point(0, 0);
            this.pnlStockDGV.Name = "pnlStockDGV";
            this.pnlStockDGV.Size = new System.Drawing.Size(534, 220);
            this.pnlStockDGV.TabIndex = 0;
            // 
            // btnDecreaseQty
            // 
            this.btnDecreaseQty.HeaderText = "-";
            this.btnDecreaseQty.Name = "btnDecreaseQty";
            this.btnDecreaseQty.ReadOnly = true;
            this.btnDecreaseQty.Width = 30;
            // 
            // btnIncreaseQty
            // 
            this.btnIncreaseQty.HeaderText = "+";
            this.btnIncreaseQty.Name = "btnIncreaseQty";
            this.btnIncreaseQty.ReadOnly = true;
            this.btnIncreaseQty.Width = 30;
            // 
            // dgvOrderDetails
            // 
            this.dgvOrderDetails.AllowUserToAddRows = false;
            this.dgvOrderDetails.AllowUserToDeleteRows = false;
            this.dgvOrderDetails.AllowUserToResizeColumns = false;
            this.dgvOrderDetails.AllowUserToResizeRows = false;
            this.dgvOrderDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrderDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.btnIncreaseQty,
            this.btnDecreaseQty});
            this.dgvOrderDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvOrderDetails.Location = new System.Drawing.Point(3, 28);
            this.dgvOrderDetails.Name = "dgvOrderDetails";
            this.dgvOrderDetails.ReadOnly = true;
            this.dgvOrderDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvOrderDetails.Size = new System.Drawing.Size(581, 190);
            this.dgvOrderDetails.TabIndex = 1;
            // 
            // lblOrderDetails
            // 
            this.lblOrderDetails.AutoSize = true;
            this.lblOrderDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrderDetails.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblOrderDetails.Location = new System.Drawing.Point(109, 0);
            this.lblOrderDetails.Name = "lblOrderDetails";
            this.lblOrderDetails.Size = new System.Drawing.Size(102, 20);
            this.lblOrderDetails.TabIndex = 5;
            this.lblOrderDetails.Text = "Order Details";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblOrderDetails);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(447, 19);
            this.panel2.TabIndex = 2;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.dgvOrderDetails, 0, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(7, -2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 196F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 221F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(587, 221);
            this.tableLayoutPanel2.TabIndex = 76;
            // 
            // pnlBookingItemsDGV
            // 
            this.pnlBookingItemsDGV.Controls.Add(this.tableLayoutPanel2);
            this.pnlBookingItemsDGV.Location = new System.Drawing.Point(527, 4);
            this.pnlBookingItemsDGV.Name = "pnlBookingItemsDGV";
            this.pnlBookingItemsDGV.Size = new System.Drawing.Size(601, 217);
            this.pnlBookingItemsDGV.TabIndex = 1;
            // 
            // btnDelBooking
            // 
            this.btnDelBooking.Location = new System.Drawing.Point(999, 124);
            this.btnDelBooking.Name = "btnDelBooking";
            this.btnDelBooking.Size = new System.Drawing.Size(115, 23);
            this.btnDelBooking.TabIndex = 75;
            this.btnDelBooking.Text = "Delete Booking";
            this.btnDelBooking.UseVisualStyleBackColor = true;
            // 
            // pnlAddItems
            // 
            this.pnlAddItems.Controls.Add(this.pnlBookingItemsDGV);
            this.pnlAddItems.Controls.Add(this.pnlStockDGV);
            this.pnlAddItems.Location = new System.Drawing.Point(6, 206);
            this.pnlAddItems.Name = "pnlAddItems";
            this.pnlAddItems.Size = new System.Drawing.Size(1108, 220);
            this.pnlAddItems.TabIndex = 73;
            // 
            // btnReport
            // 
            this.btnReport.Location = new System.Drawing.Point(999, 153);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(115, 23);
            this.btnReport.TabIndex = 72;
            this.btnReport.Text = "Report";
            this.btnReport.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.54935F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.45065F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 225F));
            this.tableLayoutPanel1.Controls.Add(this.label2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblCar, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lstCar, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.pnlDisplayCarDetails, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.lstUpgradeIDs, 2, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 1);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.69182F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 89.30817F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(990, 211);
            this.tableLayoutPanel1.TabIndex = 34;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(767, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Bookings";
            // 
            // lblCar
            // 
            this.lblCar.AutoSize = true;
            this.lblCar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblCar.Location = new System.Drawing.Point(3, 0);
            this.lblCar.Name = "lblCar";
            this.lblCar.Size = new System.Drawing.Size(34, 20);
            this.lblCar.TabIndex = 3;
            this.lblCar.Text = "Car";
            // 
            // lstCar
            // 
            this.lstCar.FormattingEnabled = true;
            this.lstCar.Location = new System.Drawing.Point(3, 24);
            this.lstCar.Name = "lstCar";
            this.lstCar.Size = new System.Drawing.Size(205, 173);
            this.lstCar.TabIndex = 0;
            // 
            // pnlDisplayCarDetails
            // 
            this.pnlDisplayCarDetails.BackColor = System.Drawing.Color.White;
            this.pnlDisplayCarDetails.Controls.Add(this.picTEST);
            this.pnlDisplayCarDetails.Controls.Add(this.lblMileage);
            this.pnlDisplayCarDetails.Controls.Add(this.lblCondition);
            this.pnlDisplayCarDetails.Controls.Add(this.lblSalePrice);
            this.pnlDisplayCarDetails.Controls.Add(this.lblModel);
            this.pnlDisplayCarDetails.Controls.Add(this.lblMakeID);
            this.pnlDisplayCarDetails.Controls.Add(this.lblDisplayMileage);
            this.pnlDisplayCarDetails.Controls.Add(this.lblDisplayCondition);
            this.pnlDisplayCarDetails.Controls.Add(this.lblDisplaySalePrice);
            this.pnlDisplayCarDetails.Controls.Add(this.lblDisplayModel);
            this.pnlDisplayCarDetails.Controls.Add(this.lblDisplayMakeID);
            this.pnlDisplayCarDetails.Controls.Add(this.lblDisplayRegNo);
            this.pnlDisplayCarDetails.Controls.Add(this.lblRegNo);
            this.pnlDisplayCarDetails.Location = new System.Drawing.Point(267, 24);
            this.pnlDisplayCarDetails.Name = "pnlDisplayCarDetails";
            this.pnlDisplayCarDetails.Size = new System.Drawing.Size(394, 173);
            this.pnlDisplayCarDetails.TabIndex = 5;
            // 
            // picTEST
            // 
            this.picTEST.BackgroundImage = global::ScreenDesigns.Properties.Resources.desmonds;
            this.picTEST.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picTEST.Location = new System.Drawing.Point(159, 33);
            this.picTEST.Name = "picTEST";
            this.picTEST.Size = new System.Drawing.Size(181, 109);
            this.picTEST.TabIndex = 37;
            this.picTEST.TabStop = false;
            // 
            // lblMileage
            // 
            this.lblMileage.AutoSize = true;
            this.lblMileage.Location = new System.Drawing.Point(2, 155);
            this.lblMileage.Name = "lblMileage";
            this.lblMileage.Size = new System.Drawing.Size(44, 13);
            this.lblMileage.TabIndex = 36;
            this.lblMileage.Text = "Mileage";
            // 
            // lblCondition
            // 
            this.lblCondition.AutoSize = true;
            this.lblCondition.Location = new System.Drawing.Point(3, 125);
            this.lblCondition.Name = "lblCondition";
            this.lblCondition.Size = new System.Drawing.Size(51, 13);
            this.lblCondition.TabIndex = 35;
            this.lblCondition.Text = "Condition";
            // 
            // lblSalePrice
            // 
            this.lblSalePrice.AutoSize = true;
            this.lblSalePrice.Location = new System.Drawing.Point(3, 94);
            this.lblSalePrice.Name = "lblSalePrice";
            this.lblSalePrice.Size = new System.Drawing.Size(70, 13);
            this.lblSalePrice.TabIndex = 34;
            this.lblSalePrice.Text = "Sale Price (£)";
            // 
            // lblModel
            // 
            this.lblModel.AutoSize = true;
            this.lblModel.Location = new System.Drawing.Point(3, 63);
            this.lblModel.Name = "lblModel";
            this.lblModel.Size = new System.Drawing.Size(39, 13);
            this.lblModel.TabIndex = 33;
            this.lblModel.Text = "Model ";
            // 
            // lblMakeID
            // 
            this.lblMakeID.AutoSize = true;
            this.lblMakeID.Location = new System.Drawing.Point(3, 33);
            this.lblMakeID.Name = "lblMakeID";
            this.lblMakeID.Size = new System.Drawing.Size(48, 13);
            this.lblMakeID.TabIndex = 32;
            this.lblMakeID.Text = "Make ID";
            // 
            // lblDisplayMileage
            // 
            this.lblDisplayMileage.AutoSize = true;
            this.lblDisplayMileage.Location = new System.Drawing.Point(83, 155);
            this.lblDisplayMileage.Name = "lblDisplayMileage";
            this.lblDisplayMileage.Size = new System.Drawing.Size(10, 13);
            this.lblDisplayMileage.TabIndex = 31;
            this.lblDisplayMileage.Text = "-";
            // 
            // lblDisplayCondition
            // 
            this.lblDisplayCondition.AutoSize = true;
            this.lblDisplayCondition.Location = new System.Drawing.Point(83, 125);
            this.lblDisplayCondition.Name = "lblDisplayCondition";
            this.lblDisplayCondition.Size = new System.Drawing.Size(10, 13);
            this.lblDisplayCondition.TabIndex = 30;
            this.lblDisplayCondition.Text = "-";
            // 
            // lblDisplaySalePrice
            // 
            this.lblDisplaySalePrice.AutoSize = true;
            this.lblDisplaySalePrice.Location = new System.Drawing.Point(83, 94);
            this.lblDisplaySalePrice.Name = "lblDisplaySalePrice";
            this.lblDisplaySalePrice.Size = new System.Drawing.Size(10, 13);
            this.lblDisplaySalePrice.TabIndex = 29;
            this.lblDisplaySalePrice.Text = "-";
            // 
            // lblDisplayModel
            // 
            this.lblDisplayModel.AutoSize = true;
            this.lblDisplayModel.Location = new System.Drawing.Point(83, 63);
            this.lblDisplayModel.Name = "lblDisplayModel";
            this.lblDisplayModel.Size = new System.Drawing.Size(10, 13);
            this.lblDisplayModel.TabIndex = 28;
            this.lblDisplayModel.Text = "-";
            // 
            // lblDisplayMakeID
            // 
            this.lblDisplayMakeID.AutoSize = true;
            this.lblDisplayMakeID.Location = new System.Drawing.Point(83, 33);
            this.lblDisplayMakeID.Name = "lblDisplayMakeID";
            this.lblDisplayMakeID.Size = new System.Drawing.Size(10, 13);
            this.lblDisplayMakeID.TabIndex = 27;
            this.lblDisplayMakeID.Text = "-";
            // 
            // lblDisplayRegNo
            // 
            this.lblDisplayRegNo.AutoSize = true;
            this.lblDisplayRegNo.Location = new System.Drawing.Point(83, 4);
            this.lblDisplayRegNo.Name = "lblDisplayRegNo";
            this.lblDisplayRegNo.Size = new System.Drawing.Size(10, 13);
            this.lblDisplayRegNo.TabIndex = 26;
            this.lblDisplayRegNo.Text = "-";
            // 
            // lblRegNo
            // 
            this.lblRegNo.AutoSize = true;
            this.lblRegNo.Location = new System.Drawing.Point(3, 4);
            this.lblRegNo.Name = "lblRegNo";
            this.lblRegNo.Size = new System.Drawing.Size(47, 13);
            this.lblRegNo.TabIndex = 25;
            this.lblRegNo.Text = "Reg. No";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(267, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 20);
            this.label1.TabIndex = 72;
            this.label1.Text = "Details";
            // 
            // lstUpgradeIDs
            // 
            this.lstUpgradeIDs.FormattingEnabled = true;
            this.lstUpgradeIDs.Location = new System.Drawing.Point(767, 24);
            this.lstUpgradeIDs.Name = "lstUpgradeIDs";
            this.lstUpgradeIDs.Size = new System.Drawing.Size(194, 173);
            this.lstUpgradeIDs.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(-119, -1);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1367, 55);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 74;
            this.pictureBox1.TabStop = false;
            // 
            // btnHome
            // 
            this.btnHome.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHome.BackgroundImage")));
            this.btnHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.Location = new System.Drawing.Point(14, 86);
            this.btnHome.Margin = new System.Windows.Forms.Padding(2);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(75, 75);
            this.btnHome.TabIndex = 77;
            this.btnHome.UseVisualStyleBackColor = true;
            // 
            // errP
            // 
            this.errP.ContainerControl = this;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel6.Location = new System.Drawing.Point(-14, 1);
            this.panel6.Margin = new System.Windows.Forms.Padding(2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(3, 520);
            this.panel6.TabIndex = 38;
            // 
            // btns0
            // 
            this.btns0.Location = new System.Drawing.Point(6, 3);
            this.btns0.Name = "btns0";
            this.btns0.Size = new System.Drawing.Size(24, 24);
            this.btns0.TabIndex = 24;
            this.btns0.Text = "A";
            this.btns0.UseVisualStyleBackColor = true;
            // 
            // btns23
            // 
            this.btns23.Location = new System.Drawing.Point(36, 3);
            this.btns23.Name = "btns23";
            this.btns23.Size = new System.Drawing.Size(24, 24);
            this.btns23.TabIndex = 21;
            this.btns23.Text = "X";
            this.btns23.UseVisualStyleBackColor = true;
            // 
            // btns25
            // 
            this.btns25.Location = new System.Drawing.Point(66, 3);
            this.btns25.Name = "btns25";
            this.btns25.Size = new System.Drawing.Size(24, 24);
            this.btns25.TabIndex = 23;
            this.btns25.Text = "Z";
            this.btns25.UseVisualStyleBackColor = true;
            // 
            // btns22
            // 
            this.btns22.Location = new System.Drawing.Point(96, 3);
            this.btns22.Name = "btns22";
            this.btns22.Size = new System.Drawing.Size(24, 24);
            this.btns22.TabIndex = 20;
            this.btns22.Text = "W";
            this.btns22.UseVisualStyleBackColor = true;
            // 
            // btns24
            // 
            this.btns24.Location = new System.Drawing.Point(126, 3);
            this.btns24.Name = "btns24";
            this.btns24.Size = new System.Drawing.Size(24, 24);
            this.btns24.TabIndex = 22;
            this.btns24.Text = "Y";
            this.btns24.UseVisualStyleBackColor = true;
            // 
            // btns21
            // 
            this.btns21.Location = new System.Drawing.Point(156, 3);
            this.btns21.Name = "btns21";
            this.btns21.Size = new System.Drawing.Size(24, 24);
            this.btns21.TabIndex = 19;
            this.btns21.Text = "V";
            this.btns21.UseVisualStyleBackColor = true;
            // 
            // btns20
            // 
            this.btns20.Location = new System.Drawing.Point(186, 3);
            this.btns20.Name = "btns20";
            this.btns20.Size = new System.Drawing.Size(24, 24);
            this.btns20.TabIndex = 18;
            this.btns20.Text = "U";
            this.btns20.UseVisualStyleBackColor = true;
            // 
            // btns19
            // 
            this.btns19.Location = new System.Drawing.Point(216, 3);
            this.btns19.Name = "btns19";
            this.btns19.Size = new System.Drawing.Size(24, 24);
            this.btns19.TabIndex = 17;
            this.btns19.Text = "T";
            this.btns19.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Location = new System.Drawing.Point(115, 18);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(3, 520);
            this.panel5.TabIndex = 75;
            // 
            // btns18
            // 
            this.btns18.Location = new System.Drawing.Point(246, 3);
            this.btns18.Name = "btns18";
            this.btns18.Size = new System.Drawing.Size(24, 24);
            this.btns18.TabIndex = 14;
            this.btns18.Text = "S";
            this.btns18.UseVisualStyleBackColor = true;
            // 
            // btns16
            // 
            this.btns16.Location = new System.Drawing.Point(306, 3);
            this.btns16.Name = "btns16";
            this.btns16.Size = new System.Drawing.Size(24, 24);
            this.btns16.TabIndex = 15;
            this.btns16.Text = "Q";
            this.btns16.UseVisualStyleBackColor = true;
            // 
            // btns15
            // 
            this.btns15.Location = new System.Drawing.Point(336, 3);
            this.btns15.Name = "btns15";
            this.btns15.Size = new System.Drawing.Size(24, 24);
            this.btns15.TabIndex = 14;
            this.btns15.Text = "P";
            this.btns15.UseVisualStyleBackColor = true;
            // 
            // btns14
            // 
            this.btns14.Location = new System.Drawing.Point(366, 3);
            this.btns14.Name = "btns14";
            this.btns14.Size = new System.Drawing.Size(24, 24);
            this.btns14.TabIndex = 13;
            this.btns14.Text = "O";
            this.btns14.UseVisualStyleBackColor = true;
            // 
            // btns13
            // 
            this.btns13.Location = new System.Drawing.Point(396, 3);
            this.btns13.Name = "btns13";
            this.btns13.Size = new System.Drawing.Size(24, 24);
            this.btns13.TabIndex = 12;
            this.btns13.Text = "N";
            this.btns13.UseVisualStyleBackColor = true;
            // 
            // btns12
            // 
            this.btns12.Location = new System.Drawing.Point(426, 3);
            this.btns12.Name = "btns12";
            this.btns12.Size = new System.Drawing.Size(24, 24);
            this.btns12.TabIndex = 11;
            this.btns12.Text = "M";
            this.btns12.UseVisualStyleBackColor = true;
            // 
            // btnDisplayExit
            // 
            this.btnDisplayExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDisplayExit.BackgroundImage")));
            this.btnDisplayExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDisplayExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplayExit.Location = new System.Drawing.Point(14, 176);
            this.btnDisplayExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnDisplayExit.Name = "btnDisplayExit";
            this.btnDisplayExit.Size = new System.Drawing.Size(75, 75);
            this.btnDisplayExit.TabIndex = 78;
            this.btnDisplayExit.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel4.Location = new System.Drawing.Point(-14, 1);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(3, 520);
            this.panel4.TabIndex = 38;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(115)))), ((int)(((byte)(165)))));
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(-8, 18);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(3, 520);
            this.panel3.TabIndex = 76;
            // 
            // btns17
            // 
            this.btns17.Location = new System.Drawing.Point(276, 3);
            this.btns17.Name = "btns17";
            this.btns17.Size = new System.Drawing.Size(24, 24);
            this.btns17.TabIndex = 16;
            this.btns17.Text = "R";
            this.btns17.UseVisualStyleBackColor = true;
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnlMain.Controls.Add(this.btnDelBooking);
            this.pnlMain.Controls.Add(this.btnNewBooking);
            this.pnlMain.Controls.Add(this.pnlAddItems);
            this.pnlMain.Controls.Add(this.btnReport);
            this.pnlMain.Controls.Add(this.tableLayoutPanel1);
            this.pnlMain.Controls.Add(this.btnDeleteItem);
            this.pnlMain.Controls.Add(this.btnAddItem);
            this.pnlMain.Location = new System.Drawing.Point(123, 94);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1125, 444);
            this.pnlMain.TabIndex = 73;
            // 
            // btnDeleteItem
            // 
            this.btnDeleteItem.Location = new System.Drawing.Point(999, 63);
            this.btnDeleteItem.Name = "btnDeleteItem";
            this.btnDeleteItem.Size = new System.Drawing.Size(115, 26);
            this.btnDeleteItem.TabIndex = 8;
            this.btnDeleteItem.Text = "Delete Item";
            this.btnDeleteItem.UseVisualStyleBackColor = true;
            // 
            // btnAddItem
            // 
            this.btnAddItem.Location = new System.Drawing.Point(999, 36);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.Size = new System.Drawing.Size(115, 23);
            this.btnAddItem.TabIndex = 6;
            this.btnAddItem.Text = "Begin Add";
            this.btnAddItem.UseVisualStyleBackColor = true;
            // 
            // btns11
            // 
            this.btns11.Location = new System.Drawing.Point(456, 3);
            this.btns11.Name = "btns11";
            this.btns11.Size = new System.Drawing.Size(24, 24);
            this.btns11.TabIndex = 4;
            this.btns11.Text = "L";
            this.btns11.UseVisualStyleBackColor = true;
            // 
            // btns10
            // 
            this.btns10.Location = new System.Drawing.Point(486, 3);
            this.btns10.Name = "btns10";
            this.btns10.Size = new System.Drawing.Size(24, 24);
            this.btns10.TabIndex = 10;
            this.btns10.Text = "K";
            this.btns10.UseVisualStyleBackColor = true;
            // 
            // btns9
            // 
            this.btns9.Location = new System.Drawing.Point(516, 3);
            this.btns9.Name = "btns9";
            this.btns9.Size = new System.Drawing.Size(24, 24);
            this.btns9.TabIndex = 9;
            this.btns9.Text = "J";
            this.btns9.UseVisualStyleBackColor = true;
            // 
            // btns8
            // 
            this.btns8.Location = new System.Drawing.Point(546, 3);
            this.btns8.Name = "btns8";
            this.btns8.Size = new System.Drawing.Size(24, 24);
            this.btns8.TabIndex = 8;
            this.btns8.Text = "I";
            this.btns8.UseVisualStyleBackColor = true;
            // 
            // btns7
            // 
            this.btns7.Location = new System.Drawing.Point(576, 3);
            this.btns7.Name = "btns7";
            this.btns7.Size = new System.Drawing.Size(24, 24);
            this.btns7.TabIndex = 7;
            this.btns7.Text = "H";
            this.btns7.UseVisualStyleBackColor = true;
            // 
            // btns5
            // 
            this.btns5.Location = new System.Drawing.Point(636, 3);
            this.btns5.Name = "btns5";
            this.btns5.Size = new System.Drawing.Size(24, 24);
            this.btns5.TabIndex = 5;
            this.btns5.Text = "F";
            this.btns5.UseVisualStyleBackColor = true;
            // 
            // btns4
            // 
            this.btns4.Location = new System.Drawing.Point(666, 3);
            this.btns4.Name = "btns4";
            this.btns4.Size = new System.Drawing.Size(24, 24);
            this.btns4.TabIndex = 4;
            this.btns4.Text = "E";
            this.btns4.UseVisualStyleBackColor = true;
            // 
            // btns3
            // 
            this.btns3.Location = new System.Drawing.Point(696, 3);
            this.btns3.Name = "btns3";
            this.btns3.Size = new System.Drawing.Size(24, 24);
            this.btns3.TabIndex = 3;
            this.btns3.Text = "D";
            this.btns3.UseVisualStyleBackColor = true;
            // 
            // btns2
            // 
            this.btns2.Location = new System.Drawing.Point(726, 3);
            this.btns2.Name = "btns2";
            this.btns2.Size = new System.Drawing.Size(24, 24);
            this.btns2.TabIndex = 2;
            this.btns2.Text = "C";
            this.btns2.UseVisualStyleBackColor = true;
            // 
            // btns1
            // 
            this.btns1.Location = new System.Drawing.Point(756, 3);
            this.btns1.Name = "btns1";
            this.btns1.Size = new System.Drawing.Size(24, 24);
            this.btns1.TabIndex = 1;
            this.btns1.Text = "B";
            this.btns1.UseVisualStyleBackColor = true;
            // 
            // pnlButtons
            // 
            this.pnlButtons.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pnlButtons.Controls.Add(this.btns0);
            this.pnlButtons.Controls.Add(this.btns23);
            this.pnlButtons.Controls.Add(this.btns25);
            this.pnlButtons.Controls.Add(this.btns22);
            this.pnlButtons.Controls.Add(this.btns24);
            this.pnlButtons.Controls.Add(this.btns21);
            this.pnlButtons.Controls.Add(this.btns20);
            this.pnlButtons.Controls.Add(this.btns19);
            this.pnlButtons.Controls.Add(this.btns18);
            this.pnlButtons.Controls.Add(this.btns17);
            this.pnlButtons.Controls.Add(this.btns16);
            this.pnlButtons.Controls.Add(this.btns15);
            this.pnlButtons.Controls.Add(this.btns14);
            this.pnlButtons.Controls.Add(this.btns13);
            this.pnlButtons.Controls.Add(this.btns12);
            this.pnlButtons.Controls.Add(this.btns11);
            this.pnlButtons.Controls.Add(this.btns10);
            this.pnlButtons.Controls.Add(this.btns9);
            this.pnlButtons.Controls.Add(this.btns8);
            this.pnlButtons.Controls.Add(this.btns7);
            this.pnlButtons.Controls.Add(this.btns6);
            this.pnlButtons.Controls.Add(this.btns5);
            this.pnlButtons.Controls.Add(this.btns4);
            this.pnlButtons.Controls.Add(this.btns3);
            this.pnlButtons.Controls.Add(this.btns2);
            this.pnlButtons.Controls.Add(this.btns1);
            this.pnlButtons.Location = new System.Drawing.Point(123, 56);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(1125, 32);
            this.pnlButtons.TabIndex = 72;
            // 
            // btns6
            // 
            this.btns6.Location = new System.Drawing.Point(606, 3);
            this.btns6.Name = "btns6";
            this.btns6.Size = new System.Drawing.Size(24, 24);
            this.btns6.TabIndex = 6;
            this.btns6.Text = "G";
            this.btns6.UseVisualStyleBackColor = true;
            // 
            // frmEditDelUpgradeOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1252, 542);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.btnDisplayExit);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlButtons);
            this.Name = "frmEditDelUpgradeOrder";
            this.Text = "frmEditDelUpgradeOrder";
            this.Load += new System.EventHandler(this.frmEditDelUpgradeOrder_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStock)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlStock.ResumeLayout(false);
            this.pnlStockDGV.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderDetails)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.pnlBookingItemsDGV.ResumeLayout(false);
            this.pnlAddItems.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.pnlDisplayCarDetails.ResumeLayout(false);
            this.pnlDisplayCarDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picTEST)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errP)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.pnlMain.ResumeLayout(false);
            this.pnlButtons.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNewBooking;
        private System.Windows.Forms.DataGridView dgvStock;
        private System.Windows.Forms.TextBox txtDisplaySearch;
        private System.Windows.Forms.ComboBox cmbDisplaySearch;
        private System.Windows.Forms.Label lblStockDetails;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel pnlStock;
        private System.Windows.Forms.Panel pnlStockDGV;
        private System.Windows.Forms.DataGridViewButtonColumn btnDecreaseQty;
        private System.Windows.Forms.DataGridViewButtonColumn btnIncreaseQty;
        private System.Windows.Forms.DataGridView dgvOrderDetails;
        private System.Windows.Forms.Label lblOrderDetails;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel pnlBookingItemsDGV;
        private System.Windows.Forms.Button btnDelBooking;
        private System.Windows.Forms.Panel pnlAddItems;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblCar;
        private System.Windows.Forms.ListBox lstCar;
        private System.Windows.Forms.Panel pnlDisplayCarDetails;
        private System.Windows.Forms.PictureBox picTEST;
        private System.Windows.Forms.Label lblMileage;
        private System.Windows.Forms.Label lblCondition;
        private System.Windows.Forms.Label lblSalePrice;
        private System.Windows.Forms.Label lblModel;
        private System.Windows.Forms.Label lblMakeID;
        private System.Windows.Forms.Label lblDisplayMileage;
        private System.Windows.Forms.Label lblDisplayCondition;
        private System.Windows.Forms.Label lblDisplaySalePrice;
        private System.Windows.Forms.Label lblDisplayModel;
        private System.Windows.Forms.Label lblDisplayMakeID;
        private System.Windows.Forms.Label lblDisplayRegNo;
        private System.Windows.Forms.Label lblRegNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstUpgradeIDs;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.ErrorProvider errP;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btnDisplayExit;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Button btnDeleteItem;
        private System.Windows.Forms.Button btnAddItem;
        private System.Windows.Forms.Panel pnlButtons;
        private System.Windows.Forms.Button btns0;
        private System.Windows.Forms.Button btns23;
        private System.Windows.Forms.Button btns25;
        private System.Windows.Forms.Button btns22;
        private System.Windows.Forms.Button btns24;
        private System.Windows.Forms.Button btns21;
        private System.Windows.Forms.Button btns20;
        private System.Windows.Forms.Button btns19;
        private System.Windows.Forms.Button btns18;
        private System.Windows.Forms.Button btns17;
        private System.Windows.Forms.Button btns16;
        private System.Windows.Forms.Button btns15;
        private System.Windows.Forms.Button btns14;
        private System.Windows.Forms.Button btns13;
        private System.Windows.Forms.Button btns12;
        private System.Windows.Forms.Button btns11;
        private System.Windows.Forms.Button btns10;
        private System.Windows.Forms.Button btns9;
        private System.Windows.Forms.Button btns8;
        private System.Windows.Forms.Button btns7;
        private System.Windows.Forms.Button btns6;
        private System.Windows.Forms.Button btns5;
        private System.Windows.Forms.Button btns4;
        private System.Windows.Forms.Button btns3;
        private System.Windows.Forms.Button btns2;
        private System.Windows.Forms.Button btns1;
    }
}