﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScreenDesigns
{
    public partial class frmUpgradeOrders : Form
    {
        public string tempRegNo, tempUpgradeOrderID;
        public DateTime tempDateOrdered, tempDateCompleted;
        public bool ok = true;
        public frmUpgradeOrders()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            ok = false;
            this.Close();
        }

        private void frmUpgradeOrders_Load(object sender, EventArgs e)
        {
            lblDisplayUpgradeOrderID.Text = tempUpgradeOrderID;
            lblDisplayRegNo.Text = tempRegNo;
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            tempDateOrdered = dtpAddDateOrdered.Value;
            tempDateCompleted = dtpAddDateCompleted.Value;
            MessageBox.Show("It will take: " + (tempDateCompleted - tempDateOrdered).Days + " days to complete this booking.");

            this.Close();
        }

        


            

    }

}