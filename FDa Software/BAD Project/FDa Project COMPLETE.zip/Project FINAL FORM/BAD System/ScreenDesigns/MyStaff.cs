﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScreenDesigns
{
    class MyStaff
    {
        private string staffID, forename, surname, street, town, county, postcode, email, telNo;


        public MyStaff()
        {
            this.staffID = "";
            this.surname = "";
            this.forename = "";
            this.street = "";
            this.town = "";
            this.county = "";
            this.postcode = "";
            this.email = "";
            this.telNo = "";
        }

        public MyStaff(string staffID, string surname, string forename, string street, string town, string county, string postcode,string email,string telNo)
        {
            this.staffID = staffID;
            this.surname = surname;
            this.forename = forename;
            this.street = street;
            this.town = town;
            this.county = county;
            this.postcode = postcode;
            this.email = email;
            this.telNo = telNo;
        }

        public string StaffID
        {
            get { return staffID; }
            set { staffID = value; }
        }

        public string Surname
        {
            get { return surname; }
            set
            {
                if (MyValidation.validLength(value, 2, 15) && MyValidation.validSurname(value))
                {
                    surname = MyValidation.firstLetterEachWordUpper(value);
                }
                else
                {
                    throw new MyException("Surname must be between 2-15 letters.");
                }
            }
        }

        public string Forename
        {
            get { return forename; }
            set
            {
                if (MyValidation.validLength(value, 2, 15) && MyValidation.validForename(value))
                {
                    forename = MyValidation.firstLetterEachWordUpper(value);
                }
                else
                {
                    throw new MyException("Forename must be between 2-15 letters.");
                }
            }
        }

        public string Street
        {
            get { return street; }
            set
            {
                if (MyValidation.validLength(value, 5, 40) && MyValidation.validLetterNumberWhiteSpace(value))
                {
                    street = MyValidation.firstLetterEachWordUpper(value);
                }
                else
                {
                    throw new MyException("Street must be 5-40 letters.");
                }
            }
        }

        public string Town
        {

            get { return town; }
            set
            {
                if (MyValidation.validLength(value, 2, 20) && MyValidation.validLetterWhiteSpace(value))
                {
                    town = MyValidation.firstLetterEachWordUpper(value);
                }
                else
                {
                    throw new MyException("Town must be 2-20 letters.");
                }
            }
        }

        public string County
        {

            get { return county; }
            set
            {
                if (MyValidation.validLength(value, 2, 20) && MyValidation.validLetter(value))
                {
                    county = MyValidation.firstLetterEachWordUpper(value);
                }
                else
                {
                    throw new MyException("Country must be 2-20 letters.");
                }
            }
        }

        public string TelNo
        {
            get { return telNo; }
            set
            {
                if (MyValidation.validTelNo(value) && MyValidation.validLength(value, 11, 11))
                {
                    telNo = value;
                }
                else
                {
                    throw new MyException("Input number was invalid length (Must be 11 numbers long).");
                }
            }
        }

        public string Postcode
        {
            get { return postcode; }
            set
            {
                if (MyValidation.validPostcode(value))
                {
                    postcode = MyValidation.EachLetterToUpper(value);
                }
                else
                {
                    throw new MyException("Postcode entered incorrectly");
                }
            }
        }

        public string Email
        {
            get { return email; }
            set
            {
                if (MyValidation.validEmail(value))
                {
                    email = value;
                }
                else
                {
                    throw new MyException("Email entered incorrectly");
                }
            }
        }
    }
}

    
