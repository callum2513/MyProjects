﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScreenDesigns
{
    public partial class frmMaintenance : Form
    {
        public frmMaintenance()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMainMenu frmMM = new frmMainMenu();
            frmMM.ShowDialog();
        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmStaff staffForm = new frmStaff();
            staffForm.ShowDialog();
        }

        private void btnMaintenance_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmUpgrades frmUp = new frmUpgrades();
            frmUp.ShowDialog();
        }

       

        private void btnDisplayEdit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmEditDelUpgradeOrder frmEditUp = new frmEditDelUpgradeOrder();
            frmEditUp.ShowDialog();
        }

        private void btnMaintenance_MouseHover(object sender, EventArgs e)
        {
            lblUpgradesBtn.Show();
        }

        private void btnMaintenance_MouseLeave(object sender, EventArgs e)
        {
            lblUpgradesBtn.Hide();
        }
        

        private void btnDisplayEdit_MouseHover(object sender, EventArgs e)
        {
            lblEditBtns.Show();
        }

        private void btnDisplayEdit_MouseLeave(object sender, EventArgs e)
        {
            lblEditBtns.Hide();
        }
    }
}
