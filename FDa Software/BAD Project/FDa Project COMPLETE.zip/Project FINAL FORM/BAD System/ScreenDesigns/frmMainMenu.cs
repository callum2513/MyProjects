﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScreenDesigns
{
	public partial class frmMainMenu : Form
	{
		public frmMainMenu()
		{
			InitializeComponent();
		}

		private void frmMainMenu_Load(object sender, EventArgs e)
		{
			pnlTopMenuBar.BackColor = Color.FromArgb(27, 99, 155);
			panel1.BackColor = Color.FromArgb(27, 99, 155);
			/*btnCustomer.BackColor = Color.FromArgb(100, 100, 100);
			btnAppointments.BackColor = Color.FromArgb(100, 100, 100);
			btnCars.BackColor = Color.FromArgb(100, 100, 100);
			btnExit.BackColor = Color.FromArgb(100, 100, 100);
			btnMaintenance.BackColor = Color.FromArgb(100, 100, 100);
			btnSales.BackColor = Color.FromArgb(100, 100, 100);*/

		}

		private void bannerTimer_Tick(object sender, EventArgs e)
		{
			pb1.Left -= 2;
			pb2.Left -= 2;

			if (pb1.Left == -100)
				pb1.Left = 100;

			if (pb2.Left <= -100)
				pb2.Left = pb1.Left + 100;
		}

		private void btnCustomer_MouseHover(object sender, EventArgs e)
		{
			lblCustBtn.Visible = true;
		}
		private void btnCustomer_MouseLeave(object sender, EventArgs e)
		{
			lblCustBtn.Visible = false;
		}
		private void btnMaintenance_MouseHover(object sender, EventArgs e)
		{
			lblMaintenanceBtn.Visible = true;
		}
		private void btnMaintenance_MouseLeave(object sender, EventArgs e)
		{
			lblMaintenanceBtn.Visible = false;
		}
		private void btnCars_MouseHover(object sender, EventArgs e)
		{
			lblCarsBtn.Visible = true;
		}
		private void btnCars_MouseLeave(object sender, EventArgs e)
		{
			lblCarsBtn.Visible = false;
		}
		private void btnSales_MouseHover(object sender, EventArgs e)
		{
			lblSalesBtn.Visible = true;
		}
		private void btnSales_MouseLeave(object sender, EventArgs e)
		{
			lblSalesBtn.Visible = false;
		}
		private void btnAppointments_MouseHover(object sender, EventArgs e)
		{
			btnStaff.Visible = true;
		}
		private void btnAppointments_MouseLeave(object sender, EventArgs e)
		{
			btnStaff.Visible = false;
		}
		private void btnExit_MouseHover(object sender, EventArgs e)
		{
			lblExitBtn.Visible = true;
		}
		private void btnExit_MouseLeave(object sender, EventArgs e)
		{
			lblExitBtn.Visible = false;
		}

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmCustomer custForm = new frmCustomer();
            custForm.ShowDialog();
        }

        private void btnCars_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmCar carForm = new frmCar();
            carForm.ShowDialog();
        }

        private void btnSales_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmSales salesForm = new frmSales();
            salesForm.ShowDialog();
        }

        private void btnMaintenance_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMaintenance frmMain = new frmMaintenance();
            frmMain.ShowDialog();
        }

        private void btnAppointments_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmStaff frmSt = new frmStaff();
            frmSt.ShowDialog();
        }
    }
}
