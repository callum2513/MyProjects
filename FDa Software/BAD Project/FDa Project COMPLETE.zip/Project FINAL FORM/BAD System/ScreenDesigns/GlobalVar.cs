﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScreenDesigns
{
    class GlobalVar
    {
        public static int purchasePriceGlobal = 0;
        public static Boolean tradeInCar = false, tradeInFormClose = false, addFinance = false;
        public static int counter = 0;
        public static int noOfMonths = 0;
    }
}
