﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScreenDesigns
{
    class MySales
    {
        private string orderID = "", custID = "";
        private DateTime orderDate = DateTime.Now;
        private int paymentTypeID = 0;


        public MySales()
        {
            this.orderID = "";
            this.custID = "";
            this.orderDate = DateTime.Now;
            this.paymentTypeID = 0;
        }

        public MySales(string OrderID, string CustID, DateTime OrderDate, int PaymentTypeID)
        {
            this.orderID = OrderID;
            this.custID = CustID;
            this.orderDate = OrderDate;
            this.paymentTypeID = PaymentTypeID;
        }

        public string OrderID
        {
            get { return orderID; }
            set { orderID = value; }
        }
        public string CustID
        {
            get { return custID; }
            set { custID = value; }
        }
        public DateTime OrderDate
        {
            get { return orderDate; }
            set
            {
                if (value.Date >= DateTime.Now.Date)
                {
                    orderDate = value;
                }
                else
                    throw new MyException("Order Date cannot be in the past");
            }
        }
        public int PaymentTypeID
        {
            get { return paymentTypeID; }
            set
            {
                if (value >= 1 || value <= 4)
                {
                    paymentTypeID = value;
                }
                else
                    throw new MyException("PaymentTypeID must be 1,2,3 or 4");   
            }
        }



    }
}
