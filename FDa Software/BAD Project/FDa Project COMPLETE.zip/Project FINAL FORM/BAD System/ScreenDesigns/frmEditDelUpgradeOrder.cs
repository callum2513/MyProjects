﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace ScreenDesigns
{
    public partial class frmEditDelUpgradeOrder : Form
    {

        Button[] btns = new Button[26];

        SqlDataAdapter daCar, daTest, daAddBooking, daUpgradeStock, daUpgrades, daAddUpgrade, daCarDetails2, daTCD, daMake, daStockSearch, daStock;
        DataSet dsDesmonds = new DataSet();
        SqlCommandBuilder cmbBAddUpgrade, cmdBTest, cmbBCarDetails2, cmdBMake, cmdbStockSearch, cmdBStock, cmbBAddBooking;
        SqlCommand cmdTCD, cmdCarDetails, cmdUpgrades, cmdUpgradeStock;
        SqlConnection conn;
        DataRow drAddNewUpgrade, drAddBooking;
        String connStr, sqlTest, sqlUpgrades, sqlMake, sqlCars, sqlCarDetails2, sqlTCD, sqlUpgradeStock, sqlStockSearch, sqlStock, sqlAddUpgrade, sqlAddBooking;
        frmReports frmReport = new frmReports();
        frmQuantity frmQ = new frmQuantity();
        frmUpgradeOrders frmOO = new frmUpgradeOrders();
        string tempooID = "";
        bool ok = true;

        private void btnAddItem_Click_1(object sender, EventArgs e)
        {

        }

        private void btnDelBooking_Click(object sender, EventArgs e)
        {
            drAddNewUpgrade = dsDesmonds.Tables["upgradeOrderDetails"].Rows.Find(lstUpgradeIDs.SelectedValue);
            drAddBooking = dsDesmonds.Tables["upgradeOrderDetails"].Rows.Find(lstUpgradeIDs.SelectedValue);

            if (MessageBox.Show("Are you sure you want to delete this booking? this canot be undone.", "Delete Bookings", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
            {
                try
                {
                    drAddNewUpgrade.Delete();
                    daAddUpgrade.Update(dsDesmonds, "upgradeOrderDetails");
                }
                catch (SqlException)
                {
                    MessageBox.Show("Can't Delete this upgrade!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    drAddNewUpgrade.RejectChanges();
                }

                try
                {
                    drAddBooking.Delete();
                    daAddBooking.Update(dsDesmonds, "upgradeOrders");
                }
                catch (SqlException)
                {
                    MessageBox.Show("Can't Delete this upgrade!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    drAddNewUpgrade.RejectChanges();
                }
            }

        }

        string concatOoID = "UpO";
        int tempooIDNo;

        List<String> ooIDList = new List<string>();

        private void btnHome_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMainMenu frmMM = new frmMainMenu();
            frmMM.ShowDialog();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {

            try
            {
                frmReport frmrep = new frmReport();
                frmrep.upgradeOrderID = lstUpgradeIDs.SelectedValue.ToString();
                frmrep.ShowDialog();
            }
            catch (Exception)
            {
                MessageBox.Show("No upgrades to report on!");
            }
        }

        private void btnAddBooking_Click(object sender, EventArgs e)
        {
            errP.Clear();

            if (btnNewBooking.Text == "New Booking")
            {
                pnlAddItems.Visible = true;
                pnlBookingItemsDGV.Visible = false;
                dgvStock.Enabled = true;
                btnNewBooking.Text = "Save New Booking";
                tableLayoutPanel1.Enabled = false;
            }
            else
            {
                MyUpgradeOrder myoo = new MyUpgradeOrder(); // Have to insert an upgrade order into here first // 
                MyUpgradeOrderDetails myood = new MyUpgradeOrderDetails(); // Then the details of the upgrade order get added //
                frmOO.tempUpgradeOrderID = getUpODID();
                frmOO.tempRegNo = lstCar.SelectedValue.ToString();
                tableLayoutPanel1.Enabled = false;

                int selectedRowIndex = dgvStock.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = dgvStock.Rows[selectedRowIndex];
                string tempMakeID = Convert.ToString(selectedRow.Cells["MakeID"].Value);

                if (tempMakeID != lblDisplayMakeID.Text)
                {
                    MessageBox.Show("This part is for a different Make, please choose a part with with the Make: " + lblDisplayMakeID.Text.Trim());
                    ok = false;
                }

                if (ok)
                {
                    frmOO.ShowDialog();
                    ok = frmOO.ok;

                    try
                    {
                        myoo.DateOrdered = frmOO.tempDateOrdered;
                    }
                    catch (Exception)
                    {
                        ok = false;
                        throw;
                    }

                    try
                    {
                        myoo.DateCompleted = frmOO.tempDateCompleted;
                    }
                    catch (Exception)
                    {
                        ok = false;
                        throw;
                    }

                    try
                    {
                        myoo.UpgradeOrderID = getUpODID();
                    }
                    catch (Exception)
                    {
                        ok = false;
                        throw;
                    }

                    try
                    {
                        myoo.RegNo = lstCar.SelectedValue.ToString();
                    }
                    catch (Exception)
                    {
                        ok = false;
                        throw;
                    }

                    int frmQUpgradeDesc = dgvStock.SelectedCells[0].RowIndex;
                    DataGridViewRow frmQselectedRow = dgvStock.Rows[frmQUpgradeDesc];
                    string frmQtempUpgradeDesc = Convert.ToString(frmQselectedRow.Cells["UpgradeDesc"].Value);


                    string frmQtempUpgradeID = Convert.ToString(frmQselectedRow.Cells["UpgradeID"].Value);


                    string frmQtempSupplier = Convert.ToString(frmQselectedRow.Cells["SupplierID"].Value);


                    string frmQtempMake = Convert.ToString(frmQselectedRow.Cells["MakeID"].Value);


                    double frmQtempSell = Convert.ToDouble(frmQselectedRow.Cells["SellPrice"].Value);


                    double frmQtempPurc = Convert.ToDouble(frmQselectedRow.Cells["PurchasePrice"].Value);


                    frmQ.upgradeID = frmQtempUpgradeID;
                    frmQ.upgradeDesc = frmQtempUpgradeDesc;
                    frmQ.supplier = frmQtempSupplier;
                    frmQ.make = frmQtempMake;
                    frmQ.sellPrice = frmQtempSell;
                    frmQ.purchasePrice = frmQtempPurc;
                    frmQ.ShowDialog();

                    if (frmQ.quantity == 0)
                    {
                        ok = false;
                    }

                    try
                    {
                        myood.UpgradeOrderID = getUpODID();
                    }
                    catch (Exception)
                    {

                        throw;
                    }

                    try
                    {
                        myood.UpgradeID = Convert.ToString(frmQselectedRow.Cells["UpgradeID"].Value);
                    }
                    catch (Exception)
                    {

                        throw;
                    }

                    try
                    {
                        myood.Quantity = frmQ.quantity;
                    }
                    catch (Exception)
                    {

                        throw;
                    }

                    try
                    {
                        myood.StaffID = frmQ.staffID;
                    }
                    catch (Exception)
                    {

                        throw;
                    }
                    try
                    {
                        if (ok)
                        {
                            // Add the new upgrade order

                            drAddBooking = dsDesmonds.Tables["upgradeOrders"].NewRow();

                            drAddBooking["UpgradeOrderID"] = myoo.UpgradeOrderID;
                            drAddBooking["RegNo"] = myoo.RegNo;
                            drAddBooking["DateOrdered"] = myoo.DateOrdered;
                            drAddBooking["DateCompleted"] = myoo.DateCompleted;

                            dsDesmonds.Tables["upgradeOrders"].Rows.Add(drAddBooking);
                            daAddBooking.Update(dsDesmonds, "upgradeOrders");

                            //Add the details for the new order

                            drAddNewUpgrade = dsDesmonds.Tables["upgradeOrderDetails"].NewRow();

                            drAddNewUpgrade["UpgradeOrderID"] = myood.UpgradeOrderID;
                            drAddNewUpgrade["UpgradeID"] = myood.UpgradeID;
                            drAddNewUpgrade["Quantity"] = myood.Quantity;
                            drAddNewUpgrade["StaffID"] = myood.StaffID;

                            dsDesmonds.Tables["upgradeOrderDetails"].Rows.Add(drAddNewUpgrade);
                            daAddUpgrade.Update(dsDesmonds, "upgradeOrderDetails");


                            dgvOrderDetails.DataSource = null;


                            fillListBoxUpgradeStock(lstCar.SelectedValue.ToString());

                            fillListBoxUpgrades(lblDisplayRegNo.Text.Trim());

                            btnNewBooking.Text = "New Booking";

                            tableLayoutPanel1.Enabled = true;

                        }
                    }
                    catch (MyException ex)
                    {
                        MessageBox.Show("" + ex.TargetSite + "" + ex.Message, "Error!", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    btnNewBooking.Text = "New Booking";

                    pnlAddItems.Visible = false;
                    pnlBookingItemsDGV.Visible = false;
                    dgvStock.Enabled = false;
                    tableLayoutPanel1.Enabled = true;


                }
            }
        }

        private void dgvStock_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            int frmQUpgradeDesc = dgvStock.SelectedCells[0].RowIndex;
            DataGridViewRow frmQselectedRow = dgvStock.Rows[frmQUpgradeDesc];
            string frmQtempUpgradeDesc = Convert.ToString(frmQselectedRow.Cells["UpgradeDesc"].Value);


            string frmQtempUpgradeID = Convert.ToString(frmQselectedRow.Cells["UpgradeID"].Value);


            string frmQtempSupplier = Convert.ToString(frmQselectedRow.Cells["SupplierID"].Value);


            string frmQtempMake = Convert.ToString(frmQselectedRow.Cells["MakeID"].Value);


            double frmQtempSell = Convert.ToDouble(frmQselectedRow.Cells["SellPrice"].Value);


            double frmQtempPurc = Convert.ToDouble(frmQselectedRow.Cells["PurchasePrice"].Value);


            frmQ.upgradeID = frmQtempUpgradeID;
            frmQ.upgradeDesc = frmQtempUpgradeDesc;
            frmQ.supplier = frmQtempSupplier;
            frmQ.make = frmQtempMake;
            frmQ.sellPrice = frmQtempSell;
            frmQ.purchasePrice = frmQtempPurc;
            frmQ.ShowDialog();
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            frmReport.ShowDialog();
        }

        private void frmEditDelUpgradeOrder_Activated(object sender, EventArgs e)
        {
            if (btnDelBooking.Text == "Cancel Booking")
            {
                ok = false;
            }



            dgvOrderDetails.Refresh();
            dgvStock.Refresh();
        }

        private void dgvOrderDetails_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int columnIndex = dgvOrderDetails.CurrentCell.ColumnIndex;
            string columnName = dgvOrderDetails.Columns[columnIndex].Name;
            string str = dgvOrderDetails.Rows[dgvOrderDetails.SelectedRows[0].Index].Cells[6].Value.ToString();

            if (columnName.Equals("btnIncreaseQty"))
            {
                drAddNewUpgrade = dsDesmonds.Tables["AllStock"].Rows.Find(str);

                //The quantity in stock before any changes
                int tempQty = Convert.ToInt32(drAddNewUpgrade["QtyInStock"].ToString());

                if (tempQty > 1)
                {
                    drAddNewUpgrade.BeginEdit();

                    drAddNewUpgrade["QtyInStock"] = (tempQty - 1);

                    drAddNewUpgrade.EndEdit();

                    daStock.Update(dsDesmonds, "AllStock");

                    dgvStock.DataSource = null;
                    dgvStock.DataSource = dsDesmonds.Tables["AllStock"];

                    // Adds quanitity to the existing booking //

                    Object[] findKeys = new Object[2];
                    findKeys[0] = lstUpgradeIDs.SelectedValue.ToString();
                    findKeys[1] = str;

                    drAddNewUpgrade = dsDesmonds.Tables["upgradeOrderDetails"].Rows.Find(findKeys);

                    tempQty = Convert.ToInt32(drAddNewUpgrade["Quantity"].ToString());

                    drAddNewUpgrade.BeginEdit();

                    drAddNewUpgrade["Quantity"] = tempQty + 1;

                    drAddNewUpgrade.EndEdit();

                    daAddUpgrade.Update(dsDesmonds, "upgradeOrderDetails");

                    dgvOrderDetails.DataSource = null;
                    dgvOrderDetails.DataSource = dsDesmonds.Tables["UpgradeStock"];

                    // puts the buttons back where they belong  

                    dgvOrderDetails.Columns["btnIncreaseQty"].DisplayIndex = 5;
                    dgvOrderDetails.Columns["btnIncreaseQty"].Visible = true;

                    dgvOrderDetails.Columns["btnDecreaseQty"].DisplayIndex = 5;
                    dgvOrderDetails.Columns["btnDecreaseQty"].Visible = true;
                }
                else
                {
                    MessageBox.Show("Not enough stock to increase quantity!");
                }

            }
            else if (columnName.Equals("btnDecreaseQty"))
            {
                int tempBookingQty = Convert.ToInt32(dgvOrderDetails.Rows[dgvOrderDetails.SelectedRows[0].Index].Cells[5].Value);
                tempBookingQty--;

                if (tempBookingQty <= 1)
                {
                    DialogResult dResult = MessageBox.Show("Would you like to delete this item from the booking?", "Remove item", MessageBoxButtons.YesNo);

                    if (dResult.Equals(DialogResult.Yes))
                    {
                        Object[] findKeys = new Object[2];
                        findKeys[0] = lstUpgradeIDs.SelectedValue.ToString();
                        findKeys[1] = str;

                        drAddNewUpgrade = dsDesmonds.Tables["upgradeOrderDetails"].Rows.Find(findKeys);

                        drAddNewUpgrade.Delete();

                        daAddUpgrade.Update(dsDesmonds, "upgradeOrderDetails");

                        dgvOrderDetails.DataSource = null;
                        dgvOrderDetails.DataSource = dsDesmonds.Tables["UpgradeStock"];



                        dgvOrderDetails.Columns["btnIncreaseQty"].DisplayIndex = 5;
                        dgvOrderDetails.Columns["btnIncreaseQty"].Visible = true;

                        dgvOrderDetails.Columns["btnDecreaseQty"].DisplayIndex = 5;
                        dgvOrderDetails.Columns["btnDecreaseQty"].Visible = true;

                    }
                    else
                    {

                    }
                }
                else
                {
                    drAddNewUpgrade = dsDesmonds.Tables["AllStock"].Rows.Find(str);

                    //The quantity in stock before any changes
                    int tempQty = Convert.ToInt32(drAddNewUpgrade["QtyInStock"].ToString());


                    if (tempQty > 1)
                    {
                        drAddNewUpgrade.BeginEdit();

                        drAddNewUpgrade["QtyInStock"] = (tempQty + 1);

                        drAddNewUpgrade.EndEdit();

                        daStock.Update(dsDesmonds, "AllStock");

                        dgvStock.DataSource = null;
                        dgvStock.DataSource = dsDesmonds.Tables["AllStock"];

                        // Adds quanitity to the existing booking //

                        Object[] findKeys = new Object[2];
                        findKeys[0] = lstUpgradeIDs.SelectedValue.ToString();
                        findKeys[1] = str;

                        drAddNewUpgrade = dsDesmonds.Tables["upgradeOrderDetails"].Rows.Find(findKeys);

                        tempQty = Convert.ToInt32(drAddNewUpgrade["Quantity"].ToString());

                        drAddNewUpgrade.BeginEdit();

                        drAddNewUpgrade["Quantity"] = tempQty - 1;

                        drAddNewUpgrade.EndEdit();

                        daAddUpgrade.Update(dsDesmonds, "upgradeOrderDetails");

                        dgvOrderDetails.DataSource = null;
                        dgvOrderDetails.DataSource = dsDesmonds.Tables["UpgradeStock"];

                        // puts the buttons back where they belong  

                        dgvOrderDetails.Columns["btnIncreaseQty"].DisplayIndex = 5;
                        dgvOrderDetails.Columns["btnIncreaseQty"].Visible = true;

                        dgvOrderDetails.Columns["btnDecreaseQty"].DisplayIndex = 5;
                        dgvOrderDetails.Columns["btnDecreaseQty"].Visible = true;
                    }
                }


            }
        }

        private void lstUpgradeIDs_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnDeleteItem_Click(object sender, EventArgs e)
        {
            string str = dgvOrderDetails.Rows[dgvOrderDetails.SelectedRows[0].Index].Cells[6].Value.ToString();


            if (dgvOrderDetails.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an upgrade from the list", "Upgrades");
            }
            else
            {


                Object[] findKeys = new Object[2];
                findKeys[0] = lstUpgradeIDs.SelectedValue.ToString();
                findKeys[1] = str;

                drAddNewUpgrade = dsDesmonds.Tables["upgradeOrderDetails"].Rows.Find(findKeys);

                try
                {
                    if (MessageBox.Show("Are you sure you want to delete this upgrade?", "Delete Upgrade", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                    {
                        drAddNewUpgrade.Delete();

                        daAddUpgrade.Update(dsDesmonds, "upgradeOrderDetails");

                        dgvOrderDetails.DataSource = null;
                        dgvOrderDetails.DataSource = dsDesmonds.Tables["UpgradeStock"];



                        dgvOrderDetails.Columns["btnIncreaseQty"].DisplayIndex = 5;
                        dgvOrderDetails.Columns["btnIncreaseQty"].Visible = true;

                        dgvOrderDetails.Columns["btnDecreaseQty"].DisplayIndex = 5;
                        dgvOrderDetails.Columns["btnDecreaseQty"].Visible = true;


                    }
                }
                catch (SqlException MyEx)
                {

                    throw;
                }
            }
        }

        private string getUpODID()
        {
            sqlTest = @"select distinct UpgradeOrderID from upgradeOrders";
            daTest = new SqlDataAdapter(sqlTest, connStr);
            cmdBTest = new SqlCommandBuilder(daTest);
            daTest.FillSchema(dsDesmonds, SchemaType.Source, "ooID");
            daTest.Fill(dsDesmonds, "ooID");




            foreach (DataRow dr in dsDesmonds.Tables["ooID"].Rows)
            {

                tempooID = (dr["UpgradeOrderID"].ToString());

            }

            tempooIDNo = Convert.ToInt32(tempooID.Substring(3, 5));
            tempooIDNo++;

            tempooID = (concatOoID + Convert.ToString(tempooIDNo));

            return tempooID;
        }

        private void frmEditDelUpgradeOrder_Load(object sender, EventArgs e)
        {
            pnlAddItems.Visible = false;

            int no;
            dgvOrderDetails.Columns["btnIncreaseQty"].Visible = false;
            dgvOrderDetails.Columns["btnDecreaseQty"].Visible = false;


            if (cmbDisplaySearch.SelectedIndex > 0)
            {

            }
            else
            {
                txtDisplaySearch.Enabled = false;
            }

            lstCar.Enabled = false;
            pnlDisplayCarDetails.Enabled = false;

            lstUpgradeIDs.Enabled = false;

            btnNewBooking.Enabled = false;
            btnDelBooking.Enabled = false;
            btnDeleteItem.Enabled = false;
            btnAddItem.Enabled = false;

            dgvStock.Enabled = false;



            for (int i = 0; i < 26; i++)
            {
                btns[i] = (Button)pnlButtons.Controls[i];
                btns[i].Text = "" + (char)(65 + i);
                btns[i].Enabled = false;
                btns[i].Click += new EventHandler(btnA_Click);
            }

            connStr = @"Data Source = .; Initial Catalog = Desmonds; Integrated Security = true";
            sqlCars = @"select * from car";
            daCar = new SqlDataAdapter(sqlCars, connStr);
            daCar.Fill(dsDesmonds, "car");

            sqlMake = @"select * from make";
            daMake = new SqlDataAdapter(sqlMake, connStr);
            cmdBMake = new SqlCommandBuilder(daMake);
            daMake.FillSchema(dsDesmonds, SchemaType.Source, "make");
            daMake.Fill(dsDesmonds, "make");

            sqlStock = @"select * from upgradeStock";
            daStock = new SqlDataAdapter(sqlStock, connStr);
            cmdBStock = new SqlCommandBuilder(daStock);
            daStock.FillSchema(dsDesmonds, SchemaType.Source, "AllStock");
            daStock.Fill(dsDesmonds, "AllStock");
            dgvStock.DataSource = dsDesmonds.Tables["AllStock"];
            dgvStock.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);



            foreach (DataRow dr in dsDesmonds.Tables["car"].Rows)
            {
                no = (int)dr["RegNo"].ToString()[0] - 65;
                btns[no].Enabled = true;
                btns[no].BackColor = Color.Black;
                btns[no].ForeColor = Color.White;
            }


            conn = new SqlConnection(connStr);

            sqlTCD = @"select RegNo, MakeID, Model, SalePrice, Mileage, Condition from car where RegNo LIKE @Letter order by Condition, Mileage";
            cmdTCD = new SqlCommand(sqlTCD, conn);
            cmdTCD.Parameters.Add("@Letter", SqlDbType.VarChar);
            daTCD = new SqlDataAdapter(cmdTCD);
            daTCD.FillSchema(dsDesmonds, SchemaType.Source, "TCD");

            //set up dataAdapter for upgrades for the listbox
            sqlUpgrades = @"select distinct c.RegNo, uo.UpgradeOrderID from upgradeOrders uo join upgradeOrderDetails uod on uod.UpgradeOrderID = uo.UpgradeOrderID join upgradeStock us on us.UpgradeID = uod.UpgradeID join car c on c.RegNo = uo.RegNo where c.RegNo LIKE @RegNo";
            cmdUpgrades = new SqlCommand(sqlUpgrades, conn);
            cmdUpgrades.Parameters.Add("@RegNo", SqlDbType.VarChar);
            daUpgrades = new SqlDataAdapter(cmdUpgrades);
            daUpgrades.FillSchema(dsDesmonds, SchemaType.Source, "Upgrades");

            //set up dataAdapter for the stock for the stock listbox

            sqlUpgradeStock = @"select us.UpgradeDesc, us.SellPrice, us.MakeID, ood.Quantity, ood.UpgradeID from upgradeStock us join upgradeOrderDetails ood on ood.UpgradeID = us.UpgradeID where ood.UpgradeOrderID LIKE @UpgradeOrderID";
            cmdUpgradeStock = new SqlCommand(sqlUpgradeStock, conn);
            cmdUpgradeStock.Parameters.Add("@UpgradeOrderID", SqlDbType.VarChar);
            daUpgradeStock = new SqlDataAdapter(cmdUpgradeStock);
            daUpgradeStock.FillSchema(dsDesmonds, SchemaType.Source, "UpgradeStock");

            DataColumn[] keyColumns = new DataColumn[1];
            keyColumns[0] = dsDesmonds.Tables["UpgradeStock"].Columns["UpgradeID"];
            dsDesmonds.Tables["UpgradeStock"].PrimaryKey = keyColumns;

            //Need a simple dataset with no parameter values to use with delete car details
            sqlCarDetails2 = @"select * from car";
            daCarDetails2 = new SqlDataAdapter(sqlCarDetails2, conn);
            cmbBCarDetails2 = new SqlCommandBuilder(daCarDetails2);
            daCarDetails2.FillSchema(dsDesmonds, SchemaType.Source, "BookingDet2");
            daCarDetails2.Fill(dsDesmonds, "BookingDet2");


            // need another simple dataset to add a new upgrade
            sqlAddUpgrade = @"Select * from upgradeOrderDetails";
            daAddUpgrade = new SqlDataAdapter(sqlAddUpgrade, conn);
            cmbBAddUpgrade = new SqlCommandBuilder(daAddUpgrade);
            daAddUpgrade.FillSchema(dsDesmonds, SchemaType.Source, "upgradeOrderDetails");
            daAddUpgrade.Fill(dsDesmonds, "upgradeOrderDetails");

            // simple dataset to add a new booking
            sqlAddBooking = @"select * from upgradeOrders";
            daAddBooking = new SqlDataAdapter(sqlAddBooking, conn);
            cmbBAddBooking = new SqlCommandBuilder(daAddBooking);
            daAddBooking.FillSchema(dsDesmonds, SchemaType.Source, "upgradeOrders");
            daAddBooking.Fill(dsDesmonds, "upgradeOrders");


        }
        private void cmbDisplaySearch_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            txtDisplaySearch.Enabled = true;
        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            if (btnAddItem.Text.Equals("Begin Add"))
            {
                pnlAddItems.Visible = true;
                dgvStock.Enabled = true;
                btnAddItem.Text = "Save";
            }
            else if (btnAddItem.Text.Equals("Save"))
            {
                MyUpgradeOrderDetails ood = new MyUpgradeOrderDetails();

                int selectedRowIndex = dgvStock.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = dgvStock.Rows[selectedRowIndex];
                string tempMakeID = Convert.ToString(selectedRow.Cells["MakeID"].Value);

                int selectedRowIndex2 = dgvStock.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow2 = dgvStock.Rows[selectedRowIndex];
                string tempUpgradeID = Convert.ToString(selectedRow.Cells["UpgradeID"].Value);

                int frmQUpgradeDesc = dgvStock.SelectedCells[0].RowIndex;
                DataGridViewRow frmQselectedRow = dgvStock.Rows[frmQUpgradeDesc];
                string frmQtempUpgradeDesc = Convert.ToString(frmQselectedRow.Cells["UpgradeDesc"].Value);


                string frmQtempUpgradeID = Convert.ToString(frmQselectedRow.Cells["UpgradeID"].Value);


                string frmQtempSupplier = Convert.ToString(frmQselectedRow.Cells["SupplierID"].Value);


                string frmQtempMake = Convert.ToString(frmQselectedRow.Cells["MakeID"].Value);


                double frmQtempSell = Convert.ToDouble(frmQselectedRow.Cells["SellPrice"].Value);


                double frmQtempPurc = Convert.ToDouble(frmQselectedRow.Cells["PurchasePrice"].Value);


                frmQ.upgradeID = frmQtempUpgradeID;
                frmQ.upgradeDesc = frmQtempUpgradeDesc;
                frmQ.supplier = frmQtempSupplier;
                frmQ.make = frmQtempMake;
                frmQ.sellPrice = frmQtempSell;
                frmQ.purchasePrice = frmQtempPurc;
                frmQ.ShowDialog();

                if (tempMakeID.Equals(lblDisplayMakeID.Text.Trim()))
                {
                    try
                    {
                        ood.UpgradeID = tempUpgradeID;
                    }
                    catch (MyException MyEx)
                    {

                        ok = false;
                    }


                    try
                    {
                        ood.UpgradeOrderID = lstUpgradeIDs.SelectedValue.ToString();
                    }
                    catch (MyException MyEx)
                    {

                        ok = false;
                    }

                    try
                    {
                        ood.Quantity = frmQ.quantity;
                    }
                    catch (Exception)
                    {

                        ok = false;
                    }

                    try
                    {
                        ood.StaffID = frmQ.staffID;
                    }
                    catch (Exception)
                    {

                        ok = false;
                    }

                    try
                    {
                        if (ok)
                        {
                            bool dupeOk = true;


                            for (int i = 0; i < dgvOrderDetails.Rows.Count; i++)
                            {
                                dupeOk = true;

                                string str = dgvOrderDetails.Rows[dgvOrderDetails.Rows[i].Index].Cells[6].Value.ToString();

                                if (dgvOrderDetails.Rows[dgvOrderDetails.Rows[i].Index].Cells[6].Value.Equals(ood.UpgradeID))
                                {
                                    if (MessageBox.Show("An upgrade with the selected ID already exists within this booking. Would you like to add the new quantity onto the existing order?", "Add Upgrade", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                                    {

                                        try
                                        {
                                            int noOfStock = Convert.ToInt32(dgvStock.Rows[dgvStock.SelectedRows[0].Index].Cells[3].Value);

                                            if (noOfStock >= ood.Quantity) //Checks whether there is enough stock // 
                                            {
                                                int newStock = (noOfStock - ood.Quantity);
                                                int newQty = Convert.ToInt32(dgvOrderDetails.Rows[dgvOrderDetails.Rows[i].Index].Cells[5].Value);



                                                MyUpgradeOrderDetails myUods = new MyUpgradeOrderDetails();

                                                try
                                                {
                                                    myUods.Quantity = newStock;
                                                }
                                                catch (MyException MyEx)
                                                {

                                                    throw;
                                                }

                                                //Removes Qty from database // 

                                                drAddNewUpgrade = dsDesmonds.Tables["AllStock"].Rows.Find(str);

                                                drAddNewUpgrade.BeginEdit();
                                                drAddNewUpgrade["QtyInStock"] = myUods.Quantity;

                                                drAddNewUpgrade.EndEdit();

                                                daStock.Update(dsDesmonds, "AllStock");



                                                // Adds quanitity to the existing booking //

                                                Object[] findKeys = new Object[2];
                                                findKeys[0] = lstUpgradeIDs.SelectedValue.ToString();
                                                findKeys[1] = str;

                                                drAddNewUpgrade = dsDesmonds.Tables["upgradeOrderDetails"].Rows.Find(findKeys);
                                                newQty = newQty + ood.Quantity;

                                                drAddNewUpgrade.BeginEdit();

                                                drAddNewUpgrade["Quantity"] = newQty;

                                                drAddNewUpgrade.EndEdit();

                                                daAddUpgrade.Update(dsDesmonds, "upgradeOrderDetails");



                                            }
                                            else
                                            {
                                                MessageBox.Show("Not enough items in stock to complete order!");
                                                break;
                                            }
                                        }
                                        catch (Exception)
                                        {

                                            throw;
                                        }



                                        dupeOk = false;
                                        break;
                                    }

                                }
                                else
                                {

                                }
                            }

                            // adds a new row if new item
                            if (dupeOk)
                            {
                                drAddNewUpgrade = dsDesmonds.Tables["upgradeOrderDetails"].NewRow();

                                drAddNewUpgrade["UpgradeOrderID"] = ood.UpgradeOrderID;
                                drAddNewUpgrade["UpgradeID"] = ood.UpgradeID;
                                drAddNewUpgrade["Quantity"] = ood.Quantity;
                                drAddNewUpgrade["StaffID"] = ood.StaffID;

                                try
                                {
                                    dsDesmonds.Tables["upgradeOrderDetails"].Rows.Add(drAddNewUpgrade);
                                    daAddUpgrade.Update(dsDesmonds, "upgradeOrderDetails");


                                    dgvOrderDetails.DataSource = null;


                                    fillListBoxUpgradeStock(lstCar.SelectedValue.ToString());

                                    MessageBox.Show("New upgrade added");

                                    if (MessageBox.Show("Would you like to add another Upgrade?", "Add Upgrade", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                                    {

                                    }
                                }
                                catch (ConstraintException MyEx)
                                {

                                    MessageBox.Show("Add canceled");
                                }


                            }


                        }
                    }
                    catch (MyException MyEx)
                    {

                        throw;
                    }
                }
                else
                {
                    MessageBox.Show("This part is for a different Make, please choose a part with with the Make: " + lblDisplayMakeID.Text.Trim());
                }

                btnAddItem.Text = "Begin Add";

                dgvStock.DataSource = null;
                dgvStock.DataSource = dsDesmonds.Tables["AllStock"];

                dgvOrderDetails.DataSource = null;
                dgvOrderDetails.DataSource = dsDesmonds.Tables["UpgradeStock"];



                dgvOrderDetails.Columns["btnIncreaseQty"].DisplayIndex = 5;
                dgvOrderDetails.Columns["btnIncreaseQty"].Visible = true;

                dgvOrderDetails.Columns["btnDecreaseQty"].DisplayIndex = 5;
                dgvOrderDetails.Columns["btnDecreaseQty"].Visible = true;
            }
        }

        private void btnShowReports_Click(object sender, EventArgs e)
        {
            pnlDisplayCarDetails.Hide();
            lstCar.Hide();
            lstUpgradeIDs.Hide();
        }

        private void cmbDisplaySearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtDisplaySearch.Enabled = true;
        }

        private void txtDisplaySearch_TextChanged(object sender, EventArgs e)
        {
            upgradeDataGrid();
        }

        private void upgradeDataGrid()
        {
            dgvStock.DataSource = null;
            dgvStock.Refresh();

            String tempPara = ("'%" + txtDisplaySearch.Text.ToString() + "%'");
            String tempAtt = cmbDisplaySearch.Text.ToString();

            sqlStockSearch = @"select * from upgradeStock where " + tempAtt + " like " + tempPara;
            daStockSearch = new SqlDataAdapter(sqlStockSearch, connStr);
            cmdbStockSearch = new SqlCommandBuilder(daStockSearch);
            dsDesmonds.Tables["AllStock"].Clear();
            daStockSearch.FillSchema(dsDesmonds, SchemaType.Source, "AllStock");
            daStockSearch.Fill(dsDesmonds, "AllStock");
            dgvStock.DataSource = dsDesmonds.Tables["AllStock"];

            dgvStock.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            dgvStock.Refresh();
        }

        private void lstUpgrades_Enter(object sender, EventArgs e)
        {

        }

        private void lblDisplayMakeID_TextChanged(object sender, EventArgs e)
        {
            switch (lblDisplayMakeID.Text.Trim())
            {
                case "AUD":
                    try
                    {
                        picTEST.BackgroundImage = Image.FromFile("C:/Users/sandw/Documents/GitHub/ProjectMain/BAD System/ScreenDesigns/Resources/Pictures/Audi-Logo.jpg");
                    }
                    catch (Exception)
                    {

                    }

                    try
                    {
                        picTEST.BackgroundImage = Image.FromFile("C:/Users/odo15093981/Documents/GitHub/ProjectMain/BAD System/ScreenDesigns/Resources/Pictures/Audi-Logo.jpg");
                    }
                    catch (Exception)
                    {

                    }


                    break;

                case "FIA":
                    try
                    {
                        picTEST.BackgroundImage = Image.FromFile("C:/Users/sandw/Documents/GitHub/ProjectMain/BAD System/ScreenDesigns/Resources/Pictures/Fiat_Logo_2007.png");
                    }
                    catch (Exception)
                    {

                    }

                    try
                    {
                        picTEST.BackgroundImage = Image.FromFile("C:/Users/odo15093981/Documents/GitHub/ProjectMain/BAD System/ScreenDesigns/Resources/Pictures/Fiat_Logo_2007.png");
                    }
                    catch (Exception)
                    {

                    }

                    break;

                case "FRD":

                    try
                    {
                        picTEST.BackgroundImage = Image.FromFile("C:/Users/sandw/Documents/GitHub/ProjectMain/BAD System/ScreenDesigns/Resources/Pictures/1200px-Ford_logo_flat.svg.png");
                    }
                    catch (Exception)
                    {

                    }

                    try
                    {
                        picTEST.BackgroundImage = Image.FromFile("C:/Users/odo15093981/Documents/GitHub/ProjectMain/BAD System/ScreenDesigns/Resources/Pictures/1200px-Ford_logo_flat.svg.png");
                    }
                    catch (Exception)
                    {

                    }

                    break;

                case "HON":
                    try
                    {
                        picTEST.BackgroundImage = Image.FromFile("C:/Users/sandw/Documents/GitHub/ProjectMain/BAD System/ScreenDesigns/Resources/Pictures/Honda-logo.png");

                    }
                    catch (Exception)
                    {

                    }

                    try
                    {
                        picTEST.BackgroundImage = Image.FromFile("C:/Users/odo15093981/Documents/GitHub/ProjectMain/BAD System/ScreenDesigns/Resources/Pictures/Honda-logo.png");
                    }
                    catch (Exception)
                    {

                    }

                    break;

                case "NIS":
                    try
                    {
                        picTEST.BackgroundImage = Image.FromFile("C:/Users/sandw/Documents/GitHub/ProjectMain/BAD System/ScreenDesigns/Resources/Pictures/Nissan Logo 5.png");
                    }
                    catch (Exception)
                    {

                    }

                    try
                    {
                        picTEST.BackgroundImage = Image.FromFile("C:/Users/odo15093981/Documents/GitHub/ProjectMain/BAD System/ScreenDesigns/Resources/Pictures/Nissan Logo 5.png");
                    }
                    catch (Exception)
                    {

                    }
                    break;

                case "REN":
                    try
                    {
                        picTEST.BackgroundImage = Image.FromFile("C:/Users/sandw/Documents/GitHub/ProjectMain/BAD System/ScreenDesigns/Resources/Pictures/Renault-logo-2.png");
                    }
                    catch (Exception)
                    {

                    }

                    try
                    {
                        picTEST.BackgroundImage = Image.FromFile("C:/Users/odo15093981/Documents/GitHub/ProjectMain/BAD System/ScreenDesigns/Resources/Pictures/Renault-logo-2.png");
                    }
                    catch (Exception)
                    {

                    }
                    break;

                default:
                    break;
            }
        }

        public frmEditDelUpgradeOrder()
        {
            InitializeComponent();
        }

        private void btnDisplayExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMaintenance frmMain = new frmMaintenance();
            frmMain.ShowDialog();
        }

        private void lstCar_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lstCar_MouseClick(object sender, MouseEventArgs e)
        {
            lblDisplayRegNo.Text = dsDesmonds.Tables["TCD"].Rows[lstCar.SelectedIndex][0].ToString();
            lblDisplayMakeID.Text = dsDesmonds.Tables["TCD"].Rows[lstCar.SelectedIndex][1].ToString();
            lblDisplayModel.Text = dsDesmonds.Tables["TCD"].Rows[lstCar.SelectedIndex][2].ToString();
            lblDisplaySalePrice.Text = dsDesmonds.Tables["TCD"].Rows[lstCar.SelectedIndex][3].ToString();
            lblDisplayMileage.Text = dsDesmonds.Tables["TCD"].Rows[lstCar.SelectedIndex][4].ToString();
            lblDisplayCondition.Text = dsDesmonds.Tables["TCD"].Rows[lstCar.SelectedIndex][5].ToString();

            dsDesmonds.Tables["Upgrades"].Clear();

            btnNewBooking.Enabled = true;
            btnDelBooking.Enabled = true;

            fillListBoxUpgrades(lblDisplayRegNo.Text.Trim());

        }

        private void lstUpgradeIDs_MouseClick(object sender, MouseEventArgs e)
        {


            if (lstUpgradeIDs.Items[0].Equals("This car has no upgrades on record."))
            {
                btnAddItem.Enabled = false;
                btnDeleteItem.Enabled = false;
                dgvOrderDetails.DataSource = null;
                dgvOrderDetails.Enabled = false;
            }
            else
            {
                btnAddItem.Enabled = true;
                btnDeleteItem.Enabled = true;
                dsDesmonds.Tables["UpgradeStock"].Clear();
                dgvOrderDetails.Enabled = true;
                fillListBoxUpgradeStock(lstUpgradeIDs.SelectedValue.ToString());
            }


        }

        private void fillListBoxUpgradeStock(String str)
        {
            cmdUpgradeStock.Parameters["@UpgradeOrderID"].Value = str + "%";
            daUpgradeStock.Fill(dsDesmonds, "UpgradeStock");
            dgvOrderDetails.DataSource = dsDesmonds.Tables["UpgradeStock"];

            dgvOrderDetails.Columns["btnIncreaseQty"].DisplayIndex = 5;
            dgvOrderDetails.Columns["btnIncreaseQty"].Visible = true;

            dgvOrderDetails.Columns["btnDecreaseQty"].DisplayIndex = 5;
            dgvOrderDetails.Columns["btnDecreaseQty"].Visible = true;




        }

        private void fillListBoxUpgrades(String str)
        {

            cmdUpgrades.Parameters["@RegNo"].Value = str + "%";
            daUpgrades.Fill(dsDesmonds, "Upgrades");

            if (dsDesmonds.Tables["Upgrades"].Rows.Count < 1)
            {
                lstUpgradeIDs.DataSource = null;
                lstUpgradeIDs.Items.Clear();
                lstUpgradeIDs.Items.Add("This car has no upgrades on record.");
            }
            else
            {
                // Fill listbox
                lstUpgradeIDs.DataSource = dsDesmonds.Tables["Upgrades"];
                lstUpgradeIDs.DisplayMember = dsDesmonds.Tables["Upgrades"].Columns["UpgradeOrderID"].ToString();
                lstUpgradeIDs.ValueMember = dsDesmonds.Tables["Upgrades"].Columns["UpgradeOrderID"].ToString();
            }

            if (lstUpgradeIDs.Items[0].Equals("This car has no upgrades on record."))
            {
                pnlAddItems.Visible = false;
            }


        }

        private void btnA_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;

            //get car details for listbox - use selected button letter for parameter

            String str = b.Text;

            //empty dataset table car
            dsDesmonds.Tables["TCD"].Clear();

            lstCar.Enabled = true;
            pnlDisplayCarDetails.Enabled = true;
            lstUpgradeIDs.Enabled = true;

            fillListboxCars(str);
        }

        private void fillListboxCars(String str)
        {
            cmdTCD.Parameters["@Letter"].Value = str + "%";
            daTCD.Fill(dsDesmonds, "TCD");

            // fill listbox
            lstCar.DataSource = dsDesmonds.Tables["TCD"];
            lstCar.DisplayMember = dsDesmonds.Tables["TCD"].Columns["RegNo"].ToString();
            lstCar.ValueMember = dsDesmonds.Tables["TCD"].Columns["RegNo"].ToString();

        }


    }
}

